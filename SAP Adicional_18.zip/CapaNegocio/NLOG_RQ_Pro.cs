﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

namespace CapaNegocio
{
    public class NLOG_RQ_Pro
    {

        DLOG_RQ_Pro cd = new DLOG_RQ_Pro();

        public DataTable LOG_RQ_PROVEEDOR(int rqDes, int rqHas)
        {
            return cd.LOG_RQ_PROVEEDOR(rqDes, rqHas);
        }

        public void LOG_RQ_Proveedor_Obs(int posNrq, string posCodArt, string obs)
        {
            cd.LOG_RQ_Proveedor_Obs(posNrq, posCodArt, obs);
        }
    }
}
