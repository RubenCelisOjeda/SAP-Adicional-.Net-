﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;

namespace CapaNegocio
{
    public class NLogin
    {
        DLogin dl = new DLogin();
        public void GuarCheckUsu( bool chkUsu, string Usu)
        {
             dl.GuarCheckUsu(chkUsu, Usu);
        }
        public DataTable RecUsu(string Usu)
        {
            return dl.RecUsu(Usu);
        }
        public int ValidarUsuario (string usu, string pass)
        {
            return DLogin.ValidarUsuario(usu, pass); 
        }

        public void CreateConnectionString(string Base)
        {
            DLogin.CreateConnectionString(Base);
        }

        public DataTable RecuperoBases()
        {
            return dl.RecuperoBases();
        }

        public string ConectarBases(string Base)
        {
            return dl.ConectarBases(Base);
        }

        public string RecuperaBaseSAP()
        {
            return dl.RecuperaBaseSAP();
        }

    }
}
