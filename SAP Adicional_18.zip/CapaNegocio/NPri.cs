﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Windows.Forms;

namespace CapaNegocio
{
    public class NPri
    {
        public static DataTable CargaMenu(Int32 IdMenu, ToolStripMenuItem mP, MenuStrip Menu, int CodUsuAct)
        {
            return DPri.CargarMenu(IdMenu, mP, Menu, CodUsuAct);
        }
    }
}
