﻿using CapaDatos;
using Entidades.Men_Fav;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NMenFav
    {
        DMenFav menFav = new DMenFav();
        public void MenFav_InsAct(byte Consulta, AgrMenu_Enc Enc)
        {
            menFav.MenFav_InsAct(Consulta, Enc);
        }

        public DataTable MenFav_Rec(Int16 CodUsu)
        {
            return menFav.MenFav_Rec(CodUsu);
        }
        public void MenFav_Eli(string CodMenu, Int16 CodUsu)
        {
            menFav.MenFav_Eli(CodMenu, CodUsu);
        }
        public DataTable MenFav_RecMenFav (Int16 CodUsu)
        {
            return menFav.MenFav_RecMenFav(CodUsu);
        }
    }
}
