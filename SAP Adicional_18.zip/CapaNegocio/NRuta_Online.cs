﻿using CapaDatos;
using Entidades.Ruta_Online;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace CapaNegocio
{
    public class NRuta_Online
    {
        private DRuta_Online rutOnl = new DRuta_Online();

        public DataTable Ruta_Online_RecArePro()
        {
            return rutOnl.Ruta_Online_RecArePro();
        }

        public DataTable Ruta_Online_Filtros(string vista, string procedimiento, string param)
        {
            return rutOnl.Ruta_Online_Filtros(vista,procedimiento,param);
        }

        public DataTable Ruta_Online_RecCor(DateTime Fec)
        {
            return rutOnl.Ruta_Online_RecCor(Fec);
        }

        public DataTable Ruta_Online_RecPro(DateTime fec, bool tod)
        {
            return rutOnl.Ruta_Online_RecPro(fec, tod);
        }

        public DataTable Ruta_Online_RecDis()
        {
            return rutOnl.Ruta_Online_RecDis();
        }

        public DataTable Ruta_Online_RecTrans()
        {
            return rutOnl.Ruta_Online_RecTrans();
        }

        public void Ruta_Online_ActCol( Int16 numMov, Int16 col, string valor ,Int16 estDat = 0 , bool estado = false, Int16 rq = 0)
        {
            rutOnl.Ruta_Online_ActCol(numMov, col, valor, estDat, estado,rq);
        }

        public void Ruta_Online_ActFecMod(Ruta_Online_ItemEnc item)
        {
            rutOnl.Ruta_Online_ActFecMod(item);
        }

        public Int16 Ruta_Online_RecVerMov(DateTime fec)
        {
            return rutOnl.Ruta_Online_RecVerMov(fec);
        }

        public void Ruta_Online_InsAteMon(Ruta_Online_ItemEnc item)
        {
            rutOnl.Ruta_Online_InsAteMon(item);
        }

        public void Ruta_Online_ActRutPro(Ruta_Online_ItemEnc item)
        {
            rutOnl.Ruta_Online_ActRutPro(item);
        }

        public DataTable Ruta_Online_RecProPen()
        {
            return rutOnl.Ruta_Online_RecProPen();
        }

        public DataTable Ruta_Online_RecItemEnc(int numMov)
        {
            return rutOnl.Ruta_Online_RecItemEnc(numMov);
        }

        public void Ruta_Online_ActItemEnc(Ruta_Online_ItemEnc item)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                rutOnl.Ruta_Online_ActItemEnc(item);
                scope.Complete();
            }
        }

        public DataTable Ruta_Online_RecDatTim(DateTime fecRut)
        {
            return rutOnl.Ruta_Online_RecDatTim(fecRut);
        }
    }
}
