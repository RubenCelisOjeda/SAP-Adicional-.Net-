﻿using CapaDatos;
using Entidades.DMan_ArticuloCompuesto;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace CapaNegocio
{
    public class NMan_ArticuloCompuesto
    {
        DMan_ArticuloCompuesto dm = new DMan_ArticuloCompuesto();
       
        public DataTable Man_ArticuloCompuesto_Rec()
        {
            return dm.Man_ArtCom_Rec();
        }

        public DataSet ArtCom_MovGeneral_Rec(Int16 direccion, Int16 DArticulo)
        {
            return dm.ArtCom_MovGeneral_Rec(direccion, DArticulo);
        }
        public void ArtCom_Act(string cadRut, string nomArc, int codArtCom)
        {
            dm.ArtCom_Act(cadRut, nomArc, codArtCom);
        }
        public void ArtCom_ActApl(string cadRut, int codArtCom)
        {
            dm.ArtCom_ActApl(cadRut, codArtCom);
        }
        public void ArtCom_Eli(int Cod)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                dm.ArtCom_Eli(Cod);
                scope.Complete();
            }
        }
        public void ArtCom_UpdCol(Int16 Col, ArtComMae_Enc Enc, int CodUsu = 0)
        {
            dm.ArtCom_UpdCol(Col, Enc, CodUsu);
        }
        public DataTable ArtCom_Tip_Rec()
        {
           return  dm.ArtCom_Tip_Rec();
        }
        public void ArtCom_ActGua(ArtCom_Enc Enc)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                dm.ArtCom_ActGua(Enc);
                scope.Complete();
            }
        }
        public DataTable Man_ArticulosCompuesto_Filtros(string vista, string procedimiento, string param1, int param2 = 0)
        {
            return dm.Man_ArticulosCompuesto_Filtros(vista, procedimiento, param1, param2);
        }
        public int Man_ArtCom_ValCodArt(string CodArt)
        {
            return dm.Man_ArtCom_ValCodArt(CodArt);
        }
    }
}
