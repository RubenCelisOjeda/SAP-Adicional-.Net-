﻿using CapaDatos;
using Entidades.Man_Menus;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NMan_Men
    {
        DMan_Men dm = new DMan_Men();
        public DataTable Rec_KeyNod(string keyNod)
        {
            return dm.Rec_KeyNod(keyNod);
        }

        public DataTable Rec_Menus()
        {
            return dm.Rec_Menus();
        }
        public int RecCodMen()
        {
            return dm.RecCodMen();
        }
        public void InsMen(ManMen_Enc MenEncIns)
        {
            dm.InsMen(MenEncIns);
        }
        public void EliMenu(Int16 codigo)
        {
            dm.EliMenu(codigo);
        }
        public void ActMen(ManMen_Enc MenEncAct)
        {
            dm.ActMen(MenEncAct);
        }
    }
}
