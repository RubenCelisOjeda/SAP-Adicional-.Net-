﻿using CapaDatos;
using Entidades.Man_Menus;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NMan_UsuMae
    {
        DMan_UsuMae dmUsu= new DMan_UsuMae();
        public DataTable RecUsuMae()
        {
            return dmUsu.RecUsuMae();
        }
        public DataTable RecManUsu(Int16 dir, int usu)
        {
            return dmUsu.RecManUsu(dir,usu);
        }
        public void ActGuaUsu(Man_UsuMae actGuar)
        {
            dmUsu.ActGuaUsu(actGuar);
        }
        public void EliUsu(Int16 CodEmp)
        {
            dmUsu.EliUsu(CodEmp);
        }
        public void ActUsuMae(string UsuClaAct, Int16 CodUsu,Int16 NumCol)
        {
            dmUsu.ActUsuMae(UsuClaAct, CodUsu, NumCol);
        }
    }
}
