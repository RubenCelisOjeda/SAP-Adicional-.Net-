﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;
using Entidades.VEN_CroPag;
using System.Transactions;

namespace CapaNegocio
{
    public class NVEN_CroPag
    {
        DVEN_CroPag dc = new DVEN_CroPag();

        public DataSet VEN_CroPag_Enc_rec(Int64 NumMov)
        {
            return dc.VEN_CroPag_Enc_rec(NumMov);
        }
        public DataTable VEN_CroPag_Tot_CA_OFV_ODV(string nummov)
        {
            return dc.VEN_CroPag_Tot_CA_OFV_ODV(nummov);
        }
        public DataTable VEN_CroPag_visgen(Int16 Columna, string filtro)
        {
            return dc.VEN_CroPag_visgen(Columna, filtro);
        }
        public DataTable VEN_CroPag_CotMigRQ(int NumRq, string cadnummovcot)
        {
            return dc.VEN_CroPag_CotMigRQ(NumRq, cadnummovcot);
        }

        public void VEN_CroPag_Enc_actgua(VEN_CroPag Enc)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                dc.VEN_CroPag_Enc_actgua(Enc);
                scope.Complete();
            }
        }

    }
}
