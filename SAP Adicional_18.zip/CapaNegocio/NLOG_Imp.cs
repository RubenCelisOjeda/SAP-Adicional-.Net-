﻿using CapaDatos;
using Entidades.LOG_Imp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace CapaNegocio
{
    public class NLOG_Imp
    {
        DLOG_Imp logImp = new DLOG_Imp();

        public byte GEN_For_ConAcc(Int16 CodUsu, Int16 CodDoc, string Cam, byte Acc)
        {
            return logImp.GEN_For_ConAcc(CodUsu, CodDoc, Cam, Acc);
        }
        public DataSet LOG_Imp_DetImp(Int16 NumMov)
        {
            return logImp.LOG_Imp_DetImp(NumMov);
        }
        public void Log_Imp_AnuImp(Int16 CodUsu, int NumMov)
        {
            logImp.Log_Imp_AnuImp(CodUsu, NumMov);
        }
        public void Log_Imp_ProImp(Int16 CodUsu, int NumMov)
        {
            logImp.Log_Imp_ProImp(CodUsu, NumMov);
        }
        public DataTable LOG_Imp_Filtros(string vista, string procedimiento, Int16 param2, string param)
        {
            return logImp.LOG_Imp_Filtros(vista, procedimiento, param2, param);
        }

        public void LOG_Imp_Gua_EncDet(LOG_Imp_Enc Enc)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                logImp.LOG_Imp_Gua_EncDet(Enc);
                scope.Complete();
            }
        } 
    }
}
