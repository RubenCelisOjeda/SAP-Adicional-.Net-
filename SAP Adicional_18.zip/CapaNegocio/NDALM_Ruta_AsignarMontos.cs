﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NDALM_Ruta_AsignarMontos
    {
        DALM_Ruta_AsignarMontos RutAsi = new DALM_Ruta_AsignarMontos();
        public DataTable Ruta_AsignarMontos_Rec(DateTime FecDes, DateTime FecHas)
        {
            return RutAsi.Ruta_AsignarMontos_Rec(FecDes, FecHas);
        }
        public void Ruta_AsignarMontos_GuaMon(decimal Monto, int NumMovRut)
        {
            RutAsi.Ruta_AsignarMontos_GuaMon(Monto,NumMovRut);
        }
        public DataTable Ruta_AsignarMontos_ExpSap(DateTime FDesde, DateTime FHasta)
        {
            return RutAsi.Ruta_AsignarMontos_ExpSap(FDesde, FHasta);
        }
    }
}
