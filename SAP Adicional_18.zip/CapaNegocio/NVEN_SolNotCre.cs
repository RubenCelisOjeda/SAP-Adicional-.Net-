﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;
using Entidades.VEN_SolNotCre;
using System.Transactions;


namespace CapaNegocio
{
    public class NVEN_SolNotCre
    {
        DVEN_SolNotCre cd = new DVEN_SolNotCre();

        public void VEN_SolNotCre_Est(Int64 nummov, Int32 codusu, Int16 codest, string docnumnotcre)
        {
            cd.VEN_SolNotCre_Est(nummov, codusu, codest, docnumnotcre);
        }

        public DataSet VEN_SolNotCre_rec(Int64 nummov)
        {
            return cd.VEN_SolNotCre_rec(nummov);
        }

        public DataTable VEN_SolNotCre_VisGen(Int16 val, Int32 codusu)
        {
            return cd.VEN_SolNotCre_VisGen(val, codusu);
        }

        public DataTable VEN_SolNotCre_ListDoc(Int64 RQ, short Tipo)
        {
            try
            {
                return cd.VEN_SolNotCre_ListDoc(RQ, Tipo);
            }
            catch  (Exception )
            {
                return null;
            }

        }

        public DataTable VEN_SolNotCre_DocDet(Int64 docnum)
        {
            return cd.VEN_SolNotCre_DocDet(docnum);
        }

        public void VEN_SolNotCre_ingact(VEN_SolNotCre Enc)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    cd.VEN_SolNotCre_ingact(Enc);

                    scope.Complete();
                }
            }
            catch (Exception)
            {

                throw;
            }

            
        }

    }
}
