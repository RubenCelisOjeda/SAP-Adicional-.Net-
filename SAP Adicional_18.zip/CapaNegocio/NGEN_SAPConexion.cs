﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;


namespace CapaNegocio
{
    public class NGEN_SAPConexion
    {
        DGEN_SAPConexion sap = new DGEN_SAPConexion();

        public long SAP_ValidarUsuario(string Usuario, string Password)
        {
            Int64 ResultEnum;

            ResultEnum = Convert.ToInt64(sap.SAP_ValidarUsuario(Usuario, Password));

            return ResultEnum;

        }

        public Int32 SAP_ConectarCompañia(string Usuario, string Password)
        {

            Int32 Conecta = sap.SAP_ConectarCompañia(Usuario, Password);

            return Conecta;

        }

        //public void VEN_SolNotCre_MigSAP(Int64 nummov, Int64 docnum, short tipnotcre)
        //{
        //    sap.VEN_SolNotCre_MigSAP(nummov, docnum, tipnotcre);
        //}

        //public void VEN_Cot_MigSAP(out string docentry, out string errorSAP, Int64 nummov, string empresa)
        //{
        //    sap.VEN_Cot_MigSAP(out docentry, out errorSAP, nummov, empresa);
        //}

        //public void VEN_MaeArt_ActDat(out string errorSAP, string itemcode, double lon, double anc,
        //                                double alt, double pes, string clagen,
        //                                string nomuni, string caradi)
        //{
        //    sap.VEN_MaeArt_ActDat(out errorSAP, itemcode, lon, anc, alt, pes, clagen, nomuni, caradi);
        //}

    }
}
