﻿using CapaDatos;
using Entidades.SolFac;
using System;
using System.Data;
using System.Transactions;

namespace CapaNegocio
{
    public class NSolFac
    {
        DSolFac sf = new DSolFac();
        public void VEN_SolFac_Enc_IngAct(SolFac_Enc Enc)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                sf.VEN_SolFac_Enc_IngAct(Enc);
                scope.Complete();
            }
        }

        public DataTable SBO_TRAZ_PROD(string WhsCode)
        {
            return sf.SBO_TRAZ_PROD(WhsCode);
        }

        public DataTable VEN_SolFac_ListORV(int NumRQ)
        {
            return sf.VEN_SolFac_ListORV(NumRQ);
        }

        public DataTable VEN_SolFac_DetORV(int Docnum)
        {
            return sf.VEN_SolFac_DetORV(Docnum);
        }
        public DataSet VEN_SolFac_Enc_Det_rec_(Int64 numMov)
        {
            return sf.VEN_SolFac_Enc_Det_rec_(numMov);
        }
        public int VEN_SolFac_ConAcc(int CodEmp, int Cam, byte Acc)
        {
            return sf.VEN_SolFac_ConAcc(CodEmp, Cam, Acc);
        }

        public void VEN_SolFac_Enc_Procesar(string DocNumBF, byte CodEst, DateTime FecMod, int CodUsuMod, Int64 NumMov)
        {
            sf.VEN_SolFac_Enc_Procesar(DocNumBF, CodEst, FecMod, CodUsuMod, NumMov);
        }

        public void VEN_SolFac_Enc_Anular(Int64 numMov, DateTime fecha, int codUsu)
        {
            sf.VEN_SolFac_Enc_Anular(numMov, fecha, codUsu);
        }
        public DateTime FechaDespachoOddOti(string NumDoc)
        {
             return sf.FechaDespachoOddOti(NumDoc);
        }

    }
}
