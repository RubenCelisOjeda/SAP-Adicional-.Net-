﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NArtEti
    {
        DArtEti artEti = new DArtEti();
        public DataTable ArtEti_Filtros(string vista, string procedimeinto, string param, Int16 param2)
        {
            return artEti.ArtEti_Filtros(vista,procedimeinto,param,param2);
        }
    }
}
