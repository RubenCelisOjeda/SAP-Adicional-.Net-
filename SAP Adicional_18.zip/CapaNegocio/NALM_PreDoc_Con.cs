﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NALM_PreDoc_Con
    {
        DALM_PreDoc_Con docCon = new DALM_PreDoc_Con();
        public DataTable PreDoc_Con_Filtros(string vista, string procedimiento, string param)
        {
            return docCon.PreDoc_Con_Filtros(vista,procedimiento,param);
        }
        public DataTable PreDoc_Con_Rec(byte TipPro, Int16 TipCon, DateTime FecIni, DateTime FecFin, Int16 Ruta, string Alm, bool ConSto)
        {
            return docCon.PreDoc_Con_Rec(TipPro, TipCon, FecIni,FecFin,Ruta,Alm, ConSto);
        }
    }
}
