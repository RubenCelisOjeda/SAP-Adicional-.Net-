﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

 namespace CapaNegocio
{
    public class NLOG_SegDoc2
    {
        DLOG_SegDoc2 cd = new DLOG_SegDoc2();

        public DataTable LOG_SegDoc2(DateTime fIni, DateTime fFin)
        {
            return cd.LOG_SegDoc2(fIni, fFin);
        }

        public DataTable LOG_SegDoc_Est()
        {
            return cd.LOG_SegDoc_Est();
        }

        public DataTable LOG_SegDoc_Est_(string tabla, int docnum, string est, string obs, Int16 CodUsu)
        {
            return cd.LOG_SegDoc_Est_(tabla, docnum, est, obs, CodUsu);
        }


    }
}
