﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

namespace CapaNegocio
{
    public class NVEN_CAIF
    {
        DVEN_CAIF cd = new DVEN_CAIF();

        public DataTable VEN_CAIF_Años()
        {
            return cd.VEN_CAIF_Años();
        }

        public DataTable VEN_CAIF_Metas(Int32 Año, Int16 CodTip)
        {
            return cd.VEN_CAIF_Metas(Año, CodTip);
        }

        public void VEN_CAIF_Metas_ingact(Int32 codemp, string codcenven, Int16 mes, Int32 año, Int16 codtipmet, decimal meta, Int32 codusu)
        {
            cd.VEN_CAIF_Metas_acting(codemp, codcenven, mes, año, codtipmet, meta, codusu);
        }

        public DataTable VEN_CAIF_rep(DateTime fec, Int16 tiprep, Int32 codusu)
        {
            return cd.VEN_CAIF_rep(fec, tiprep, codusu);
        }

        public DataSet VEN_CAIF_gra(Int16 tiprep, DateTime fec, Int16 tipo, Int32 codemp, string codcenven)
        {
            return cd.VEN_CAIF_gra(tiprep, fec, tipo, codemp, codcenven);
        }

        public DataTable VEN_CAIF_MetTip()
        {
            return cd.VEN_CAIF_MetTip();
        }
    }
}
