﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaNegocio
{
    public static class  NProVar
    {        

        public static void SelTex(TextBox T)
        {
            T.SelectionStart = 0;
            T.SelectionLength = T.Text.Length;
        }
    }
}
