﻿using CapaDatos;
using Entidades.LOG_InfRSV;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NLOG_InfRSV
    {
        DLOG_InfRSV InfRsv = new DLOG_InfRSV();
        public DataTable LOG_InfoRSV_RecOfv(bool MosTodOFV)
        {
            return InfRsv.LOG_InfoRSV_RecOfv(MosTodOFV);
        }
        public void LOG_InfoRSV_GuaOfv(LOG_InfRSV_Enc_Est Enc)
        {
            InfRsv.LOG_InfoRSV_GuaOfv(Enc);
        }
        public DataTable LOG_InfoRSV_RecOrd(bool MosTodOFV)
        {
            return InfRsv.LOG_InfoRSV_RecOrd(MosTodOFV);
        }
        public void LOG_InfoRSV_GuaOrd(LOG_InfRSV_Enc_Est Enc)
        {
            InfRsv.LOG_InfoRSV_GuaOrd(Enc);
        }
        public DataTable LOG_InfRSV_Filtro(string vista, string procedimiento, int param, string param2)
        {
            return InfRsv.LOG_InfRSV_Filtro(vista, procedimiento, param, param2); ;
        }
        public void LOG_InfoRSV_GuaDetPed(LOG_InfRSV_DetPed Det)
        {
            InfRsv.LOG_InfoRSV_GuaDetPed(Det);
        }
        public DataTable LOG_InfoRSV_RecDetPed(bool Tipo)
        {
            return InfRsv.LOG_InfoRSV_RecDetPed(Tipo);
        }
        public DataTable LOG_InfoRSV_RecOrdAba(bool Tipo)
        {
           return InfRsv.LOG_InfoRSV_RecOrdAba(Tipo);
        }
        public void LOG_InfoRSV_GuaOrdAba(LOG_InfRSV_Enc_OrdAba Enc)
        {
            InfRsv.LOG_InfoRSV_GuaOrdAba(Enc);
        }
        public void LOG_InfoRSV_EliDetPed(LOG_InfRSV_DetPed Det)
        {
            InfRsv.LOG_InfoRSV_EliDetPed(Det);
        }
        public void LOG_InfoRSV_EliOrdAba(LOG_InfRSV_Enc_OrdAba Enc)
        {
            InfRsv.LOG_InfoRSV_EliOrdAba(Enc);
        }
    }
}
