﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NCam_Contra
    {
        DCam_Contra camCon = new DCam_Contra();
        public DataTable Rec_UsuarioEmpleado(Int16 CodUsu)
        {
            return camCon.Rec_UsuarioEmpleado(CodUsu);
        }
        public void Act_UsuarioClave(Int16 CodUsu,string Clave)
        {
            camCon.Act_UsuarioClave(CodUsu, Clave);
        }
        public bool Val_UsuarioClave(int codUsu, string clave, bool res)
        {
            return camCon.Val_UsuarioClave(codUsu, clave, res);
        }

    }
}
