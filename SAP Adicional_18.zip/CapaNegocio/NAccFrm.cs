﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NAccFrm
    {
        private DAccFrm accFrm = new DAccFrm();

        public DataTable Acc_Frm_RecFrmUsu(int CodUsuAct)
        {
            return accFrm.Acc_Frm_RecFrmUsu(CodUsuAct);
        }
        public DataTable AccFrm_Filtros(string vista, string procedimiento, string param1,int CodUsu)
        {
            return accFrm.AccFrm_Filtros(vista,procedimiento,param1, CodUsu);
        }
        public void AccFrm_InsUsu(int CodUsu, int CodDoc)
        {
            accFrm.AccFrm_InsUsu(CodUsu, CodDoc);
        }
        public void AccFrm_UpdAccUsu(int CodUsu, int CodDoc, string Campo, bool Check)
        {
            accFrm.AccFrm_UpdAccUsu(CodUsu, CodDoc, Campo, Check);
        }
        public DataTable AccFrm_RecUsuEmp(int CodUsuOcu)
        {
            return accFrm.AccFrm_RecUsuEmp(CodUsuOcu);
        }

        public void AccFrm_CopDocUsu(int CodUsuOri, int CodUsuDes)
        {
            accFrm.AccFrm_CopDocUsu(CodUsuOri, CodUsuDes);
        }
    }
}
