﻿using CapaDatos;
using Entidades.ALM_Ubi_ConStock;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NALM_Ubi_ConStock
    {
        DALM_Ubi_ConStock ubiSto = new DALM_Ubi_ConStock();

        public DataTable ALM_Ubi_ConStock_Filtros(string vista, string procedimiento, 
                                                  string param, Int16 Param2 = 0)
        {
            return ubiSto.ALM_Ubi_ConStock_Filtros(vista, procedimiento, param, Param2);
        }

        public DataTable ALM_Ubi_ConStock_MosMovDia(DateTime FecDes, DateTime FecHas, string CodAlm, 
                                                                            Int16 Tip, string CodArt)
        {
            return ubiSto.ALM_Ubi_ConStock_MosMovDia(FecDes, FecHas, CodAlm, Tip, CodArt);
        }

        public DataTable ALM_Ubi_ConStock_ValUbi(Int16 Res, string CodAlm, string Zona, string Rack, 
                                                                  string Col, string Fila, char Tipo)
        {
            return ubiSto.ALM_Ubi_ConStock_ValUbi(Res,CodAlm,Zona,Rack,Col,Fila,Tipo);
        }

        public DataTable ALM_Ubi_ConStock_RecComStock(Int16 Index)
        {
            return ubiSto.ALM_Ubi_ConStock_RecComStock(Index);
        }

        public DataTable ALM_Ubi_ConStock_RecMovDia(DateTime FDes, DateTime FHas, string CodAlm, 
                                                                        byte Tip, string CodArt)

        {
            return ubiSto.ALM_Ubi_ConStock_RecMovDia(FDes, FHas, CodAlm, Tip, CodArt);
        }

        public string ALM_Ubi_ConStock_StoAlm(string CodAlm, string CodArt)
        {
            return ubiSto.ALM_Ubi_ConStock_StoAlm(CodAlm, CodArt);
        }

        public string ALM_Ubi_ConStock_StoUniSapAdi(string CodArt, string Zon, string Rac, string Col, 
                                                                            string Fil, string CodAlm)

        {
            return ubiSto.ALM_Ubi_ConStock_StoUniSapAdi(CodArt, Zon, Rac, Col, Fil, CodAlm);
        }

        public void ALM_Ubi_ConStock_ValMovStkFin(ALM_Ubi_ConStock_Enc Ubi)
        {
            ubiSto.ALM_Ubi_ConStock_ValMovStkFin(Ubi);
        }

        public void ALM_Ubi_ConStock_InsMov(ALM_Ubi_ConStock_Enc Ubi)
        {
            ubiSto.ALM_Ubi_ConStock_InsMov(Ubi);
        }

        public void ALM_Ubi_ConStock_EliArt(int codUsu, DateTime fecMod, int numMov)
        {
            ubiSto.ALM_Ubi_ConStock_EliArt(codUsu, fecMod, numMov);
        }

        public DataTable ALM_Ubi_ConStock_RecTipArt(Int16 tipInd)
        {
            return ubiSto.ALM_Ubi_ConStock_RecTipArt(tipInd);
        }

        public DataTable ALM_Ubi_ConStock_RecUbi()
        {
            return ubiSto.ALM_Ubi_ConStock_RecUbi();
        }

        public void ALM_Ubi_ConStock_ActCantCom(int? numMov, decimal? cantCom)
        {
            ubiSto.ALM_Ubi_ConStock_ActCantCom(numMov, cantCom);
        }
    }
}
