﻿using CapaDatos;
using Entidades.Man_Contactos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NMan_Contactos
    {
        private DMan_Contactos manCon = new DMan_Contactos();

        public DataTable Man_Contactos_RecDis()
        {
            return manCon.Man_Contactos_RecDis();
        }

        public DataTable Man_Contactos_RecPro()
        {
            return manCon.Man_Contactos_RecPro();
        }

        public DataTable Man_Contactos_RecRes()
        {
            return manCon.Man_Contactos_RecRes();
        }

        public DataTable Man_Contactos_RecTipCon()
        {
            return manCon.Man_Contactos_RecTipCon();
        }

        public DataTable Man_Contactos_RecCat()
        {
            return manCon.Man_Contactos_RecCat();
        }

        public void Man_Contactos_UpdCampo(int codCon, string campo, string valor)
        {
            manCon.Man_Contactos_UpdCampo(codCon, campo, valor);
        }

        public void Man_Contactos_UpdGuaCon(Man_Contactos_Enc con)
        {
            manCon.Man_Contactos_UpdGuaCon(con);
        }

        public DataTable Man_Contactos_RecDatRecom(Int16 dir, int usu)
        {
            return manCon.Man_Contactos_RecDatRecom(dir, usu);
        }

        public DataTable Man_Contactos_Filtro(string vista, string procedimiento, string prm)
        {
            return manCon.Man_Contactos_Filtro(vista, procedimiento, prm);
        }

        public void Man_Contactos_EliRecom(int codCon)
        {
            manCon.Man_Contactos_EliRecom(codCon);
        }

        public int Man_Contactos_ValCodCon(int codCon)
        {
            return manCon.Man_Contactos_ValCodCon(codCon);
        }

        public DataTable Man_Contactos_FilRecom(Int16 col, string filtro)
        {
            return manCon.Man_Contactos_FilRecom(col, filtro);
        }
    }
}
