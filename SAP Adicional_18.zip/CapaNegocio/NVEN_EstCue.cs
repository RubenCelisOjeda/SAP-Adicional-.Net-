﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;
using Entidades.VEN_EstCue;

namespace CapaNegocio
{
    public class NVEN_EstCue
    {
        DVEN_EstCue cd = new DVEN_EstCue();

        public DataTable VEN_EstCue_OpcOri(Byte origen, int rq)
        {
            return cd.VEN_EstCue_OpcOri(origen, rq);
        }

        public void VEN_EstCue_Docs(VEN_EstCue EstCue, Int32 CodUsu)
        {
            cd.VEN_EstCue_Docs(EstCue, CodUsu);
        }
    }
}
