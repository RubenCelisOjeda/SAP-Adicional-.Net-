﻿using CapaDatos;
using Entidades.Men_Acc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace CapaNegocio
{
    public class NMen_Acc
    {
        DMen_Acc dm = new DMen_Acc();

        public DataTable Men_Acc_Filtros(string vista, string procedimiento, string param1)
        {
            return dm.Men_Acc_Filtros(vista, procedimiento,param1);
        }

        public DataTable RecMenUsu(Int16 CodUsu, Int16 valor)
        {
            return dm.RecMenUsu(CodUsu, valor);
        }
        public DataTable RecKeyNod(string KeyNod)
        {
            return dm.RecKeyNod(KeyNod);
        }
        public void MenAccInsEli(MenuAcc_Enc MenAccIns, int NodChe)
        {
            dm.MenAccInsEli(MenAccIns, NodChe);
        }
        public void Men_Accesos_CopiarAccesos(MenuAcc_Enc Enc)
        {
            dm.Men_Accesos_CopiarAccesos(Enc);
        }
        public int Men_Accesos_ValNod(int CodUsu, string NotSup)
        {
            return dm.Men_Accesos_ValNod(CodUsu, NotSup);
        }
    }
}
