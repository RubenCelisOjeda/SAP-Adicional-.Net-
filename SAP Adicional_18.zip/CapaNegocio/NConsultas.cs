﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Data.SqlClient;

namespace CapaNegocio
{
    public class NConsultas
    {
        DConsultas cd = new DConsultas();

        public bool Seguridad_ValPass(Int16 codUsu, string pass)
        {
            return cd.Seguridad_ValPass(codUsu, pass);
        }
        public DataTable LOG_rep_InfRSV_RecInfRes(Int16 val)
        {
            return cd.LOG_rep_InfRSV_RecInfRes(val);
        }

        public DataTable RANKING_DE_RECOMENDADORES_POR_PERIODOS(DateTime fecIni, DateTime fecFin)
        {
            return cd.RANKING_DE_RECOMENDADORES_POR_PERIODOS(fecIni, fecFin);
        }
        public bool ValRqGenSap(string rq, string baseSap)
        {
            return cd.ValRqGenSap(rq, baseSap);
        }
        public bool ValCodArtGenSap(string CodArtSap,string BaseSAP)
        {
            return cd.ValCodArtGenSap(CodArtSap, BaseSAP);
        }

        public DataTable LOG_Imp_AbrRec(short Col, string Filtro)
        {
            return cd.LOG_Imp_AbrRec(Col, Filtro);
        }
        public DataTable ALM_Inventario_AbrirRec(short Col, string Filtro)
        {
            return cd.ALM_Inventario_AbrirRec(Col,Filtro);
        }
        public DataTable Ruta_Item_RecRqInf(int Rq)
        {
            return cd.Ruta_Item_RecRqInf(Rq);
        }
        public DataTable Ruta_Item_ListarRQ(short Col, string Filtro)
        {
            return cd.Ruta_Item_ListarRQ(Col, Filtro);
        }

        public DataTable DocumentoTipoRec(Int16 CodTip)
        {
            return cd.DocumentoTipoRec(CodTip);
        }
     
        public DataTable Ruta_Item_VisGen(short Col, string Filtro)
        {
           return cd.Ruta_Item_VisGen(Col, Filtro);
        }

        public DataTable ven_cueporcob_cat()
        {
            return cd.ven_cueporcob_cat();
        }

        public DataTable ven_cueporcob(DateTime param1, DateTime param2)
        {
            return cd.ven_cueporcob( param1, param2);
        }

        public DataTable RecuperaInfoRQ(string vista, string procedimiento, int param1, string param2)
        {
            return cd.RecuperaInfoRQ(vista, procedimiento, param1, param2);
        }

        public DataTable VEN_CudreRQ(Int64 rq)
        {
            return cd.VEN_CuadreRQ(rq);            
        }

        public DataTable VEN_RQ_info(int rq)
        {
            return cd.VEN_RQ_info(rq);
        }

        public DataTable VEN_Cot_Filtros(string vista, string procedimiento, string param1, string param2, string param3, string param4, string param5)
        {
            return cd.VEN_Cot_Filtros(vista, procedimiento, param1, param2, param3, param4, param5);
        }

        public DataTable OPE_Pro_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            return cd.OPE_Pro_Filtros(vista, procedimiento, param1, param2);
        }

        public DataTable LOG_OFC_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            return cd.LOG_OFC_Filtros(vista, procedimiento, param1, param2);
        }

        public decimal IGV_Recuperar(DateTime Fecha)
        {
            return cd.IGV_Recuperar(Fecha);
        }

        public decimal TipoCambio_Recuperar(DateTime Fecha)
        {
            return cd.TipoCambio_Recuperar(Fecha);
        }

        public string FechaServidor()
        {
            return cd.FechaServidor();
        }

        public DataTable VEN_RQ_Doc(int rq, int tipo)
        {
            return cd.VEN_RQ_Doc(rq, tipo);
        }

        public DataTable VEN_rep_Ing(DateTime fecini, DateTime fecfin)
        {
            return cd.VEN_rep_Ing(fecini, fecfin);
        }

        public DataTable VEN_rep_CotApr(DateTime FDesde, DateTime FHasta)
        {
            return cd.VEN_rep_CotApr(FDesde, FHasta);
        }

        public DataTable VEN_rep_CotAprCol()
        {
            return cd.VEN_rep_CotAprCol();
        }

        public DataTable VEN_rep_Fac(DateTime FDesde, DateTime FHasta)
        {
            return cd.VEN_rep_Fac(FDesde, FHasta);
        }

        public DataTable LOG_Alm_ArtSto(int CodUsu, string filtro, Byte valor, bool tipo)
        {
            return cd.LOG_Alm_ArtSto(CodUsu, filtro, valor, tipo);
        }

        public DataTable OPE_OFVAprSerInsPro(Int16 valor)
        {
            return cd.OPE_OFVAprSerInsPro(valor);
        }

        public void OPE_OFVApr_dat_acting(Int16 codrep, Int64 numdoc, string codart, string est, string obs, Int32 codusu, bool sel)
        {
            cd.OPE_OFVApr_dat_acting(codrep, numdoc, codart, est, obs, codusu, sel);
        }

        public DataTable OPE_ODVAprSerInsPro(Int16 valor)
        {
            return cd.OPE_ODVAprSerInsPro(valor);
        }

        public DataTable OPE_OFVAprSerSupDis(Int16 valor)
        {
            return cd.OPE_OFVAprSerSupDis(valor);
        }

        public DataTable OPE_ODVAprSerSupDis(Int16 valor)
        {
            return cd.OPE_ODVAprSerSupDis(valor);
        }

        public DataTable LOG_rep_Ing(DateTime fIni, DateTime fFin)
        {
            return cd.LOG_rep_Ing(fIni, fFin);
        }

        public DataTable ALM_rep_SolTra_Stock(DateTime fIni, DateTime fFin)
        {
            return cd.ALM_rep_SolTra_Stock(fIni, fFin);
        }

        public DataSet VEN_rep_CroPag(DateTime fIni, DateTime fFin)
        {
            return cd.VEN_rep_CroPag(fIni, fFin);
        }

        public DataTable ALM_rep_DocPenDes()
        {
            return cd.ALM_rep_DocPenDes();
        }

        public DataTable TRZ_ALM_ConPro(DateTime fIni, DateTime fFin)
        {
            return cd.TRZ_ALM_ConPro(fIni, fFin);
        }

        public DataTable VEN_rep_AdmRQ(Int16 Valor)
        {
            return cd.VEN_rep_AdmRQ(Valor);
        }

        public DataTable ALM_MovIngxEnc_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            return cd.ALM_MovIngxEnc_Filtros(vista, procedimiento, param1, param2);
        }

        public DataTable ALM_MovIng_EncAlm(int CodEnc, DateTime FDesde, DateTime FHasta)
        {
            return cd.ALM_MovIng_EncAlm(CodEnc, FDesde, FHasta);
        }

        public byte GEN_AccByDoc(Int32 codEmp, Int16 codDoc, string campo, byte acc)
        {
            return cd.GEN_AccByDoc(codEmp, codDoc, campo, acc);
        }

        public DataTable VEN_rep_DesOtoxVen(DateTime fecini, DateTime fecfin)
        {
            return cd.VEN_rep_DesOtoxVen(fecini, fecfin);
        }

        public DataTable VEN_Cot_visgen(Int16 col, string filtro)
        {
            return cd.VEN_Cot_visgen(col, filtro);
        }

        public bool Validar_CodArtCom(Int64 CodArtCom)
        {
            return cd.Validar_CodArtCom(CodArtCom);
        }

        public bool Validar_CodArt(string CodArt, string BaseSAP)
        {
            return cd.Validar_CodArt(CodArt, BaseSAP);
        }

        public DataTable ALM_repDis_TipRutVen(string procedimiento, DateTime fecini, DateTime fecfin)
        {
            return cd.ALM_repDis_TipRutVen(procedimiento, fecini, fecfin);
        }

        public DataTable LOG_SegDoc(DateTime FInicial, DateTime FFinal)
        {
            return cd.LOG_SegDoc(FFinal, FFinal);
        }

        public DataTable ALM_Ubi_PorCrear()
        {
            return cd.ALM_Ubi_PorCrear();
        }

        public DataTable LOG_RQ_Rango(int RqInicial, int RqFinal)
        {
            return cd.LOG_RQ_Rango(RqInicial, RqFinal);
        }

        public DataTable LOG_RQ_Rango_Detalle(int RqInicial, int RqFinal)
        {
            return cd.LOG_RQ_Rango_Detalle(RqInicial, RqFinal);
        }

        public DataTable ALM_AlmArt_Stock_Filtros(string vista, string procedimiento, string param1)
        {
            return cd.ALM_AlmArt_Stock_Filtros(vista, procedimiento, param1);
        }

        public DataTable ALM_rep_AccAlm(byte tipo, Int16 CodUsuAre, string CodAlm)
        {
            return cd.ALM_rep_AccAlm(tipo, CodUsuAre, CodAlm);
        }

        public void ALM_rep_AlmArt_AccAlm_InsDel(string CodAlm, Int16 CodUsuAre, byte Ind, bool InsDel)
        {
            cd.ALM_rep_AlmArt_AccAlm_InsDel(CodAlm, CodUsuAre, Ind, InsDel);
        }

        public DataTable VEN_Cot_SeleccionarRQ(string codcli, Int64 rq, short tipo)
        {
            return cd.VEN_Cot_SeleccionarRQ(codcli, rq, tipo);
        }

        public DataTable LOG_MaeArt_ActDat_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            return cd.LOG_MaeArt_ActDat_Filtros(vista, procedimiento, param1, param2);
        }
    }
}

