﻿using CapaDatos;
using Entidades.Ruta_Corte;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NRuta_Corte
    {
        DRuta_Corte rutCor = new DRuta_Corte();
        public DataTable Ruta_Corte_RecCorPed()
        {
            return rutCor.Ruta_Corte_RecCorPed();
        }
        public DataTable Ruta_Corte_Filtros(string vista, string procedimiento, string param1)
        {
            return rutCor.Ruta_Corte_Filtros(vista,procedimiento,param1);
        }
        public void Ruta_Corte_InsCorPed(Ruta_Corte_Enc Enc)
        {
            rutCor.Ruta_Corte_InsCorPed(Enc);
        }
        public void Ruta_Corte_EliCorPed(Int16 CodCorPed, DateTime FecCor)
        {
            rutCor.Ruta_Corte_EliCorPed(CodCorPed, FecCor);
        }
    }
}
