﻿using CapaDatos;
using Entidades.Ruta_Item;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NRuta_Item
    {
        DRuta_Item rutIte = new DRuta_Item();

        public void Ruta_ItemDocRel_Eliminar(int NumMovRut, Int16 TipDoc, int NumDoc)
        {
            rutIte.Ruta_ItemDocRel_Eliminar(NumMovRut,TipDoc,NumDoc);
        }
        public void Ruta_ItemDocRel_Guardar(Ruta_Item_Enc DocRel)
        {
            rutIte.Ruta_ItemDocRel_Guardar(DocRel);
        }
        public void Ruta_Item_Eliminar(Int32 NumMov)
        {
            rutIte.Ruta_Item_Eliminar(NumMov);
        }
        public void Ruta_Item_GuardarActualizar(Ruta_Item_Enc Enc)
        {
            rutIte.Ruta_Item_GuardarActualizar(Enc);
        }
        public int Ruta_Item_CorPed(Int16 CodCorPed, DateTime Fec)
        {
            return rutIte.Ruta_Item_CorPed(CodCorPed,Fec);
        }
        public bool Ruta_Item_AccTipVen(string CodTipVen, Int16 CodUsuAre)
        {
            return rutIte.Ruta_Item_AccTipVen(CodTipVen, CodUsuAre);
        }
        public DataTable Ruta_Item_Filtros(string vista, string procedimiento, string param,string param2="")
        {
            return rutIte.Ruta_Item_Filtros(vista,procedimiento,param, param2);
        }
        public DataTable Ruta_Item_RecDocRel(int NumMov)
        {
            return rutIte.Ruta_Item_RecDocRel(NumMov);
        }
        public DataTable Ruta_Item_RecEnc(int NumMov)
        {
            return rutIte.Ruta_Item_RecEnc(NumMov);
        }
    }
}

