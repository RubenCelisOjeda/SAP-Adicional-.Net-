﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Data.SqlClient;
using Entidades.OPE_Pro;
using System.Transactions;

namespace CapaNegocio
{
    public class NOPE_Pro
    {
        DOPE_Pro cd = new DOPE_Pro();

        public DataTable OPE_Pro_VisGen(bool VisDet)
        {
            return cd.OPE_Pro_VisGen(VisDet);
        }

        public void OPE_Pro_InsertarEditar(OPE_Pro Enc)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                cd.OPE_Pro_InsertarEditar(Enc);

                scope.Complete();
            }                
        }

        public DataTable OPE_Pro_VisGen_Filtro(string filtro, bool VisDet)
        {

            return cd.OPE_Pro_VisGen_Filtro(filtro, VisDet);

        }

        public DataSet OPE_Pro_rec(int nummov)
        {
            return cd.OPE_Pro_rec(nummov);
        }


        public DataSet OPE_Pro_rec2(int nummov, Int32 codusu)
        {
            return cd.OPE_Pro_rec2(nummov, codusu);
        }


        public void OPE_Pro_Det1(OPE_Pro Enc)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                cd.OPE_Pro_Det1_ingact(Enc);

                scope.Complete();
            }
        }

        public void OPE_Pro_Est(Int64 nummov, Int32 codusu, Int16 codest)
        {
            cd.OPE_Pro_Est(nummov, codusu, codest);
        }

        public void OPE_Pro_ActFecAprIns(Int64 nummov, Int32 codusu, DateTime fecaprins, Int64 rq)
        {
            cd.OPE_Pro_ActFecAprIns(nummov, codusu, fecaprins, rq);
        }
    }
}
