﻿using CapaDatos;
using Entidades.CON_CuePorCob;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class NCON_CuePorCob
    {
        DCON_CuePorCob dc = new DCON_CuePorCob();

        public DataTable CON_CuePorCob_Clear()
        {
            return dc.Con_Cueporcob_Clear();
        }
        public DataTable CON_CuePorCob_CatSeg(Int16 codcat)
        {
            return dc.CON_CuePorCob_CatSeg(codcat);
        }
        public DataTable CON_CuePorCob_CatEst(Int16 codcat)
        {
            return dc.CON_CuePorCob_CatEst(codcat);
        }

        public DataTable CON_CuePorCob(DateTime fDesde, DateTime fHasta, int tipo)
        {
            return dc.CON_CuePorCob(fDesde, fHasta, tipo);
        }
        public DataTable CON_CuePorCob_cat()
        {
            return dc.CON_CuePorCob_cat();
        }
        public DataTable CON_CuePorCob_Enc()
        {
            return dc.CON_CuePorCob_Enc();
        }

        public void CON_CuePorCob_Col_actval(CON_CuePorCob_Col_actval Enc)
        {
            dc.CON_CuePorCob_Col_actval(Enc);
        }
    }
}
