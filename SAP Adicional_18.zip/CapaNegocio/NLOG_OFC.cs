﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CapaDatos;
using Entidades.LOG_OFC;
using System.Transactions;

namespace CapaNegocio
{
    public class NLOG_OFC
    {
        DLOG_OFC cd = new DLOG_OFC();

        public DataSet LOG_OFC_rec(Int64 nummov)
        {
            return cd.LOG_OFC_rec(nummov);
        }

        public DataTable LOG_OFC_VisGen(Int16 val)
        {
            return cd.LOG_OFC_VisGen(val);
        }

        public void LOG_OFC_ingact(LOG_OFC Enc)
        {
            using(TransactionScope scope = new TransactionScope())
            {
                cd.LOG_OFC_ingact(Enc);

                scope.Complete();
            }
        }
    }
}
