﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos;
using System.Data;
using System.Data.SqlClient;
using Entidades.VEN_Cot;
using System.Transactions;

namespace CapaNegocio
{
    public class NVEN_Cot
    {
        DVEN_Cot cd = new DVEN_Cot();

        public DataTable VEN_Cot_ArtComMosCom(int codcom, string moneda, string tipoventa)
        {
            return cd.VEN_Cot_ArtComMosCom(codcom, moneda, tipoventa);
        }

        public DataTable VEN_Cot_Stock(string codart)
        {
            return cd.VEN_Cot_Stock(codart);
        }

        public DataTable VEN_Cot_Art(string filtro, string moneda, string tipoventa)
        {
            return cd.VEN_Cot_Art(filtro, moneda, tipoventa);
        }

        public byte VEN_Cot_CodTipArtCom(Int32 CodArtCom)
        {
            return cd.VEN_Cot_CodTipArtCom(CodArtCom);
        }

        public decimal VEN_Cot_RecTipCam()
        {
            return cd.VEN_Cot_RecTipCam();
        }
        
        public Int16 VEN_Cot_CodGruArt(string CodArt)
        {
            return cd.VEN_Cot_CodGruArt(CodArt);
        }

        public void VEN_Cot_ingact(VEN_Cot Enc, Int64 NumMovCotOri)
        {
            using(TransactionScope scope = new TransactionScope())
            {
                cd.VEN_Cot_ingact(Enc, NumMovCotOri);

                scope.Complete();
            }
        }

        public Int16 VEN_Cot_ValCenVen(Int32 codemp, string codcenven)
        {
            return cd.VEN_Cot_ValCenVen(codemp, codcenven);
        }

        public Int16 VEN_Cot_ValInfRec(string codcenven, Int16 tip, Int16 cod, Int16 codret)
        {
            return cd.VEN_Cot_ValInfRec(codcenven, tip, cod, codret);
        }

        public DataTable VEN_Cot_ValTipVenyOtr(Int16 Tipo, string TipVen, string TipVenRel, string Rubro, string TipObr, string Dim)
        {
            return cd.VEN_Cot_ValTipVenyOtr(Tipo, TipVen, TipVenRel, Rubro, TipObr, Dim);
        }

        public string VEN_Cot_RecNomAdi(Int64 nummov)
        {
            return cd.VEN_Cot_RecNomAdi(nummov);
        }

        public DataSet VEN_Cot_rec(Int64 nummov)
        {
            return cd.VEN_Cot_rec(nummov);
        }

        public DataTable VEN_Cot_Amb_orden(Int64 nummov)
        {
            return cd.VEN_Cot_Amb_orden(nummov);
        }

        public decimal VEN_Cot_ConPreVen(Int64 nummov, string codart, string codmon )
        {
            return cd.VEN_Cot_ConPreVen(nummov, codart, codmon);
        }

        public bool VEN_Cot_Validar_UsuApr(Int32 codusu)
        {
            return cd.VEN_Cot_Validar_UsuApr(codusu);
        }

        public void VEN_Cot_ActCotApr(Int64 nummov, Int32 codusu)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                cd.VEN_Cot_ActCotApr(nummov, codusu);

                scope.Complete();
            }
        }

        public DataTable VEN_Cot_RecValCotMig(Int64 docentry)
        {
            return cd.VEN_Cot_RecValCotMig(docentry);
        }

        public void VEN_Cot_ActCotMig(Int32 codadmrq, Int32 codusu, Int32 rq, Int64 docentry,  Int64 docnum,  Int64 nummov)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                cd.VEN_Cot_ActCotMig(codadmrq, codusu, rq, docentry, docnum,  nummov);
                scope.Complete();
            }
        }

        public DataTable VEN_Cot_ValImp(Int64 nummov)
        {
            return cd.VEN_Cot_ValImp(nummov);
        }

        public DataTable VEN_Cot_ValImpAmb(Int64 nummov)
        {
            return cd.VEN_Cot_ValImpAmb(nummov);
        }

        public void VEN_Cot_AmbOrden(VEN_Cot_AmbOrd AmbOrd)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                cd.VEN_Cot_AmbOrden(AmbOrd);

                scope.Complete();
            }
        }

        public void VEN_Cot_ValImpCon(Int64 nummov, Int16 ade, Int16 conent, string con01, string con02, Int32 codusu)
        {
            using (TransactionScope scope = new TransactionScope())
            {
                cd.VEN_Cot_ValImpCon(nummov, ade, conent, con01, con02, codusu);

                scope.Complete();
            }
        }

        public decimal VEN_Cot_NivDes(Int32 codusu)
        {
            return cd.VEN_Cot_NivDes(codusu);
        }

        public decimal VEN_Cot_NivDesArtCom(Int32 codartcom)
        {
            return cd.VEN_Cot_NivDesArtCom(codartcom);
        }

        public decimal VEN_CotDetAS_Cos(string codart, string moneda)
        {
            return cd.VEN_CotDetAS_Cos(codart, moneda);
        }
    }
}
