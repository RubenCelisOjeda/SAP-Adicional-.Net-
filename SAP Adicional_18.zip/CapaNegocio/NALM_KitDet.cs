﻿using CapaDatos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public  class NALM_KitDet
    {
        DALM_KitDet KitDet = new DALM_KitDet();
        public DataTable Rec_AlmKitDet()
        {
            return KitDet.Rec_AlmKitDet();
        }
    }
}
