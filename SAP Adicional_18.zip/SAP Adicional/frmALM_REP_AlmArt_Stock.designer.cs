﻿namespace SAP_Adicional
{
    partial class frmALM_REP_AlmArt_Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnExp = new System.Windows.Forms.Button();
            this.btnMos = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblFil = new System.Windows.Forms.Label();
            this.txtFil = new System.Windows.Forms.TextBox();
            this.chkSinStock = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv
            // 
            this.dgv.AllowFiltering = true;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.dgv.Location = new System.Drawing.Point(12, 41);
            this.dgv.Name = "dgv";
            this.dgv.Rows.DefaultSize = 19;
            this.dgv.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.dgv.Size = new System.Drawing.Size(1249, 485);
            this.dgv.TabIndex = 0;
            this.dgv.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.dgv_BeforeSort);
            this.dgv.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.dgv_KeyPressEdit);
            this.dgv.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.dgv_AfterDataRefresh);
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(967, 12);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(111, 23);
            this.btnExp.TabIndex = 2;
            this.btnExp.Text = "Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // btnMos
            // 
            this.btnMos.Location = new System.Drawing.Point(858, 12);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(111, 23);
            this.btnMos.TabIndex = 1;
            this.btnMos.Text = "Mostrar/Actualizar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(13, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Filtro:";
            // 
            // lblFil
            // 
            this.lblFil.BackColor = System.Drawing.Color.DimGray;
            this.lblFil.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFil.ForeColor = System.Drawing.Color.White;
            this.lblFil.Location = new System.Drawing.Point(60, 14);
            this.lblFil.Name = "lblFil";
            this.lblFil.Size = new System.Drawing.Size(165, 20);
            this.lblFil.TabIndex = 18;
            this.lblFil.Text = "CODIGO";
            this.lblFil.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtFil
            // 
            this.txtFil.Location = new System.Drawing.Point(225, 14);
            this.txtFil.Name = "txtFil";
            this.txtFil.Size = new System.Drawing.Size(514, 21);
            this.txtFil.TabIndex = 0;
            this.txtFil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFil_KeyPress);
            // 
            // chkSinStock
            // 
            this.chkSinStock.AutoSize = true;
            this.chkSinStock.Location = new System.Drawing.Point(744, 17);
            this.chkSinStock.Name = "chkSinStock";
            this.chkSinStock.Size = new System.Drawing.Size(111, 17);
            this.chkSinStock.TabIndex = 19;
            this.chkSinStock.Text = "Articulos sin stock";
            this.chkSinStock.UseVisualStyleBackColor = true;
            // 
            // frmALM_REP_AlmArt_Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1273, 538);
            this.Controls.Add(this.chkSinStock);
            this.Controls.Add(this.txtFil);
            this.Controls.Add(this.lblFil);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.btnMos);
            this.Controls.Add(this.dgv);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_REP_AlmArt_Stock";
            this.Text = "Stock Almacenes";
            this.Load += new System.EventHandler(this.frmALM_REP_AlmArt_Stock_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private C1.Win.C1FlexGrid.C1FlexGrid dgv;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblFil;
        private System.Windows.Forms.TextBox txtFil;
        private System.Windows.Forms.CheckBox chkSinStock;
    }
}