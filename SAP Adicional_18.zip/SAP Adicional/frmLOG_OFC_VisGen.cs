﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace SAP_Adicional
{
    public partial class frmLOG_OFC_VisGen : Form
    {

        NLOG_OFC nsnc = new NLOG_OFC();
        //int TipoColumna;
        DataView dv = new DataView();

        public frmLOG_OFC_VisGen()
        {
            InitializeComponent();
        }

        private void frmOPE_Pro_VisGen_Load(object sender, EventArgs e)
        {
            MosAct();           
        }

        private void MosAct()        
        {
            dgv.Columns.Clear();
            dv = nsnc.LOG_OFC_VisGen(Convert.ToInt16(this.chkMosTod.Checked)).DefaultView;

            this.dgv.DataSource = dv;

        }

        private void dgv_formato()
        {            
            dgv.RowHeadersVisible = false;
            dgv.Font = new Font("Tahoma", 7);

            dgv.Columns[0].Visible = false;
            dgv.Columns[1].Width = 80; //NumOFC
            dgv.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.Columns[2].Width = 80; //FEc. Emision
            dgv.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.Columns[3].Width = 250; //Tipo OFC
            dgv.Columns[4].Width = 250; //Tipo Servicio
            dgv.Columns[5].Width = 40; //Moneda
            dgv.Columns[6].Width = 70; //Estado
            dgv.Columns[7].Width = 100; //Creado Por
            dgv.Columns[8].Width = 150; //Modificado por
            dgv.Columns[9].Width = 100; //Fec. Ult. Mod.            
    }

        private void dgv_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //if(dgv.Columns[e.ColumnIndex].ValueType == typeof(decimal) ||
            //    dgv.Columns[e.ColumnIndex].ValueType == typeof(Int16) ||
            //    dgv.Columns[e.ColumnIndex].ValueType == typeof(Int32) ||
            //    dgv.Columns[e.ColumnIndex].ValueType == typeof(Int64))
            //{//Si es numerico es 1
            //    TipoColumna = 1;
            //}

            //if (dgv.Columns[e.ColumnIndex].ValueType == typeof(string))
            //{//Si es texto es 2
            //    TipoColumna = 2;
            //}

            //if (dgv.Columns[e.ColumnIndex].ValueType == typeof(DateTime))
            //{//Si es fecha es 3
            //    TipoColumna = 3;
            //}

            this.lblFiltro.Text = dgv.Columns[e.ColumnIndex].Name;
            this.txtFiltro.Focus();
            
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_DoubleClick(object sender, EventArgs e)
        {

            frmLOG_OFC frm = new frmLOG_OFC();
            //
            frm.MdiParent = this.MdiParent;
            frm.NumMov = Convert.ToInt64(dgv.CurrentRow.Cells[0].Value);
            frm.Buscar();
            frm.LOG_OFC_EstBot("abrir");
            frm.Show();            

        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {
            dv.RowFilter = this.lblFiltro.Text + " LIKE '%" + txtFiltro.Text + "%'";
        }

        private void dgv_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgv_formato();
        }

        private void dgv_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //Referenciamos el control TextBox subyacente en la celda actual.

            TextBox cellTextBox = (DataGridViewTextBoxEditingControl)e.Control;

            cellTextBox.ReadOnly = true;
        }

        private void btnMosAct_Click(object sender, EventArgs e)
        {
            MosAct();
        }

        private void btnNueOFC_Click(object sender, EventArgs e)
        {
            frmLOG_OFC frm = new frmLOG_OFC();
            //
            frm.MdiParent = this.MdiParent;

            frm.LOG_OFC_EstBot("deshacer");
            frm.LimpiarControles();
            frm.btnNuevo.PerformClick();
            frm.Show();
        }
    }
}
