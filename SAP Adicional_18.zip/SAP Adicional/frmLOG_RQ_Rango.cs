﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_RQ_Rango : Form
    {
        NConsultas nc = new NConsultas();

        public frmLOG_RQ_Rango()
        {
            InitializeComponent();
        }  
        private void btnMos_Click(object sender, EventArgs e)

        {
            int DocSelec = 0;         
            //
            if (txtIni.Text != "" && txtFin.Text == "") //Validar sin error
            {
                MessageBox.Show("Ingrese un número en el valor final", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFin.Focus();
                return;
            }
            else if (txtIni.Text == "" && txtFin.Text == "")//Validar sin error
            {
                MessageBox.Show("Tiene que ingresar números válidos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtIni.Focus();
                return;
            }

            else if (txtIni.Text == "" && txtFin.Text != "")//Validar sin error
            {
                MessageBox.Show("Ingrese un número en el valor de inicio", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtIni.Focus();
                return;
            }


            try
            {
                DocSelec = Convert.ToInt32(txtIni.Text);  //Valida si hay una letra ,foco para el inicio   
            }
            catch
            {
                MessageBox.Show("Solo se permite consultar numeros de RQ");
                txtIni.Focus();
                return;
            }
           
            try
            {
                DocSelec= Convert.ToInt32(txtFin.Text);//Valida si hay una letra , foco para el final  
            }
            catch
            {
                MessageBox.Show("Solo se permite consultar numeros de RQ");
                txtFin.Focus();
                return;
            }


            long ini = long.Parse( txtIni.Text);
            long fin = long.Parse(txtFin.Text);
         
            if ((ini) > (fin))
            {
                MessageBox.Show("El valor de inicio no puede ser mayor que el valor final", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFin.Focus();
                return;
            }

            else
            {
                fg.DataSource = nc.LOG_RQ_Rango(Convert.ToInt32(txtIni.Text), Convert.ToInt32(txtFin.Text));
                FormRepRQ(1);
                fg2.DataSource = nc.LOG_RQ_Rango_Detalle(Convert.ToInt32(txtIni.Text), Convert.ToInt32(txtFin.Text));
                FormRepRQ(2);
            }
        }

        private void txtIni_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsControl(e.KeyChar) ) //solo permite numeros y borrar
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                txtFin.Focus();
            }
        }

        private void txtFin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        public void FormRepRQ( int fgRepRQ) //formato del flexgrid
        {
            try
            {
                if (fgRepRQ == 1)
                {
                    fg.Cols[0].Width = 80;
                    fg.Cols[2].Width = 260;
                    fg.Cols[3].Width = 220;
                    fg.Cols[4].Width = 50;
                    fg.Cols.Frozen = 2;
                    fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                    fg.Styles.Alternate.BackColor = Color.LightBlue;
                    fg.Styles.Highlight.BackColor = Color.Blue;
                    fg.Styles.Highlight.ForeColor = Color.White;
                    fg.AllowFreezing = AllowFreezingEnum.Both;
                }
               if (fgRepRQ == 2)
                {
                    fg2.Cols[0].Width = 80;                                  
                    fg2.Cols[2].Width = 420;
                    fg2.Cols[3].Width = 60;
                    fg2.Cols[3].Format = "0";
                    fg2.Cols[5].Width = 250;
                    fg2.Cols.Frozen = 2;
                    fg2.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                    fg2.Styles.Alternate.BackColor = Color.LightBlue;
                    fg2.Styles.Highlight.BackColor = Color.Blue;
                    fg2.Styles.Highlight.ForeColor = Color.White;
                    fg2.AllowFreezing = AllowFreezingEnum.Both;
                }
            }
            catch { }
            
        }

        public void Exportar(int ExpFg) //exportar excel
        {
            try
            {
                if (ExpFg == 1)
                {
                    DateTime Hoy = DateTime.Now;
                    string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                    FileFlags flags = FileFlags.IncludeFixedCells;
                    string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                    string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                    fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                    Process.Start(Ruta);
                }
                 if (ExpFg == 2)
                {
                    DateTime Hoy = DateTime.Now;
                    string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                    FileFlags flags = FileFlags.IncludeFixedCells;
                    string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                    string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                    fg2.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                    Process.Start(Ruta);
                }
            }
            catch { }
         
        }
        private void btnExp2_Click(object sender, EventArgs e)
        {
            if (tabControl1.TabPages[0] == tabControl1.SelectedTab) //si selecciona el encabezado migra
            {
                Exportar(1);
            }
            else                                                   
            {
                Exportar(2);                                        //si selecciona el detalle migra
            }         
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar !=27) //no permite borrar
            {
                e.Handled = true;
            }
        }

        private void fg2_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void frmLOG_RQ_Rango_Load(object sender, EventArgs e)
        {
            txtIni.MaxLength = 8; //maximo de caracteres
            txtFin.MaxLength = 8;
        }
    }
}
