﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace SAP_Adicional
{
    public partial class frmVEN_SolNotCre_VisGen : Form
    {

        NVEN_SolNotCre nsnc = new NVEN_SolNotCre();
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        public frmVEN_SolNotCre_VisGen()
        {
            InitializeComponent();
        }

        private void frmOPE_Pro_VisGen_Load(object sender, EventArgs e)
        {
            MosAct();           
        }

        private void MosAct()        
        {

            fg.DataSource = nsnc.VEN_SolNotCre_VisGen(Convert.ToInt16(this.chkMosTod.Checked), varglo.CodUsuAct);            

        }

        private void FormatoFG()
        {
            fg.Rows[0].Height = 40;
            fg.Styles.Normal.WordWrap = true;

            fg.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Both;
            fg.Cols.Frozen = 5;

            fg.Cols[0].Width = 60; //NumMov
            fg.Cols[1].Width = 80; //NumSol
            fg.Cols[2].Width = 70; //FEc. Emision
            fg.Cols[3].Width = 250; //Cliente
            fg.Cols[4].Width = 50; //RQ
            fg.Cols[5].Width = 50; //Moneda
            fg.Cols[6].Width = 60; //Monto Sol. NC
            fg.Cols[7].Width = 70; //Estado
            fg.Cols[8].Width = 130; //N° Boleta/Factura
            fg.Cols[9].Width = 200; //Obs
            fg.Cols[10].Width = 100; //Creado Por
            fg.Cols[11].Width = 150; //Modificado por
            fg.Cols[12].Width = 100; //Fec. Ult. Mod.   

            fg.Cols[0].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
            fg.Cols[1].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
            fg.Cols[2].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
            fg.Cols[4].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
            fg.Cols[5].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
            fg.Cols[11].Format = "dd/MM/yyyy HH:mm";

            fg.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            
        }

        private void btnNueSol_Click(object sender, EventArgs e)
        {
            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 1, "nue", 0) == 1)
            {
                frmVEN_SolNotCre frm = new frmVEN_SolNotCre();
                frm.MdiParent = this.MdiParent;
                frm.VEN_SolNotCre_EstBot("deshacer");
                frm.VEN_SolNot_LimpiarControles();
                frm.btnNue.PerformClick();             
                frm.Show();
                frm.txtRQ_Ini.Focus();
            }
            else
            {
                MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnMosAct_Click(object sender, EventArgs e)
        {
            MosAct();
        }

        private void fg_DoubleClick(object sender, EventArgs e)
        {
            if (fg.RowSel == -1) { return; }

            frmVEN_SolNotCre frm = new frmVEN_SolNotCre();

            frm.MdiParent = this.MdiParent;
            frm.NumMov = Convert.ToInt64(fg.Cols[0][fg.RowSel]);
            frm.VEN_SolNot_Buscar();
            frm.VEN_SolNotCre_EstBot("abrir");
            frm.Show();
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoFG();
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }
    }
}
