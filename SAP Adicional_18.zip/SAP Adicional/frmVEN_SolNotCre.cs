﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using Entidades.VEN_SolNotCre;
using SAP_Adicional.Reportes;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace SAP_Adicional
{
    public partial class frmVEN_SolNotCre : Form , SAP_Variables
    {
        NVEN_SolNotCre snc = new NVEN_SolNotCre();
        NGEN_SAPConexion sap = new NGEN_SAPConexion();
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        public Int64 NumMov = 0;
        Int16 EstDoc = 0;
        string Moneda = "";
        bool SAP_UserBad;
        Int32 SAP_Conecta;
        short TipNotCre;
        string MonMoneda;
        string Email;
        string Telefono;
        string RucDni;
        public Int16 Est;
        public frmVEN_SolNotCre()
        {
            InitializeComponent();
        }

        private void frmVEN_SolNotCre_Load(object sender, EventArgs e)
        {
            frmVEN_SolNotCre_VisGen este = new frmVEN_SolNotCre_VisGen();

            VEN_SolNot_Formato_dgvDoc();
            VEN_SolNot_CargarFormSolDev();
        }
        private void VEN_SolNot_CargarFormSolDev()
        {
            cboEntBan.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTipDel.DropDownStyle = ComboBoxStyle.DropDownList;
            cboEntBan.SelectedIndex = 0;
            gpbAplNotCre.Enabled = false;
        }
        private void VEN_SolNot_SumTotArt()
        {
            decimal suma = 0;
            for (int i = 1; i < fg.Rows.Count; i++)
            {
                suma += Convert.ToDecimal(fg.Rows[i][8]);
            }
            txtMonSolDev.Text = decimal.Round(suma,2).ToString();
        }

        public void VEN_SolNot_Buscar()
        {
            Formato_dgvSol();

            pnCub.Visible = false;
            pnEnc.Visible = true;
            //pnDet.Visible = true;

            DataSet dsVEN_SolNetCre = new DataSet();

            dsVEN_SolNetCre = snc.VEN_SolNotCre_rec(NumMov);

            //Tabla VEN_SolNotCre_Enc del DataSet
            DataTable dtEnc = dsVEN_SolNetCre.Tables["VEN_SolNotCre_Enc"];

            this.NumMov = Convert.ToInt64(dtEnc.Rows[0]["NumMov"]);
            this.txtNumSol.Text = dtEnc.Rows[0]["NumSol"].ToString();
            this.txtFecEmi.Text = dtEnc.Rows[0]["FecEmi"].ToString();
            TipNotCre = Convert.ToInt16(dtEnc.Rows[0]["TipNotCre"].ToString());
            txtTipNotCre.Text = dtEnc.Rows[0]["TipoNota"].ToString();
            this.txtTipDoc.Text = dtEnc.Rows[0]["TipDoc"].ToString();
            this.txtDocNum.Text = dtEnc.Rows[0]["DocNum"].ToString();
            this.txtRQ.Text = dtEnc.Rows[0]["RQ"].ToString();
            this.txtCodCli.Text = dtEnc.Rows[0]["CodCli"].ToString();
            this.txtCli.Text = dtEnc.Rows[0]["Cliente"].ToString();
            this.EstDoc = Convert.ToByte(dtEnc.Rows[0]["codest"]);
            this.txtEst.Text = dtEnc.Rows[0]["Estado"].ToString();
            this.txtNumDocNotCre.Text = dtEnc.Rows[0]["DocNumNotCre"].ToString();
            this.txtObs.Text = dtEnc.Rows[0]["Obs"].ToString();
            this.cboTipDel.SelectedIndex = Convert.ToInt16(dtEnc.Rows[0]["TipDev"]);
            this.txtTipDevDes.Text = dtEnc.Rows[0]["TipDevDes"].ToString();
            this.txtMonSolDev.Text = dtEnc.Rows[0]["MonSolDev"].ToString();


            this.cboEntBan.SelectedIndex =Convert.ToInt16(dtEnc.Rows[0]["EntBan"]);

            this.txtOtrBan.Text = dtEnc.Rows[0]["OtrBan"].ToString();
            this.txtTipCue.Text = dtEnc.Rows[0]["TipCuen"].ToString();
            this.txtCuenBan.Text = dtEnc.Rows[0]["CuenBan"].ToString();
            this.txtCueInt.Text = dtEnc.Rows[0]["CueInt"].ToString();

            MonMoneda = dtEnc.Rows[0]["CodMon"].ToString();
            Email = dtEnc.Rows[0]["Email"].ToString();
            Telefono = dtEnc.Rows[0]["Tel"].ToString();
            RucDni = dtEnc.Rows[0]["RucDni"].ToString();
            //Tabla VEN_SolNotCre_Det del DataSet
            DataTable dtDet = dsVEN_SolNetCre.Tables["VEN_SolNotCre_Det"];

            foreach (DataRow dr in dtDet.Rows)
            {
                string[] rowDet = new string[]
                                            {(fg.Rows.Count).ToString(),
                                            dr["docnum"].ToString(),
                                            dr["codart"].ToString(),
                                            dr["des"].ToString(),
                                            dr["canfac"].ToString(),
                                            dr["cansol"].ToString(),
                                            dr["preuni"].ToString(),
                                            dr["pordes"].ToString(),
                                            dr["totlin"].ToString(),
                                            dr["linenum"].ToString(),
                                            dr["codalm"].ToString(),
                                            dr["tipdoc"].ToString(),
                                            dr["DocNumFac"].ToString(),
                                            dr["IGV"].ToString()
                                            };
                fg.AddItem(rowDet);
            }
            VEN_SolNot_LineasTotales();
            VEN_SolNot_ValoresTotales();
            VEN_SolNot_SumTotArt();
            VEN_SolNotCre_EstBot("abrir");
        }

        private void VEN_SolNot_ElegirTipo()
        {
            pnCub.Visible = true;
            gbTipOri.Visible = true;
            pnDocOri.Visible = false;
            //
            this.rbMer.Checked = true;
            this.txtRQ_Ini.Focus();
        }
        
        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }

        public void VEN_SolNotCre_EstBot(string BotonEstado)
        {
            bool[] EstadoM = { true };

            //nuevo, abrir, guardar, deshacer, modificar, rechazar, aprobar, cancelar, migrarsap, procesar, atendida,opc.impresion

            switch (BotonEstado)
            {
                case "nuevo":
                case "modificar":
                    EstadoM = matriz(false, false, true, true, false, false, false, false, false, false,false,false);
                    break;
                case "abrir":
                case "guardar":
                    EstadoM = matriz();
                    switch (EstDoc)
                    {
                        
                        case 1: //Generado
                            EstadoM = matriz(true, true, false, false, true, true, true, true, false, false,false, true);
                            break;
                        case 4: //Anulado
                            EstadoM = matriz(true, true, false, false, false, false, false, false, false, false, false,true);
                            break;
                        case 5: //Rechazado
                            EstadoM = matriz(true, true, false, false, true, false, true, true, false, false, false, true);
                            break;
                        case 8: //Procesado
                            EstadoM = matriz(true, true, false, false, false, false, false, false, true, true, true, true);
                            break;
                        case 11: //Atendida
                            EstadoM = matriz(true, true, false, false, false, false, false, false, false, true, false, true);
                            break;
                        case 12: //Aprobada
                            EstadoM = matriz(true, true, false, false, false, false, false, true, true, true, false, true);
                            break;

                    }
                    break;
                case "deshacer":                
                    EstadoM = matriz(true, true, false, false, false, false, false, false, false, false, false,false);
                    break;         
            }

            this.btnNue.Enabled = EstadoM[0];
            this.btnAbr.Enabled = EstadoM[1];
            this.btnGua.Enabled = EstadoM[2];
            this.btnDes.Enabled = EstadoM[3];
            this.btnMod.Enabled = EstadoM[4];
            this.btnRec.Enabled = EstadoM[5];
            this.btnApr.Enabled = EstadoM[6];
            this.btnAnu.Enabled = EstadoM[7];
            this.btnMigSAP.Enabled = EstadoM[8];
            this.btnPro.Enabled = EstadoM[9];
            this.btnAte.Enabled = EstadoM[10];
            this.btnImp.Enabled = EstadoM[11]; 
        }

        private void frmVEN_SolNotCre_Resize(object sender, EventArgs e)
        {
            pnCub.Left = 0;
            pnCub.Top = 0;
            pnCub.Height = this.Height;
            pnCub.Width = this.Width;

            pnlDet.Width = this.Width - 50;
            pnlDet.Height = this.Height - 200;

            tbcSolNot.Width = pnlDet.Width - 20;
            tbcSolNot.Height = pnlDet.Height - 220;

            fg.Width = tbcSolNot.Width - 20;
            fg.Height = tbcSolNot.Height - 60;
        }

        private void btnAceTip_Click(object sender, EventArgs e)
        {
            Int64 rq;

            //Validaciones
            if(rbMer.Checked == false && rbCon.Checked == false)
            {
                MessageBox.Show("Debe seleccionar un tipo de Solicitud", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }

            if (string.IsNullOrEmpty(this.txtRQ_Ini.Text) == true & string.IsNullOrEmpty(this.txtDocNumOri.Text) == true)
            {
                MessageBox.Show("Debe ingresar un valor en el campo RQ o N° Doc", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }

            if (string.IsNullOrEmpty(this.txtRQ_Ini.Text) != true & string.IsNullOrEmpty(this.txtDocNumOri.Text) != true)
            {
                MessageBox.Show("Debe ingresar un valor en el campo RQ o N° Doc, no en ambos", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }

            if (string.IsNullOrEmpty(this.txtRQ_Ini.Text) != true) //Si el valor esta en el RQ
            {
                if (Int64.TryParse(txtRQ_Ini.Text, out rq) == false)
                {
                    MessageBox.Show("Debe ingresar un numero de RQ valido", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtRQ_Ini.Focus();
                }
                else
                {
                    RecDatRQ(Convert.ToInt64(txtRQ_Ini.Text));
                }
            }
            else //Si el valor estas en el N° Doc
            {
                if (Int64.TryParse(txtDocNumOri.Text, out rq) == false)
                {
                    MessageBox.Show("Debe ingresar un numero de documento valido", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtRQ_Ini.Focus();
                }
                else
                {
                    RecDetDoc(Convert.ToInt64(this.txtDocNumOri.Text));

                    VEN_SolNot_Nuevo();
                }
            } 

        }

        private void RecDoc(Int64 RQ, short Tipo)
        {
            try
            {
                DataTable dt = snc.VEN_SolNotCre_ListDoc(RQ, Tipo);

                dgvDoc.Rows.Clear();

                if (dt.Rows.Count != 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        dgvDoc.Rows.Add();
                        dgvDoc.Rows[dgvDoc.Rows.Count - 1].Cells["Tipo"].Value = dr["TipoDoc"].ToString();
                        dgvDoc.Rows[dgvDoc.Rows.Count - 1].Cells["N° Doc"].Value = dr["N° Doc"].ToString();
                        dgvDoc.Rows[dgvDoc.Rows.Count - 1].Cells["N° Referencia"].Value = dr["N° Referencia"].ToString();
                        dgvDoc.Rows[dgvDoc.Rows.Count - 1].Cells["Cliente"].Value = dr["Cliente"].ToString();
                        dgvDoc.Rows[dgvDoc.Rows.Count - 1].Cells["TipoObjeto"].Value = dr["ObjType"].ToString();
                    }

                    VEN_SolNot_AceDoc();

                }
                else
                {
                    MessageBox.Show("Este número de RQ no contiene documentos para realizar la Nota de Credito", "SAP Adicional", 
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning); return;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                return;
            }

        }

        private void btnNue_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnNue);
        }

        private void btnCanDoc_Click(object sender, EventArgs e)
        {
            pnDocOri.Visible = false;
            gbTipOri.Visible = true;
        }

        private void btnCanTip_Click(object sender, EventArgs e)
        {
            if (Est == 1)
            {
                pnlDet.Visible = false;
            }
            gbTipOri.Visible = false;
            pnCub.Visible = false;
        }

        private void VEN_SolNot_Formato_dgvDoc()
        {
            dgvDoc.ColumnCount = 5;

            dgvDoc.Columns[0].Name = "Tipo";
            dgvDoc.Columns[1].Name = "N° Doc";
            dgvDoc.Columns[2].Name = "N° Referencia";
            dgvDoc.Columns[3].Name = "Cliente";
            dgvDoc.Columns[4].Name = "TipoObjeto";

            dgvDoc.Font = new Font("Tahoma", 7);
            dgvDoc.RowHeadersVisible = false;

            dgvDoc.Columns[0].Width = 40; //Tipo
            dgvDoc.Columns[1].Width = 70; //N° Doc
            dgvDoc.Columns[2].Width = 100; //N° Referencia
            dgvDoc.Columns[3].Width = 350; //Cliente
            dgvDoc.Columns[4].Visible = false; //Tipo Objeto

            this.dgvDoc.Columns["N° Doc"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvDoc.AllowUserToResizeRows = false;
        }

        private void Formato_dgvSol()
        {
            fg.Cols.Count = 14;
            fg.Rows.Count = 1;
            fg.Rows.Fixed = 1;
            fg.Rows[0].Height = 30;
            fg.Cols.Frozen = 4;
            fg.Styles.Normal.WordWrap = true;

            this.fg.Styles["Fixed"].Font = new Font("Tahoma", 7, FontStyle.Bold);

            fg.Cols[0].Caption = "Item";
            fg.Cols[1].Caption = "N° Doc";
            fg.Cols[2].Caption = "Código Producto";
            fg.Cols[3].Caption = "Descripción";
            fg.Cols[4].Caption = "Cantidad-F/B";            
            fg.Cols[5].Caption = "Cantidad-Sol";
            fg.Cols[6].Caption = "Precio Und. " + Moneda;
            fg.Cols[7].Caption = "% Dscto";
            fg.Cols[8].Caption = "Total " + Moneda;
            fg.Cols[9].Caption = "LineNum";
            fg.Cols[10].Caption = "Almacen";
            fg.Cols[11].Caption = "TipoDoc";
            fg.Cols[12].Caption = "DocNumFac";
            fg.Cols[13].Caption = "IGV";

            fg.Cols[12].Visible = false;
            fg.Cols[13].Visible = false;

            fg.Cols[0].Width = 40; //Item
            fg.Cols[1].Width = 80; //N° F/B
            fg.Cols[2].Width = 80; //Código Producto
            fg.Cols[3].Width = 400; //Descripción
            fg.Cols[4].Width = 80; //Cantidad-F/B
            fg.Cols[5].Width = 80; //Cantidad-Sol
            fg.Cols[6].Width = 80; //Precio Und.
            fg.Cols[7].Width = 80; //% Dscto
            fg.Cols[8].Width = 80; //Total
            fg.Cols[9].Visible = false; //LineNum
            fg.Cols[10].Width = 80; //Almacen
            fg.Cols[11].Width = 50; //Tipo Doc F/E

            fg.Cols[4].DataType = typeof(decimal);
            fg.Cols[5].DataType = typeof(decimal);
            fg.Cols[6].DataType = typeof(decimal);
            fg.Cols[7].DataType = typeof(decimal);            
            fg.Cols[8].DataType = typeof(decimal);

            fg.Cols[4].Format = "#,###.00";
            fg.Cols[5].Format = "#,###.00";
            fg.Cols[6].Format = "#,###.00";
            fg.Cols[7].Format = "#,###.00";
            fg.Cols[8].Format = "#,###.00";

            //-------------------------------------------------
        }


        private void VEN_SolNot_AceDoc()
        {
            //Primero verificamos que exista alguna fila seleccionada

            //if (fg.SelectionMode == C1.Win.C1FlexGrid.SelectionModeEnum.Cell)
                
            //{
            //    MessageBox.Show("Debe seleccionar una fila", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    return;
            //}

            //Damos formato al grid
            Formato_dgvSol();

            if (dgvDoc.Rows.Count != 0)
            {
                for (int i = 0; i < dgvDoc.Rows.Count; i++)
                {
                    RecDetDoc(Convert.ToInt64(dgvDoc.Rows[i].Cells[1].Value));
                }

                VEN_SolNot_LineasTotales();
                VEN_SolNot_Nuevo();
            }
        }

        private void VEN_SolNot_Nuevo()
        {
            pnCub.Visible = false;
            pnEnc.Visible = true;
            pnlDet.Visible = true;

            DateTime Hoy = DateTime.Today;

            txtFecEmi.Text = Hoy.ToString("d");

            EstDoc = 1;

            gpbAplNotCre.Enabled = true;

            VEN_SolNotCre_EstBot("nuevo");
        }

        private void RecDatRQ(Int64 RQ)
        {
            DataTable dtenc = nc.RecuperaInfoRQ("", "VEN_RQ_Info", 1, RQ.ToString());

            if (dtenc.Rows.Count > 0)
            {
                this.txtCodCli.Text = dtenc.Rows[0]["Cod.Cliente"].ToString();
                this.txtCli.Text = dtenc.Rows[0]["Cliente"].ToString();
                this.txtRQ.Text = this.txtRQ_Ini.Text;
                Moneda = dtenc.Rows[0]["Moneda"].ToString();

                RecDoc(Convert.ToInt64(this.txtRQ_Ini.Text), Convert.ToInt16(rbMer.Checked ? 1 : 2));
            }
            else
            {
                MessageBox.Show("El RQ ingresado no devolvio información, ingrese otro número de RQ","SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }

        }

        private void RecDetDoc(Int64 DocNum)
        {


            DataTable dtdet = new DataTable();

            //Llenamos el datatable con los resultados del procedimiento
            dtdet = snc.VEN_SolNotCre_DocDet(DocNum);            

            foreach (DataRow dr in dtdet.Rows)
            {
                fg.Rows.Add();
                fg.Rows[fg.Rows.Count - 1][0] = (fg.Rows.Count -1).ToString();
                fg.Rows[fg.Rows.Count - 1][1] = dr["DocNum"].ToString();
                fg.Rows[fg.Rows.Count - 1][2] = dr["itemcode"].ToString();
                fg.Rows[fg.Rows.Count - 1][3] = dr["itemname"].ToString();
                fg.Rows[fg.Rows.Count - 1][4] = dr["Quantity"].ToString();
                fg.Rows[fg.Rows.Count - 1][6] = dr["price"].ToString();
                fg.Rows[fg.Rows.Count - 1][7] = dr["discprcnt"].ToString();
                fg.Rows[fg.Rows.Count - 1][8] = dr["Total (doc)"].ToString();
                fg.Rows[fg.Rows.Count - 1][9] = dr["linenum"].ToString();
                fg.Rows[fg.Rows.Count - 1][10] = dr["WhsCode"].ToString();
                fg.Rows[fg.Rows.Count - 1][11] = dr["TipoDoc"].ToString();
                fg.Rows[fg.Rows.Count - 1][12] = dr["docnumfac"].ToString();
                fg.Rows[fg.Rows.Count - 1][13] = dr["igv"].ToString();

            }


        }

        private void btnGua_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnGua);
        }

        private void txtRQ_Ini_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnAceTip.Focus();
            }
        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnMod);
        }

        private void btnAnu_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnAnu);
        }

        private void btnPro_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnPro);
        }

        public void VEN_SolNot_LimpiarControles()
        {
            foreach (Control ctrl in this.pnEnc.Controls)
            {
                if (ctrl is TextBox) ctrl.Text = "";
            }

            rbMer.Checked = false;
            rbCon.Checked = false;
            txtNumSol.Text = "";
            txtRQ_Ini.Text = "";

        }

        private void btnDes_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnDes);
        }

        private void pnCub_Resize(object sender, EventArgs e)
        {
            gbTipOri.Left = (pnCub.Width - gbTipOri.Left) / 2;
            gbTipOri.Top = (pnCub.Height - gbTipOri.Height) / 2;

            pnDocOri.Left = (pnCub.Width - pnDocOri.Left) / 2;
            pnDocOri.Top = (pnCub.Height - pnDocOri.Height) / 2;

        }

        private void pnDet_Resize(object sender, EventArgs e)
        {
        }

        private void btnMigSAP_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnMigSAP);
        }

        public void rec_SAP_UserBad(bool UserBad)
        {
            SAP_UserBad = UserBad;
        }

        private void rbMer_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMer.Checked == true)
            {
                TipNotCre = 1;
                txtTipNotCre.Text = "MERCADERIA";
            }
        }

        private void rbCon_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCon.Checked == true)
            {
                TipNotCre = 2;
                txtTipNotCre.Text = "CONCEPTO";
            }
        }

        public void rec_SAP_Connection(int ErrorCode)
        {
            SAP_Conecta = ErrorCode;
        }

        private void btnAbr_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnAbr);
        }

        private void btnCarColCanSol_Click(object sender, EventArgs e)
        {

            foreach (C1.Win.C1FlexGrid.Row row in fg.Rows)
            {
                row[5] = row[4];
            }
        }

        private void btnRec_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnRec);

        }

        private void btnApr_Click(object sender, EventArgs e)
        {
            VEN_SolNot_Botones(btnApr);
        }

        void VEN_SolNot_Botones(ToolStripButton boton)
        {
            switch (boton.Text)
            {
                case "&Nuevo":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct,1,"nue",0) == 1)
                    {
                        VEN_SolNot_ElegirTipo();                        
                    }
                    else
                    {
                        MessageBox.Show("No cuenta con acceso para realizar esta operación","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    }

                    break;

                case "&Abrir":                

                    Boolean formCargado;

                    formCargado = false;
                    //formularios abiertos en la aplicacion
                    foreach (Form frm in Application.OpenForms)
                    {
                        if (frm.GetType() == typeof(frmVEN_SolNotCre_VisGen))
                        {
                            formCargado = true;
                        }
                    }

                    if (formCargado == false)
                    {
                        frmVEN_SolNotCre_VisGen f = new frmVEN_SolNotCre_VisGen();

                        f.MdiParent = this.MdiParent;
                        f.BringToFront();
                        f.Show();
                    }

                    this.Dispose();

                    break;

                case "&Guardar":
                    
                    //Validaciones

                    //Validamos que se haya llenado algun valor en la columna cantidad-Sol
                    decimal CanSol = 0;

                    foreach (C1.Win.C1FlexGrid.Row row in fg.Rows)
                    {
                        if (row.Index > 0)
                        {
                            CanSol = CanSol + Convert.ToDecimal(row[5]);
                        }                        
                    }

                    if (CanSol == 0)
                    {
                        MessageBox.Show("Debe ingresar algun valor en el campo Cantidad-Sol", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    //Entidad encabezado de VEN_SolNotCre donde tambien se llama a los detalles
                    VEN_SolNotCre Enc = new VEN_SolNotCre();

                    Enc.NumMov = NumMov;
                    Enc.NumSol = this.txtNumSol.Text;
                    Enc.TipNotCre = TipNotCre;
                    Enc.TipDoc = txtTipDoc.Text;
                    //Enc.DocNum = Convert.ToInt64(string.IsNullOrEmpty(txtDocNum.Text) = true;
                    Enc.CodCli = this.txtCodCli.Text;
                    Enc.RQ = Convert.ToInt64(this.txtRQ.Text);
                    Enc.CodMon = Moneda;
                    Enc.Obs = this.txtObs.Text;
                    Enc.DirEnvNotCre = "";
                    Enc.CodUsu = varglo.CodUsuAct;

                    //encabezado de solicitud de devoluciones
                    Enc.TipDev = Convert.ToInt16(cboTipDel.SelectedIndex);
                    Enc.TipDevDes = txtTipDevDes.Text;

                    decimal MonDevDes = 0;
                    decimal.TryParse(txtMonSolDev.Text, out MonDevDes);
                    Enc.MonDevDes = MonDevDes;


                    //if ( cboEntBan.SelectedIndex == 7)
                    //{
                        Enc.OtrBan = cboEntBan.SelectedText;
                    //}
                    //else
                    //{
                        Enc.EntBan = (Int16)cboEntBan.SelectedIndex;
                    //}
                    
                    Enc.TipCue = txtTipCue.Text;
                    Enc.CueBan = txtCuenBan.Text;
                    Enc.CueInt = txtCueInt.Text;


                    //Recorremos el datagridview para agregar las lineas con la cantidad-sol diferente de cero
                    foreach (C1.Win.C1FlexGrid.Row row in fg.Rows)
                    {
                        VEN_SolNotCre_Det Det = new VEN_SolNotCre_Det();

                        if (row.Index > 0) //Para que no agarre la fila de titulos
                        {
                            if (Convert.ToDecimal(row[5]) > 0)
                            {
                                                                
                                Det.Item = Convert.ToInt16(row[0].ToString());
                                Det.DocNum = Convert.ToInt64(row[1]);
                                Det.CodArt = row[2].ToString();
                                Det.CanFac = Convert.ToDecimal(row[4]);
                                Det.CanSol = Convert.ToDecimal(row[5]);
                                Det.PreUni = Convert.ToDecimal(row[6]);
                                Det.PorDes = Convert.ToDecimal(row[7]);
                                Det.TotLin = Convert.ToDecimal(row[8]);
                                Det.LineNum = Convert.ToInt16(row[9]);
                                Det.CodAlm = row[10].ToString();
                                Det.TipDoc = row[11].ToString();
                                Det.DocNumFac = Convert.ToInt64(row[12].ToString());
                                Det.IGV = Convert.ToDecimal(row[13].ToString());

                                Enc.Det.Add(Det);
                            }
                        }
                    }
            
                    //Pasamos la entidad para guardar
                    snc.VEN_SolNotCre_ingact(Enc);

                    //Recuperamos el numero de movimiento y numso generados
                    NumMov = Enc.NumMov;
                    this.txtNumSol.Text = Enc.NumSol;

                    gpbAplNotCre.Enabled = false;

                    VEN_SolNotCre_EstBot("guardar");

                    break;

                case "Deshacer":

                    VEN_SolNotCre_EstBot("deshacer");

                    VEN_SolNot_LimpiarControles();

                    pnEnc.Visible = false;
                    pnCub.Visible = false;
                    pnlDet.Visible = false;

                    break;

                case "Modificar":

                    gpbAplNotCre.Enabled = true;

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 1, "mod", 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("modificar");
                    }
                    else
                    {
                        MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }                    

                    break;

                case "Rechazar":

                    VEN_SolNotCre_ConEst("rec",Convert.ToInt16(boton.Tag)); break;

                case "Aprobar":

                    VEN_SolNotCre_ConEst("apr", Convert.ToInt16(boton.Tag)); break;

                case "Anular":

                    VEN_SolNotCre_ConEst("anu", Convert.ToInt16(boton.Tag)); break;

                case "Procesar":

                    VEN_SolNotCre_ConEst("pro", Convert.ToInt16(boton.Tag)); break;

                case "Atendido":

                    VEN_SolNotCre_ConEst("ate", Convert.ToInt16(boton.Tag)); break;

                case "Migrar SAP":

                    if (sap.SAP_ValidarUsuario(varglo.UsuSAP, varglo.PasSAP) != 0)
                    {//La primera vez las variables van a estar vacias y devolvera error por lo que
                     //mostrara el formulario de inicio de sesion
                        frmGEN_SAP_IniSes f = new frmGEN_SAP_IniSes();

                        f.SAP_Var = this;
                        f.ShowDialog();

                        if (SAP_UserBad == true) return;
                    }
                    else
                    {
                        SAP_Conecta = sap.SAP_ConectarCompañia(varglo.UsuSAP, varglo.PasSAP);
                    }

                    if (SAP_Conecta != 0)
                    {
                        MessageBox.Show("Se ha producido el error " + SAP_Conecta.ToString(), "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        List<Int64> lista = new List<Int64>();
                        Int64 DocNumFac = 0;
                        bool Existe = false;

                        //if (Convert.ToDecimal(fg.Rows[1][12]) > 0)
                        //{
                        //    lista.Add(Convert.ToInt64(fg.Rows[1][12]));
                        //    DocNumFac = Convert.ToInt64(fg.Rows[1][12]);
                        //}

                        for (int i = 1; i < fg.Rows.Count; i++)
                        {
                           
                            if (Convert.ToDecimal(fg.Rows[i][12]) > 0)
                            {                                
                                DocNumFac = Convert.ToInt64(fg.Rows[i][12]);

                                for (int j = 0; j < lista.Count; j++)
                                {
                                    Existe = false;

                                    if (DocNumFac == lista[j])
                                    {
                                        Existe = true;
                                        break;
                                    }
                                }

                                if (Existe == false)
                                {
                                    lista.Add(DocNumFac);                                       
                                }                                
                            }
                        }

                        for (int i = 0; i < lista.Count; i++)
                        {
                            SAP_Conecta = sap.SAP_ConectarCompañia(varglo.UsuSAP, varglo.PasSAP);

                            //sap.VEN_SolNotCre_MigSAP(NumMov, lista[i], TipNotCre);

                        }
                    }

                    break;
            }

        }

        private void VEN_SolNot_LineasTotales()
        {

            fg.Rows.Add();
            fg.Rows[fg.Rows.Count - 1][1] = "TOTAL";            

            fg.Rows.Add();
            fg.Rows[fg.Rows.Count - 1][1] = "TOTAL + IGV";
            
        }

        private void VEN_SolNot_ValoresTotales()
        {
            decimal Total = 0;
            decimal TotalIGV = 0;

            for (int i = 1; i < fg.Rows.Count; i++)
            {
                if (Convert.ToDecimal(fg.Rows[i][5]) > 0)
                {
                    Total = Total + Convert.ToDecimal(fg.Rows[i][8]);
                    TotalIGV = TotalIGV + (Convert.ToDecimal(fg.Rows[i][8]) * (1 + (Convert.ToDecimal(fg.Rows[i][13]) / 100)));
                }
            }

            fg.Rows[fg.Rows.Count - 2][8] = Total;
            fg.Rows[fg.Rows.Count - 1][8] = TotalIGV;
        }

        private void btnAte_Click(object sender, EventArgs e)
        {
           VEN_SolNot_Botones(btnAte);
        }

        private void VEN_SolNotCre_ConEst(string cadbot, Int16 codest)
        {
            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 1, cadbot, 0) == 1)
            {
                DialogResult res = MessageBox.Show("¿Esta seguro de realizar esta acción?", "SAP Adicional", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (res == DialogResult.Yes)
                {
                    snc.VEN_SolNotCre_Est(NumMov, varglo.CodUsuAct, codest, txtNumDocNotCre.Text);

                    EstDoc = codest;

                    switch (codest)
                    {
                        case 4:
                             this.txtEst.Text = "ANULADO"; break;
                        case 5:
                            this.txtEst.Text = "RECHAZADO"; break;
                        case 8:
                            this.txtEst.Text = "PROCESADO"; break;

                        case 11:
                            this.txtEst.Text = "ATENDIDA"; break;
                        case 12:
                            this.txtEst.Text = "APROBADO"; break;

                    }
                    
                    VEN_SolNotCre_EstBot("abrir");
                }
            }
            else
            {
                MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLim_Click(object sender, EventArgs e)
        {
            LimpiarSolDes();
        }
        private void LimpiarSolDes()
        {
            cboTipDel.SelectedIndex = 0;
            txtMonSolDev.Clear();
            txtOtrBan.Clear();
            txtTipCue.Clear();
            txtCuenBan.Clear();
            txtCueInt.Clear();
            txtTipDevDes.Clear();
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            LimpiarSolDes();
            TabPage t = tbcSolNot.TabPages[0];
            tbcSolNot.SelectTab(t);
        }

        private void cboEntBan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboEntBan.SelectedIndex == 0)
            {
                txtCuenBan.ReadOnly = false;
                txtCueInt.ReadOnly = true;
                txtCuenBan.Focus();
                txtCueInt.Clear();
                txtOtrBan.Clear();
            }
            else
            {
                txtCuenBan.ReadOnly = true;
                txtCueInt.ReadOnly = false;
                txtCueInt.Focus();
                txtCuenBan.Clear();

            }

            if (cboEntBan.SelectedIndex == 7)
            {
                txtOtrBan.ReadOnly = false;
                txtOtrBan.Focus();
                txtCuenBan.Clear();
                txtCueInt.Clear();
            }
            else
            {
                txtOtrBan.ReadOnly = true;
                txtCueInt.Clear();
                txtOtrBan.Clear();
            }
        }

        private void txtTipDevDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtMonSolDev.Focus();
                    
            }
        }

        private void txtMonSolDev_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                cboEntBan.Focus();

            }
            if (char.IsDigit(e.KeyChar)) //permite ingresar solo numericos
            {
                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))//permite ingresar la tecla backspace
            {
                e.Handled = false;
            }
            else if (e.KeyChar == '.' && !txtMonSolDev.Text.Contains(".")) //verifica si hay un punto decimal
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtOtrBan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtTipCue.Focus();
            }

            if (char.IsLetter(e.KeyChar))         { e.Handled = false; }
            else if (char.IsControl(e.KeyChar))   { e.Handled = false; }
            else if (char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtTipCue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtCuenBan.Focus();
            }
        }

        private void txtCuenBan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtCueInt.Focus();
            }
        }

        private void txtCueInt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnLim.Focus();
            }
        }

        private void btnLim_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnCanSol.Focus();
            }
        }

       
        private void fg_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 5)
            {
                decimal DocSelec = 0;
                try
                {
                    DocSelec = Convert.ToDecimal(fg.Rows[e.Row][5]);
                }
                catch
                {
                    fg.Rows[e.Row][5] = 0; return;
                }

                if (Convert.ToDecimal(fg.Rows[e.Row][5]) > Convert.ToDecimal(fg.Rows[e.Row][4]))
                {
                    MessageBox.Show("La cantidad solicitada no puede superar la facturada", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    fg.Rows[e.Row][5] = 0; return;
                }

                fg.Rows[e.Row][8] = (Convert.ToDecimal(fg.Rows[e.Row][5]) * Convert.ToDecimal(fg.Rows[e.Row][6])) -
                                         ((Convert.ToDecimal(fg.Rows[e.Row][5]) * Convert.ToDecimal(fg.Rows[e.Row][6])) * (Convert.ToDecimal(fg.Rows[e.Row][7]) / 100));

                VEN_SolNot_ValoresTotales();
            }
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.Col != 5 || (e.Col == 5 && this.btnMod.Enabled == true))
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void solicitiudDeNotaDeCréditoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConnectionInfo crConnectionInfo = new ConnectionInfo(); ;
            Database crDatabase;
            Tables crTables;
            Table crTable;
            TableLogOnInfo crTableLogOnInfo;

            crConnectionInfo.ServerName = "zeus";
            crConnectionInfo.DatabaseName = VarGlo.Instance().Base; // Las tablas para el informe están siempre en la base de datos global.
            crConnectionInfo.IntegratedSecurity = true;

            frmVisor f = new frmVisor();
            rptVEN_SolNoCre repSolNot = new rptVEN_SolNoCre();


            crDatabase = repSolNot.Database; // Obtener la colección de tablas del objeto de informe
            crTables = crDatabase.Tables;

            for (int i = 0; i < crTables.Count; i++)
            {

                crTable = crTables[i];

                crTableLogOnInfo = crTable.LogOnInfo;

                crTableLogOnInfo.ConnectionInfo = crConnectionInfo;

                crTable.ApplyLogOnInfo(crTableLogOnInfo);

                //If your DatabaseName is changing at runtime, specify the table location. For example, when you are reporting off of a Northwind database on SQL server you should have the following line of code:

                //crTable.Location = "Northwind.dbo." + crTable.Location.Substring(crTable.Location.LastIndexOf(".") + 1)
            
            }

            //solicitud de nota de credito
            repSolNot.SetParameterValue("@nummov", NumMov);
            f.MdiParent = this.MdiParent;
            f.crv.ReportSource = repSolNot;
            f.crv.Zoom(120);
            f.WindowState = FormWindowState.Maximized;
            f.Show();
            Visible = true;

        }

        private void solicitudDeDevoluciónAClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConnectionInfo crConnectionInfo = new ConnectionInfo(); ;
            Database crDatabase;
            Tables crTables;
            Table crTable;
            TableLogOnInfo crTableLogOnInfo;

            crConnectionInfo.ServerName = "zeus";
            crConnectionInfo.DatabaseName = VarGlo.Instance().Base; // Las tablas para el informe están siempre en la base de datos global.
            crConnectionInfo.IntegratedSecurity = true;

            frmVisor f = new frmVisor();
            rptVEN_SolDevCli repSolDev = new rptVEN_SolDevCli();


            crDatabase = repSolDev.Database; // Obtener la colección de tablas del objeto de informe
            crTables = crDatabase.Tables;

            for (int i = 0; i < crTables.Count; i++)

            {

                crTable = crTables[i];

                crTableLogOnInfo = crTable.LogOnInfo;

                crTableLogOnInfo.ConnectionInfo = crConnectionInfo;

                crTable.ApplyLogOnInfo(crTableLogOnInfo);

                //If your DatabaseName is changing at runtime, specify the table location. For example, when you are reporting off of a Northwind database on SQL server you should have the following line of code:

                //crTable.Location = "Northwind.dbo." + crTable.Location.Substring(crTable.Location.LastIndexOf(".") + 1)

            }

            // solicitud de devolucion
            repSolDev.SetParameterValue("@nummov", NumMov);
            f.MdiParent = this.MdiParent;
            f.crv.ReportSource = repSolDev;
            f.crv.Zoom(120);
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }

        private void btnImp_ButtonClick(object sender, EventArgs e)
        {

        }
    }
}