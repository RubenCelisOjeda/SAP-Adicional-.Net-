﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.Man_Contactos;
using Interfaces;
using SAP_Adicional.Reportes;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmMan_Contactos : Form, IMan_Contactos
    {
        private NMan_Contactos manCon = new NMan_Contactos();
        private VarGlo varglo = VarGlo.Instance();
        private string _colName = "Codigo";
        private bool _estReg = false; //agrega o actualiza
        private byte _index = 0;
        private Int16 _colLbl = 0;
        private string _msg = "";

        public frmMan_Contactos()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
        }

        private void btnNue_Click(object sender, EventArgs e)
        {
            this._estReg = false;
            this.Man_Contactos_Botones(this.btnNue);
        }

        private void btnExpMae_Click(object sender, EventArgs e)
        {
            //valida el acceso del usuario
            if (MetGlo.GEN_AccByDoc(VarGlo.Instance().CodUsuAct,5,"Exp",0) == 1)
            {
                MetGlo.ExportarExcel(this.fgMae, this.Text);
            }
            else
            {
                this._msg = "No cuenta con acceso para realizar esta operación,comuniquese con el administrador.";
                this.Man_Contactos_MosMsgStrip(this._msg, Color.Red);
            }
        }

        private void frmMan_Contactos_Load(object sender, EventArgs e)
        {
            this.Man_Contactos_EstBot("carga");
            this.Man_Contactos_IsSoloLectura(true);
            this.Man_Contactos_IsSoloLecturaCod();
            this.Man_Contactos_RecRecom();
            this.btnPri.PerformClick();
            this.btnNue.Focus();
        }

        private void Man_Contactos_IsSoloLectura(bool isVal)
        {
            //Deshabilita o habilita los textos dependiendo del parametro
            foreach (Control c in this.tabManCon.TabPages[0].Controls)
            {
                if (c is TextBox & c.BackColor != Color.PaleTurquoise)
                {
                    ((TextBox)c).ReadOnly = isVal;
                }
            }
            this.chkIna.Enabled = !isVal;
        }

        private void Man_Contactos_LimTex()
        {
            //Limpia los textos del tabPages
            foreach (Control c in this.tabManCon.TabPages[0].Controls)
            {
                if (c is TextBox)
                {
                    c.Text = "";
                }
            }

            this.chkIna.Checked = false;
        }

        private void Man_Contactos_IsSoloLecturaCod()
        {
            //Deshabilita los textos de solo lectura los campos de color celeste
            foreach (Control c in this.tabManCon.TabPages[0].Controls)
            {
                if (c is TextBox & c.BackColor == Color.PaleTurquoise)
                {
                    ((TextBox)c).ReadOnly = true;
                }
            }
        }


        private void fgMae_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.Man_Contactos_ForGen();
            this.Man_Contactos_ForCol();
            this.RecDistritos();
            this.RecProfesion();
            this.RecResponsable();
            this.RecTipoContacto();
            this.RecCategoria();
        }

        private void Man_Contactos_ForGen()
        {
            //formato general del grid
            this.fgMae.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            this.fgMae.VisualStyle = VisualStyle.Office2010Silver;
            this.fgMae.Styles.Alternate.BackColor = Color.LightBlue;
            this.fgMae.Styles.Highlight.BackColor = Color.Blue;
            this.fgMae.Styles.Highlight.ForeColor = Color.White;
            this.fgMae.AllowFreezing = AllowFreezingEnum.Both;
            this.fgMae.Cols.Frozen = 3;
        }

        private void Man_Contactos_ForCol()
        {
            //Ancho de columnas
            this.fgMae.Cols["Codigo"].Width = 50;
            this.fgMae.Cols["Nombres"].Width = 150;
            this.fgMae.Cols["Apellidos"].Width = 150;
            this.fgMae.Cols["Direccion"].Width = 250;
            this.fgMae.Cols["Distrito"].Width = 120;
            this.fgMae.Cols["DireccionCasa"].Width = 150;
            this.fgMae.Cols["Distrito2"].Width = 150;
            this.fgMae.Cols["DNI"].Width = 100;
            this.fgMae.Cols["Compania"].Width = 120;
            this.fgMae.Cols["Cargo"].Width = 120;
            this.fgMae.Cols["Responsabilidad"].Width = 120;
            this.fgMae.Cols["Inactivo"].Width = 50;
            this.fgMae.Cols["Modificado por:"].Width = 200;

            //Tipo de dato 
            this.fgMae.Cols["Inactivo"].DataType = typeof(bool);
        }
 
        private void RecDistritos()
        {
            //Recupera los distritos de contactos en la columna del grid
            ListDictionary lisDis = new ListDictionary();
            DataTable dtDistritos = null; 
            CellStyle stlDis = null;
            string value = "";
            string key = "";

            dtDistritos = this.manCon.Man_Contactos_RecDis();

            for (int distrito = 0; distrito < dtDistritos.Rows.Count; distrito++)
            {
                value = dtDistritos.Rows[distrito][1].ToString();
                key = dtDistritos.Rows[distrito][0].ToString();
                lisDis.Add(key,value);
            }

            stlDis = fgMae.Styles.Add("Distrito");
            stlDis = fgMae.Styles.Add("Distrito2");
            stlDis.DataMap = lisDis;

            this.fgMae.Cols["Distrito"].Style = stlDis;
            this.fgMae.Cols["Distrito2"].Style = stlDis;
        }

        private void RecProfesion()
        {
            //Recupera las profesiones de contactos en la columna del grid
            ListDictionary lisPro = new ListDictionary();
            DataTable dtProfesion = null; 
            CellStyle stlPro = null;
            string value = "";
            string key = "";

            dtProfesion = this.manCon.Man_Contactos_RecPro();

            for (int profesion = 0; profesion < dtProfesion.Rows.Count; profesion++)
            {
                value = dtProfesion.Rows[profesion][1].ToString();
                key = dtProfesion.Rows[profesion][0].ToString();

                lisPro.Add(key,value);
            }

            stlPro = fgMae.Styles.Add("Profesion");
            stlPro.DataMap = lisPro;
            this.fgMae.Cols["Profesion"].Style = stlPro;
        }

        private void RecResponsable()
        {
            //Recupera los responsables  de contactos en la columna del grid
            ListDictionary lisRes = new ListDictionary();
            DataTable dtResponsable = null; 
            CellStyle stlRes = null;
            string value = "";
            string key = "";

            dtResponsable = this.manCon.Man_Contactos_RecRes();

            for (int responsable = 0; responsable < dtResponsable.Rows.Count; responsable++)
            {
                value = dtResponsable.Rows[responsable][1].ToString();
                key = dtResponsable.Rows[responsable][0].ToString();

                lisRes.Add(key, value);
            }

            stlRes = fgMae.Styles.Add("Responsabilidad");
            stlRes.DataMap = lisRes;
            this.fgMae.Cols["Responsabilidad"].Style = stlRes;
        }

        private void RecTipoContacto()
        {
            //Recupera los tipos de contactos en la columna del grid
            ListDictionary lisTipCon = new ListDictionary();
            DataTable dtTipCon = null; 
            CellStyle stlTipCon = null;
            string value = "";
            string key = "";

            dtTipCon = this.manCon.Man_Contactos_RecTipCon();

            for (int contacto = 0; contacto < dtTipCon.Rows.Count; contacto++)
            {
                value = dtTipCon.Rows[contacto][1].ToString();
                key = dtTipCon.Rows[contacto][0].ToString();

                lisTipCon.Add(key, value);
            }

            stlTipCon = fgMae.Styles.Add("TipoContacto");
            stlTipCon.DataMap = lisTipCon;
            this.fgMae.Cols["TipoContacto"].Style = stlTipCon;
        }

        private void RecCategoria()
        {
            //Recupera las categorias de contactos en la columna del grid

            ListDictionary lisCat = new ListDictionary();
            DataTable dtCat = null; 
            CellStyle stlCat = null;
            string value = "";
            string key = "";

            dtCat = this.manCon.Man_Contactos_RecCat();

            for (int categoria = 0; categoria < dtCat.Rows.Count; categoria++)
            {
                value = dtCat.Rows[categoria][1].ToString();
                key = dtCat.Rows[categoria][0].ToString();

                lisCat.Add(key, value);
            }

            stlCat = this.fgMae.Styles.Add("Categoria");
            stlCat.DataMap = lisCat;
            this.fgMae.Cols["Categoria"].Style = stlCat;
        }

        private void txtFil_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                Cursor.Current = Cursors.WaitCursor;
                this.Man_Contactos_FiltroRecom();
                Cursor.Current = Cursors.Default;
            }
        }

        private void Man_Contactos_FiltroRecom()
        {
            /******************************************
             * Nombre: "Filtro de recomendadores"
             * Proposito: <"Filtrar los datos dependiendo el dato ingresado en el textbox">
             * Output: <Mostrar los datos del filtro en el grid>
             * Creado por: Ruben C.
             *****************************************/

            DataTable dtFilCon = null;
            Int16 col = 0;

            col = Convert.ToInt16(this.txtFil.Text == "" ? 99 : this._colLbl);
            dtFilCon = manCon.Man_Contactos_FilRecom(col, this.txtFil.Text);

            //Valida si hay datos
            if (dtFilCon.Rows.Count > 0)
            {
                this.fgMae.DataSource = dtFilCon;
            }

            if (dtFilCon.Rows.Count == 0)
            {
                this.fgMae.DataSource = dtFilCon;
                this.Man_Contactos_MosMsgStrip("No se encontraron datos.", Color.DodgerBlue);
            }
        }

        private void Man_Contactos_RecRecom()
        {
            //Muestra los 100 primeros registros en el grid
            DataTable dtFilCon = null;
            dtFilCon = manCon.Man_Contactos_FilRecom(-1,"");

            if (dtFilCon.Rows.Count > 0)
            {
                this.fgMae.DataSource = dtFilCon;
                this._colLbl = 0;
            }
            else
            {
                this._msg = "No hay registros,agregue uno nuevo o cierre la ventana.";
                this.Man_Contactos_MosMsgStrip(this._msg, Color.DodgerBlue);
                this.Man_Contactos_EstBot("nuevo");
            }
        }

        private void fgMae_BeforeSort(object sender, SortColEventArgs e)
        {
            //Obtiene el nombre de la columna al hacer clickear
            this._colLbl = (Int16)e.Col;

            this._colName = this.fgMae.Cols[e.Col].Name;
            this.lblFil.Text = this.fgMae.Cols[e.Col].Name;
            this.txtFil.Focus();
        }

        private void fgMae_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //valida el acceso del usuario
            if (MetGlo.GEN_AccByDoc(VarGlo.Instance().CodUsuAct,5,"Mod",0) == 1)
            {
                //Solo permite editar en las columnas validadas
                if (e.Col != 0 && e.Col != 21 && e.Col != 22 && e.Col != 23 && e.Col != 24)
                {
                    //Permite editar los campos de aquellas columnas validadas
                    if (e.KeyChar != 3 || e.KeyChar != 27)
                    {
                        e.Handled = false;
                    }
                }
                else
                {
                    //deshabilita el grid de las columnas no validadas
                    e.Handled = true;
                }
            }
            else
            {
                e.Handled = true;
                this._msg = "No cuenta con acceso para realizar esta operación,comuniquese con el administrador.";
                this.Man_Contactos_MosMsgStrip(this._msg, Color.Red);
            }
        }

        private void fgMae_AfterEdit(object sender, RowColEventArgs e)
        {
            //Guarda el valor ingresado ,validando la columna y el acceso las cuales no se van a editar
            int codigo = 0;
            string valor = "";

            //valida el acceso del usuario
            if (MetGlo.GEN_AccByDoc(VarGlo.Instance().CodUsuAct, 5, "Mod", 0) == 1)
            {
                if (e.Col != 0 & e.Col != 21 & e.Col != 22 & e.Col != 23 & e.Col != 24)
                {
                    codigo = Convert.ToInt32(this.fgMae.Cols[0][this.fgMae.RowSel]);
                    valor = this.fgMae[e.Row, e.Col].ToString();

                    manCon.Man_Contactos_UpdCampo(codigo,
                                                  this.Man_Contactos_ObtNomCol(),
                                                  valor);

                    //actuliza los datos si el codigo es igual al editado en el grid
                    int codCod = 0;
                    codCod = (int)this.fgMae.Rows[this.fgMae.RowSel][0];

                    if (Convert.ToInt32(this.txtCodCon.Text) == codCod)
                    {
                        this.Man_Contactos_RecDatRecom(4, codCod);
                    }
                }
            }
        }
        private string Man_Contactos_ObtNomCol()
        {
            //obtiene el nombre con el numero de columna editada,
            if (fgMae.Col == 1) _colName = "Nombres";
            if (fgMae.Col == 2) _colName = "Apellidos";
            if (fgMae.Col == 3) _colName = "Direccion";
            if (fgMae.Col == 4) _colName = "Distrito";
            if (fgMae.Col == 5) _colName = "DireccionCasa";
            if (fgMae.Col == 6) _colName = "CodigoDistritoCasa";
            if (fgMae.Col == 7) _colName = "DNI";
            if (fgMae.Col == 8) _colName = "Telefono";
            if (fgMae.Col == 9) _colName = "Celular";
            if (fgMae.Col == 10) _colName = "Email";
            if (fgMae.Col == 11) _colName = "Email2";
            if (fgMae.Col == 12) _colName = "FechaNacimiento";
            if (fgMae.Col == 13) _colName = "CodigoProfesion";
            if (fgMae.Col == 14) _colName = "Compania";
            if (fgMae.Col == 15) _colName = "CargoProfesion";
            if (fgMae.Col == 16) _colName = "CodigoResponsabilidad";
            if (fgMae.Col == 17) _colName = "TelfTrabajo";
            if (fgMae.Col == 18) _colName = "CodigoTipoContacto";
            if (fgMae.Col == 19) _colName = "CodigoCategoria";
            if (fgMae.Col == 20) _colName = "Inactivo";

            return _colName;
        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            this._estReg = true;
            this.Man_Contactos_Botones(this.btnMod);
        }

        private void btnGua_Click(object sender, EventArgs e)
        {
            this.Man_Contactos_Botones(this.btnGua);
        }

        private void Man_Contactos_TexPre()
        {
            //texto prederminado
            this.txtCodDis.Text = "0";
            this.txtDis.Text = "(Sin Especificar)";
            this.txtCodDis2.Text = "0";
            this.txtDis2.Text = "(Sin Especificar)";
            this.txtNom.Focus();
        }

        private void Man_Contactos_Botones(Button btn)
        {
            switch (btn.Text)
            {
                case "&Nuevo":
                    {
                        /******************************************
                        * Nombre: "Boton nuevo"
                        * Proposito: <"Habilita el estado de los botones,limpia los textos y muestra el texto predeterminado">
                        * Output: <>
                        * Creado por: Ruben C.
                        *****************************************/

                        //valida el acceso del usuario
                        if (MetGlo.GEN_AccByDoc(VarGlo.Instance().CodUsuAct,5,"Nue",0) == 1)
                        {
                            this.Man_Contactos_EstBot("nuevo");
                            this.Man_Contactos_IsSoloLectura(false);
                            this.Man_Contactos_LimTex();
                            this.Man_Contactos_TexPre();
                            this.gpbBot.Enabled = false;
                        }
                        else
                        {
                            this._msg = "No cuenta con acceso para realizar esta operación,comuniquese con el administrador.";
                            this.Man_Contactos_MosMsgStrip(this._msg,Color.Red);
                        }
                    }
                    break;

                case "&Modificar":
                    {
                        /******************************************
                        * Nombre: "Boton modificar"
                        * Proposito: <"Habilita los textbox y los botones">
                        * Output: <>
                        * Creado por: Ruben C.
                        *****************************************/

                        //valida el acceso del usuario
                        if (MetGlo.GEN_AccByDoc(VarGlo.Instance().CodUsuAct,5,"Mod",0) == 1)
                        {
                            this.Man_Contactos_IsSoloLectura(false);
                            this.Man_Contactos_EstBot("modificar");
                            this.gpbBot.Enabled = false;
                        }
                        else
                        {
                            this._msg = "No cuenta con acceso para realizar esta operación,comuniquese con el administrador.";
                            this.Man_Contactos_MosMsgStrip(this._msg, Color.Red);
                        }
                    }
                    break;

                case "&Guardar":
                    {
                        /******************************************
                         * Nombre: "Boton guardar"
                         * Proposito: <"Guarda el nuevo contacto validando las cajas de textos">
                         * Output: <Recupera el codigo del nuevo contacto>
                         * Creado por: Ruben C.
                         *****************************************/
                        string msg = "";

                        frmPri fPri = (frmPri)this.MdiParent;
                        fPri.tmrMsg.Enabled = true;

                        var lbl = fPri.tlsLblMen;

                        if (this.txtNom.Text == "")
                        {
                            Man_Contactos_MosMsgStrip("Ingrese el nombre.",Color.Red);
                            this.txtNom.Focus();
                        }
                        else if (this.txtDirOfc.Text == "")
                        {
                            Man_Contactos_MosMsgStrip("Ingrese la dirección de oficina.", Color.Red);
                            this.txtDirOfc.Focus();
                        }
                        else if (this.txtCodDis.Text == "")
                        {
                            Man_Contactos_MosMsgStrip("Ingrese el distrito.", Color.Red);
                            this.txtDis.Focus();
                        }
                        else if (this.txtCodCat.Text == "")
                        {
                            Man_Contactos_MosMsgStrip("Ingrese una categoria.", Color.Red);
                            this.txtCat.Focus();
                        }
                        else if (this.txtCodTipCon.Text == "")
                        {
                            Man_Contactos_MosMsgStrip("Ingrese un tipo de contacto.", Color.Red);
                            this.txtTipCon.Focus();
                        }
                        else if (this.txtCodRes.Text == "")
                        {
                            Man_Contactos_MosMsgStrip("Ingrese una responsabilidad.", Color.Red);
                            this.txtRes.Focus();
                        }
                        else
                        {
                            //Asignando valores a la entidad
                            Man_Contactos_Enc con = new Man_Contactos_Enc()
                            {
                                acc = this._estReg,
                                nom = this.txtNom.Text,
                                ape = this.txtApe.Text,
                                dir = this.txtDirOfc.Text,
                                dirCas = this.txtDirCas.Text,
                                tel = this.txtTelPar.Text,
                                cel = this.txtCel.Text,
                                ema = this.txtEma1.Text,
                                ema2 = this.txtEma2.Text,
                                com = this.txtCom.Text,
                                carPro = this.txtCar.Text,
                                telTra = this.txtTelTra.Text,
                                fecC = DateTime.Now.Date,
                                codUsuC = Convert.ToInt16(varglo.CodUsuAct),
                                fecM = DateTime.Now.Date,
                                codUsuM = Convert.ToInt16(varglo.CodUsuAct),
                                codTipCon = Convert.ToInt16(this.txtCodTipCon.Text),
                                fecN = this.txtFecNac.Text,
                                ruc = this.txtRuc.Text,
                                dni = this.txtDni.Text,
                                conAct = Convert.ToInt16(this.chkIna.Checked),
                                ctaDet = this.txtCtaDtr.Text,

                                //validando las variables en una linea
                                dis = Convert.ToInt16(this.txtCodDis.Text == "" ? 0 : 
                                      Convert.ToInt16(this.txtCodDis.Text)),

                                codCon = Convert.ToInt32(this.txtCodCon.Text == "" ? 0 : 
                                         Convert.ToInt32(this.txtCodCon.Text)),
                                codDisCas = Convert.ToInt16(this.txtCodDis2.Text == "" ? 0 : 
                                            Convert.ToInt16(this.txtCodDis2.Text)),

                                codPro = Convert.ToInt16(this.txtCodPro.Text == "" ? 0 : 
                                         Convert.ToInt16(this.txtCodPro.Text)),

                                codRes = Convert.ToInt16(this.txtCodRes.Text == "" ? 0 : 
                                         Convert.ToInt16(this.txtCodRes.Text)),

                                codTipCia = Convert.ToInt32(this.txtCodCat.Text == "" ? 0 : 
                                            Convert.ToInt32(this.txtCodCat.Text)),
                            };

                            //Ejecutamos la consulta
                            this.manCon.Man_Contactos_UpdGuaCon(con);

                            //Obtien el nuevo codigo
                            this.txtCodCon.Text = con.codCon.ToString();
                            this.Man_Contactos_EstBot("guardar");

                            //Muestra si el mensaje se actualizara o se agrega uno nuevo
                            if (!this._estReg)
                            {
                                this.Man_Contactos_MosMsgStrip("Se registro correctamente.", Color.Green);
                            }
                            else
                            {
                                this.Man_Contactos_MosMsgStrip("Se actulizo correctamente.", Color.Green);
                            }

                            this.Man_Contactos_IsSoloLectura(true);
                            this.Man_Contactos_RecRecom();
                            this.gpbBot.Enabled = true;
                            this._estReg = false;
                        }
                    }
                    break;

                case "&Borrar":
                    {
                        /******************************************
                         * Nombre: "Boton borrar"
                         * Proposito: <"Elimina el registro,actuliza el grid recomendadores con los nuevos datos
                         *            deshabilita los botones y pasa al siguiente o anterior registro validando la respuesta">
                         * Output: <>
                         * Creado por: Ruben C.
                         *****************************************/

                        //valida el acceso del usuario
                        if (MetGlo.GEN_AccByDoc(VarGlo.Instance().CodUsuAct,5,"Eli",0) == 1)
                        {
                            //Valida la respuesta
                            DialogResult msg = MessageBox.Show("¿Esta seguro que desea eliminar?", "Mensaje del sistema",
                                                                        MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                            if (msg == DialogResult.Yes)
                            {
                                //Borra registro con el id que esta en el textbox
                                this.manCon.Man_Contactos_EliRecom(Convert.ToInt32(this.txtCodCon.Text));
                                this.Man_Contactos_RecRecom();
                                this.Man_Contactos_EstBot("borrar");
                                this.Man_Contactos_MosMsgStrip("Se elimino correctamente.", Color.Green);
                                this.btnPri.PerformClick();
                                this._estReg = false;
                            }
                        }
                        else
                        {
                            this._msg = "No cuenta con acceso para realizar esta operación,comuniquese con el administrador.";
                            this.Man_Contactos_MosMsgStrip(_msg,Color.Red);
                        }
                    }
                    break;

                case "&Cancelar":
                    {
                      /******************************************
                       * Nombre: "Boton cancelar"
                       * Proposito: <"Cambia el estado de los botones,limpiar los textos y se establece en solo lectura
                       *              pasando al primer registro">
                       * Output: <>
                       * Creado por: Ruben C.
                       *****************************************/

                        this.Man_Contactos_EstBot("cancelar");
                        this.Man_Contactos_LimTex();
                        this.Man_Contactos_IsSoloLectura(true);
                        this.gpbBot.Enabled = true;
                        this._estReg = false;

                        DataTable dtFilCon = null;
                        dtFilCon = manCon.Man_Contactos_FilRecom(-1, "");

                        if (dtFilCon.Rows.Count == 0)
                        {
                            this._msg = "No hay registros,agregue uno nuevo o cierre la ventana.";
                            this.Man_Contactos_MosMsgStrip(this._msg,Color.DodgerBlue);
                        }

                        this.btnPri.PerformClick();
                    }
                    break;

                case "Cerrar":
                    {
                        this.Close();
                    }
                    break;

                case "&Vista previa":
                    {
                        /******************************************
                       * Nombre: "Vista previa"
                       * Proposito: <"Visualizar los datos con el id del recomendador,validando su codigo">
                       * Output: <Mostrar todos los datos del recomendado en el reporte>
                       * Creado por: Ruben C.
                       *****************************************/
                        int codCon = 0;
                        codCon = Convert.ToInt32(this.txtCodCon.Text);

                        rptManContactos_Impresion rpt = new rptManContactos_Impresion();
                        rpt.SetParameterValue("@Codigo", codCon);

                        if (this.manCon.Man_Contactos_ValCodCon(codCon) != 0)
                        {
                            rpt.SetParameterValue("@CantCotApro", codCon);
                        }
                        else
                        {
                            rpt.SetParameterValue("@CantCotApro", 0);
                        }

                        MetGlo.CRVisPre(rpt);
                    }
                    break;

                case "Primero":
                    {
                        //Visualiza los datos en los textos del primer boton del recomendador
                        int codCon = 0;
                        codCon = Convert.ToInt32(this.txtCodCon.Text == "" ? 0 : Convert.ToInt32(this.txtCodCon.Text));
                        this.Man_Contactos_RecDatRecom(0, codCon);
                    }
                    break;

                case "Retroceder":
                    {
                        //Visualiza los datos en los textos del anterior boton del recomendador
                        int codCon = 0;
                        codCon = Convert.ToInt32(this.txtCodCon.Text == "" ? 0 : Convert.ToInt32(this.txtCodCon.Text));
                        this.Man_Contactos_RecDatRecom(1, codCon);
                    }
                    break;

                case "Avanzar":
                    {
                        //Visualiza los datos en los textos del siguiente boton del recomendador
                        int codCon = 0;
                        codCon = Convert.ToInt32(this.txtCodCon.Text == "" ? 0 : Convert.ToInt32(this.txtCodCon.Text));
                        this.Man_Contactos_RecDatRecom(2, codCon);
                    }
                    break;

                case "Ultimo":
                    {
                        //Visualiza los datos en los textos del el ultimo boton del recomendador
                        int codCon = 0;
                        codCon = Convert.ToInt32(this.txtCodCon.Text == "" ? 0 : Convert.ToInt32(this.txtCodCon.Text));
                        this.Man_Contactos_RecDatRecom(3, codCon);
                    }
                    break;

                default:
                    break;
            }
        }


        private void btnCer_Click(object sender, EventArgs e)
        {
            this.Man_Contactos_Botones(btnCer);
        }

        private void btnBor_Click(object sender, EventArgs e)
        {
            this.Man_Contactos_Botones(this.btnBor);
        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }

      
        private void Man_Contactos_EstBot(string btnEst)
        {
            //Estado de los botones

            bool[] estM = { true };

            switch (btnEst)
            {
                case "carga":
                case "cancelar":
                case "guardar":
                case "borrar":
                    {
                        estM = matriz(true, true, false, true, true, true,true);
                    }
                    break;

                case "nuevo":
                case "modificar":
                    {
                        estM = matriz(false, false, true, false, true, false, false);
                    }
                    break;
            }

            this.btnNue.Enabled = estM[0];
            this.btnMod.Enabled = estM[1];
            this.btnGua.Enabled = estM[2];
            this.btnBor.Enabled = estM[3];
            this.btnCan.Enabled = estM[4];
            this.btnCer.Enabled = estM[5];
            this.btnVisPre.Enabled = estM[6];
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            this.Man_Contactos_Botones(this.btnCan);
        }

        private void btnVisPre_Click(object sender, EventArgs e)
        {
            this.Man_Contactos_Botones(this.btnVisPre);
        }

        private void Man_Contactos_RecDatRecom(Int16 index, int codCon)
        {
            DataTable dtRecRecom = null;
            dtRecRecom = this.manCon.Man_Contactos_RecDatRecom(index,codCon);

            //Valida el boton retroceder si llego al ultimo registro
            if (dtRecRecom.Rows.Count == 0 & index == 1 )
            {
                this.btnPri.PerformClick();
                return;
            }

            //Valida el boton avanzar si llego al primer registro 
            if (dtRecRecom.Rows.Count == 0 & index == 2)
            {
                this.btnUlt.PerformClick();
                return;
            }

            //validamos si no hay datos en el grid y el indice es 0
            if (dtRecRecom.Rows.Count == 0 & index == 0) 
            {
                this.btnNue.PerformClick();
                return;
            }

            if (dtRecRecom.Rows.Count > 0)
            {
                //Asignamos los datos a las cajas de texto
                this.txtCodCon.Text = dtRecRecom.Rows[0]["Codigo"].ToString();
                this.chkIna.Checked = Convert.ToBoolean(dtRecRecom.Rows[0]["Inactivo"]);
                this.txtNom.Text = dtRecRecom.Rows[0]["Nombres"].ToString();
                this.txtApe.Text = dtRecRecom.Rows[0]["Apellidos"].ToString();
                this.txtDirOfc.Text = dtRecRecom.Rows[0]["Direccion"].ToString();
                this.txtCodDis.Text = dtRecRecom.Rows[0]["CodigoDistrito"].ToString();
                this.txtDis.Text = dtRecRecom.Rows[0]["Distrito"].ToString();
                this.txtDirCas.Text = dtRecRecom.Rows[0]["DireccionCasa"].ToString();
                this.txtCodDis2.Text = dtRecRecom.Rows[0]["CodigoDistritoCasa"].ToString();
                this.txtDis2.Text = dtRecRecom.Rows[0]["DistritoCasa"].ToString();
                this.txtTelPar.Text = dtRecRecom.Rows[0]["Telefono"].ToString();
                this.txtTelTra.Text = dtRecRecom.Rows[0]["TelfTrabajo"].ToString();
                this.txtCel.Text = dtRecRecom.Rows[0]["Celular"].ToString();
                this.txtFecNac.Text = dtRecRecom.Rows[0]["FechaNacimiento"].ToString();
                this.txtEma1.Text = dtRecRecom.Rows[0]["Email"].ToString();
                this.txtEma2.Text = dtRecRecom.Rows[0]["Email2"].ToString();
                this.txtCodPro.Text = dtRecRecom.Rows[0]["CodigoProfesion"].ToString();
                this.txtPro.Text = dtRecRecom.Rows[0]["Profesion"].ToString();
                this.txtCodTipCon.Text = dtRecRecom.Rows[0]["CodigoTipoContacto"].ToString();
                this.txtTipCon.Text = dtRecRecom.Rows[0]["TipoContacto"].ToString();
                this.txtCom.Text = dtRecRecom.Rows[0]["Compania"].ToString();
                this.txtCar.Text = dtRecRecom.Rows[0]["Cargo"].ToString();
                this.txtCodRes.Text = dtRecRecom.Rows[0]["CodigoResponsabilidad"].ToString();
                this.txtRes.Text = dtRecRecom.Rows[0]["Responsabilidad"].ToString();
                this.txtCodCat.Text = dtRecRecom.Rows[0]["CodigoCategoria"].ToString();
                this.txtCat.Text = dtRecRecom.Rows[0]["Categoria"].ToString();
                this.txtRuc.Text = dtRecRecom.Rows[0]["RUC"].ToString();
                this.txtDni.Text = dtRecRecom.Rows[0]["DNI"].ToString();
                this.txtCtaDtr.Text = dtRecRecom.Rows[0]["CtaDetraccion"].ToString();

                //Pasamos los parametros al finrow para poder desaplazarnos con el id del recomendador
                this.fgMae.Row = this.fgMae.FindRow(this.txtCodCon.Text,
                                                    0,
                                                    2,
                                                    false,
                                                    false,
                                                    false);
            }
        }

        private void btnPri_Click(object sender, EventArgs e)
        {
            this._index = 0;
            this.Man_Contactos_Botones(btnPri);
        }

        private void btnRet_Click(object sender, EventArgs e)
        {
            this._index = 1;
            this.Man_Contactos_Botones(btnRet);
        }

        private void btnAva_Click(object sender, EventArgs e)
        {
            this._index = 2;
            this.Man_Contactos_Botones(btnAva);
        }

        private void btnUlt_Click(object sender, EventArgs e)
        {
            this._index = 3;
            this.Man_Contactos_Botones(btnUlt);
        }

        private void tabManCon_Selecting(object sender, TabControlCancelEventArgs e)
        {
            //Valida que solo se puede pasar al 2 tabPages cuando no se este modificando ni agregando uno nuevo
            if (!this.btnMod.Enabled | !this.btnNue.Enabled) 
            {
                //valida cuando hace click en la pestaña
                if (this.tabManCon.SelectedTab == this.tabManCon.TabPages[1]) 
                {
                    //se posiciona en el primer tabpages
                    this.tabManCon.SelectedTab = this.tabManCon.TabPages[0];
                    this.txtNom.Focus();

                    this._msg = "No se puede pasar a la siguiente vista mientras de edita o se ingresa un nuevo recomendador.";
                    Man_Contactos_MosMsgStrip(this._msg, Color.DodgerBlue);
                }
            }
        }

        private void Man_Contactos_MosMsgStrip(string msg,Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }

        private void Man_Contactos_Filtro(string vista, string procedimiento, string prm)
        {
            /******************************************
            * Nombre: "Filtro de contactos"
            * Proposito: <"Filtrar los datos al presionar enter en los textos establecidos>
            * Output: <Mostrar los datos al seleccionar la fila del filtro>
            * Creado por: Ruben C.
            *****************************************/
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtFil = new DataTable();
            dtFil = this.manCon.Man_Contactos_Filtro(vista, procedimiento, prm);

            if (dtFil.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 23;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFil;
                frm.Man_Contactos = this;
                frm.ShowDialog();
            }
            else if (dtFil.Rows.Count == 1)
            {
                DataRow row = dtFil.Rows[0];

                switch (vista)
                {
                    case "Distrito":
                        {
                            this.txtCodDis.Text = row["Codigo"].ToString();
                            this.txtDis.Text = row["Distrito"].ToString();
                            this.txtDirCas.Focus();
                        }
                        break;

                    case "Distrito2":
                        {
                            this.txtCodDis2.Text = row["Codigo"].ToString();
                            this.txtDis2.Text = row["Distrito"].ToString();
                            this.txtTelPar.Focus();
                        }
                        break;

                    case "Profesion":
                        {
                            this.txtCodPro.Text = row["Codigo"].ToString();
                            this.txtPro.Text = row["Profesion"].ToString();
                            this.txtTipCon.Focus();
                        }
                        break;

                    case "TipoContacto":
                        {
                            this.txtCodTipCon.Text = row["Codigo"].ToString();
                            this.txtTipCon.Text = row["TipoContacto"].ToString();
                            this.txtCom.Focus();
                        }
                        break;

                    case "Responsabilidad":
                        {
                            this.txtCodRes.Text = row["Codigo"].ToString();
                            this.txtRes.Text = row["Responsabilidad"].ToString();
                            this.txtCat.Focus();
                        }
                        break;

                    case "Categoria":
                        {
                            this.txtCodCat.Text = row["Codigo"].ToString();
                            this.txtCat.Text = row["Categoria"].ToString();
                            this.txtRuc.Focus();
                        }
                        break;

                    default:
                        break;
                }
            }
            else if (dtFil.Rows.Count == 0)
            {
                varglo.Elegi = false;
                this.Man_Contactos_MosMsgStrip("No se encontraron registros.", Color.Red);
            }

            Cursor.Current = Cursors.Default;
        }

        private void txtDis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Man_Contactos_Filtro("Distrito","MantenimientoCliente_Distrito",this.txtDis.Text);
            }
        }

        public void RecDat_Dis(string codDis, string dis)
        {
            //Interfaces que recuperan los datos a lahora de seleccionar un fila del grid filtrado
            this.txtCodDis.Text = codDis;
            this.txtDis.Text = dis;
           
        }

        public void RecDat_Dis2(string codDis, string dis)
        {
            //Interfaces que recuperan los datos a lahora de seleccionar un fila del grid filtrado
            this.txtCodDis2.Text = codDis;
            this.txtDis2.Text = dis;
        }

        public void RecDat_Pro(string codPro, string pro)
        {
            //Interfaces que recuperan los datos a lahora de seleccionar un fila del grid filtrado
            this.txtCodPro.Text = codPro;
            this.txtPro.Text = pro;
        }

        public void RecDat_TipCon(string codTipCon, string tipCon)
        {
            //Interfaces que recuperan los datos a lahora de seleccionar un fila del grid filtrado
            this.txtCodTipCon.Text = codTipCon;
            this.txtTipCon.Text = tipCon;
        }

        public void RecDat_Res(string codRes, string res)
        {
            //Interfaces que recuperan los datos a lahora de seleccionar un fila del grid filtrado
            this.txtCodRes.Text = codRes;
            this.txtRes.Text = res;
        }

        public void RecDat_Cat(string codCat, string cat)
        {
            //Interfaces que recuperan los datos a lahora de seleccionar un fila del grid filtrado
            this.txtCodCat.Text = codCat;
            this.txtCat.Text = cat;
        }

        private void txtDis2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Man_Contactos_Filtro("Distrito2", "MantenimientoCliente_Distrito", this.txtDis2.Text);
            }
        }

        private void txtPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Man_Contactos_Filtro("Profesion", "Filtro_Profesion", this.txtPro.Text);
            }
        }

        private void txtTipCon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Man_Contactos_Filtro("TipoContacto", "Filtro_Contactos_Tipo", this.txtTipCon.Text);
            }
        }

        private void txtRes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Man_Contactos_Filtro("Responsabilidad","Filtro_Responsabilidad", this.txtRes.Text);
            }
        }

        private void txtCat_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Man_Contactos_Filtro("Categoria", "Filtro_Contactos_Categoria", this.txtCat.Text);
            }
        }

        private void txtCodCon_KeyPress(object sender, KeyPressEventArgs e)
        {
            Man_Contactos_EveKeyPres(txtNom,e);
        }

        private void Man_Contactos_EveKeyPres(Control tex,KeyPressEventArgs e)
        {
            //evento keypress para pasar el foco al apretar enter
            if (e.KeyChar == (char)13)
            {
                tex.Focus();
            }
        }

        private void txtNom_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtApe, e);
        }

        private void txtApe_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtDirOfc, e);
        }

        private void txtDirOfc_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtDis, e);
        }

        private void txtDirCas_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtDis2, e);
        }

        private void txtTelPar_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtTelTra, e);
        }

        private void txtTelTra_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtCel, e);
        }

        private void txtCel_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtFecNac, e);
        }

        private void txtFecNac_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtEma1, e);
        }

        private void txtEma1_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtEma2, e);
        }

        private void txtEma2_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtPro, e);
        }

        private void txtCom_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtCar, e);
        }

        private void txtCar_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtRes, e);
        }

        private void txtRuc_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtDni, e);
        }

        private void txtDni_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.txtCtaDtr, e);
        }

        private void txtCtaDtr_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Man_Contactos_EveKeyPres(this.btnPri, e);
        }

        private void fgMae_DoubleClick(object sender, EventArgs e)
        {
            /*Muestra los datos en los textbox en el primer tabPages del
              tab control al hacer doble click en el grid  */

            int codCon = 0;
            codCon = (int)this.fgMae.Rows[this.fgMae.RowSel][0];

            this.tabManCon.SelectedTab = this.tabManCon.TabPages[0];
            this.Man_Contactos_RecDatRecom(4, codCon);
        }
    }
}
