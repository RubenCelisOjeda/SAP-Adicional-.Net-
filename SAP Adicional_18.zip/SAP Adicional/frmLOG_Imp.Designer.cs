﻿namespace SAP_Adicional
{
    partial class frmLOG_Imp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLOG_Imp));
            this.tspImp = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.btnAbrir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.btnDeshacer = new System.Windows.Forms.ToolStripButton();
            this.btnModificar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAnu = new System.Windows.Forms.ToolStripButton();
            this.btnPro = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnOc = new System.Windows.Forms.ToolStripButton();
            this.btnTra = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSitImp = new System.Windows.Forms.ToolStripButton();
            this.tabComImpOtr = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabConArtCom = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.fgSinCod = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.fgCom = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.fgArt = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.lblUltUsu = new System.Windows.Forms.Label();
            this.gpbArt = new System.Windows.Forms.GroupBox();
            this.btnModIte = new System.Windows.Forms.Button();
            this.btnCanIte = new System.Windows.Forms.Button();
            this.btnBorIte = new System.Windows.Forms.Button();
            this.btnAgrIte = new System.Windows.Forms.Button();
            this.mkbFecEntPro = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCosArt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCanArt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtImp = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCat = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDesArt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCodArt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.gpbUltUsu = new System.Windows.Forms.GroupBox();
            this.txtDesMon = new System.Windows.Forms.TextBox();
            this.txtCodMon = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.mkbEta = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.mkbEtd = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.mkbFecLLe = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDesEstPag = new System.Windows.Forms.TextBox();
            this.txtCodEstPag = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDesEnv = new System.Windows.Forms.TextBox();
            this.txtDesPro = new System.Windows.Forms.TextBox();
            this.txtCodEnv = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodPro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gpbInc = new System.Windows.Forms.GroupBox();
            this.rdbFob = new System.Windows.Forms.RadioButton();
            this.rdbExWor = new System.Windows.Forms.RadioButton();
            this.gpbLal = new System.Windows.Forms.GroupBox();
            this.txtDesLab = new System.Windows.Forms.TextBox();
            this.gpbPayTer = new System.Windows.Forms.GroupBox();
            this.txtDesPayTer = new System.Windows.Forms.TextBox();
            this.gpbShiDet = new System.Windows.Forms.GroupBox();
            this.txtConPer = new System.Windows.Forms.TextBox();
            this.txtPhoDet = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txtEma = new System.Windows.Forms.TextBox();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txtFaxDet = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtFwd = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.gpbShiInf = new System.Windows.Forms.GroupBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtUltDes = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtPho = new System.Windows.Forms.TextBox();
            this.txtCouImp = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtCon = new System.Windows.Forms.TextBox();
            this.txtVia = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtInvTo = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtOrdDat = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.gpbOtrDat = new System.Windows.Forms.GroupBox();
            this.cboLey = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.chkEnvInt = new System.Windows.Forms.CheckBox();
            this.mkbOtrFecEntPro = new System.Windows.Forms.MaskedTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtOtrNumImp = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtCodImp = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtTra = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtNomBar = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.mkbFecDisDes = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtNumImp = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtFecEmi = new System.Windows.Forms.TextBox();
            this.tspImp.SuspendLayout();
            this.tabComImpOtr.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabConArtCom.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgSinCod)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCom)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArt)).BeginInit();
            this.gpbArt.SuspendLayout();
            this.gpbUltUsu.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.gpbInc.SuspendLayout();
            this.gpbLal.SuspendLayout();
            this.gpbPayTer.SuspendLayout();
            this.gpbShiDet.SuspendLayout();
            this.gpbShiInf.SuspendLayout();
            this.gpbOtrDat.SuspendLayout();
            this.SuspendLayout();
            // 
            // tspImp
            // 
            this.tspImp.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tspImp.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.btnAbrir,
            this.toolStripSeparator1,
            this.btnGuardar,
            this.btnDeshacer,
            this.btnModificar,
            this.toolStripSeparator2,
            this.btnAnu,
            this.btnPro,
            this.toolStripSeparator3,
            this.btnOc,
            this.btnTra,
            this.toolStripSeparator4,
            this.btnSitImp});
            this.tspImp.Location = new System.Drawing.Point(0, 0);
            this.tspImp.Name = "tspImp";
            this.tspImp.Size = new System.Drawing.Size(1314, 36);
            this.tspImp.TabIndex = 2;
            this.tspImp.Text = "toolStrip1";
            // 
            // btnNuevo
            // 
            this.btnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("btnNuevo.Image")));
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.btnNuevo.Size = new System.Drawing.Size(42, 33);
            this.btnNuevo.Text = "&Nuevo";
            this.btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnAbrir
            // 
            this.btnAbrir.Image = ((System.Drawing.Image)(resources.GetObject("btnAbrir.Image")));
            this.btnAbrir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAbrir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(34, 33);
            this.btnAbrir.Text = "&Abrir";
            this.btnAbrir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAbrir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbrir.Click += new System.EventHandler(this.btnAbrir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 36);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(50, 33);
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnDeshacer
            // 
            this.btnDeshacer.Image = ((System.Drawing.Image)(resources.GetObject("btnDeshacer.Image")));
            this.btnDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDeshacer.Name = "btnDeshacer";
            this.btnDeshacer.Size = new System.Drawing.Size(56, 33);
            this.btnDeshacer.Text = "&Deshacer";
            this.btnDeshacer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDeshacer.Click += new System.EventHandler(this.btnDeshacer_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(54, 33);
            this.btnModificar.Text = "&Modificar";
            this.btnModificar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 36);
            // 
            // btnAnu
            // 
            this.btnAnu.Image = ((System.Drawing.Image)(resources.GetObject("btnAnu.Image")));
            this.btnAnu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAnu.Name = "btnAnu";
            this.btnAnu.Size = new System.Drawing.Size(42, 33);
            this.btnAnu.Text = "&Anular";
            this.btnAnu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAnu.Click += new System.EventHandler(this.btnAnu_Click);
            // 
            // btnPro
            // 
            this.btnPro.Image = ((System.Drawing.Image)(resources.GetObject("btnPro.Image")));
            this.btnPro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPro.Name = "btnPro";
            this.btnPro.Size = new System.Drawing.Size(53, 33);
            this.btnPro.Text = "&Procesar";
            this.btnPro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPro.Click += new System.EventHandler(this.btnPro_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 36);
            // 
            // btnOc
            // 
            this.btnOc.Image = ((System.Drawing.Image)(resources.GetObject("btnOc.Image")));
            this.btnOc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOc.Name = "btnOc";
            this.btnOc.Size = new System.Drawing.Size(56, 33);
            this.btnOc.Text = "     &OC     ";
            this.btnOc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnOc.Click += new System.EventHandler(this.btnOc_Click);
            // 
            // btnTra
            // 
            this.btnTra.Image = ((System.Drawing.Image)(resources.GetObject("btnTra.Image")));
            this.btnTra.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTra.Name = "btnTra";
            this.btnTra.Size = new System.Drawing.Size(63, 33);
            this.btnTra.Text = "&Traducción";
            this.btnTra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnTra.Click += new System.EventHandler(this.btnTra_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 36);
            // 
            // btnSitImp
            // 
            this.btnSitImp.Image = ((System.Drawing.Image)(resources.GetObject("btnSitImp.Image")));
            this.btnSitImp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSitImp.Name = "btnSitImp";
            this.btnSitImp.Size = new System.Drawing.Size(52, 33);
            this.btnSitImp.Text = "&Sit. Imp.";
            this.btnSitImp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSitImp.Click += new System.EventHandler(this.btnSitImp_Click);
            // 
            // tabComImpOtr
            // 
            this.tabComImpOtr.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabComImpOtr.Controls.Add(this.tabPage1);
            this.tabComImpOtr.Controls.Add(this.tabPage2);
            this.tabComImpOtr.Location = new System.Drawing.Point(6, 42);
            this.tabComImpOtr.Multiline = true;
            this.tabComImpOtr.Name = "tabComImpOtr";
            this.tabComImpOtr.SelectedIndex = 0;
            this.tabComImpOtr.Size = new System.Drawing.Size(1045, 536);
            this.tabComImpOtr.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabConArtCom);
            this.tabPage1.Controls.Add(this.lblUltUsu);
            this.tabPage1.Controls.Add(this.gpbArt);
            this.tabPage1.Controls.Add(this.gpbUltUsu);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1037, 507);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Importación";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabConArtCom
            // 
            this.tabConArtCom.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabConArtCom.Controls.Add(this.tabPage3);
            this.tabConArtCom.Controls.Add(this.tabPage4);
            this.tabConArtCom.Controls.Add(this.tabPage5);
            this.tabConArtCom.Location = new System.Drawing.Point(6, 271);
            this.tabConArtCom.Multiline = true;
            this.tabConArtCom.Name = "tabConArtCom";
            this.tabConArtCom.SelectedIndex = 0;
            this.tabConArtCom.Size = new System.Drawing.Size(1010, 228);
            this.tabConArtCom.TabIndex = 23;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.fgSinCod);
            this.tabPage3.Location = new System.Drawing.Point(24, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(982, 220);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Sin codigo";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // fgSinCod
            // 
            this.fgSinCod.AllowFiltering = true;
            this.fgSinCod.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgSinCod.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgSinCod.Location = new System.Drawing.Point(1, 0);
            this.fgSinCod.Name = "fgSinCod";
            this.fgSinCod.Rows.DefaultSize = 19;
            this.fgSinCod.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgSinCod.Size = new System.Drawing.Size(993, 220);
            this.fgSinCod.TabIndex = 27;
            this.fgSinCod.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgSinCod_StartEdit);
            this.fgSinCod.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgSinCod_AfterEdit);
            this.fgSinCod.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgSinCod_KeyPressEdit);
            this.fgSinCod.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgSinCod_KeyDown);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.fgCom);
            this.tabPage4.Location = new System.Drawing.Point(24, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(982, 220);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Componentes";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // fgCom
            // 
            this.fgCom.AllowEditing = false;
            this.fgCom.AllowFiltering = true;
            this.fgCom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgCom.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgCom.Enabled = false;
            this.fgCom.Location = new System.Drawing.Point(1, 0);
            this.fgCom.Name = "fgCom";
            this.fgCom.Rows.DefaultSize = 19;
            this.fgCom.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgCom.Size = new System.Drawing.Size(993, 224);
            this.fgCom.TabIndex = 26;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.fgArt);
            this.tabPage5.Location = new System.Drawing.Point(24, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(982, 220);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Articulos";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // fgArt
            // 
            this.fgArt.AllowFiltering = true;
            this.fgArt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgArt.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgArt.Location = new System.Drawing.Point(1, 0);
            this.fgArt.Name = "fgArt";
            this.fgArt.Rows.DefaultSize = 19;
            this.fgArt.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgArt.Size = new System.Drawing.Size(995, 224);
            this.fgArt.TabIndex = 25;
            this.fgArt.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgArt_AfterEdit);
            this.fgArt.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgArt_KeyPressEdit);
            // 
            // lblUltUsu
            // 
            this.lblUltUsu.AutoSize = true;
            this.lblUltUsu.ForeColor = System.Drawing.Color.Blue;
            this.lblUltUsu.Location = new System.Drawing.Point(8, 6);
            this.lblUltUsu.Name = "lblUltUsu";
            this.lblUltUsu.Size = new System.Drawing.Size(78, 13);
            this.lblUltUsu.TabIndex = 24;
            this.lblUltUsu.Text = "Ultimo usuario:";
            // 
            // gpbArt
            // 
            this.gpbArt.Controls.Add(this.btnModIte);
            this.gpbArt.Controls.Add(this.btnCanIte);
            this.gpbArt.Controls.Add(this.btnBorIte);
            this.gpbArt.Controls.Add(this.btnAgrIte);
            this.gpbArt.Controls.Add(this.mkbFecEntPro);
            this.gpbArt.Controls.Add(this.label15);
            this.gpbArt.Controls.Add(this.txtObs);
            this.gpbArt.Controls.Add(this.label14);
            this.gpbArt.Controls.Add(this.txtCosArt);
            this.gpbArt.Controls.Add(this.label13);
            this.gpbArt.Controls.Add(this.txtCanArt);
            this.gpbArt.Controls.Add(this.label12);
            this.gpbArt.Controls.Add(this.txtImp);
            this.gpbArt.Controls.Add(this.label11);
            this.gpbArt.Controls.Add(this.txtCat);
            this.gpbArt.Controls.Add(this.label10);
            this.gpbArt.Controls.Add(this.txtDesArt);
            this.gpbArt.Controls.Add(this.label9);
            this.gpbArt.Controls.Add(this.txtCodArt);
            this.gpbArt.Controls.Add(this.label8);
            this.gpbArt.Location = new System.Drawing.Point(8, 119);
            this.gpbArt.Name = "gpbArt";
            this.gpbArt.Size = new System.Drawing.Size(913, 146);
            this.gpbArt.TabIndex = 11;
            this.gpbArt.TabStop = false;
            this.gpbArt.Text = "Articulo";
            // 
            // btnModIte
            // 
            this.btnModIte.BackColor = System.Drawing.Color.White;
            this.btnModIte.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnModIte.Location = new System.Drawing.Point(298, 112);
            this.btnModIte.Name = "btnModIte";
            this.btnModIte.Size = new System.Drawing.Size(94, 28);
            this.btnModIte.TabIndex = 29;
            this.btnModIte.Text = "Modificar";
            this.btnModIte.UseVisualStyleBackColor = false;
            this.btnModIte.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // btnCanIte
            // 
            this.btnCanIte.BackColor = System.Drawing.Color.White;
            this.btnCanIte.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCanIte.Location = new System.Drawing.Point(205, 112);
            this.btnCanIte.Name = "btnCanIte";
            this.btnCanIte.Size = new System.Drawing.Size(94, 28);
            this.btnCanIte.TabIndex = 22;
            this.btnCanIte.Text = "Cancelar item";
            this.btnCanIte.UseVisualStyleBackColor = false;
            this.btnCanIte.Click += new System.EventHandler(this.btnCanIte_Click);
            // 
            // btnBorIte
            // 
            this.btnBorIte.BackColor = System.Drawing.Color.White;
            this.btnBorIte.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBorIte.Location = new System.Drawing.Point(112, 112);
            this.btnBorIte.Name = "btnBorIte";
            this.btnBorIte.Size = new System.Drawing.Size(94, 28);
            this.btnBorIte.TabIndex = 21;
            this.btnBorIte.Text = "&Borrar item";
            this.btnBorIte.UseVisualStyleBackColor = false;
            this.btnBorIte.Click += new System.EventHandler(this.btmBorIte_Click);
            // 
            // btnAgrIte
            // 
            this.btnAgrIte.BackColor = System.Drawing.Color.White;
            this.btnAgrIte.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgrIte.Location = new System.Drawing.Point(19, 112);
            this.btnAgrIte.Name = "btnAgrIte";
            this.btnAgrIte.Size = new System.Drawing.Size(94, 28);
            this.btnAgrIte.TabIndex = 20;
            this.btnAgrIte.Text = "Ag&regar item";
            this.btnAgrIte.UseVisualStyleBackColor = false;
            this.btnAgrIte.Click += new System.EventHandler(this.btnAgrIte_Click);
            // 
            // mkbFecEntPro
            // 
            this.mkbFecEntPro.Location = new System.Drawing.Point(740, 80);
            this.mkbFecEntPro.Mask = "00/00/0000";
            this.mkbFecEntPro.Name = "mkbFecEntPro";
            this.mkbFecEntPro.Size = new System.Drawing.Size(108, 21);
            this.mkbFecEntPro.TabIndex = 19;
            this.mkbFecEntPro.ValidatingType = typeof(System.DateTime);
            this.mkbFecEntPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mkbFecEntPro_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(637, 88);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(108, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "Fec. Ent. proveedor:";
            // 
            // txtObs
            // 
            this.txtObs.BackColor = System.Drawing.Color.White;
            this.txtObs.ForeColor = System.Drawing.Color.Blue;
            this.txtObs.Location = new System.Drawing.Point(365, 80);
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(270, 21);
            this.txtObs.TabIndex = 18;
            this.txtObs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtObs_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(339, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "Obs:";
            // 
            // txtCosArt
            // 
            this.txtCosArt.BackColor = System.Drawing.Color.White;
            this.txtCosArt.ForeColor = System.Drawing.Color.Blue;
            this.txtCosArt.Location = new System.Drawing.Point(233, 80);
            this.txtCosArt.Name = "txtCosArt";
            this.txtCosArt.Size = new System.Drawing.Size(100, 21);
            this.txtCosArt.TabIndex = 17;
            this.txtCosArt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCosArt_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(188, 88);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Costo U:";
            // 
            // txtCanArt
            // 
            this.txtCanArt.BackColor = System.Drawing.Color.White;
            this.txtCanArt.ForeColor = System.Drawing.Color.Blue;
            this.txtCanArt.Location = new System.Drawing.Point(66, 80);
            this.txtCanArt.Name = "txtCanArt";
            this.txtCanArt.Size = new System.Drawing.Size(94, 21);
            this.txtCanArt.TabIndex = 16;
            this.txtCanArt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCanArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCanArt_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Cant:";
            // 
            // txtImp
            // 
            this.txtImp.BackColor = System.Drawing.Color.DarkGray;
            this.txtImp.ForeColor = System.Drawing.Color.Blue;
            this.txtImp.Location = new System.Drawing.Point(64, 53);
            this.txtImp.Name = "txtImp";
            this.txtImp.Size = new System.Drawing.Size(784, 21);
            this.txtImp.TabIndex = 15;
            this.txtImp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtImp_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(0, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Importación:";
            // 
            // txtCat
            // 
            this.txtCat.BackColor = System.Drawing.Color.White;
            this.txtCat.ForeColor = System.Drawing.Color.Blue;
            this.txtCat.Location = new System.Drawing.Point(618, 20);
            this.txtCat.Name = "txtCat";
            this.txtCat.Size = new System.Drawing.Size(230, 21);
            this.txtCat.TabIndex = 14;
            this.txtCat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCat_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(568, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Catálogo:";
            // 
            // txtDesArt
            // 
            this.txtDesArt.BackColor = System.Drawing.Color.White;
            this.txtDesArt.ForeColor = System.Drawing.Color.Blue;
            this.txtDesArt.Location = new System.Drawing.Point(233, 20);
            this.txtDesArt.Name = "txtDesArt";
            this.txtDesArt.Size = new System.Drawing.Size(328, 21);
            this.txtDesArt.TabIndex = 13;
            this.txtDesArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArt_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(172, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Descripción:";
            // 
            // txtCodArt
            // 
            this.txtCodArt.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodArt.Location = new System.Drawing.Point(64, 20);
            this.txtCodArt.Name = "txtCodArt";
            this.txtCodArt.Size = new System.Drawing.Size(94, 21);
            this.txtCodArt.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Código:";
            // 
            // gpbUltUsu
            // 
            this.gpbUltUsu.Controls.Add(this.txtDesMon);
            this.gpbUltUsu.Controls.Add(this.txtCodMon);
            this.gpbUltUsu.Controls.Add(this.label7);
            this.gpbUltUsu.Controls.Add(this.mkbEta);
            this.gpbUltUsu.Controls.Add(this.label6);
            this.gpbUltUsu.Controls.Add(this.mkbEtd);
            this.gpbUltUsu.Controls.Add(this.label5);
            this.gpbUltUsu.Controls.Add(this.mkbFecLLe);
            this.gpbUltUsu.Controls.Add(this.label4);
            this.gpbUltUsu.Controls.Add(this.txtDesEstPag);
            this.gpbUltUsu.Controls.Add(this.txtCodEstPag);
            this.gpbUltUsu.Controls.Add(this.label3);
            this.gpbUltUsu.Controls.Add(this.txtDesEnv);
            this.gpbUltUsu.Controls.Add(this.txtDesPro);
            this.gpbUltUsu.Controls.Add(this.txtCodEnv);
            this.gpbUltUsu.Controls.Add(this.label2);
            this.gpbUltUsu.Controls.Add(this.txtCodPro);
            this.gpbUltUsu.Controls.Add(this.label1);
            this.gpbUltUsu.Location = new System.Drawing.Point(9, 17);
            this.gpbUltUsu.Name = "gpbUltUsu";
            this.gpbUltUsu.Size = new System.Drawing.Size(912, 96);
            this.gpbUltUsu.TabIndex = 0;
            this.gpbUltUsu.TabStop = false;
            // 
            // txtDesMon
            // 
            this.txtDesMon.BackColor = System.Drawing.Color.White;
            this.txtDesMon.ForeColor = System.Drawing.Color.Blue;
            this.txtDesMon.Location = new System.Drawing.Point(666, 69);
            this.txtDesMon.Name = "txtDesMon";
            this.txtDesMon.Size = new System.Drawing.Size(184, 21);
            this.txtDesMon.TabIndex = 10;
            this.txtDesMon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesMon_KeyPress);
            // 
            // txtCodMon
            // 
            this.txtCodMon.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodMon.Location = new System.Drawing.Point(618, 69);
            this.txtCodMon.Name = "txtCodMon";
            this.txtCodMon.Size = new System.Drawing.Size(47, 21);
            this.txtCodMon.TabIndex = 9;
            this.txtCodMon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(569, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Moneda:";
            // 
            // mkbEta
            // 
            this.mkbEta.Location = new System.Drawing.Point(775, 44);
            this.mkbEta.Mask = "00/00/0000";
            this.mkbEta.Name = "mkbEta";
            this.mkbEta.Size = new System.Drawing.Size(75, 21);
            this.mkbEta.TabIndex = 8;
            this.mkbEta.ValidatingType = typeof(System.DateTime);
            this.mkbEta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mkbEta_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(750, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "ETA:";
            // 
            // mkbEtd
            // 
            this.mkbEtd.Location = new System.Drawing.Point(675, 44);
            this.mkbEtd.Mask = "00/00/0000";
            this.mkbEtd.Name = "mkbEtd";
            this.mkbEtd.Size = new System.Drawing.Size(69, 21);
            this.mkbEtd.TabIndex = 7;
            this.mkbEtd.ValidatingType = typeof(System.DateTime);
            this.mkbEtd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mkbEtd_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(648, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "ETD:";
            // 
            // mkbFecLLe
            // 
            this.mkbFecLLe.Location = new System.Drawing.Point(775, 11);
            this.mkbFecLLe.Mask = "00/00/0000";
            this.mkbFecLLe.Name = "mkbFecLLe";
            this.mkbFecLLe.Size = new System.Drawing.Size(75, 21);
            this.mkbFecLLe.TabIndex = 6;
            this.mkbFecLLe.ValidatingType = typeof(System.DateTime);
            this.mkbFecLLe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mkbFecLLe_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(648, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Fecha de llegada  a  SQO:";
            // 
            // txtDesEstPag
            // 
            this.txtDesEstPag.BackColor = System.Drawing.Color.White;
            this.txtDesEstPag.ForeColor = System.Drawing.Color.Blue;
            this.txtDesEstPag.Location = new System.Drawing.Point(447, 69);
            this.txtDesEstPag.Name = "txtDesEstPag";
            this.txtDesEstPag.Size = new System.Drawing.Size(116, 21);
            this.txtDesEstPag.TabIndex = 5;
            this.txtDesEstPag.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesEstPag_KeyPress);
            // 
            // txtCodEstPag
            // 
            this.txtCodEstPag.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodEstPag.Location = new System.Drawing.Point(386, 69);
            this.txtCodEstPag.Name = "txtCodEstPag";
            this.txtCodEstPag.Size = new System.Drawing.Size(61, 21);
            this.txtCodEstPag.TabIndex = 4;
            this.txtCodEstPag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(300, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Estado de pago:";
            // 
            // txtDesEnv
            // 
            this.txtDesEnv.BackColor = System.Drawing.Color.White;
            this.txtDesEnv.ForeColor = System.Drawing.Color.Blue;
            this.txtDesEnv.Location = new System.Drawing.Point(161, 69);
            this.txtDesEnv.Name = "txtDesEnv";
            this.txtDesEnv.Size = new System.Drawing.Size(125, 21);
            this.txtDesEnv.TabIndex = 3;
            this.txtDesEnv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesEnv_KeyPress);
            // 
            // txtDesPro
            // 
            this.txtDesPro.BackColor = System.Drawing.Color.White;
            this.txtDesPro.ForeColor = System.Drawing.Color.Blue;
            this.txtDesPro.Location = new System.Drawing.Point(161, 41);
            this.txtDesPro.Name = "txtDesPro";
            this.txtDesPro.Size = new System.Drawing.Size(402, 21);
            this.txtDesPro.TabIndex = 1;
            this.txtDesPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesPro_KeyPress);
            // 
            // txtCodEnv
            // 
            this.txtCodEnv.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodEnv.Location = new System.Drawing.Point(60, 69);
            this.txtCodEnv.Name = "txtCodEnv";
            this.txtCodEnv.Size = new System.Drawing.Size(100, 21);
            this.txtCodEnv.TabIndex = 2;
            this.txtCodEnv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Envio:";
            // 
            // txtCodPro
            // 
            this.txtCodPro.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodPro.Location = new System.Drawing.Point(60, 41);
            this.txtCodPro.Name = "txtCodPro";
            this.txtCodPro.Size = new System.Drawing.Size(100, 21);
            this.txtCodPro.TabIndex = 0;
            this.txtCodPro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Proveedor:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.gpbInc);
            this.tabPage2.Controls.Add(this.gpbLal);
            this.tabPage2.Controls.Add(this.gpbPayTer);
            this.tabPage2.Controls.Add(this.gpbShiDet);
            this.tabPage2.Controls.Add(this.gpbShiInf);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1037, 507);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Otros datos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // gpbInc
            // 
            this.gpbInc.Controls.Add(this.rdbFob);
            this.gpbInc.Controls.Add(this.rdbExWor);
            this.gpbInc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbInc.Location = new System.Drawing.Point(9, 451);
            this.gpbInc.Name = "gpbInc";
            this.gpbInc.Size = new System.Drawing.Size(774, 51);
            this.gpbInc.TabIndex = 43;
            this.gpbInc.TabStop = false;
            this.gpbInc.Text = "Incoterm";
            // 
            // rdbFob
            // 
            this.rdbFob.AutoSize = true;
            this.rdbFob.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbFob.Location = new System.Drawing.Point(103, 20);
            this.rdbFob.Name = "rdbFob";
            this.rdbFob.Size = new System.Drawing.Size(45, 17);
            this.rdbFob.TabIndex = 1;
            this.rdbFob.TabStop = true;
            this.rdbFob.Text = "FOB";
            this.rdbFob.UseVisualStyleBackColor = true;
            // 
            // rdbExWor
            // 
            this.rdbExWor.AutoSize = true;
            this.rdbExWor.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbExWor.Location = new System.Drawing.Point(20, 20);
            this.rdbExWor.Name = "rdbExWor";
            this.rdbExWor.Size = new System.Drawing.Size(70, 17);
            this.rdbExWor.TabIndex = 0;
            this.rdbExWor.TabStop = true;
            this.rdbExWor.Text = "Ex Works";
            this.rdbExWor.UseVisualStyleBackColor = true;
            // 
            // gpbLal
            // 
            this.gpbLal.Controls.Add(this.txtDesLab);
            this.gpbLal.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbLal.Location = new System.Drawing.Point(9, 400);
            this.gpbLal.Name = "gpbLal";
            this.gpbLal.Size = new System.Drawing.Size(774, 51);
            this.gpbLal.TabIndex = 42;
            this.gpbLal.TabStop = false;
            this.gpbLal.Text = "Labels";
            // 
            // txtDesLab
            // 
            this.txtDesLab.BackColor = System.Drawing.Color.White;
            this.txtDesLab.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesLab.Location = new System.Drawing.Point(9, 18);
            this.txtDesLab.Multiline = true;
            this.txtDesLab.Name = "txtDesLab";
            this.txtDesLab.Size = new System.Drawing.Size(722, 27);
            this.txtDesLab.TabIndex = 38;
            this.txtDesLab.Text = "All boxed should by printed or sticked with MADE IN ITALY or Country where manufa" +
    "ctured,in any size.";
            // 
            // gpbPayTer
            // 
            this.gpbPayTer.Controls.Add(this.txtDesPayTer);
            this.gpbPayTer.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbPayTer.Location = new System.Drawing.Point(9, 311);
            this.gpbPayTer.Name = "gpbPayTer";
            this.gpbPayTer.Size = new System.Drawing.Size(774, 87);
            this.gpbPayTer.TabIndex = 41;
            this.gpbPayTer.TabStop = false;
            this.gpbPayTer.Text = "Payment Terms";
            // 
            // txtDesPayTer
            // 
            this.txtDesPayTer.BackColor = System.Drawing.Color.White;
            this.txtDesPayTer.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesPayTer.Location = new System.Drawing.Point(6, 20);
            this.txtDesPayTer.Multiline = true;
            this.txtDesPayTer.Name = "txtDesPayTer";
            this.txtDesPayTer.Size = new System.Drawing.Size(728, 55);
            this.txtDesPayTer.TabIndex = 38;
            this.txtDesPayTer.Text = "In advance by Swift Bank Transfer from Trazzo Iluminacion S.A.C.";
            // 
            // gpbShiDet
            // 
            this.gpbShiDet.Controls.Add(this.txtConPer);
            this.gpbShiDet.Controls.Add(this.txtPhoDet);
            this.gpbShiDet.Controls.Add(this.label34);
            this.gpbShiDet.Controls.Add(this.label35);
            this.gpbShiDet.Controls.Add(this.txtEma);
            this.gpbShiDet.Controls.Add(this.txtAdd);
            this.gpbShiDet.Controls.Add(this.label36);
            this.gpbShiDet.Controls.Add(this.label37);
            this.gpbShiDet.Controls.Add(this.txtFaxDet);
            this.gpbShiDet.Controls.Add(this.label38);
            this.gpbShiDet.Controls.Add(this.txtFwd);
            this.gpbShiDet.Controls.Add(this.label39);
            this.gpbShiDet.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbShiDet.Location = new System.Drawing.Point(9, 177);
            this.gpbShiDet.Name = "gpbShiDet";
            this.gpbShiDet.Size = new System.Drawing.Size(774, 128);
            this.gpbShiDet.TabIndex = 40;
            this.gpbShiDet.TabStop = false;
            this.gpbShiDet.Text = "Shipping details";
            // 
            // txtConPer
            // 
            this.txtConPer.BackColor = System.Drawing.Color.White;
            this.txtConPer.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConPer.Location = new System.Drawing.Point(465, 98);
            this.txtConPer.Name = "txtConPer";
            this.txtConPer.Size = new System.Drawing.Size(269, 21);
            this.txtConPer.TabIndex = 37;
            // 
            // txtPhoDet
            // 
            this.txtPhoDet.BackColor = System.Drawing.Color.White;
            this.txtPhoDet.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoDet.Location = new System.Drawing.Point(68, 98);
            this.txtPhoDet.Name = "txtPhoDet";
            this.txtPhoDet.Size = new System.Drawing.Size(280, 21);
            this.txtPhoDet.TabIndex = 37;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(383, 92);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 27);
            this.label34.TabIndex = 36;
            this.label34.Text = "Contact person:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(25, 106);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 36;
            this.label35.Text = "Phone:";
            // 
            // txtEma
            // 
            this.txtEma.BackColor = System.Drawing.Color.White;
            this.txtEma.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEma.Location = new System.Drawing.Point(465, 62);
            this.txtEma.Name = "txtEma";
            this.txtEma.Size = new System.Drawing.Size(269, 21);
            this.txtEma.TabIndex = 34;
            // 
            // txtAdd
            // 
            this.txtAdd.BackColor = System.Drawing.Color.White;
            this.txtAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdd.Location = new System.Drawing.Point(68, 63);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(280, 21);
            this.txtAdd.TabIndex = 34;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(384, 70);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(35, 13);
            this.label36.TabIndex = 35;
            this.label36.Text = "Email:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(17, 70);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(50, 13);
            this.label37.TabIndex = 35;
            this.label37.Text = "Address:";
            // 
            // txtFaxDet
            // 
            this.txtFaxDet.BackColor = System.Drawing.Color.White;
            this.txtFaxDet.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFaxDet.Location = new System.Drawing.Point(465, 30);
            this.txtFaxDet.Name = "txtFaxDet";
            this.txtFaxDet.Size = new System.Drawing.Size(269, 21);
            this.txtFaxDet.TabIndex = 33;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(384, 39);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 13);
            this.label38.TabIndex = 33;
            this.label38.Text = "Fax:";
            // 
            // txtFwd
            // 
            this.txtFwd.BackColor = System.Drawing.Color.White;
            this.txtFwd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFwd.Location = new System.Drawing.Point(68, 30);
            this.txtFwd.Name = "txtFwd";
            this.txtFwd.Size = new System.Drawing.Size(280, 21);
            this.txtFwd.TabIndex = 33;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(6, 36);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(61, 13);
            this.label39.TabIndex = 33;
            this.label39.Text = "Forwarder:";
            // 
            // gpbShiInf
            // 
            this.gpbShiInf.Controls.Add(this.txtFax);
            this.gpbShiInf.Controls.Add(this.txtUltDes);
            this.gpbShiInf.Controls.Add(this.label31);
            this.gpbShiInf.Controls.Add(this.label27);
            this.gpbShiInf.Controls.Add(this.txtPho);
            this.gpbShiInf.Controls.Add(this.txtCouImp);
            this.gpbShiInf.Controls.Add(this.label30);
            this.gpbShiInf.Controls.Add(this.label26);
            this.gpbShiInf.Controls.Add(this.txtCon);
            this.gpbShiInf.Controls.Add(this.txtVia);
            this.gpbShiInf.Controls.Add(this.label29);
            this.gpbShiInf.Controls.Add(this.label25);
            this.gpbShiInf.Controls.Add(this.txtInvTo);
            this.gpbShiInf.Controls.Add(this.label28);
            this.gpbShiInf.Controls.Add(this.txtOrdDat);
            this.gpbShiInf.Controls.Add(this.label24);
            this.gpbShiInf.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbShiInf.Location = new System.Drawing.Point(6, 6);
            this.gpbShiInf.Name = "gpbShiInf";
            this.gpbShiInf.Size = new System.Drawing.Size(774, 165);
            this.gpbShiInf.TabIndex = 33;
            this.gpbShiInf.TabStop = false;
            this.gpbShiInf.Text = "Shipping Info";
            // 
            // txtFax
            // 
            this.txtFax.BackColor = System.Drawing.Color.White;
            this.txtFax.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFax.Location = new System.Drawing.Point(465, 128);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(269, 21);
            this.txtFax.TabIndex = 39;
            // 
            // txtUltDes
            // 
            this.txtUltDes.BackColor = System.Drawing.Color.White;
            this.txtUltDes.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUltDes.Location = new System.Drawing.Point(68, 128);
            this.txtUltDes.Name = "txtUltDes";
            this.txtUltDes.Size = new System.Drawing.Size(280, 21);
            this.txtUltDes.TabIndex = 39;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(387, 135);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 13);
            this.label31.TabIndex = 38;
            this.label31.Text = "Fax:";
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(0, 123);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 29);
            this.label27.TabIndex = 38;
            this.label27.Text = "Ultimate Dest:";
            // 
            // txtPho
            // 
            this.txtPho.BackColor = System.Drawing.Color.White;
            this.txtPho.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPho.Location = new System.Drawing.Point(465, 98);
            this.txtPho.Name = "txtPho";
            this.txtPho.Size = new System.Drawing.Size(269, 21);
            this.txtPho.TabIndex = 37;
            // 
            // txtCouImp
            // 
            this.txtCouImp.BackColor = System.Drawing.Color.White;
            this.txtCouImp.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCouImp.Location = new System.Drawing.Point(68, 98);
            this.txtCouImp.Name = "txtCouImp";
            this.txtCouImp.Size = new System.Drawing.Size(280, 21);
            this.txtCouImp.TabIndex = 37;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(387, 106);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 13);
            this.label30.TabIndex = 36;
            this.label30.Text = "Phone:";
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(0, 93);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(69, 29);
            this.label26.TabIndex = 36;
            this.label26.Text = "Country of Import:";
            // 
            // txtCon
            // 
            this.txtCon.BackColor = System.Drawing.Color.White;
            this.txtCon.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCon.Location = new System.Drawing.Point(465, 62);
            this.txtCon.Name = "txtCon";
            this.txtCon.Size = new System.Drawing.Size(269, 21);
            this.txtCon.TabIndex = 34;
            // 
            // txtVia
            // 
            this.txtVia.BackColor = System.Drawing.Color.DarkGray;
            this.txtVia.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVia.ForeColor = System.Drawing.Color.Blue;
            this.txtVia.Location = new System.Drawing.Point(68, 63);
            this.txtVia.Name = "txtVia";
            this.txtVia.Size = new System.Drawing.Size(280, 21);
            this.txtVia.TabIndex = 34;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(386, 70);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 13);
            this.label29.TabIndex = 35;
            this.label29.Text = "Consignee:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(46, 70);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 13);
            this.label25.TabIndex = 35;
            this.label25.Text = "Via:";
            // 
            // txtInvTo
            // 
            this.txtInvTo.BackColor = System.Drawing.Color.White;
            this.txtInvTo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvTo.Location = new System.Drawing.Point(465, 30);
            this.txtInvTo.Name = "txtInvTo";
            this.txtInvTo.Size = new System.Drawing.Size(269, 21);
            this.txtInvTo.TabIndex = 33;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(386, 38);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 13);
            this.label28.TabIndex = 33;
            this.label28.Text = "Invoice To:";
            // 
            // txtOrdDat
            // 
            this.txtOrdDat.BackColor = System.Drawing.Color.DarkGray;
            this.txtOrdDat.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrdDat.ForeColor = System.Drawing.Color.Blue;
            this.txtOrdDat.Location = new System.Drawing.Point(68, 30);
            this.txtOrdDat.Name = "txtOrdDat";
            this.txtOrdDat.Size = new System.Drawing.Size(280, 21);
            this.txtOrdDat.TabIndex = 33;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 36);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 13);
            this.label24.TabIndex = 33;
            this.label24.Text = "Order Date:";
            // 
            // gpbOtrDat
            // 
            this.gpbOtrDat.Controls.Add(this.cboLey);
            this.gpbOtrDat.Controls.Add(this.label32);
            this.gpbOtrDat.Controls.Add(this.chkEnvInt);
            this.gpbOtrDat.Controls.Add(this.mkbOtrFecEntPro);
            this.gpbOtrDat.Controls.Add(this.label21);
            this.gpbOtrDat.Controls.Add(this.txtOtrNumImp);
            this.gpbOtrDat.Controls.Add(this.label20);
            this.gpbOtrDat.Controls.Add(this.txtCodImp);
            this.gpbOtrDat.Controls.Add(this.label19);
            this.gpbOtrDat.Controls.Add(this.txtTra);
            this.gpbOtrDat.Controls.Add(this.label18);
            this.gpbOtrDat.Controls.Add(this.txtNomBar);
            this.gpbOtrDat.Controls.Add(this.label17);
            this.gpbOtrDat.Controls.Add(this.mkbFecDisDes);
            this.gpbOtrDat.Controls.Add(this.label16);
            this.gpbOtrDat.Location = new System.Drawing.Point(1057, 84);
            this.gpbOtrDat.Name = "gpbOtrDat";
            this.gpbOtrDat.Size = new System.Drawing.Size(234, 490);
            this.gpbOtrDat.TabIndex = 30;
            this.gpbOtrDat.TabStop = false;
            this.gpbOtrDat.Text = "Otros datos";
            // 
            // cboLey
            // 
            this.cboLey.FormattingEnabled = true;
            this.cboLey.Items.AddRange(new object[] {
            "0 - Sin leyenda",
            "1 - Pendiente de revisión e ingreso SAP.",
            "2 - Carga aun en trámite por agente de aduanas.",
            "3 - Contenedor Italia.",
            "4 - Contenedor China."});
            this.cboLey.Location = new System.Drawing.Point(26, 392);
            this.cboLey.Name = "cboLey";
            this.cboLey.Size = new System.Drawing.Size(195, 21);
            this.cboLey.TabIndex = 34;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(23, 376);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 13);
            this.label32.TabIndex = 34;
            this.label32.Text = "Leyenda:";
            // 
            // chkEnvInt
            // 
            this.chkEnvInt.AutoSize = true;
            this.chkEnvInt.Location = new System.Drawing.Point(23, 342);
            this.chkEnvInt.Name = "chkEnvInt";
            this.chkEnvInt.Size = new System.Drawing.Size(115, 17);
            this.chkEnvInt.TabIndex = 33;
            this.chkEnvInt.Text = "Envio Introducción";
            this.chkEnvInt.UseVisualStyleBackColor = true;
            // 
            // mkbOtrFecEntPro
            // 
            this.mkbOtrFecEntPro.Location = new System.Drawing.Point(92, 302);
            this.mkbOtrFecEntPro.Mask = "00/00/0000";
            this.mkbOtrFecEntPro.Name = "mkbOtrFecEntPro";
            this.mkbOtrFecEntPro.Size = new System.Drawing.Size(91, 21);
            this.mkbOtrFecEntPro.TabIndex = 32;
            this.mkbOtrFecEntPro.ValidatingType = typeof(System.DateTime);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(20, 286);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(166, 13);
            this.label21.TabIndex = 27;
            this.label21.Text = "Fecha de Entrega del Proveedor:";
            // 
            // txtOtrNumImp
            // 
            this.txtOtrNumImp.BackColor = System.Drawing.Color.White;
            this.txtOtrNumImp.ForeColor = System.Drawing.Color.Blue;
            this.txtOtrNumImp.Location = new System.Drawing.Point(20, 244);
            this.txtOtrNumImp.Name = "txtOtrNumImp";
            this.txtOtrNumImp.Size = new System.Drawing.Size(201, 21);
            this.txtOtrNumImp.TabIndex = 31;
            this.txtOtrNumImp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOtrNumImp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOtrNumImp_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(19, 228);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 13);
            this.label20.TabIndex = 25;
            this.label20.Text = "N° Importación:";
            // 
            // txtCodImp
            // 
            this.txtCodImp.BackColor = System.Drawing.Color.White;
            this.txtCodImp.ForeColor = System.Drawing.Color.Blue;
            this.txtCodImp.Location = new System.Drawing.Point(20, 196);
            this.txtCodImp.Name = "txtCodImp";
            this.txtCodImp.Size = new System.Drawing.Size(201, 21);
            this.txtCodImp.TabIndex = 30;
            this.txtCodImp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodImp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodImp_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 180);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(210, 13);
            this.label19.TabIndex = 23;
            this.label19.Text = "Cod. Contenedor de importación marítima:";
            // 
            // txtTra
            // 
            this.txtTra.BackColor = System.Drawing.Color.White;
            this.txtTra.ForeColor = System.Drawing.Color.Blue;
            this.txtTra.Location = new System.Drawing.Point(20, 144);
            this.txtTra.Name = "txtTra";
            this.txtTra.Size = new System.Drawing.Size(201, 21);
            this.txtTra.TabIndex = 29;
            this.txtTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTra_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(17, 128);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(113, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "AWB / B/L TRACKING:";
            // 
            // txtNomBar
            // 
            this.txtNomBar.BackColor = System.Drawing.Color.White;
            this.txtNomBar.ForeColor = System.Drawing.Color.Blue;
            this.txtNomBar.Location = new System.Drawing.Point(20, 93);
            this.txtNomBar.Name = "txtNomBar";
            this.txtNomBar.Size = new System.Drawing.Size(201, 21);
            this.txtNomBar.TabIndex = 28;
            this.txtNomBar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomBar_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 77);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(146, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "Nombre de Barco o N° Vuelo:";
            // 
            // mkbFecDisDes
            // 
            this.mkbFecDisDes.Location = new System.Drawing.Point(92, 43);
            this.mkbFecDisDes.Mask = "00/00/0000";
            this.mkbFecDisDes.Name = "mkbFecDisDes";
            this.mkbFecDisDes.Size = new System.Drawing.Size(91, 21);
            this.mkbFecDisDes.TabIndex = 27;
            this.mkbFecDisDes.ValidatingType = typeof(System.DateTime);
            this.mkbFecDisDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mkbFecDisDes_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(19, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(164, 13);
            this.label16.TabIndex = 17;
            this.label16.Text = "Fecha disponible para despacho:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(545, 9);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(83, 13);
            this.label22.TabIndex = 15;
            this.label22.Text = "N° Importación:";
            // 
            // txtNumImp
            // 
            this.txtNumImp.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtNumImp.Location = new System.Drawing.Point(634, 6);
            this.txtNumImp.Name = "txtNumImp";
            this.txtNumImp.Size = new System.Drawing.Size(89, 21);
            this.txtNumImp.TabIndex = 33;
            this.txtNumImp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(740, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 13);
            this.label23.TabIndex = 31;
            this.label23.Text = "Emisión:";
            // 
            // txtFecEmi
            // 
            this.txtFecEmi.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtFecEmi.Location = new System.Drawing.Point(787, 6);
            this.txtFecEmi.Name = "txtFecEmi";
            this.txtFecEmi.Size = new System.Drawing.Size(82, 21);
            this.txtFecEmi.TabIndex = 34;
            this.txtFecEmi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // frmLOG_Imp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1331, 575);
            this.Controls.Add(this.txtFecEmi);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtNumImp);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.gpbOtrDat);
            this.Controls.Add(this.tabComImpOtr);
            this.Controls.Add(this.tspImp);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmLOG_Imp";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Importación";
            this.Load += new System.EventHandler(this.frmLOG_Imp_Load);
            this.tspImp.ResumeLayout(false);
            this.tspImp.PerformLayout();
            this.tabComImpOtr.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabConArtCom.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgSinCod)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgCom)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgArt)).EndInit();
            this.gpbArt.ResumeLayout(false);
            this.gpbArt.PerformLayout();
            this.gpbUltUsu.ResumeLayout(false);
            this.gpbUltUsu.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.gpbInc.ResumeLayout(false);
            this.gpbInc.PerformLayout();
            this.gpbLal.ResumeLayout(false);
            this.gpbLal.PerformLayout();
            this.gpbPayTer.ResumeLayout(false);
            this.gpbPayTer.PerformLayout();
            this.gpbShiDet.ResumeLayout(false);
            this.gpbShiDet.PerformLayout();
            this.gpbShiInf.ResumeLayout(false);
            this.gpbShiInf.PerformLayout();
            this.gpbOtrDat.ResumeLayout(false);
            this.gpbOtrDat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ToolStrip tspImp;
        public System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.ToolStripButton btnAbrir;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton btnDeshacer;
        private System.Windows.Forms.ToolStripButton btnModificar;
        private System.Windows.Forms.ToolStripButton btnAnu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btnPro;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnSitImp;
        private System.Windows.Forms.ToolStripButton btnOc;
        private System.Windows.Forms.TabControl tabComImpOtr;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gpbUltUsu;
        private System.Windows.Forms.GroupBox gpbArt;
        private System.Windows.Forms.TextBox txtCodPro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodEnv;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDesEnv;
        private System.Windows.Forms.TextBox txtDesPro;
        private System.Windows.Forms.TextBox txtDesEstPag;
        private System.Windows.Forms.TextBox txtCodEstPag;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox mkbFecLLe;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox mkbEta;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox mkbEtd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDesMon;
        private System.Windows.Forms.TextBox txtCodMon;
        private System.Windows.Forms.TextBox txtCodArt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDesArt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtImp;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCanArt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCosArt;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox mkbFecEntPro;
        private System.Windows.Forms.Button btnAgrIte;
        private System.Windows.Forms.Button btnCanIte;
        private System.Windows.Forms.Button btnBorIte;
        private System.Windows.Forms.GroupBox gpbOtrDat;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox mkbFecDisDes;
        private System.Windows.Forms.TextBox txtNomBar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtCodImp;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtTra;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox mkbOtrFecEntPro;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtOtrNumImp;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtNumImp;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtFecEmi;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox gpbShiInf;
        private System.Windows.Forms.TextBox txtOrdDat;
        private System.Windows.Forms.TextBox txtVia;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtCouImp;
        private System.Windows.Forms.TextBox txtUltDes;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtPho;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtCon;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtInvTo;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox gpbShiDet;
        private System.Windows.Forms.TextBox txtConPer;
        private System.Windows.Forms.TextBox txtPhoDet;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtEma;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtFaxDet;
        private System.Windows.Forms.TextBox txtFwd;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox gpbPayTer;
        private System.Windows.Forms.TextBox txtDesPayTer;
        private System.Windows.Forms.GroupBox gpbLal;
        private System.Windows.Forms.TextBox txtDesLab;
        private System.Windows.Forms.GroupBox gpbInc;
        private System.Windows.Forms.RadioButton rdbExWor;
        private System.Windows.Forms.RadioButton rdbFob;
        private System.Windows.Forms.Label lblUltUsu;
        private System.Windows.Forms.TabControl tabConArtCom;
        private System.Windows.Forms.TabPage tabPage3;
        private C1.Win.C1FlexGrid.C1FlexGrid fgSinCod;
        private System.Windows.Forms.TabPage tabPage4;
        private C1.Win.C1FlexGrid.C1FlexGrid fgCom;
        private System.Windows.Forms.TabPage tabPage5;
        private C1.Win.C1FlexGrid.C1FlexGrid fgArt;
        private System.Windows.Forms.CheckBox chkEnvInt;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cboLey;
        private System.Windows.Forms.ToolStripButton btnTra;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Button btnModIte;
    }
}