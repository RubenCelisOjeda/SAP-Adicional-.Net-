﻿using C1.Win.C1FlexGrid;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace SAP_Adicional
{
    public partial class frmOPE_OFVAprOpeDis : Form
    {
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        public frmOPE_OFVAprOpeDis()
        {
            InitializeComponent();
        }

        private void btnMosAct_Click(object sender, EventArgs e)
        {
            switch (this.tb.SelectedIndex)
            {
                case 0:
                    this.fgOFV.DataSource = nc.OPE_OFVAprSerSupDis(Convert.ToInt16(this.chkOFV.Checked));
                    break;
                case 1:
                    this.fgODV.DataSource = nc.OPE_ODVAprSerSupDis(Convert.ToInt16(this.chkOFV.Checked));
                    break;

            }
            
        }

        private void FormatoGrid()
        {
            CellStyle s;

            switch (this.tb.SelectedIndex)
            {
                case 0:
                    fgOFV.Styles.Normal.WordWrap = true;
                    this.fgOFV.Rows[0].Height = 50;

                    this.fgOFV.Cols[0].Width = 60; //N° OFV
                    this.fgOFV.Cols[1].Width = 70;
                    this.fgOFV.Cols[2].Width = 60;
                    this.fgOFV.Cols[3].Width = 200;
                    this.fgOFV.Cols[4].Width = 200; //Nombre de la venta
                    this.fgOFV.Cols[5].Width = 150;
                    this.fgOFV.Cols[6].Width = 100;
                    this.fgOFV.Cols[7].Width = 70; //Estado OFV
                    this.fgOFV.Cols[8].Width = 250;
                    this.fgOFV.Cols[9].Width = 60;
                    this.fgOFV.Cols[10].Width = 100;
                    this.fgOFV.Cols[11].Width = 100;
                    this.fgOFV.Cols[12].Width = 200;
                    this.fgOFV.Cols[13].Visible = false;

                    this.fgOFV.Cols[11].ComboList = "PENDIENTE|REVISADO|CANCELADO";

                    this.fgOFV.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;

                    this.fgOFV.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
                    this.fgOFV.Cols.Frozen = 4;

                    s = fgOFV.Styles[CellStyleEnum.Frozen];
                    s.ForeColor = Color.Blue;

                    break;
                case 1:
                    fgODV.Styles.Normal.WordWrap = true;
                    this.fgODV.Rows[0].Height = 50;

                    this.fgODV.Cols[0].Width = 60;
                    this.fgODV.Cols[1].Width = 70;
                    this.fgODV.Cols[2].Width = 60;
                    this.fgODV.Cols[3].Width = 200;
                    this.fgODV.Cols[4].Width = 300;
                    this.fgODV.Cols[5].Width = 200;
                    this.fgODV.Cols[6].Width = 150;
                    this.fgODV.Cols[7].Width = 110;
                    this.fgODV.Cols[8].Width = 70;
                    this.fgODV.Cols[9].Width = 80;
                    this.fgODV.Cols[10].Width = 80;
                    this.fgODV.Cols[11].Width = 80;
                    this.fgODV.Cols[12].Width = 90;
                    this.fgODV.Cols[13].Width = 200;
                    this.fgODV.Cols[14].Width = 250;
                    this.fgODV.Cols[15].Visible = false;

                    this.fgODV.Cols[10].Format = "#,###,###";
                    this.fgODV.Cols[11].Format = "#,###,###";

                    this.fgODV.Cols[12].ComboList = "PENDIENTE|REVISADO|CANCELADO";

                    this.fgODV.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;

                    this.fgODV.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;
                    this.fgODV.Cols.Frozen = 4;

                    s = fgODV.Styles[CellStyleEnum.Frozen];
                    s.ForeColor = Color.Blue;

                    break;
            }
        }

        private void fgOFV_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGrid();
        }

        private void fgOFV_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.Col != 12)
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void fgOFV_Click(object sender, EventArgs e)
        {

        }

        private void fgOFV_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 11 || e.Col == 12)
            {
                nc.OPE_OFVApr_dat_acting(3,
                                        Convert.ToInt64(fgOFV.Cols[0][e.Row].ToString()),
                                        fgOFV.Cols[13][e.Row].ToString(),
                                        fgOFV.Cols[11][e.Row].ToString(),
                                        fgOFV.Cols[12][e.Row].ToString(),                                       
                                        varglo.CodUsuAct,
                                        false);

            }
        }

        private void fgODV_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGrid();
        }

        private void fgODV_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 12 || e.Col == 13)
            {
                nc.OPE_OFVApr_dat_acting(4,
                                        Convert.ToInt64(fgODV.Cols[0][e.Row].ToString()),
                                        fgODV.Cols[15][e.Row].ToString(),
                                        fgODV.Cols[12][e.Row].ToString(),
                                        fgODV.Cols[13][e.Row].ToString(),
                                        varglo.CodUsuAct,
                                        false);

            }
        }

        private void fgODV_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.Col != 13)
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            switch (this.tb.SelectedIndex)
            {
                case 0:
                    ExportExcel(fgOFV);
                    break;
                case 1:
                    ExportExcel(fgODV);
                    break;

            }
        }

        public void ExportExcel(C1FlexGrid fg)
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

            string Ruta = RutaEscritorio + @"\" + this.Text + " - " + this.tb.SelectedTab.Text + " - " + fecha + ".xlsx";

            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);

        }
    }
}
