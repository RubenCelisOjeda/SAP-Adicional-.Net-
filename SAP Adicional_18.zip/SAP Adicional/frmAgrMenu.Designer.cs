﻿namespace SAP_Adicional
{
    partial class frmAgrMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAgrMenu));
            this.pnlBarra = new System.Windows.Forms.Panel();
            this.lblMini = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCer = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAgr = new System.Windows.Forms.Button();
            this.btnActMenFav = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAct = new System.Windows.Forms.Button();
            this.fgMen = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.cmbNomMen = new System.Windows.Forms.ComboBox();
            this.btnEli = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tolTip = new System.Windows.Forms.ToolTip(this.components);
            this.pnlBarra.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMen)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBarra
            // 
            this.pnlBarra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBarra.BackColor = System.Drawing.Color.Gray;
            this.pnlBarra.Controls.Add(this.lblMini);
            this.pnlBarra.Controls.Add(this.label1);
            this.pnlBarra.Controls.Add(this.lblCer);
            this.pnlBarra.Location = new System.Drawing.Point(5, 3);
            this.pnlBarra.Name = "pnlBarra";
            this.pnlBarra.Size = new System.Drawing.Size(407, 31);
            this.pnlBarra.TabIndex = 16;
            this.pnlBarra.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBarra_MouseMove);
            // 
            // lblMini
            // 
            this.lblMini.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblMini.BackColor = System.Drawing.Color.White;
            this.lblMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMini.Image = ((System.Drawing.Image)(resources.GetObject("lblMini.Image")));
            this.lblMini.Location = new System.Drawing.Point(356, 5);
            this.lblMini.Name = "lblMini";
            this.lblMini.Size = new System.Drawing.Size(18, 17);
            this.lblMini.TabIndex = 11;
            this.lblMini.Click += new System.EventHandler(this.lblMini_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(154, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Añadir a menú";
            this.label1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label1_MouseMove);
            // 
            // lblCer
            // 
            this.lblCer.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblCer.BackColor = System.Drawing.Color.White;
            this.lblCer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCer.Image = ((System.Drawing.Image)(resources.GetObject("lblCer.Image")));
            this.lblCer.Location = new System.Drawing.Point(381, 5);
            this.lblCer.Name = "lblCer";
            this.lblCer.Size = new System.Drawing.Size(20, 17);
            this.lblCer.TabIndex = 0;
            this.lblCer.Click += new System.EventHandler(this.lblCer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Nombre:";
            // 
            // btnAgr
            // 
            this.btnAgr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAgr.BackColor = System.Drawing.Color.DarkGray;
            this.btnAgr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAgr.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgr.ForeColor = System.Drawing.Color.Black;
            this.btnAgr.Location = new System.Drawing.Point(9, 265);
            this.btnAgr.Name = "btnAgr";
            this.btnAgr.Size = new System.Drawing.Size(69, 22);
            this.btnAgr.TabIndex = 21;
            this.btnAgr.Text = "Agregar";
            this.btnAgr.UseVisualStyleBackColor = false;
            this.btnAgr.Click += new System.EventHandler(this.btnAgr_Click);
            // 
            // btnActMenFav
            // 
            this.btnActMenFav.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnActMenFav.BackColor = System.Drawing.Color.DarkGray;
            this.btnActMenFav.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnActMenFav.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnActMenFav.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActMenFav.ForeColor = System.Drawing.Color.Black;
            this.btnActMenFav.Location = new System.Drawing.Point(84, 265);
            this.btnActMenFav.Name = "btnActMenFav";
            this.btnActMenFav.Size = new System.Drawing.Size(142, 22);
            this.btnActMenFav.TabIndex = 22;
            this.btnActMenFav.Text = "Actulizar menú favoritos";
            this.btnActMenFav.UseVisualStyleBackColor = false;
            this.btnActMenFav.Click += new System.EventHandler(this.btnActMenFav_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.btnAct);
            this.panel2.Controls.Add(this.fgMen);
            this.panel2.Controls.Add(this.cmbNomMen);
            this.panel2.Controls.Add(this.btnEli);
            this.panel2.Controls.Add(this.btnAgr);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btnActMenFav);
            this.panel2.Location = new System.Drawing.Point(5, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(407, 296);
            this.panel2.TabIndex = 24;
            // 
            // btnAct
            // 
            this.btnAct.BackColor = System.Drawing.Color.Gold;
            this.btnAct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAct.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAct.ForeColor = System.Drawing.Color.Black;
            this.btnAct.Location = new System.Drawing.Point(323, 14);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(77, 22);
            this.btnAct.TabIndex = 26;
            this.btnAct.Text = "Actulizar";
            this.btnAct.UseVisualStyleBackColor = false;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            this.btnAct.MouseHover += new System.EventHandler(this.btnAct_MouseHover);
            // 
            // fgMen
            // 
            this.fgMen.AllowFiltering = true;
            this.fgMen.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgMen.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgMen.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fgMen.Location = new System.Drawing.Point(8, 40);
            this.fgMen.Name = "fgMen";
            this.fgMen.Rows.DefaultSize = 19;
            this.fgMen.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgMen.Size = new System.Drawing.Size(393, 214);
            this.fgMen.TabIndex = 0;
            this.fgMen.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgMen_StartEdit);
            this.fgMen.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgMen_AfterEdit);
            this.fgMen.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgMen_KeyPressEdit);
            // 
            // cmbNomMen
            // 
            this.cmbNomMen.BackColor = System.Drawing.Color.Khaki;
            this.cmbNomMen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNomMen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbNomMen.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNomMen.FormattingEnabled = true;
            this.cmbNomMen.Location = new System.Drawing.Point(51, 17);
            this.cmbNomMen.Name = "cmbNomMen";
            this.cmbNomMen.Size = new System.Drawing.Size(255, 19);
            this.cmbNomMen.TabIndex = 25;
            this.tolTip.SetToolTip(this.cmbNomMen, "ds");
            this.cmbNomMen.MouseHover += new System.EventHandler(this.cmbNomMen_MouseHover);
            // 
            // btnEli
            // 
            this.btnEli.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEli.BackColor = System.Drawing.Color.DarkGray;
            this.btnEli.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEli.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEli.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEli.ForeColor = System.Drawing.Color.Black;
            this.btnEli.Location = new System.Drawing.Point(331, 265);
            this.btnEli.Name = "btnEli";
            this.btnEli.Size = new System.Drawing.Size(69, 22);
            this.btnEli.TabIndex = 23;
            this.btnEli.Text = "Eliminar";
            this.btnEli.UseVisualStyleBackColor = false;
            this.btnEli.Click += new System.EventHandler(this.btnEli_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "carpeta.png");
            // 
            // frmAgrMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(417, 339);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlBarra);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximizeBox = false;
            this.Name = "frmAgrMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmAgrMenu_Load);
            this.pnlBarra.ResumeLayout(false);
            this.pnlBarra.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBarra;
        private System.Windows.Forms.Label lblMini;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAgr;
        private System.Windows.Forms.Button btnActMenFav;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnEli;
        private System.Windows.Forms.ComboBox cmbNomMen;
        private C1.Win.C1FlexGrid.C1FlexGrid fgMen;
        private System.Windows.Forms.Button btnAct;
        private System.Windows.Forms.ToolTip tolTip;
    }
}