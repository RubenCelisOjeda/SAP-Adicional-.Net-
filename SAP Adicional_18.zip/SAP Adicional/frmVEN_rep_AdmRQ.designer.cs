﻿namespace SAP_Adicional
{
    partial class frmVEN_rep_AdmRQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnExp = new System.Windows.Forms.Button();
            this.btnMos = new System.Windows.Forms.Button();
            this.btnAdmAsig = new System.Windows.Forms.Button();
            this.chkMosTod = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.Custom;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(3, 42);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fg.Size = new System.Drawing.Size(994, 484);
            this.fg.TabIndex = 39;
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            // 
            // btnExp
            // 
            this.btnExp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExp.Location = new System.Drawing.Point(448, 14);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(111, 23);
            this.btnExp.TabIndex = 3;
            this.btnExp.Text = "Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // btnMos
            // 
            this.btnMos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMos.Location = new System.Drawing.Point(5, 14);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(111, 23);
            this.btnMos.TabIndex = 2;
            this.btnMos.Text = "Mostrar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // btnAdmAsig
            // 
            this.btnAdmAsig.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdmAsig.Location = new System.Drawing.Point(558, 14);
            this.btnAdmAsig.Name = "btnAdmAsig";
            this.btnAdmAsig.Size = new System.Drawing.Size(111, 23);
            this.btnAdmAsig.TabIndex = 40;
            this.btnAdmAsig.Text = "Adm. Asignados";
            this.btnAdmAsig.UseVisualStyleBackColor = true;
            this.btnAdmAsig.Click += new System.EventHandler(this.btnAdmAsig_Click);
            // 
            // chkMosTod
            // 
            this.chkMosTod.AutoSize = true;
            this.chkMosTod.Location = new System.Drawing.Point(126, 19);
            this.chkMosTod.Name = "chkMosTod";
            this.chkMosTod.Size = new System.Drawing.Size(90, 17);
            this.chkMosTod.TabIndex = 41;
            this.chkMosTod.Text = "Mostrar Todo";
            this.chkMosTod.UseVisualStyleBackColor = true;
            // 
            // frmVEN_rep_AdmRQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 538);
            this.Controls.Add(this.chkMosTod);
            this.Controls.Add(this.btnAdmAsig);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.btnMos);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_rep_AdmRQ";
            this.Text = "Reporte - Administrador RQ";
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private C1.Win.C1FlexGrid.C1FlexGrid fg;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.Button btnAdmAsig;
        private System.Windows.Forms.CheckBox chkMosTod;
    }
}