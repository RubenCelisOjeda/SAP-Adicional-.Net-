﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using SAP_Adicional.Reportes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.VEN_EstCue;
using System.IO;
using System.Configuration;
using CrystalDecisions.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace SAP_Adicional
{
    //public class C1CheckBox : System.Windows.Forms.CheckBox,Form
    public partial class frmVEN_EstCue : Form
    {
        NVEN_EstCue nc = new NVEN_EstCue();
        Byte Origen;
        VarGlo varglo = VarGlo.Instance();
        

        public CheckEnum Checkbox { get; set; }

        //SqlDataReader dr;

        public frmVEN_EstCue()
        {
            InitializeComponent();
        }

        private void frmVEN_EstCue_Load(object sender, EventArgs e)
        {

        }
        public void Caja()
        {
            fg.Cols[3].Style.DataType = typeof(bool);
            fg.Cols[3].Style.ImageAlign = ImageAlignEnum.CenterCenter;
        }

        private void btnMos_Click(object sender, EventArgs e)
        {

        }
        public void Columnas()
        {
            fg.Cols[0].Width = 60;
            fg.Cols[1].Width = 340;
            fg.Cols[2].Width = 200;
            fg.Cols[3].Width = 50;
            fg.Cols[4].Visible = false;
        }

        private void rdbOrigen_0_CheckedChanged(object sender, EventArgs e)
        {
            Origen = 0;
        }

        private void rdbOrigen_1_CheckedChanged(object sender, EventArgs e)
        {
            Origen = 1;
        }

        private void rdbOrigen_2_CheckedChanged(object sender, EventArgs e)
        {

            Origen = 2;
        }

        private void rdbOrigen_3_CheckedChanged(object sender, EventArgs e)
        {
            Origen = 3;
        }

        private void btnMost__Click(object sender, EventArgs e)
        {
            if (txtRq_.Text == "")
            {
                return;
            }
            this.fg.DataSource = nc.VEN_EstCue_OpcOri(Origen, Convert.ToInt32(txtRq_.Text));
            Caja();
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            Columnas();
            Caja();
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void txtRq__KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
              btnMost_.Focus();
            }
        }

        private void rdbOrigen_0_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==(char)13)
            {
                txtRq_.Focus();
            }
        }

        private void rdbOrigen_1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtRq_.Focus();
            }
        }

        private void rdbOrigen_2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtRq_.Focus();
            }
        }

        private void rdbOrigen_3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtRq_.Focus();
            }
        }

        private void frmVEN_EstCue_Load_1(object sender, EventArgs e)
        {

        }

        private void btnMosRep_Click(object sender, EventArgs e)
        {
            int i;
            bool seleccionar = false;

            for (i = 1; i < fg.Rows.Count; i++)
            {
                if (Convert.ToInt32(fg.Rows[i][3].ToString()) != 0) { seleccionar = true; /*frmVisor v = new frmVisor(); v.Show();*/ }
            }
            if (seleccionar == false) { MessageBox.Show("Debe seleccionar minimo un documento", "SAP Adicional"); return; }

            VEN_EstCue EstCue = new VEN_EstCue();// instanciamos la clase VEN_EstCue_Docs de las variables declaradas

            for (int j = 1; j < fg.Rows.Count; j++)
            {
                VEN_EstCue estcueitem = new VEN_EstCue();

                if (Convert.ToInt32(fg.Rows[j][3].ToString()) != 0)
                {
                    estcueitem.RQ = Convert.ToInt32(this.txtRq_.Text);
                    estcueitem.NumDoc = fg.Rows[j][4].ToString();
                    estcueitem.CodUsuActi = varglo.CodUsuAct;
                    EstCue.EstCueList.Add(estcueitem);
                }
            }

            nc.VEN_EstCue_Docs(EstCue, varglo.CodUsuAct);

            ConnectionInfo crConnectionInfo = new ConnectionInfo(); ;
            Database crDatabase;
            Tables crTables;
            Table crTable;
            TableLogOnInfo crTableLogOnInfo;

            crConnectionInfo.ServerName = "zeus";
            crConnectionInfo.DatabaseName = VarGlo.Instance().Base; // Las tablas para el informe están siempre en la base de datos global.
            crConnectionInfo.IntegratedSecurity = true;

            frmVisor f = new frmVisor();
            rptVEN_EstCue repDoc = new rptVEN_EstCue();

            crDatabase = repDoc.Database; // Obtener la colección de tablas del objeto de informe
            crTables = crDatabase.Tables;

            for (i = 0; i < crTables.Count; i++)
            {

                crTable = crTables[i];

                crTableLogOnInfo = crTable.LogOnInfo;

                crTableLogOnInfo.ConnectionInfo = crConnectionInfo;

                crTable.ApplyLogOnInfo(crTableLogOnInfo);

                //If your DatabaseName is changing at runtime, specify the table location. For example, when you are reporting off of a Northwind database on SQL server you should have the following line of code:

                //crTable.Location = "Northwind.dbo." + crTable.Location.Substring(crTable.Location.LastIndexOf(".") + 1)

            }

            repDoc.SetParameterValue("@origen", Origen);
            repDoc.SetParameterValue("@codusu", varglo.CodUsuAct);
            repDoc.SetParameterValue("@rq", txtRq_.Text);
            repDoc.SetParameterValue("@empresa", varglo.Empresa);            

            f.MdiParent = this.MdiParent;
            f.crv.ReportSource = repDoc;
            f.crv.Zoom(120);
            f.WindowState = FormWindowState.Maximized;
            f.Show();
        }
    }   
}
