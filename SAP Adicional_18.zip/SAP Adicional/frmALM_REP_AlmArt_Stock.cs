﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_REP_AlmArt_Stock : Form
    {
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();
        int TipoColumna=0;

        public frmALM_REP_AlmArt_Stock()
        {
            InitializeComponent();
        }

        private void dgv_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar !=27)
            {
                e.Handled = true;
            }
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            this.dgv.DataSource = nc.LOG_Alm_ArtSto(varglo.CodUsuAct,"", 1, chkSinStock.Checked);
            
        }

        private void frmALM_REP_AlmArt_Stock_Load(object sender, EventArgs e)
        {

            dgv.DataSource = nc.LOG_Alm_ArtSto(varglo.CodUsuAct, "", 0, chkSinStock.Checked);

            Formato();           
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            ExportExcel();
        }
        public void ExportExcel()
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            dgv.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }
        public void Formato()
        {           
            dgv.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            dgv.Styles.Alternate.BackColor = Color.LightBlue;
            dgv.Styles.Highlight.BackColor = Color.Blue;
            dgv.Styles.Highlight.ForeColor = Color.White;
            dgv.AllowFreezing = AllowFreezingEnum.Both;
            CellStyle s = dgv.Styles[CellStyleEnum.Subtotal0];
            s.BackColor = Color.Yellow;
            s.ForeColor = Color.Blue;
                              
            dgv.Cols.Frozen = 3;

            TamañoColumnas();
        }

        private void TamañoColumnas()
        {

            dgv.AutoSizeCols();

            dgv.Cols[0].Width = 100;
            dgv.Cols[1].Width = 600;
            dgv.Cols[2].Width = 160;
        }

        private void dgv_BeforeSort(object sender, SortColEventArgs e)
        {
            if (dgv.Cols[e.Col].DataType == typeof(decimal) ||
               dgv.Cols[e.Col].DataType == typeof(Int16) ||
               dgv.Cols[e.Col].DataType == typeof(Int32) ||
               dgv.Cols[e.Col].DataType == typeof(Int64))
            {
                TipoColumna = 1;
            }
            if (dgv.Cols[e.Col].DataType == typeof(string))
            {
                TipoColumna = 2;
            }
            if (dgv.Cols[e.Col].DataType == typeof(DateTime))
            {
                TipoColumna = 3;
            }
            this.lblFil.Text = dgv.Cols[e.Col].Name;
            this.txtFil.Focus();
        }
       
        private void txtFil_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                string consulta;
                consulta = "";
                if (e.KeyChar == (char)13)
                {
                       if (txtFil.Text != "")
                       {                            
                            if (TipoColumna == 1)
                            {
                            consulta = " WHERE [" + this.lblFil.Text + "] LIKE '%" + txtFil.Text + "%'";
                            this.dgv.DataSource = nc.LOG_Alm_ArtSto(varglo.CodUsuAct, consulta, 1, chkSinStock.Checked);
                            }
                            if (TipoColumna == 2)
                            {
                            consulta = " WHERE [" + this.lblFil.Text + "] LIKE '%" + txtFil.Text + "%'";
                            this.dgv.DataSource = nc.LOG_Alm_ArtSto(varglo.CodUsuAct, consulta, 1, chkSinStock.Checked);
                            }
                            if (TipoColumna == 3)
                            {
                            consulta = " WHERE [" + this.lblFil.Text + "] LIKE '%" + txtFil.Text + "%'";
                            this.dgv.DataSource = nc.LOG_Alm_ArtSto(varglo.CodUsuAct, consulta, 1, chkSinStock.Checked);
                            }
                        }
                        else
                        {
                            this.dgv.DataSource = nc.LOG_Alm_ArtSto(varglo.CodUsuAct, consulta, 1, chkSinStock.Checked);
                        }                                       
                  }                                                                                  
            }
            catch
            {

            }                
        }

        private void dgv_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
                        
            TamañoColumnas();

        }
    }
}
