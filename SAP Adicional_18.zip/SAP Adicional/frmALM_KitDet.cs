﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_KitDet : Form
    {
        NALM_KitDet kitDet = new NALM_KitDet();
        public frmALM_KitDet()
        {
            InitializeComponent();
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fgDetCom.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch { }
        }

        private void btnMosAct_Click(object sender, EventArgs e)
        {
            DataTable dtKitDet = new DataTable();
            dtKitDet = kitDet.Rec_AlmKitDet();

            if (dtKitDet.Rows.Count > 0)
            {
                fgDetCom.DataSource = dtKitDet;
            }
            else
            {
                MessageBox.Show("No se encontraron datos","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                btnMosAct.Focus();
                return;
            }
        }
        void FormatoGeneral()
        {
            fgDetCom.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fgDetCom.VisualStyle = VisualStyle.Office2010Silver;
            fgDetCom.Styles.Alternate.BackColor = Color.LightBlue;
            fgDetCom.Styles.Highlight.BackColor = Color.Blue;
            fgDetCom.Styles.Highlight.ForeColor = Color.White;
            fgDetCom.AllowFreezing = AllowFreezingEnum.Both;
            fgDetCom.Cols.Frozen = 2;
        }

        void SizeColumas()
        {
            //tamaño de las columnas
            fgDetCom.Cols["Codigo Kit"].Width = 60;
            fgDetCom.Cols["Descripcion Kit"].Width = 600;
            fgDetCom.Cols["Tipo Kit"].Width = 60;
            fgDetCom.Cols["Inactivo"].Width = 45;
            fgDetCom.Cols["Codigo Articulo"].Width = 80;
            fgDetCom.Cols["Descripcion Articulo"].Width = 450;
            fgDetCom.Cols["Cant."].Width = 30;
            fgDetCom.Cols["Descontinuado"].Width = 75;
            fgDetCom.Cols["Grupo Articulo"].Width = 105;
        }
        private void fgDetCom_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            SizeColumas();
            FormatoGeneral();
        }

        private void fgDetCom_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }


    }
}
