﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_RQ_Proveedor : Form
    {
        NLOG_RQ_Pro nc = new NLOG_RQ_Pro();

        public frmLOG_RQ_Proveedor()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(txtIni.Text) > Convert.ToInt32(txtFin.Text))
                {
                    MessageBox.Show("El valor de inicio no puede ser mayor que el valor final", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtFin.Focus();
                }
                else
                {
                    fg.DataSource = nc.LOG_RQ_PROVEEDOR(Convert.ToInt32(txtIni.Text), Convert.ToInt32(txtFin.Text));
                    FormatoGeneral();
                }
            }
            catch
            {
                
            }            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtFin.Focus();
            }
        }

        private void txtFin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar ==(char)13)
            {
                btnMos.Focus();
            }
        }

        public void FormatoGeneral()
        {                       
            
            fg.Cols.Frozen = 4;
            fg.AutoSizeCols();
            fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;
            fg.AllowFreezing = AllowFreezingEnum.Both;

            fg.Cols[1].Width = 300; //Cliente
            fg.Cols[3].Width = 500; //Des

            for (int i = 5; i < fg.Cols.Count; i++)
            {
                if (i != 16 && i != 17 && i != 18 && i != 19)
                {
                    fg.Cols[i].Width = 70;
                    fg.Cols[i].Format = "0.00";
                }                
            }

            fg.Cols[16].Width = 150; //Proveedor
            fg.Cols[17].Width = 300; //Obs
            fg.Cols[18].Width = 150; //Catalogo
            fg.Cols[19].Width = 70; //Fecha Entrega

        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col != 17)
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }
        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGeneral();
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }
        private void fg_AfterEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 17)
            {
                nc.LOG_RQ_Proveedor_Obs(Convert.ToInt32(fg[e.Row, 0]), Convert.ToString(fg[e.Row, 2]), Convert.ToString(fg[e.Row, 17]));
            }
        }

        private void frmLOG_RQ_Proveedor_Load(object sender, EventArgs e)
        {
            fg.Styles.Normal.WordWrap = true;
            fg.Rows.Count = 1;
            fg.Cols.Count = 1;
            fg.Rows[0].Height = 50;
        }
    }
}
