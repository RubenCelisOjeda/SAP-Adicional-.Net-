﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using Entidades.LOG_OFC;

namespace SAP_Adicional
{
    public partial class frmLOG_OFC : Form , LOG_OFC_Filtros
    {
        NConsultas nc = new NConsultas();
        NLOG_OFC nofc = new NLOG_OFC();
        VarGlo varglo = VarGlo.Instance();

        public Int64 NumMov;

        public frmLOG_OFC()
        {
            InitializeComponent();
        }

        private void txtTipOFC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo OFC", "Filtro_LOG_OFC_TipOFC", this.txtTipOFC.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    if (txtCodTipOFC.Text == 2.ToString())
                    {
                        pnTipSer.Visible = true;
                        txtTipSer.Focus();
                    }
                    else
                    {
                        pnTipSer.Visible = false;
                        txtMon.Focus();
                    }
                }
            }
        }

        private void txtTipOFC_TextChanged(object sender, EventArgs e)
        {

        }

        public void ConsultaDatos(string vista, string procedimiento, string param1, string param2)
        {
            DataTable dt = new DataTable();

            dt = nc.LOG_OFC_Filtros(vista, procedimiento, param1, param2);

            if (dt.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 41;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.LOG_OFC = this;
                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Tipo OFC":
                        txtCodTipOFC.Text = row["Codigo"].ToString();
                        txtTipOFC.Text = row["TipoOFC"].ToString();

                        if (txtCodTipOFC.Text == 2.ToString())
                        {
                            pnTipSer.Visible = true;
                            txtTipSer.Focus();
                        }
                        else
                        {
                            pnTipSer.Visible = false;
                            txtMon.Focus();
                        }
                        break;
                    case "Tipo de Servicio":
                        txtCodTipSer.Text = row["Codigo"].ToString();
                        txtTipSer.Text = row["Tipo Servicio"].ToString();
                        break;
                    case "Servicio":
                        txtCodGas.Text = row["Codigo"].ToString();
                        txtDesGas.Text = row["Servicio"].ToString();
                        txtCta.Text = row["Cuenta"].ToString();
                        txtCodAre.Text = row["CodAre"].ToString();
                        txtAre.Text = row["Area"].ToString();
                        txtCodSubAre.Text = row["CodSubAre"].ToString();
                        txtSubAre.Text = row["SubArea"].ToString();
                        txtCodUniNeg.Text = row["CodUniNeg"].ToString();
                        txtUniNeg.Text = row["UnidadNegocio"].ToString();
                        break;
                    case "Categoria":
                        txtCodCatGas.Text = row["Codigo"].ToString();
                        txtCatGas.Text = row["Categoria"].ToString();
                        txtPro.Focus();
                        break;
                    case "Area":
                        txtCodAre.Text = row["Codigo"].ToString();
                        txtAre.Text = row["Area"].ToString();
                        txtSubAre.Focus();
                        break;
                    case "SubArea":
                        txtCodSubAre.Text = row["Codigo"].ToString();
                        txtSubAre.Text = row["SubArea"].ToString();
                        txtUniNeg.Focus();
                        break;
                    case "Unidad de Negocio":
                        txtCodUniNeg.Text = row["Codigo"].ToString();
                        txtUniNeg.Text = row["UnidadNegocio"].ToString();
                        btnSerAgr.Focus();
                        break;
                    case "Proveedor":
                        txtCodPro.Text = row["Codigo"].ToString();
                        txtPro.Text = row["Proveedor"].ToString();
                        txtDesGas.Focus();
                        break;
                    case "Moneda":
                        txtCodMon.Text = row["Codigo"].ToString();
                        txtMon.Text = row["Moneda"].ToString();
                        txtCatGas.Focus();
                        break;
                    default:
                        break;
                }
            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional");
            }
        }

        public void recdat_LOG_OFC_TipOFC(string CodTipOFC, string TipOFC)
        {
            txtCodTipOFC.Text = CodTipOFC;
            txtTipOFC.Text = TipOFC;
        }

        public void recdat_LOG_OFC_Mon(string CodMon, string Mon)
        {
            txtCodMon.Text = CodMon;
            txtMon.Text = Mon;
        }

        public void recdat_LOG_OFC_Pro(string CodPro, string Pro)
        {
            txtCodPro.Text = CodPro;
            txtPro.Text = Pro;
        }

        public void recdat_LOG_OFC_TipSer(string CodTipSer, string TipSer)
        {
            txtCodTipSer.Text = CodTipSer;
            txtTipSer.Text = TipSer;
        }

        public void recdat_LOG_OFC_CatGas(string CodCatGas, string CatGas)
        {
            this.txtCodCatGas.Text = CodCatGas;
            this.txtCatGas.Text = CatGas;
        }

        public void recdat_LOG_OFC_Are(string CodAre, string Are)
        {
            this.txtCodAre.Text = CodAre;
            this.txtAre.Text = Are;
        }

        public void recdat_LOG_OFC_SubAre(string CodSubAre, string SubAre)
        {
            this.txtCodSubAre.Text = CodSubAre;
            this.txtSubAre.Text = SubAre;
        }

        public void recdat_LOG_OFC_UniNeg(string CodUniNeg, string UniNeg)
        {
            this.txtCodUniNeg.Text = CodUniNeg;
            this.txtUniNeg.Text = UniNeg;
        }

        private void txtTipSer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo de Servicio", "Filtro_LOG_OFC_TipSer", this.txtTipSer.Text, "");

                if (varglo.Elegi == true)
                {
                    txtMon.Focus();
                }
            }
        }

        private void txtDesGas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Servicio", "Filtro_LOG_OFC_Ser",this.txtDesGas.Text,this.txtCodCatGas.Text);

                if (varglo.Elegi == true)
                {
                    txtDes.Focus();
                }
            }
        }

        public void recdat_LOG_OFC_Ser(string CodSer, string Ser, string Cta, string CodAre, string Are, string CodSubAre, string SubAre, string CodUniNeg, string UniNeg)
        {
            this.txtCodGas.Text = CodSer;
            this.txtDesGas.Text = Ser;
            this.txtCta.Text = Cta;
            this.txtCodAre.Text = CodAre;
            this.txtAre.Text = Are;
            this.txtCodSubAre.Text = CodSubAre;
            this.txtSubAre.Text = SubAre;
            this.txtCodUniNeg.Text = CodUniNeg;
            this.txtUniNeg.Text = UniNeg;
        }

        private void txtCatGas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Categoria", "Filtro_LOG_OFC_CatSer", this.txtCatGas.Text,"");

                if (varglo.Elegi == true)
                {
                    this.txtPro.Focus();
                }
            }
        }

        private void txtAre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Area", "Filtro_SAP_Area", this.txtAre.Text, "");

                if (varglo.Elegi == true)
                {
                    this.txtSubAre.Focus();
                }
            }
        }

        private void txtSubAre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("SubArea", "Filtro_SAP_SubArea", this.txtSubAre.Text, this.txtCodAre.Text);

                if (varglo.Elegi == true)
                {
                    this.txtUniNeg.Focus();
                }
            }
        }

        private void txtUniNeg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Unidad de Negocio", "Filtro_SAP_UnidadNegocio", this.txtUniNeg.Text, this.txtCodSubAre.Text);

                if (varglo.Elegi == true)
                {
                    this.txtRQ.Focus();
                }
            }
        }

        private void txtTipOFC_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtTipOFC);
        }

        private void txtTipSer_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtTipSer);
        }

        private void txtCatGas_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtCatGas);
        }

        private void txtDesGas_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtDesGas);
        }

        private void txtAre_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtAre);
        }

        private void txtSubAre_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtSubAre);
        }

        private void txtUniNeg_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtUniNeg);
        }

        private void txtPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Proveedor", "Filtro_Proveedor", this.txtPro.Text, "");

                if (varglo.Elegi == true)
                {
                    this.txtDesGas.Focus();
                }
            }
        }

        private void txtDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtCanSer.Focus();
            }
        }

        private void txtCanSer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPreUni.Focus();
            }
        }

        private  void FormatoDGV()
        {
            dgvSer.ColumnCount = 20;

            dgvSer.Columns[0].Name = "Item";
            dgvSer.Columns[1].Name = "CodCatGas";
            dgvSer.Columns[2].Name = "Categoria";
            dgvSer.Columns[3].Name = "CodPro";
            dgvSer.Columns[4].Name = "Proveedor";
            dgvSer.Columns[5].Name = "CodGas";
            dgvSer.Columns[6].Name = "Gasto";
            dgvSer.Columns[7].Name = "Cta. Mayor";
            dgvSer.Columns[8].Name = "Des. Servicio";
            dgvSer.Columns[9].Name = "Can";
            dgvSer.Columns[10].Name = "Precio Und.";
            dgvSer.Columns[11].Name = "Total";
            dgvSer.Columns[12].Name = "CodAre";
            dgvSer.Columns[13].Name = "Area";
            dgvSer.Columns[14].Name = "CodSubAre";
            dgvSer.Columns[15].Name = "SubArea";
            dgvSer.Columns[16].Name = "CodUniNeg";
            dgvSer.Columns[17].Name = "Unid. Negocio";
            dgvSer.Columns[18].Name = "RQ";
            dgvSer.Columns[19].Name = "Ruta archivo";
            
            dgvSer.Font = new Font("Tahoma", 7);

            dgvSer.Columns[6].Frozen = true;
            dgvSer.RowHeadersVisible = false;

            dgvSer.Columns[0].Width = 50; //Item
            dgvSer.Columns[1].Visible = false;//CodCatGas
            dgvSer.Columns[2].Width = 100;//Categoria
            dgvSer.Columns[3].Visible = false; //CodPro
            dgvSer.Columns[4].Width = 200;//Proveedor
            dgvSer.Columns[5].Visible = false; //CodGas
            dgvSer.Columns[6].Width = 150;//Gasto
            dgvSer.Columns[7].Width = 80;//Cta. Mayor
            dgvSer.Columns[8].Width = 250;//Des. Servicio
            dgvSer.Columns[9].Width = 50;//Can
            dgvSer.Columns[10].Width = 50;//Precio Und.
            dgvSer.Columns[11].Width = 50;//Total.
            dgvSer.Columns[12].Visible = false;//CodAre
            dgvSer.Columns[13].Width = 100; //Area
            dgvSer.Columns[14].Visible = false;//CodSubAre
            dgvSer.Columns[15].Width = 100;//SubArea
            dgvSer.Columns[16].Visible = false;//CodUniNeg
            dgvSer.Columns[17].Width = 100;//Unid. Negocio
            dgvSer.Columns[18].Width = 50;//rq
            dgvSer.Columns[19].Width = 250;//Ruta archivo

        }

        private void frmLOG_OFC_Load(object sender, EventArgs e)
        {
            FormatoDGV();
        }

        private void btnSerAgr_Click(object sender, EventArgs e)
        {
            //Agregamos la fila al dgvSer

            string[] rowDet = new string[]
            {
                (dgvSer.Rows.Count + 1).ToString(),
                this.txtCodCatGas.Text,
                this.txtCatGas.Text,
                this.txtCodPro.Text,
                this.txtPro.Text,
                this.txtCodGas.Text,
                this.txtDesGas.Text,
                this.txtCta.Text,
                this.txtDes.Text,
                this.txtCanSer.Text,
                this.txtPreUni.Text,
                (Convert.ToInt16(txtCanSer.Text) * Convert.ToDecimal(txtPreUni.Text)).ToString(),
                this.txtCodAre.Text,
                this.txtAre.Text,
                this.txtCodSubAre.Text,
                this.txtSubAre.Text,
                this.txtCodUniNeg.Text,
                this.txtUniNeg.Text,
                this.txtRQ.Text,
                this.txtRutArcAdj.Text
            };

            dgvSer.Rows.Add(rowDet);

            this.btnSerCan.PerformClick();
        }

        private void frmLOG_OFC_Resize(object sender, EventArgs e)
        {
            pnDet.Width = this.Width-100;
            tbDet.Width = pnDet.Width - 20;
            dgvSer.Width = tbDet.Width - 30;

        }

        private void btnSerCan_Click(object sender, EventArgs e)
        {
            this.txtCodCatGas.Text = "";
            this.txtCatGas.Text= "";
            this.txtCodPro.Text= "";
            this.txtPro.Text= "";
            this.txtCodGas.Text= "";
            this.txtDesGas.Text= "";
            this.txtCta.Text= "";
            this.txtDes.Text= "";
            this.txtCanSer.Text= "";
            this.txtCodAre.Text= "";
            this.txtAre.Text= "";
            this.txtCodSubAre.Text= "";
            this.txtSubAre.Text= "";
            this.txtCodUniNeg.Text= "";
            this.txtUniNeg.Text = "";
        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }

        public void LOG_OFC_EstBot(string BotonEstado)
        {
            bool[] EstadoM = { true };

            switch (BotonEstado)
            {
                case "nuevo":
                case "modificar":
                    EstadoM = matriz(false, false, true, false);
                    break;
                case "abrir":

                    switch (Convert.ToInt16(txtCodEst.Text))
                    {
                        case 1:
                            EstadoM = matriz(true, true, false, true);
                            break;
                        case 2:
                        case 3:
                        case 4:
                            EstadoM = matriz(true, true, false, false);
                            break;
                    }
                    break;
                case "guardar":
                case"deshacer":
                    EstadoM = matriz(true, true, false, true);
                    break;
            }

            this.btnNuevo.Enabled = EstadoM[0];
            this.btnAbrir.Enabled = EstadoM[1];
            this.btnGuardar.Enabled = EstadoM[2];
            this.btnModificar.Enabled = EstadoM[3];
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LOG_OFC_EstBot("nuevo");
            LimpiarControles();

            NumMov = 0;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {            

            LOG_OFC Enc = new LOG_OFC();

            Enc.NumMov = NumMov;
            Enc.NumOFC = txtNumOFC.Text;
            Enc.CodTipOFC = Convert.ToInt16(txtCodTipOFC.Text);
            Enc.CodTipSer = Convert.ToInt16(txtCodTipSer.Text);
            Enc.DocCur = txtCodMon.Text;
            Enc.EstDoc = 1;
            Enc.CodUsu = varglo.CodUsuAct;

            //Recorremos el datagridview para agregar las lineas de detalle cero
            foreach (DataGridViewRow row in dgvSer.Rows)
            {
                LOG_OFC_Det Det = new LOG_OFC_Det();

                Det.Item = Convert.ToInt16(row.Cells["Item"].Value);
                Det.CodCatGas = Convert.ToInt16(row.Cells["CodCatGas"].Value);
                Det.CodPro = Convert.ToString(row.Cells["CodPro"].Value);
                Det.CodGas = Convert.ToString(row.Cells["CodGas"].Value);
                Det.CodArt = "";
                Det.Cta = Convert.ToInt32(row.Cells["Cta. Mayor"].Value);
                Det.DesSer = Convert.ToString(row.Cells["Des. Servicio"].Value);
                Det.CanSer = Convert.ToInt16(row.Cells["Can"].Value);
                Det.Can = 0;
                Det.PreUni = Convert.ToDecimal(row.Cells["Precio Und."].Value);
                Det.Tot = Convert.ToDecimal(row.Cells["Total"].Value);
                Det.CodAre = Convert.ToString(row.Cells["CodAre"].Value);
                Det.CodSubAre = Convert.ToString(row.Cells["CodSubAre"].Value);
                Det.CodUniNeg = Convert.ToString(row.Cells["CodUniNeg"].Value);
                Det.RutArc = Convert.ToString(row.Cells["Ruta archivo"].Value);

                Enc.Det.Add(Det);
            }

            //Pasamos la entidad para guardar
            nofc.LOG_OFC_ingact(Enc);
            //Recuperamos el numero de movimiento
            NumMov = Enc.NumMov;
            this.txtNumOFC.Text = Enc.NumOFC;

            LOG_OFC_EstBot("guardar");


        }

        private void txtMon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Moneda", "Filtro_SAP_Monedas", this.txtMon.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    txtCatGas.Focus();
                }
            }
        }

        private void btnRutArcAdj_Click(object sender, EventArgs e)
        {
            string file_name = string.Empty;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string dir = @openFileDialog1.FileName; //aqui es donde me trae la ruta con el nombre del archivo.
                //string destino = Path.GetFileName(dir);
                txtRutArcAdj.Text = dir;
            }
        }

        private void txtPreUni_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar== 13)
            {
                txtAre.Focus();
            }
        }

        private void txtRQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtRutArcAdj.Focus();
            }
        }

        private void txtRutArcAdj_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnSerAgr.Focus();
            }
        }

        public void LimpiarControles()
        {
            foreach (Control ctrl in this.pnEnc.Controls)
            {
                if (ctrl is TextBox) ctrl.Text = "";
            }

            foreach (Control ctrl in this.pnDet.Controls)
            {
                if (ctrl is TextBox) ctrl.Text = "";
            }

            dgvSer.Rows.Clear();        
        }

        public void Buscar()
        {
            FormatoDGV();

            pnEnc.Visible = true;
            pnDet.Visible = true;

            DataSet dsLOG_OFC = new DataSet();

            dsLOG_OFC = nofc.LOG_OFC_rec(NumMov);

            //Tabla VEN_SolNotCre_Enc del DataSet
            DataTable dtEnc = dsLOG_OFC.Tables["LOG_OFC_Enc"];

            this.NumMov = Convert.ToInt64(dtEnc.Rows[0]["NumMov"]);
            this.txtNumOFC.Text = dtEnc.Rows[0]["numofc"].ToString();
            //this.txtFecEmi.Text = dtEnc.Rows[0]["FecEmi"].ToString();
            this.txtCodTipOFC.Text = dtEnc.Rows[0]["CodtipOFC"].ToString();
            this.txtTipOFC.Text = dtEnc.Rows[0]["TipOFC"].ToString();
            this.txtCodTipSer.Text = dtEnc.Rows[0]["CodTipSer"].ToString();
            this.txtTipSer.Text = dtEnc.Rows[0]["TipSer"].ToString();
            this.txtCodEst.Text = dtEnc.Rows[0]["EstDoc"].ToString();
            this.txtEst.Text = dtEnc.Rows[0]["Estado"].ToString();
            this.txtCodMon.Text = dtEnc.Rows[0]["DocCur"].ToString();
            this.txtMon.Text = dtEnc.Rows[0]["Moneda"].ToString();

            //Tabla VEN_SolNotCre_Det del DataSet
            DataTable dtDet = dsLOG_OFC.Tables["LOG_OFC_Det"];

            foreach (DataRow dr in dtDet.Rows)
            {
                string[] rowDet = new string[]
                                            {(dgvSer.Rows.Count + 1).ToString(),
                                            dr["CodCatGas"].ToString(),
                                            dr["Cat"].ToString(),
                                            dr["codpro"].ToString(),
                                            dr["proveedor"].ToString(),
                                            dr["codgas"].ToString(),
                                            dr["gasto"].ToString(),
                                            dr["cta"].ToString(),
                                            dr["desser"].ToString(),
                                            dr["canser"].ToString(),
                                            dr["preuni"].ToString(),
                                            dr["tot"].ToString(),
                                            dr["codare"].ToString(),
                                            dr["area"].ToString(),
                                            dr["codsubare"].ToString(),
                                            dr["subare"].ToString(),
                                            dr["codunineg"].ToString(),
                                            dr["unineg"].ToString(),
                                            dr["rq"].ToString(),
                                            dr["rutarc"].ToString()
                                            };

                dgvSer.Rows.Add(rowDet);

            }

            LOG_OFC_EstBot("abrir");

        }

        private void txtMon_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            LOG_OFC_EstBot("modificar");
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            Boolean formCargado;

            formCargado = false;
            //formularios abiertos en la aplicacion
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType() == typeof(frmGEN_AbrDoc) && Convert.ToInt16(frm.Tag) == 99)
                {
                    formCargado = true;
                    frm.BringToFront();
                    frm.Show();
                }
            }

            if (formCargado == false)
            {
                frmGEN_AbrDoc f = new frmGEN_AbrDoc();
                f.Tag = 99;
                f.MdiParent = this.MdiParent;
                f.BringToFront();
                f.Show();
            }

            this.Dispose();

        
        }
    }
}
