﻿namespace SAP_Adicional
{
    partial class frmMan_Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMan_Usuarios));
            this.tabManUsuMae = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gpbBot = new System.Windows.Forms.GroupBox();
            this.btnPri = new System.Windows.Forms.Button();
            this.btnUlt = new System.Windows.Forms.Button();
            this.btnAva = new System.Windows.Forms.Button();
            this.btnRet = new System.Windows.Forms.Button();
            this.chkMosPas = new System.Windows.Forms.CheckBox();
            this.chkUsuAct = new System.Windows.Forms.CheckBox();
            this.txtPasAga = new System.Windows.Forms.TextBox();
            this.txtPas = new System.Windows.Forms.TextBox();
            this.txtUsu = new System.Windows.Forms.TextBox();
            this.txtNomEmp = new System.Windows.Forms.TextBox();
            this.txtCodEmp = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCer = new System.Windows.Forms.Button();
            this.btnCan = new System.Windows.Forms.Button();
            this.btnBor = new System.Windows.Forms.Button();
            this.btnGua = new System.Windows.Forms.Button();
            this.btnNue = new System.Windows.Forms.Button();
            this.btnMod = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnExp = new System.Windows.Forms.Button();
            this.fgMae = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabManUsuMae.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.gpbBot.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMae)).BeginInit();
            this.SuspendLayout();
            // 
            // tabManUsuMae
            // 
            this.tabManUsuMae.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabManUsuMae.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabManUsuMae.Controls.Add(this.tabPage1);
            this.tabManUsuMae.Controls.Add(this.tabPage2);
            this.tabManUsuMae.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabManUsuMae.ItemSize = new System.Drawing.Size(100, 21);
            this.tabManUsuMae.Location = new System.Drawing.Point(3, 6);
            this.tabManUsuMae.Name = "tabManUsuMae";
            this.tabManUsuMae.SelectedIndex = 0;
            this.tabManUsuMae.Size = new System.Drawing.Size(1092, 523);
            this.tabManUsuMae.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabManUsuMae.TabIndex = 0;
            this.tabManUsuMae.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabManUsuMae_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.gpbBot);
            this.tabPage1.Controls.Add(this.chkMosPas);
            this.tabPage1.Controls.Add(this.chkUsuAct);
            this.tabPage1.Controls.Add(this.txtPasAga);
            this.tabPage1.Controls.Add(this.txtPas);
            this.tabPage1.Controls.Add(this.txtUsu);
            this.tabPage1.Controls.Add(this.txtNomEmp);
            this.tabPage1.Controls.Add(this.txtCodEmp);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnCer);
            this.tabPage1.Controls.Add(this.btnCan);
            this.tabPage1.Controls.Add(this.btnBor);
            this.tabPage1.Controls.Add(this.btnGua);
            this.tabPage1.Controls.Add(this.btnNue);
            this.tabPage1.Controls.Add(this.btnMod);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1084, 494);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mantenimiento";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // gpbBot
            // 
            this.gpbBot.Controls.Add(this.btnPri);
            this.gpbBot.Controls.Add(this.btnUlt);
            this.gpbBot.Controls.Add(this.btnAva);
            this.gpbBot.Controls.Add(this.btnRet);
            this.gpbBot.Location = new System.Drawing.Point(272, 410);
            this.gpbBot.Name = "gpbBot";
            this.gpbBot.Size = new System.Drawing.Size(371, 72);
            this.gpbBot.TabIndex = 13;
            this.gpbBot.TabStop = false;
            // 
            // btnPri
            // 
            this.btnPri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPri.Image = ((System.Drawing.Image)(resources.GetObject("btnPri.Image")));
            this.btnPri.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPri.Location = new System.Drawing.Point(45, 15);
            this.btnPri.Name = "btnPri";
            this.btnPri.Size = new System.Drawing.Size(71, 49);
            this.btnPri.TabIndex = 14;
            this.btnPri.Text = "Primero";
            this.btnPri.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPri.UseVisualStyleBackColor = true;
            this.btnPri.Click += new System.EventHandler(this.btnPri_Click);
            // 
            // btnUlt
            // 
            this.btnUlt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUlt.Image = ((System.Drawing.Image)(resources.GetObject("btnUlt.Image")));
            this.btnUlt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUlt.Location = new System.Drawing.Point(253, 15);
            this.btnUlt.Name = "btnUlt";
            this.btnUlt.Size = new System.Drawing.Size(71, 49);
            this.btnUlt.TabIndex = 17;
            this.btnUlt.Text = "Ultimo";
            this.btnUlt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnUlt.UseVisualStyleBackColor = true;
            this.btnUlt.Click += new System.EventHandler(this.btnUlt_Click);
            // 
            // btnAva
            // 
            this.btnAva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAva.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAva.Image = ((System.Drawing.Image)(resources.GetObject("btnAva.Image")));
            this.btnAva.Location = new System.Drawing.Point(183, 15);
            this.btnAva.Name = "btnAva";
            this.btnAva.Size = new System.Drawing.Size(71, 49);
            this.btnAva.TabIndex = 16;
            this.btnAva.Text = "Avanzar";
            this.btnAva.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAva.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAva.UseVisualStyleBackColor = true;
            this.btnAva.Click += new System.EventHandler(this.btnAva_Click);
            // 
            // btnRet
            // 
            this.btnRet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRet.Image = ((System.Drawing.Image)(resources.GetObject("btnRet.Image")));
            this.btnRet.Location = new System.Drawing.Point(114, 15);
            this.btnRet.Name = "btnRet";
            this.btnRet.Size = new System.Drawing.Size(71, 49);
            this.btnRet.TabIndex = 15;
            this.btnRet.Text = "Retroceder";
            this.btnRet.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRet.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRet.UseVisualStyleBackColor = true;
            this.btnRet.Click += new System.EventHandler(this.btnRet_Click);
            // 
            // chkMosPas
            // 
            this.chkMosPas.AutoSize = true;
            this.chkMosPas.Location = new System.Drawing.Point(422, 180);
            this.chkMosPas.Name = "chkMosPas";
            this.chkMosPas.Size = new System.Drawing.Size(112, 17);
            this.chkMosPas.TabIndex = 12;
            this.chkMosPas.Text = "Mostrar Password";
            this.chkMosPas.UseVisualStyleBackColor = true;
            this.chkMosPas.CheckedChanged += new System.EventHandler(this.chkMosPas_CheckedChanged);
            this.chkMosPas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkMosPas_KeyPress);
            // 
            // chkUsuAct
            // 
            this.chkUsuAct.AutoSize = true;
            this.chkUsuAct.Location = new System.Drawing.Point(272, 232);
            this.chkUsuAct.Name = "chkUsuAct";
            this.chkUsuAct.Size = new System.Drawing.Size(95, 17);
            this.chkUsuAct.TabIndex = 11;
            this.chkUsuAct.Text = "Usuario Activo";
            this.chkUsuAct.UseVisualStyleBackColor = true;
            // 
            // txtPasAga
            // 
            this.txtPasAga.ForeColor = System.Drawing.Color.Blue;
            this.txtPasAga.Location = new System.Drawing.Point(272, 202);
            this.txtPasAga.Name = "txtPasAga";
            this.txtPasAga.PasswordChar = '*';
            this.txtPasAga.Size = new System.Drawing.Size(144, 21);
            this.txtPasAga.TabIndex = 10;
            this.txtPasAga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPasAga_KeyPress);
            // 
            // txtPas
            // 
            this.txtPas.ForeColor = System.Drawing.Color.Blue;
            this.txtPas.Location = new System.Drawing.Point(272, 177);
            this.txtPas.Name = "txtPas";
            this.txtPas.PasswordChar = '*';
            this.txtPas.Size = new System.Drawing.Size(144, 21);
            this.txtPas.TabIndex = 9;
            this.txtPas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPas_KeyPress);
            // 
            // txtUsu
            // 
            this.txtUsu.ForeColor = System.Drawing.Color.Blue;
            this.txtUsu.Location = new System.Drawing.Point(272, 151);
            this.txtUsu.Name = "txtUsu";
            this.txtUsu.Size = new System.Drawing.Size(144, 21);
            this.txtUsu.TabIndex = 8;
            this.txtUsu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsu_KeyPress);
            // 
            // txtNomEmp
            // 
            this.txtNomEmp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNomEmp.ForeColor = System.Drawing.Color.Blue;
            this.txtNomEmp.Location = new System.Drawing.Point(335, 125);
            this.txtNomEmp.Name = "txtNomEmp";
            this.txtNomEmp.Size = new System.Drawing.Size(222, 21);
            this.txtNomEmp.TabIndex = 7;
            this.txtNomEmp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomUsu_KeyPress);
            // 
            // txtCodEmp
            // 
            this.txtCodEmp.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodEmp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodEmp.Location = new System.Drawing.Point(272, 125);
            this.txtCodEmp.Name = "txtCodEmp";
            this.txtCodEmp.Size = new System.Drawing.Size(64, 21);
            this.txtCodEmp.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(181, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Password(again):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(213, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(222, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Usuario:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(222, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // btnCer
            // 
            this.btnCer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCer.Image = ((System.Drawing.Image)(resources.GetObject("btnCer.Image")));
            this.btnCer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCer.Location = new System.Drawing.Point(61, 290);
            this.btnCer.Name = "btnCer";
            this.btnCer.Size = new System.Drawing.Size(67, 41);
            this.btnCer.TabIndex = 5;
            this.btnCer.Text = "Cerrar";
            this.btnCer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCer.UseVisualStyleBackColor = true;
            this.btnCer.Click += new System.EventHandler(this.btnCer_Click);
            // 
            // btnCan
            // 
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Image = ((System.Drawing.Image)(resources.GetObject("btnCan.Image")));
            this.btnCan.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCan.Location = new System.Drawing.Point(61, 250);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(67, 41);
            this.btnCan.TabIndex = 4;
            this.btnCan.Text = "Cancelar";
            this.btnCan.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // btnBor
            // 
            this.btnBor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBor.Image = ((System.Drawing.Image)(resources.GetObject("btnBor.Image")));
            this.btnBor.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBor.Location = new System.Drawing.Point(61, 210);
            this.btnBor.Name = "btnBor";
            this.btnBor.Size = new System.Drawing.Size(67, 41);
            this.btnBor.TabIndex = 3;
            this.btnBor.Text = "Borrar";
            this.btnBor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBor.UseVisualStyleBackColor = true;
            this.btnBor.Click += new System.EventHandler(this.btnBor_Click);
            // 
            // btnGua
            // 
            this.btnGua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGua.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGua.Image = ((System.Drawing.Image)(resources.GetObject("btnGua.Image")));
            this.btnGua.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGua.Location = new System.Drawing.Point(61, 170);
            this.btnGua.Name = "btnGua";
            this.btnGua.Size = new System.Drawing.Size(67, 41);
            this.btnGua.TabIndex = 2;
            this.btnGua.Text = "Guardar";
            this.btnGua.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGua.UseVisualStyleBackColor = true;
            this.btnGua.Click += new System.EventHandler(this.btnGua_Click);
            // 
            // btnNue
            // 
            this.btnNue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNue.Image = ((System.Drawing.Image)(resources.GetObject("btnNue.Image")));
            this.btnNue.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNue.Location = new System.Drawing.Point(61, 90);
            this.btnNue.Name = "btnNue";
            this.btnNue.Size = new System.Drawing.Size(67, 41);
            this.btnNue.TabIndex = 0;
            this.btnNue.Text = "Nuevo";
            this.btnNue.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNue.UseVisualStyleBackColor = true;
            this.btnNue.Click += new System.EventHandler(this.btnNue_Click);
            // 
            // btnMod
            // 
            this.btnMod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMod.Image = ((System.Drawing.Image)(resources.GetObject("btnMod.Image")));
            this.btnMod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMod.Location = new System.Drawing.Point(61, 130);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(67, 41);
            this.btnMod.TabIndex = 1;
            this.btnMod.Text = "Modificar";
            this.btnMod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnExp);
            this.tabPage2.Controls.Add(this.fgMae);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1084, 494);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Maestro";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnExp
            // 
            this.btnExp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExp.Image = ((System.Drawing.Image)(resources.GetObject("btnExp.Image")));
            this.btnExp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExp.Location = new System.Drawing.Point(6, 412);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(85, 44);
            this.btnExp.TabIndex = 2;
            this.btnExp.Text = "Exportar Excel";
            this.btnExp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click_1);
            // 
            // fgMae
            // 
            this.fgMae.AllowFiltering = true;
            this.fgMae.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgMae.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgMae.Location = new System.Drawing.Point(6, 6);
            this.fgMae.Name = "fgMae";
            this.fgMae.Rows.DefaultSize = 19;
            this.fgMae.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgMae.Size = new System.Drawing.Size(1022, 400);
            this.fgMae.TabIndex = 0;
            this.fgMae.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgMae_AfterEdit);
            this.fgMae.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgMae_KeyPressEdit);
            this.fgMae.DoubleClick += new System.EventHandler(this.fgMae_DoubleClick);
            // 
            // frmMan_Usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 532);
            this.Controls.Add(this.tabManUsuMae);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMan_Usuarios";
            this.Text = "Mantenimiento Usuarios";
            this.Load += new System.EventHandler(this.frmMan_Usuarios_Load);
            this.tabManUsuMae.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.gpbBot.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgMae)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabManUsuMae;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnCer;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Button btnBor;
        private System.Windows.Forms.Button btnGua;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.TextBox txtPasAga;
        private System.Windows.Forms.TextBox txtPas;
        private System.Windows.Forms.TextBox txtUsu;
        private System.Windows.Forms.TextBox txtNomEmp;
        private System.Windows.Forms.TextBox txtCodEmp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkUsuAct;
        private System.Windows.Forms.CheckBox chkMosPas;
        private System.Windows.Forms.GroupBox gpbBot;
        private System.Windows.Forms.Button btnPri;
        private System.Windows.Forms.Button btnUlt;
        private System.Windows.Forms.Button btnAva;
        private System.Windows.Forms.Button btnRet;
        private C1.Win.C1FlexGrid.C1FlexGrid fgMae;
        private System.Windows.Forms.Button btnNue;
        private System.Windows.Forms.Button btnExp;
    }
}