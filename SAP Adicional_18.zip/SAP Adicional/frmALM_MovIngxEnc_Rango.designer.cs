﻿namespace SAP_Adicional
{
    partial class frmALM_MovIngxEnc_Rango
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExp = new System.Windows.Forms.Button();
            this.btnMos = new System.Windows.Forms.Button();
            this.dtpFinal = new System.Windows.Forms.DateTimePicker();
            this.dtpInicio = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCodEnc = new System.Windows.Forms.TextBox();
            this.txtEnc = new System.Windows.Forms.TextBox();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(743, 17);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(111, 23);
            this.btnExp.TabIndex = 5;
            this.btnExp.Text = "Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // btnMos
            // 
            this.btnMos.Location = new System.Drawing.Point(634, 17);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(111, 23);
            this.btnMos.TabIndex = 4;
            this.btnMos.Text = "Mostrar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // dtpFinal
            // 
            this.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFinal.Location = new System.Drawing.Point(532, 18);
            this.dtpFinal.Name = "dtpFinal";
            this.dtpFinal.Size = new System.Drawing.Size(92, 21);
            this.dtpFinal.TabIndex = 3;
            this.dtpFinal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpFinal_KeyPress);
            // 
            // dtpInicio
            // 
            this.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInicio.Location = new System.Drawing.Point(389, 18);
            this.dtpInicio.Name = "dtpInicio";
            this.dtpInicio.Size = new System.Drawing.Size(88, 21);
            this.dtpInicio.TabIndex = 2;
            this.dtpInicio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpInicio_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(487, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "F.  Final:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(339, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = "F.  Inicial:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 51;
            this.label3.Text = "Encargado:";
            // 
            // txtCodEnc
            // 
            this.txtCodEnc.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodEnc.Location = new System.Drawing.Point(67, 18);
            this.txtCodEnc.Name = "txtCodEnc";
            this.txtCodEnc.ReadOnly = true;
            this.txtCodEnc.Size = new System.Drawing.Size(45, 21);
            this.txtCodEnc.TabIndex = 6;
            this.txtCodEnc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEnc
            // 
            this.txtEnc.Location = new System.Drawing.Point(112, 18);
            this.txtEnc.Name = "txtEnc";
            this.txtEnc.Size = new System.Drawing.Size(216, 21);
            this.txtEnc.TabIndex = 1;
            this.txtEnc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnc_KeyPress);
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,100,Columns:";
            this.fg.Location = new System.Drawing.Point(5, 56);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 20;
            this.fg.Size = new System.Drawing.Size(985, 470);
            this.fg.TabIndex = 52;
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            // 
            // frmALM_MovIngxEnc_Rango
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 538);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.txtEnc);
            this.Controls.Add(this.txtCodEnc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpFinal);
            this.Controls.Add(this.dtpInicio);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.btnMos);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_MovIngxEnc_Rango";
            this.Text = "Movimiento de Ingreso - Encargado Almacen";
            this.Load += new System.EventHandler(this.frmALM_MovIngxEnc_Rango_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        //private C1.Win.C1FlexGrid.C1FlexGrid fg;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.DateTimePicker dtpFinal;
        private System.Windows.Forms.DateTimePicker dtpInicio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtEnc;
        public System.Windows.Forms.TextBox txtCodEnc;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
    }
}