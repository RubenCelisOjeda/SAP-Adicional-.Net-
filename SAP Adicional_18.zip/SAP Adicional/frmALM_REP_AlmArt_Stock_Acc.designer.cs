﻿namespace SAP_Adicional
{
    partial class frmALM_REP_AlmArt_Stock_Acc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodAre = new System.Windows.Forms.TextBox();
            this.txtCodAlm = new System.Windows.Forms.TextBox();
            this.txtAre = new System.Windows.Forms.TextBox();
            this.txtAlm = new System.Windows.Forms.TextBox();
            this.chkSelAre = new System.Windows.Forms.CheckBox();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usuario/Área:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Almacén:";
            // 
            // txtCodAre
            // 
            this.txtCodAre.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodAre.Location = new System.Drawing.Point(90, 33);
            this.txtCodAre.Name = "txtCodAre";
            this.txtCodAre.Size = new System.Drawing.Size(57, 21);
            this.txtCodAre.TabIndex = 0;
            // 
            // txtCodAlm
            // 
            this.txtCodAlm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodAlm.Location = new System.Drawing.Point(90, 66);
            this.txtCodAlm.Name = "txtCodAlm";
            this.txtCodAlm.Size = new System.Drawing.Size(57, 21);
            this.txtCodAlm.TabIndex = 3;
            // 
            // txtAre
            // 
            this.txtAre.Location = new System.Drawing.Point(146, 33);
            this.txtAre.Name = "txtAre";
            this.txtAre.Size = new System.Drawing.Size(343, 21);
            this.txtAre.TabIndex = 1;
            this.txtAre.TextChanged += new System.EventHandler(this.txtAre_TextChanged);
            this.txtAre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsuAre_KeyPress);
            // 
            // txtAlm
            // 
            this.txtAlm.Location = new System.Drawing.Point(146, 66);
            this.txtAlm.Name = "txtAlm";
            this.txtAlm.Size = new System.Drawing.Size(343, 21);
            this.txtAlm.TabIndex = 4;
            this.txtAlm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAlm_KeyPress);
            // 
            // chkSelAre
            // 
            this.chkSelAre.AutoSize = true;
            this.chkSelAre.Location = new System.Drawing.Point(505, 35);
            this.chkSelAre.Name = "chkSelAre";
            this.chkSelAre.Size = new System.Drawing.Size(114, 17);
            this.chkSelAre.TabIndex = 2;
            this.chkSelAre.Text = "Selección por área";
            this.chkSelAre.UseVisualStyleBackColor = true;
            this.chkSelAre.CheckedChanged += new System.EventHandler(this.chkSelAre_CheckedChanged);
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(5, 103);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.Size = new System.Drawing.Size(641, 549);
            this.fg.TabIndex = 3;
            this.fg.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fg_AfterEdit);
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            // 
            // frmALM_REP_AlmArt_Stock_Acc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 653);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.chkSelAre);
            this.Controls.Add(this.txtAlm);
            this.Controls.Add(this.txtAre);
            this.Controls.Add(this.txtCodAlm);
            this.Controls.Add(this.txtCodAre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_REP_AlmArt_Stock_Acc";
            this.Text = "Acceso a vista de almacenes";
            this.Load += new System.EventHandler(this.frmALM_REP_AlmArt_Stock_Acc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCodAre;
        private System.Windows.Forms.TextBox txtCodAlm;
        private System.Windows.Forms.TextBox txtAre;
        private System.Windows.Forms.TextBox txtAlm;
        private System.Windows.Forms.CheckBox chkSelAre;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
    }
}