﻿namespace SAP_Adicional
{
    partial class frmOPE_Pro_VisGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnNuePro = new System.Windows.Forms.Button();
            this.btnEdiPro = new System.Windows.Forms.Button();
            this.lblFiltro = new System.Windows.Forms.Label();
            this.txtFiltro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkVisDet = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.AllowUserToResizeRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(12, 61);
            this.dgv.Name = "dgv";
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(1114, 543);
            this.dgv.TabIndex = 0;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            this.dgv.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_ColumnHeaderMouseClick);
            this.dgv.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgv_DataBindingComplete);
            this.dgv.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgv_EditingControlShowing);
            this.dgv.DoubleClick += new System.EventHandler(this.dgv_DoubleClick);
            // 
            // btnNuePro
            // 
            this.btnNuePro.Location = new System.Drawing.Point(713, 20);
            this.btnNuePro.Name = "btnNuePro";
            this.btnNuePro.Size = new System.Drawing.Size(125, 22);
            this.btnNuePro.TabIndex = 1;
            this.btnNuePro.Text = "Nuevo Proyecto";
            this.btnNuePro.UseVisualStyleBackColor = true;
            this.btnNuePro.Click += new System.EventHandler(this.btnNuePro_Click);
            // 
            // btnEdiPro
            // 
            this.btnEdiPro.Location = new System.Drawing.Point(833, 20);
            this.btnEdiPro.Name = "btnEdiPro";
            this.btnEdiPro.Size = new System.Drawing.Size(125, 22);
            this.btnEdiPro.TabIndex = 2;
            this.btnEdiPro.Text = "Editar Proyecto";
            this.btnEdiPro.UseVisualStyleBackColor = true;
            this.btnEdiPro.Click += new System.EventHandler(this.btnEdiPro_Click);
            // 
            // lblFiltro
            // 
            this.lblFiltro.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lblFiltro.Location = new System.Drawing.Point(66, 22);
            this.lblFiltro.Name = "lblFiltro";
            this.lblFiltro.Size = new System.Drawing.Size(138, 21);
            this.lblFiltro.TabIndex = 3;
            this.lblFiltro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtFiltro
            // 
            this.txtFiltro.Location = new System.Drawing.Point(205, 22);
            this.txtFiltro.Name = "txtFiltro";
            this.txtFiltro.Size = new System.Drawing.Size(503, 21);
            this.txtFiltro.TabIndex = 4;
            this.txtFiltro.TextChanged += new System.EventHandler(this.txtFiltro_TextChanged);
            this.txtFiltro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFiltro_KeyPress);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 21);
            this.label1.TabIndex = 5;
            this.label1.Text = "FILTRO:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkVisDet
            // 
            this.chkVisDet.AutoSize = true;
            this.chkVisDet.Location = new System.Drawing.Point(979, 21);
            this.chkVisDet.Name = "chkVisDet";
            this.chkVisDet.Size = new System.Drawing.Size(96, 17);
            this.chkVisDet.TabIndex = 6;
            this.chkVisDet.Text = "Vista detallada";
            this.chkVisDet.UseVisualStyleBackColor = true;
            this.chkVisDet.CheckedChanged += new System.EventHandler(this.chkVisDet_CheckedChanged);
            // 
            // frmOPE_Pro_VisGen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 616);
            this.Controls.Add(this.chkVisDet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFiltro);
            this.Controls.Add(this.lblFiltro);
            this.Controls.Add(this.btnEdiPro);
            this.Controls.Add(this.btnNuePro);
            this.Controls.Add(this.dgv);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmOPE_Pro_VisGen";
            this.Text = "Proyectos - Vista General";
            this.Load += new System.EventHandler(this.frmOPE_Pro_VisGen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnNuePro;
        private System.Windows.Forms.Button btnEdiPro;
        private System.Windows.Forms.Label lblFiltro;
        private System.Windows.Forms.TextBox txtFiltro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkVisDet;
    }
}