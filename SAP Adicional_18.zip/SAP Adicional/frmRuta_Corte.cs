﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.Ruta_Corte;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmRuta_Corte : Form, Ruta_Corte
    {
        NRuta_Corte rutCor = new NRuta_Corte();
        VarGlo varglo = VarGlo.Instance();

        public frmRuta_Corte()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            Ruta_Corte_RecDat();
        }
        void Ruta_Corte_RecDat()
        {
            DataTable dtRecCorPed = new DataTable();
            dtRecCorPed = rutCor.Ruta_Corte_RecCorPed();

            if (dtRecCorPed.Rows.Count > 0)
            {
                fgCorPed.DataSource = dtRecCorPed;
                DesignColumnas();
            }
            else
            {

                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        void DesignColumnas()
        {
            try
            {
                fgCorPed.AllowMerging = AllowMergingEnum.Free;

                for (int i=0;i < fgCorPed.Cols.Count;i++)
                {
                    fgCorPed.Cols[i].AllowMerging = true;
                }

            }catch{ return; }
        }
        private void txtDesCor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsulDatos("Corte", "[Filtro_ALM_CorPed]",txtDesCor.Text.Trim());
                txtDesCor.Focus();
            }
        }

        private void frmRuta_Corte_Load(object sender, EventArgs e)
        {
            txtCodCor.ReadOnly = true;
        }
        public void ConsulDatos(string vista, string procedimiento, string param1)
        {
            DataTable dtFiltro = new DataTable();
            dtFiltro = rutCor.Ruta_Corte_Filtros(vista, procedimiento, param1); //

            if (dtFiltro.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 30;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFiltro;
                frm.Ruta_Corte_Rec = this;

                frm.ShowDialog();

            }
            else if (dtFiltro.Rows.Count == 1)
            {
                DataRow row = dtFiltro.Rows[0];

                switch (vista)
                {
                    case "Corte":
                        txtCodCor.Text = row["Codigo"].ToString();
                        txtDesCor.Text = row["Descripcion"].ToString();
                        break;
                }
            }
            else if (dtFiltro.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del Sistemas", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void recdat_Ruta_Corte_Cor(string CodCor, string DesCor)
        {
            txtCodCor.Text = CodCor;
            txtDesCor.Text = DesCor;
        }
        void FormatoColumnas()
        {
            fgCorPed.Cols["Codigo"].Visible = false;
            fgCorPed.Cols["Corte"].Width = 80;
        }

        private void fgCorPed_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGeneral();
            FormatoColumnas();
        }
        void FormatoGeneral()
        {
            try
            {
                fgCorPed.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                fgCorPed.VisualStyle = VisualStyle.Office2010Silver;
                fgCorPed.Styles.Alternate.BackColor = Color.LightBlue;
                fgCorPed.Styles.Highlight.BackColor = Color.Blue;
                fgCorPed.Styles.Highlight.ForeColor = Color.White;
                fgCorPed.AllowFreezing = AllowFreezingEnum.Both;
            }
            catch { }
        }

        private void fgCorPed_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnReaCor_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodCor.Text)) //validamos si hay dato
            {
                MessageBox.Show("Debe elegir un corte","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtDesCor.Focus();
                return;
            }

            //ejecutamos el procedimiento
            Ruta_Corte_Enc Enc = new Ruta_Corte_Enc();
            Enc.CodCorPed = Convert.ToInt16(txtCodCor.Text);
            Enc.FecCor = dtpFec.Value.Date;
            Enc.CodUsuCre = Convert.ToInt16(varglo.CodUsuAct);

            rutCor.Ruta_Corte_InsCorPed(Enc);
            Ruta_Corte_RecDat(); //consultamos los datos
        }

        private void fgCorPed_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete) //valida que se la tecla
            {
                DialogResult mensakje = MessageBox.Show("¿Esta seguro de eliminar este corte?","Mensaje del sistema",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

                if (mensakje == DialogResult.Yes)
                {
                    Int16 CodCor = Convert.ToInt16(fgCorPed.Rows[fgCorPed.Row][1]);
                    DateTime FecCor = Convert.ToDateTime(fgCorPed.Rows[fgCorPed.Row][0]);
                    rutCor.Ruta_Corte_EliCorPed(CodCor, FecCor);
                    Ruta_Corte_RecDat();
                    btnMos.Focus();
                }
                else
                {
                    return;
                }
            }
        }
    }
}
