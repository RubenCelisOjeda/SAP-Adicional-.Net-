﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_Ubi_Crear : Form
    {
        NConsultas nc = new NConsultas();
        public frmALM_Ubi_Crear()
        {
            InitializeComponent();
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                this.fg.DataSource = nc.ALM_Ubi_PorCrear();
                FormatoGeneral();
            }
            catch { }
        }

        public void FormatoGeneral()
        {
            try
            {
                fg.Cols[2].Width = 400;
                fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                fg.Styles.Alternate.BackColor = Color.LightBlue;
                fg.Styles.Highlight.BackColor = Color.Blue;
                fg.Styles.Highlight.ForeColor = Color.White;
                fg.AllowFreezing = AllowFreezingEnum.Both;
            }
            catch { }     
        }
    }
}
