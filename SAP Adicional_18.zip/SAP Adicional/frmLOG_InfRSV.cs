﻿using C1.Win.C1FlexGrid;
using CapaDatos;
using CapaNegocio;
using Entidades.LOG_InfRSV;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_InfRSV : Form, LOG_InfRS
    {
        NLOG_InfRSV InfRsv = new NLOG_InfRSV();
        VarGlo varglo = VarGlo.Instance();
        public frmLOG_InfRSV()
        {
            InitializeComponent();
        }

        private void frmLOG_InfRSV_Load(object sender, EventArgs e)
        {
            txtCliPed.ReadOnly = true;
            txtCat.ReadOnly = true;
        }

        private void btnMosActOfe_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtInfoRSV_RecOfv = new DataTable();
            dtInfoRSV_RecOfv = InfRsv.LOG_InfoRSV_RecOfv(chkMosTodOfe.Checked);

            if (dtInfoRSV_RecOfv.Rows.Count > 0)
            {
                this.fgInfResOfe.DataSource = dtInfoRSV_RecOfv;
            }
            else
            {
                DataTable dtClear = new DataTable();
                dtClear.Clear();
                this.fgInfResOfe.DataSource = dtClear;
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Cursor.Current = Cursors.Default;
        }
        void LOG_InfRSV_FormatoColumnas(string Tipo)
        {
            switch (Tipo)
            {
                case "EstOferta":
                    {
                        fgInfResOfe.Cols["N° OFV"].Width = 60;
                        fgInfResOfe.Cols["N° RQ"].Width = 50;
                        fgInfResOfe.Cols["Cliente"].Width = 320;
                        fgInfResOfe.Cols["Nombre de la Venta"].Width = 280;
                        fgInfResOfe.Cols["Vendedor"].Width = 150;
                        fgInfResOfe.Cols[5].Width = 150; //Ing. Ope/Encargado - editable
                        fgInfResOfe.Cols["Diseño"].Width = 150; //editable
                        fgInfResOfe.Cols["Estado"].Width = 70; //editable
                        fgInfResOfe.Cols["Aprox. Instal."].Width = 70;
                        fgInfResOfe.Cols[9].Visible = false; //confirmacion de OFV 
                        fgInfResOfe.Cols["Fecha Ult. Reu."].Width = 90; //editable
                        fgInfResOfe.Cols["Adm. de Pedidos"].Width = 120; //editable
                        fgInfResOfe.Cols["Observaciones"].Width = 500; //editable
                        fgInfResOfe.Cols.Frozen = 3;
                       
                    }
                    break;
                case "EstOrden":
                    {
                        fgInfResOrd.Cols["N° ORV"].Width = 60;
                        fgInfResOrd.Cols["N° RQ"].Width = 50;
                        fgInfResOrd.Cols["Cliente"].Width = 320;
                        fgInfResOrd.Cols["Nombre de la Venta"].Width = 280;
                        fgInfResOrd.Cols["Vendedor"].Width = 150;
                        fgInfResOrd.Cols["Estado"].Width = 70; //editable
                        fgInfResOrd.Cols["Estado"].Width = 70; //editable
                        fgInfResOrd.Cols.Frozen = 3;
                        
                    }
                    break;
                case "DetPedido":
                    {
                        fgDetPed.Cols["N° RQ"].Width = 50;
                        fgDetPed.Cols["Cliente"].Width = 600;
                        fgDetPed.Cols["Código"].Width = 60;
                        fgDetPed.Cols["Articulo"].Width = 500;
                        fgDetPed.Cols["Catalogo"].Width = 150;
                        fgDetPed.Cols["Cant. Comprometida"].Width = 100;
                        fgDetPed.Cols["Proveedor"].Width = 250;
                        fgDetPed.Cols["OC"].Width = 60;
                        fgDetPed.Cols["eli"].Visible = false;
                        fgDetPed.Cols.Frozen = 2;
                        
                    }
                    break;
                case "OrdAbas":
                    {
                        fgOrdAba.Cols["Código"].Width = 70;
                        fgOrdAba.Cols["Articulo"].Width = 650;
                        fgOrdAba.Cols["Catalogo"].Width = 200;
                        fgOrdAba.Cols["Proveedor"].Width = 200;
                        fgOrdAba.Cols["Cantidad"].Width = 50;
                        fgOrdAba.Cols["Can. Com."].Width = 50;
                        fgOrdAba.Cols["Disponible"].Width = 60;
                        fgOrdAba.Cols["OC"].Width = 60;
                        fgOrdAba.Cols["Via"].Width = 30;
                        fgOrdAba.Cols["FEP"].Width = 55;
                        fgOrdAba.Cols["ETD"].Width = 55;
                        fgOrdAba.Cols["ETA"].Width = 55;
                        fgOrdAba.Cols[12].Width = 80; //Fec. Lleg. SQO
                        fgOrdAba.Cols["Fecha aprox de ingreso"].Width = 115; //Fec. Lleg. SQO

                        fgOrdAba.Cols["eli"].Visible = false; //Fec. Lleg. SQO

                        fgOrdAba.Cols["Cantidad"].Format = "0";
                        fgOrdAba.Cols["Can. Com."].Format = "0";
                        fgOrdAba.Cols["Disponible"].Format = "0";
                        fgOrdAba.Cols.Frozen = 2;
                  
                    }
                    break;
                default:
                    break;
            }
        }

        private void fgInfResOfe_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            LOG_InfRSV_FormatoColumnas("EstOferta");
            LOG_InfRSV_CargarColEstado("EstOferta");
            LOG_InfRSV_CargarColAdmPed();
        }
       
        void LOG_InfRSV_CargarColEstado(string Tipo)
        {
            switch (Tipo)
            {
                case "Oferta":
                    ListDictionary dtmOfe = new ListDictionary();
                    dtmOfe.Add("ABIERTO", "ABIERTO");
                    dtmOfe.Add("CERRADO", "CERRADO");
                    dtmOfe.Add("PARALIZADO", "PARALIZADO");

                    CellStyle styleOfe = fgInfResOfe.Styles.Add("Estado");
                    styleOfe.DataMap = dtmOfe;
                    fgInfResOfe.Cols["Estado"].Style = styleOfe;
                    break;

                case "Orden":
                    ListDictionary dtmOrd = new ListDictionary();
                    dtmOrd.Add("ABIERTO", "ABIERTO");
                    dtmOrd.Add("CERRADO", "CERRADO");
                    dtmOrd.Add("FACTURADO", "FACTURADO");

                    CellStyle styleOrd = fgInfResOrd.Styles.Add("Estado");
                    styleOrd.DataMap = dtmOrd;
                    fgInfResOrd.Cols["Estado"].Style = styleOrd;
                    break;
            }
        }
        void LOG_InfRSV_CargarColAdmPed()
        {
            ListDictionary datamap = new ListDictionary();
            datamap.Add("Omar Nima", "Omar Nima");
            datamap.Add("Alonso Polanco", "Alonso Polanco");
            datamap.Add("Enzo Altez", "Enzo Altez");
            datamap.Add("Angel Rios", "Angel Rios");

            CellStyle style = fgInfResOfe.Styles.Add("Adm. de Pedido");
            style.DataMap = datamap;
            fgInfResOfe.Cols["Adm. de Pedidos"].Style = style;
        }
        void LOG_InfRSV_CargarColEtp()
        {
            ListDictionary dtmOEtp = new ListDictionary();
            dtmOEtp.Add("CARCASAS", "CARCASAS");
            dtmOEtp.Add("CABLEADO", "CABLEADO");
            dtmOEtp.Add("MERCADERIA", "MERCADERIA");

            CellStyle styleEtp = fgInfResOrd.Styles.Add("Etapa");
            styleEtp.DataMap = dtmOEtp;
            fgInfResOrd.Cols["Etapa"].Style = styleEtp;
        }
        private void fgInfResOfe_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col == 5 | e.Col == 6 | e.Col == 7 | e.Col == 10 | e.Col == 12 | e.Col == 13)
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void fgInfResOfe_AfterEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 5 | e.Col == 6 | e.Col == 7 | e.Col == 10 | e.Col == 12 | e.Col == 13)
            {
                LOG_InfRSV_Enc_Est Enc = new LOG_InfRSV_Enc_Est();

                Enc.DocNum = Convert.ToInt32(fgInfResOfe[e.Row, 0]);
                Enc.Ingope = Convert.ToString(fgInfResOfe[e.Row, 5]);
                Enc.Dis = Convert.ToString(fgInfResOfe[e.Row, 6]);
                Enc.Est = Convert.ToString(fgInfResOfe[e.Row, 7]);
                Enc.ConOfv = Convert.ToString(fgInfResOfe[e.Row, 9]);
                Enc.FecUltReu = Convert.ToString(fgInfResOfe[e.Row, 10]);
                Enc.CodUsu = Convert.ToInt16(VarGlo.Instance().CodUsuAct);
                Enc.AdmPed = Convert.ToString(fgInfResOfe[e.Row, 12]);
                Enc.AprIns = Convert.ToString(fgInfResOfe[e.Row, 8]);
                Enc.Obs = Convert.ToString(fgInfResOfe[e.Row, 13]);

                InfRsv.LOG_InfoRSV_GuaOfv(Enc);
            }
        }

        private void btnExpOfe_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(fgInfResOfe,this.Text);
        }

        private void btnMosActOrd_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtInfoRSV_RecOrd = new DataTable();
            dtInfoRSV_RecOrd = InfRsv.LOG_InfoRSV_RecOrd(chkMosTodOrd.Checked);

            if (dtInfoRSV_RecOrd.Rows.Count > 0)
            {
                this.fgInfResOrd.DataSource = dtInfoRSV_RecOrd;
            }
            else
            {
                DataTable dtClear = new DataTable();
                dtClear.Clear();
                this.fgInfResOrd.DataSource = dtClear;
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Cursor.Current = Cursors.Default;
        }

        private void fgInfResOrd_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            LOG_InfRSV_FormatoColumnas("EstOrden");
            LOG_InfRSV_CargarColEstado("EstOrden");
            LOG_InfRSV_CargarColEtp();
        }

        private void btnExpOrd_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(fgInfResOrd, this.Text);
        }

        private void fgInfResOrd_AfterEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 5 | e.Col == 6 | e.Col == 8 )
            {
                LOG_InfRSV_Enc_Est Enc = new LOG_InfRSV_Enc_Est();

                Enc.DocNum = Convert.ToInt32(fgInfResOrd[e.Row, 0]);
                Enc.Est = Convert.ToString(fgInfResOrd[e.Row, 5]);
                Enc.Etp = Convert.ToString(fgInfResOrd[e.Row, 6]);
                Enc.AprIns = Convert.ToString(fgInfResOrd[e.Row, 8]);
                Enc.CodUsu = Convert.ToInt16(VarGlo.Instance().CodUsuAct);
                InfRsv.LOG_InfoRSV_GuaOrd(Enc);
            }
        }

        private void fgInfResOrd_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col == 5 | e.Col == 6)
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtRq_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("RQ_DetPed", "VEN_RQ_Info",1,txtRq.Text);
                txtCodArtPed.Focus();
            }
        }
        void ConsultaDatos(string vista, string procedimiento, int param1, string param2)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtInfRSV = new DataTable();
            dtInfRSV = InfRsv.LOG_InfRSV_Filtro(vista, procedimiento, param1, param2);

            if (dtInfRSV.Rows.Count > 1)
            {

                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 27;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtInfRSV;
                frm.LOG_InfRS_Rec = this;
                frm.ShowDialog();

            }
            else if (dtInfRSV.Rows.Count == 1)
            {
                DataRow row = dtInfRSV.Rows[0];

                switch (vista)
                {
                    case "RQ_DetPed":
                        txtRq.Text = row["N° RQ"].ToString();
                        txtCliPed.Text = row["Cliente"].ToString();
                        break;
                    case "Articulo":
                        txtCodArtPed.Text = row["Codigo"].ToString();
                        txtDesArtPed.Text = row["Descripcion"].ToString();
                        txtPro.Text = row["Proveedor"].ToString();
                        txtCat.Text = row["Catalogo"].ToString();
                        break;
                    case "ArticuloOc":
                        txtCodArtAba.Text = row["Codigo"].ToString();
                        txtDesArtAba.Text = row["Descripcion"].ToString();
                        txtProAba.Text = row["Proveedor"].ToString();
                        break;

                    default:
                        break;
                }
            }
            else if (dtInfRSV.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            Cursor.Current = Cursors.Default;
        }

        public void recdat_RqPed(string NumRq, string Cli)
        {
            txtRq.Text = NumRq;
            txtCliPed.Text = Cli;
        }
        public void recdat_Art(string CodArt, string DesArt, string Pro,string Cat)
        {
            txtCodArtPed.Text = CodArt;
            txtDesArtPed.Text = DesArt;
            txtPro.Text = Pro;
            txtCat.Text = Cat; 
        }
        public void recdat_ArtOC(string CodArtOC, string DesArtOC, string ProOC)
        {
            txtCodArtAba.Text = CodArtOC;
            txtDesArtAba.Text = DesArtOC;
            txtProAba.Text = ProOC;
        }

        private void txtCodArtPed_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("Articulo", "Filtro_3Articulo", 1, txtCodArtPed.Text);
                txtCantCom.Focus();
            }
        }

        private void btnAgrPed_Click(object sender, EventArgs e)
        {
            if (txtRq.Text == "")
            {
                MessageBox.Show("Ingrese un Rq","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                txtRq.Focus();
                return;
            }
            if (txtCantCom.Text == "")
            {
                MessageBox.Show("Ingrese cantidad de comprometido", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCantCom.Focus();
                return;
            }
            if (txtOc.Text == "")
            {
                MessageBox.Show("Ingrese orden de compra", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtOc.Focus();
                return;
            }
            if (chkNoSto.Checked & txtCat.Text == "")
            {
                MessageBox.Show("Debe agregar un catálogo", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtOc.Focus();
                return;
            }

            LOG_InfRSV_DetPed Det = new LOG_InfRSV_DetPed();
            Det.Rq = Convert.ToInt32(txtRq.Text);
            Det.CodArt = txtCodArtPed.Text;
            Det.Can = Convert.ToInt32(txtCantCom.Text);
            Det.OrdCom = txtOc.Text;
            Det.Cat = txtCat.Text;
            Det.CodUsu = Convert.ToInt16(varglo.CodUsuAct);


            InfRsv.LOG_InfoRSV_GuaDetPed(Det);
            if (DVarGlo.Instance().ErrorBase)
            {
                DataTable dtClear = new DataTable();
                dtClear.Clear();
                this.fgDetPed.DataSource = dtClear;
                MessageBox.Show("Ya existe el Rq con la cantidad de componente y orden de compra", "Mensaje del sistema", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                return;
            }

            LOG_InfRSV_LimpiarControles();
            btnMosActPed.PerformClick();
        }
        void LOG_InfRSV_LimpiarControles()
        {
            TabPage page = tabCon.SelectedTab;

            foreach (Control gpb in page.Controls)
            {
                if (gpb is GroupBox)
                {
                    foreach (Control texto in gpb.Controls)
                    {
                        if (texto is TextBox) texto.Text = "";
                        if (texto is DateTimePicker) ((DateTimePicker)texto).Value = DateTime.Now.Date;
                    }
                }
            }

            chkNoSto.Checked = false;
        }
        private void btnMosActPed_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtRecDetPed = new DataTable();
            dtRecDetPed = InfRsv.LOG_InfoRSV_RecDetPed(chkMosTodPed.Checked);

            if (dtRecDetPed.Rows.Count > 0)
            {
                fgDetPed.DataSource = dtRecDetPed;
            }
            else
            {
                MessageBox.Show("No se encontraron datos","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
             Cursor.Current = Cursors.WaitCursor;
        }

        private void txtCantCom_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite solo decimal
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsSeparator(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (e.KeyChar == '.' && !txtCantCom.Text.Contains(".")) //verifica si hay un punto decimal
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                txtOc.Focus();
            }
        }

        private void txtOc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnAgrPed.Focus();
            }
        }

        private void fgDetPed_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            LOG_InfRSV_FormatoColumnas("DetPedido");
        }

        private void fgDetPed_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnExpPed_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(fgDetPed,this.Text);
        }

        private void btnCanPed_Click(object sender, EventArgs e)
        {
            LOG_InfRSV_LimpiarControles();
            txtRq.Focus();
        }

        private void btnAgrAba_Click(object sender, EventArgs e)
        {
            if (txtCanAba.Text == "")
            {
                MessageBox.Show("Ingrese cantidad", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCanAba.Focus();
                return;
            }

            if (txtOcAba.Text == "")
            {
                MessageBox.Show("Ingrese orden de compra", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtOcAba.Focus();
                return;
            }
            if (dtpEntPro.Value.Date < DateTime.Now.Date)
            {
                MessageBox.Show("La fecha de entrega de proveedor no puede ser menor a la actual", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtOcAba.Focus();
                return;
            }

            LOG_InfRSV_Enc_OrdAba Enc = new LOG_InfRSV_Enc_OrdAba();
            Enc.CodArt = txtCodArtAba.Text;
            Enc.Can = Convert.ToDecimal(txtCanAba.Text);
            Enc.OrdCom = txtOcAba.Text;
            Enc.Via = txtViaAba.Text;
            Enc.FecEntPro = dtpEntPro.Value.Date.ToString();
            Enc.FecEmb = dtpEmb.Value.Date.ToString();
            Enc.FecLlePue = dtpLlePue.Value.Date.ToString();
            Enc.FecAprIng = dtpAprIng.Value.Date.ToString(); 

            InfRsv.LOG_InfoRSV_GuaOrdAba(Enc);

            if (DVarGlo.Instance().ErrorBase)
            {
                MessageBox.Show("Ya existe el articulo con la cantidad de componente y orden de compra", "Mensaje del sistema", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                return;
            }

            LOG_InfRSV_LimpiarControles();
            btnMosActAba.PerformClick();
        }

        private void btnMosActAba_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtInfoRSV_RecOrdAba = new DataTable();
            dtInfoRSV_RecOrdAba = InfRsv.LOG_InfoRSV_RecOrdAba(chkMosTodOrd.Checked);

            if (dtInfoRSV_RecOrdAba.Rows.Count > 0)
            {
                this.fgOrdAba.DataSource = dtInfoRSV_RecOrdAba;
            }
            else
            {
                DataTable dtClear = new DataTable();
                dtClear.Clear();
                this.fgOrdAba.DataSource = dtClear;
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnCanAba_Click(object sender, EventArgs e)
        {
            LOG_InfRSV_LimpiarControles();
            txtCodArtAba.Focus();
        }

        private void txtCodArtAba_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("ArticuloOc", "Filtro_3Articulo", 1, txtCodArtAba.Text);
                txtCanAba.Focus();
            }
        }

        private void txtDesArtAba_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("ArticuloOc", "Filtro_3Articulo", 2, txtDesArtAba.Text);
                txtCanAba.Focus();
            }
        }

        private void txtCanAba_KeyPress(object sender, KeyPressEventArgs e)
        { 
            //permite solo decimal
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsSeparator(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (e.KeyChar == '.' && !txtCanAba.Text.Contains(".")) //verifica si hay un punto decimal
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                txtOcAba.Focus();
            }
        }

        private void txtOcAba_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtViaAba.Focus();
            }
        }

        private void txtViaAba_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                e.Handled = true;
            }
            if (e.KeyChar == (char)13)
            {
                dtpEntPro.Focus();
            }
        }

        private void dtpEntPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpEmb.Focus();
            }
        }

        private void dtpEmb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpLlePue.Focus();
            }
        }

        private void dtpLlePue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpAprIng.Focus();
            }
        }

        private void dtpAprIng_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnAgrAba.Focus();
            }
        }

        private void fgOrdAba_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            LOG_InfRSV_FormatoColumnas("OrdAbas");
        }

        private void fgOrdAba_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void txtDesArtPed_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("Articulo", "Filtro_3Articulo", 2, txtDesArtPed.Text);
                txtPro.Focus();
            }
        }

        private void btnExpAba_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(fgOrdAba, this.Text);
        }

        private void fgDetPed_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult mensaje = MessageBox.Show("¿Esta seguro de realizar esta operación?","Mensaje del sistema",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

                if (mensaje == DialogResult.Yes)
                {
                    LOG_InfRSV_DetPed Det = new LOG_InfRSV_DetPed();

                    Det.Rq = Convert.ToInt32(fgDetPed.Rows[fgDetPed.RowSel][0]);
                    Det.CodArt = Convert.ToString(fgDetPed.Rows[fgDetPed.RowSel][2]);
                    Det.Cat = Convert.ToString(fgDetPed.Rows[fgDetPed.RowSel][4]);
                    Det.OrdCom = Convert.ToString(fgDetPed.Rows[fgDetPed.RowSel][7]);

                    InfRsv.LOG_InfoRSV_EliDetPed(Det);
                    fgDetPed.Rows.Remove(fgDetPed.RowSel);
                }
                else
                {
                    return;
                }
            }
        }

        private void fgOrdAba_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult mensaje = MessageBox.Show("¿Esta seguro de realizar esta operación?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (mensaje == DialogResult.Yes)
                {
                    LOG_InfRSV_Enc_OrdAba Enc = new LOG_InfRSV_Enc_OrdAba();

                    Enc.CodArt = Convert.ToString(fgOrdAba.Rows[fgOrdAba.RowSel][0]);
                    Enc.Cat = Convert.ToString(fgOrdAba.Rows[fgOrdAba.RowSel][2]);
                    Enc.Can = Convert.ToDecimal(fgOrdAba.Rows[fgOrdAba.RowSel][4]);
                    Enc.OrdCom = Convert.ToString(fgOrdAba.Rows[fgOrdAba.RowSel][7]);
                    Enc.CodUsu = varglo.CodUsuAct;
                   
                    InfRsv.LOG_InfoRSV_EliOrdAba(Enc);
                    fgOrdAba.Rows.Remove(fgOrdAba.RowSel);
                }
                else
                {
                    return;
                }
            }
        }
    }
}
