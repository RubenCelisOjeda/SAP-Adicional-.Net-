﻿using CapaNegocio;
using Entidades.Man_Menus;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmMan_Menus : Form
    {
        NMan_Men nMen = new NMan_Men();

        string nota;
        public frmMan_Menus()
        {
            InitializeComponent();
        }

        private void frmMan_Menus_Load(object sender, EventArgs e)
        {
            Man_Menu_CargaMenu(0, null, treVieMen, 32);
            Man_Menus_Formato_Botones();
        }

        private void Man_Menus_Formato_Botones()
        {
            txtCodMen_Vis.ReadOnly = true;
            txtKeyNod_Vis.ReadOnly = true;
            txtKeyRel_Vis.ReadOnly = true;

            txtCodMen_Nue.ReadOnly = true;
            txtKeyNod_Nue.ReadOnly = true;
            txtKeyRel_Nue.ReadOnly = true;
            txtNivSup.ReadOnly = true;

            treVieMen.TabStop = false; //no permite el foco
        }

        public void  Man_Menu_CargaMenu(Int32 IdMenu, TreeNode node, TreeView Menu, int CodUsuAct)
        {
            DataTable menu = new DataTable();
            menu = nMen.Rec_Menus();

            if (menu.Rows.Count > 0)
            {
                DataView Menus = new DataView(menu);
                //El campo nivel superior es el campo que indica el codigo del Menu Padre
                Menus.RowFilter = menu.Columns["NivelSuperior"].ColumnName + "=" + IdMenu;

                foreach (DataRowView fila in Menus)
                {
                    TreeNode m = new TreeNode();

                    nota = fila["Notacion"].ToString();
                    m.Text = fila["Menu"].ToString();
                    m.Name = fila["Codigo"].ToString();
                    m.Tag = nota;

                    //m.Nodes.Add(nota);

                    if (int.Parse(fila["NivelSuperior"].ToString()) == 0)
                    {
                        Menu.Nodes.Add(m);
                    }
                    else
                    {
                        node.Nodes.Add(m);
                    }
                    Man_Menu_CargaMenu(int.Parse(fila["Codigo"].ToString()), m, Menu, 32);
                }
            }
            else
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void treVieMen_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //declaramamos un objeto tipo treenode
            TreeNode nodo = new TreeNode();
            nodo = treVieMen.SelectedNode;
            txtKeyNod_Vis.Text = treVieMen.SelectedNode.Tag.ToString(); //obtiene el key del nodo padre

            if (nodo == null) //valida si hay datos
            {
                txtKeyNod_Vis.Clear();
            }
            else
            {
                try
                {
                    txtKeyRel_Vis.Text = (nodo.Text + " - " + nodo.Parent.Tag); 
                }
                catch
                {
                    txtKeyRel_Vis.Clear();//limpia  la caja de textos al seleccionar al padre
                    txtFor_Vis.Clear();
                }
            }
            txtKeyRel_Nue.Text = nodo.Tag.ToString();
        
            DataTable dtKeyNod = new DataTable();
            dtKeyNod = nMen.Rec_KeyNod(txtKeyNod_Vis.Text.Trim());

           //recorre y asignamos los datos
            foreach (DataRow row in dtKeyNod.Rows)
            {
                txtCodMen_Vis.Text = row["Codigo"].ToString();
                txtNomMen_Vis.Text = row["Menu"].ToString();

                txtFor_Vis.Text = string.IsNullOrEmpty(row["Formulario"].ToString()) ? "" : row["Formulario"].ToString(); //valida si  hay datos
                txtOrdJer.Text = row["NivelJerarquico"].ToString();
                txtOrdNiv.Text = row["OrdenEnsuNivel"].ToString();
                txtNivSup.Text = row["Codigo"].ToString();
            }
        }

        private void btnAgrMen_Click(object sender, EventArgs e)
        {

            int codNue;
            string key;
            TreeNode nueNod = new TreeNode();

            nMen.RecCodMen();
            codNue = nMen.RecCodMen();//recupera el valor

            //validamos que haya dato
            if (string.IsNullOrEmpty(txtNomMen_Nue.Text))
            {
                MessageBox.Show("Ingrese el nombre del Menu", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNomMen_Nue.Focus();
                return;
            }

            if (string.IsNullOrEmpty(txtKeyNod_Nue.Text) && (string.IsNullOrEmpty(txtNivSup.Text)) && chkPri.Checked == false)
            {
                MessageBox.Show("Faltan datos,seleccione un nodo", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnAgrMen.Focus();
                return;
            }

            if (chkPri.Checked == true) //agrea un nodo en el treevew como padre
            {
                key = txtNomMen_Nue.Text.ToString().Substring(0, 3) + codNue.ToString();
                nueNod.Text = txtNomMen_Nue.Text;
                nueNod.Name = codNue.ToString();
                nueNod.Tag = key;
                nueNod.Expand();
                treVieMen.Nodes.Add(nueNod);
            }
            else                     //agrega un nodo en el treevew como hijo
            {
                string keys = txtNomMen_Nue.Text.ToString().Substring(0, 3) + codNue.ToString();
                key = keys;
                nueNod.Text = txtNomMen_Nue.Text;
                nueNod.Name = codNue.ToString();
                nueNod.Tag = key;
                nueNod.Expand();
                treVieMen.Nodes.Add(nueNod);
            }

            //insertarndo los datos
            ManMen_Enc MenIns = new ManMen_Enc();
            MenIns.Codigo = Convert.ToInt32(codNue);
            MenIns.Menu = txtNomMen_Nue.Text;

            int nivSup;
            if (txtNivSup.Text == "")
            {
                nivSup = 0;
            }
            else
            {
                nivSup = Convert.ToInt32(txtNivSup.Text);
            }

            MenIns.NivSup = nivSup;
            MenIns.Notacion = key;
            MenIns.NotSup = txtKeyRel_Nue.Text;
            MenIns.Form = txtFor_Nue.Text;
            nMen.InsMen(MenIns);


            treVieMen.Nodes.Clear();
            Man_Menu_CargaMenu(0, null, treVieMen, 32);
            Man_Men_LimpiarNuevo();
        }

        private void chkPri_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPri.Checked == true)
            {
                txtNivSup.Text = "0";
                txtKeyRel_Nue.Clear();
            }
        }
        private void Man_Menu_EliNodo()
        {
            bool estado = false;
            Int16 codigo = Convert.ToInt16( txtCodMen_Vis.Text);
            foreach (TreeNode node in treVieMen.SelectedNode.Nodes)
            {
                estado = true;
            }

            if (estado == true)
            {
                MessageBox.Show("Operacion Cancelada, primero elimine los submenus","Mensaje del sistma",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            else
            {
                DialogResult mensaje = MessageBox.Show("Esta seguro de eliminar el menú", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (mensaje == DialogResult.Yes)
                {
                    int indice = treVieMen.SelectedNode.Index;
                    treVieMen.Nodes.RemoveAt(indice);
                    treVieMen.Nodes[indice].Expand();
                    nMen.EliMenu(codigo);                  
                    treVieMen.Nodes.Clear();
                    Man_Menu_CargaMenu(0, null, treVieMen, 32);
                    return;
                }
                else
                {
                    return;
                }
            }
        }
        private void Man_Men_LimpiarNuevo()
        {
            txtCodMen_Nue.Clear();
            txtNomMen_Nue.Clear();
            txtKeyNod_Nue.Clear();
            txtKeyRel_Nue.Clear();
            txtNivSup.Clear();
            txtFor_Nue.Clear();
        }

        private void btnEliMen_Click(object sender, EventArgs e)
        {
            Man_Menu_EliNodo();                
        }

        private void btnAct_Click(object sender, EventArgs e)
        {
            //actulizar menu
            ManMen_Enc MenAct = new ManMen_Enc();
            MenAct.Menu = txtNomMen_Vis.Text;
            MenAct.Form = txtFor_Vis.Text;
            MenAct.NivJer = Convert.ToInt16(txtOrdJer.Text);
            MenAct.OrdEnSuNiv = Convert.ToInt16(txtOrdNiv.Text);
            MenAct.Codigo = Convert.ToInt32(txtCodMen_Vis.Text);

            nMen.ActMen(MenAct);
            treVieMen.Nodes.Clear();
            Man_Menu_CargaMenu(0, null, treVieMen, 32);
        }

        private void txtNomMen_Vis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtFor_Vis.Focus();
            }
        }

        private void txtNomMen_Nue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtFor_Nue.Focus();
            }
        }

        private void txtFor_Nue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnAgrMen.Focus();
            }
        }

        private void txtFor_Vis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtOrdJer.Focus();
            }
        }

        private void txtOrdJer_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtOrdNiv.Focus();
            }
        }

        private void txtOrdNiv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnAct.Focus();
            }
        }
    }
}
