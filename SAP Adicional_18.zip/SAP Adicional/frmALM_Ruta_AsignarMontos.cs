﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_Ruta_AsignarMontos : Form
    {
        NDALM_Ruta_AsignarMontos RutAsi = new NDALM_Ruta_AsignarMontos();
        DataTable dtAsiMonRec;

        public frmALM_Ruta_AsignarMontos()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor; //cursor cargando

            dtAsiMonRec = new DataTable();
            dtAsiMonRec = RutAsi.Ruta_AsignarMontos_Rec(dtpInicio.Value.Date, dtpFinal.Value.Date);

            if (dtpInicio.Value.Date > dtpFinal.Value.Date)
            {
                MessageBox.Show("La fecha de inicio no puede ser mayor a la final", "Mensaje del sistema",
                                                              MessageBoxButtons.OK, MessageBoxIcon.Error);

                DataTable dtClean = new DataTable();
                dtClean.Clear();
                fgAsiMon.DataSource = dtClean;
                return;
            }

            if (dtAsiMonRec.Rows.Count > 0)
            {
                fgAsiMon.DataSource = dtAsiMonRec;
                FormatoGgAsiMon();
                FormatoColumnas();
                Suma();
                Cursor.Current = Cursors.Default; //cursor por defecto

            }
            else
            {
                DataTable dtClean = new DataTable();
                dtClean.Clear();
                fgAsiMon.DataSource = dtClean;

                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        void FormatoGgAsiMon()
        {
            fgAsiMon.AutoResize = true;
            fgAsiMon.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fgAsiMon.VisualStyle = VisualStyle.Office2010Silver;
            fgAsiMon.Styles.Alternate.BackColor = Color.LightBlue;
            fgAsiMon.Styles.Highlight.BackColor = Color.Blue;
            fgAsiMon.Styles.Highlight.ForeColor = Color.White;
            fgAsiMon.AllowFreezing = AllowFreezingEnum.Both;
            CellStyle s = fgAsiMon.Styles[CellStyleEnum.Subtotal0];
            s.BackColor = Color.Yellow;
            s.ForeColor = Color.Blue;
            fgAsiMon.Cols.Frozen = 2;
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            Suma();
        }

        private void fgAsiMon_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col != 11) //columna monto
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = true;
                }
                else
                {
                    e.Handled = false;
                }
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(this.fgAsiMon, this.Text);
        }
        void Suma()
        {
            try
            {
                fgAsiMon.Subtotal(AggregateEnum.Sum, 0, -1, 11, "TOTALES");
                fgAsiMon.SubtotalPosition = SubtotalPositionEnum.BelowData;

                fgAsiMon.Rows[fgAsiMon.Rows.Count - 1][0] = "TOTALES";
            }
            catch
            {
                return;
            }
        }

        private void frmALM_Ruta_AsignarMontos_Load(object sender, EventArgs e)
        {

        }
        void FormatoColumnas()
        {
            try
            {
                //tipo de dato
                fgAsiMon.Cols["N° Ruta"].Style.DataType = typeof(string);

                //tamaño de columnas
                fgAsiMon.Cols["N° Ruta"].Width = 60;
                fgAsiMon.Cols["CodigoGasto"].Width = 80;
                fgAsiMon.Cols["Descripción"].Width = 180;
                fgAsiMon.Cols["FechaRuta"].Width = 60;
                fgAsiMon.Cols["Cliente"].Width = 230;
                fgAsiMon.Cols["Area"].Width = 50;
                fgAsiMon.Cols["SubArea"].Width = 50;
                fgAsiMon.Cols["UnidaddeNegocio"].Width = 90;
                fgAsiMon.Cols["NumRQ"].Width = 40;
                fgAsiMon.Cols["Direccion"].Width = 220;
                fgAsiMon.Cols["Monto"].Width = 50;
                fgAsiMon.Cols["Distrito"].Width = 68;
                fgAsiMon.Cols["Transportista"].Width = 80;

            }
            catch { }

        }

        private void fgAsiMon_AfterFilter(object sender, EventArgs e)
        {
            Suma();
        }

        private void fgAsiMon_AfterEdit(object sender, RowColEventArgs e)
        {
            try
            {
                if (e.Col == 11) //columna monto
                {
                    decimal monto = Convert.ToDecimal(fgAsiMon.Cols[11][fgAsiMon.Row]);
                    string NumMovRut = fgAsiMon.Cols[0][fgAsiMon.Row].ToString() == "" ? "0" : fgAsiMon.Cols[0][fgAsiMon.Row].ToString();
                    RutAsi.Ruta_AsignarMontos_GuaMon(monto, Convert.ToInt32(NumMovRut));
                }
            }
            catch
            {
                return;
            }
        }

        private void btnExpSap_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(this.fgAsiMon, this.Text);
        }
    }
    
}
