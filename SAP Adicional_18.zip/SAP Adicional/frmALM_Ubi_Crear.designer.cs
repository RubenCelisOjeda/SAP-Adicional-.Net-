﻿namespace SAP_Adicional
{
    partial class frmALM_Ubi_Crear
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExp = new System.Windows.Forms.Button();
            this.btnMos = new System.Windows.Forms.Button();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(110, 12);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(111, 23);
            this.btnExp.TabIndex = 1;
            this.btnExp.Text = "Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // btnMos
            // 
            this.btnMos.Location = new System.Drawing.Point(0, 12);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(111, 23);
            this.btnMos.TabIndex = 0;
            this.btnMos.Text = "Mostrar/Actualizar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(0, 41);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.Size = new System.Drawing.Size(990, 485);
            this.fg.TabIndex = 6;
            // 
            // frmALM_Ubi_Crear
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 538);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.btnMos);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_Ubi_Crear";
            this.Text = "Ubicaciones por crear";
            //this.Load += new System.EventHandler(this.frmALM_Ubi_Crear_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Button btnMos;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
    }
}