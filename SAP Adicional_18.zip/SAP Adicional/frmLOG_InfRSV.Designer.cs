﻿namespace SAP_Adicional
{
    partial class frmLOG_InfRSV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabCon = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabConOfvOrd = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.chkMosTodOfe = new System.Windows.Forms.CheckBox();
            this.btnExpOfe = new System.Windows.Forms.Button();
            this.btnMosActOfe = new System.Windows.Forms.Button();
            this.fgInfResOfe = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnExpOrd = new System.Windows.Forms.Button();
            this.btnMosActOrd = new System.Windows.Forms.Button();
            this.chkMosTodOrd = new System.Windows.Forms.CheckBox();
            this.fgInfResOrd = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnExpPed = new System.Windows.Forms.Button();
            this.btnMosActPed = new System.Windows.Forms.Button();
            this.fgDetPed = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.gpbDetPed = new System.Windows.Forms.GroupBox();
            this.txtCodArtPed = new System.Windows.Forms.TextBox();
            this.chkMosTodPed = new System.Windows.Forms.CheckBox();
            this.txtOc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCantCom = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCanPed = new System.Windows.Forms.Button();
            this.btnAgrPed = new System.Windows.Forms.Button();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCat = new System.Windows.Forms.TextBox();
            this.txtRq = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDesArtPed = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCliPed = new System.Windows.Forms.TextBox();
            this.chkNoSto = new System.Windows.Forms.CheckBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.fgOrdAba = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnExpAba = new System.Windows.Forms.Button();
            this.btnMosActAba = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gpbFec = new System.Windows.Forms.GroupBox();
            this.chkMosTodAba = new System.Windows.Forms.CheckBox();
            this.dtpAprIng = new System.Windows.Forms.DateTimePicker();
            this.btnCanAba = new System.Windows.Forms.Button();
            this.btnAgrAba = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.dtpLlePue = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.dtpEmb = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpEntPro = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCodArtAba = new System.Windows.Forms.TextBox();
            this.txtDesArtAba = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtOcAba = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtViaAba = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCanAba = new System.Windows.Forms.TextBox();
            this.txtProAba = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabCon.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabConOfvOrd.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgInfResOfe)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgInfResOrd)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetPed)).BeginInit();
            this.gpbDetPed.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgOrdAba)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.gpbFec.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCon
            // 
            this.tabCon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabCon.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabCon.Controls.Add(this.tabPage2);
            this.tabCon.Controls.Add(this.tabPage3);
            this.tabCon.Controls.Add(this.tabPage1);
            this.tabCon.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tabCon.Location = new System.Drawing.Point(12, 12);
            this.tabCon.Multiline = true;
            this.tabCon.Name = "tabCon";
            this.tabCon.SelectedIndex = 0;
            this.tabCon.Size = new System.Drawing.Size(1087, 532);
            this.tabCon.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.tabConOfvOrd);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1079, 503);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Estado de Obra por RQ";
            // 
            // tabConOfvOrd
            // 
            this.tabConOfvOrd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabConOfvOrd.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabConOfvOrd.Controls.Add(this.tabPage4);
            this.tabConOfvOrd.Controls.Add(this.tabPage5);
            this.tabConOfvOrd.Location = new System.Drawing.Point(1, 3);
            this.tabConOfvOrd.Name = "tabConOfvOrd";
            this.tabConOfvOrd.SelectedIndex = 0;
            this.tabConOfvOrd.Size = new System.Drawing.Size(1082, 491);
            this.tabConOfvOrd.TabIndex = 1;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.chkMosTodOfe);
            this.tabPage4.Controls.Add(this.btnExpOfe);
            this.tabPage4.Controls.Add(this.btnMosActOfe);
            this.tabPage4.Controls.Add(this.fgInfResOfe);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1074, 462);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Oferta";
            // 
            // chkMosTodOfe
            // 
            this.chkMosTodOfe.AutoSize = true;
            this.chkMosTodOfe.Location = new System.Drawing.Point(280, 18);
            this.chkMosTodOfe.Name = "chkMosTodOfe";
            this.chkMosTodOfe.Size = new System.Drawing.Size(88, 17);
            this.chkMosTodOfe.TabIndex = 2;
            this.chkMosTodOfe.Text = "Mostrar todo";
            this.chkMosTodOfe.UseVisualStyleBackColor = true;
            // 
            // btnExpOfe
            // 
            this.btnExpOfe.BackColor = System.Drawing.Color.White;
            this.btnExpOfe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpOfe.Location = new System.Drawing.Point(129, 12);
            this.btnExpOfe.Name = "btnExpOfe";
            this.btnExpOfe.Size = new System.Drawing.Size(122, 23);
            this.btnExpOfe.TabIndex = 1;
            this.btnExpOfe.Text = "Exportar";
            this.btnExpOfe.UseVisualStyleBackColor = false;
            this.btnExpOfe.Click += new System.EventHandler(this.btnExpOfe_Click);
            // 
            // btnMosActOfe
            // 
            this.btnMosActOfe.BackColor = System.Drawing.Color.White;
            this.btnMosActOfe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosActOfe.Location = new System.Drawing.Point(6, 12);
            this.btnMosActOfe.Name = "btnMosActOfe";
            this.btnMosActOfe.Size = new System.Drawing.Size(122, 23);
            this.btnMosActOfe.TabIndex = 0;
            this.btnMosActOfe.Text = "&Mostrar/Actulizar";
            this.btnMosActOfe.UseVisualStyleBackColor = false;
            this.btnMosActOfe.Click += new System.EventHandler(this.btnMosActOfe_Click);
            // 
            // fgInfResOfe
            // 
            this.fgInfResOfe.AllowFiltering = true;
            this.fgInfResOfe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgInfResOfe.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgInfResOfe.Location = new System.Drawing.Point(5, 41);
            this.fgInfResOfe.Name = "fgInfResOfe";
            this.fgInfResOfe.Rows.DefaultSize = 19;
            this.fgInfResOfe.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgInfResOfe.Size = new System.Drawing.Size(1066, 415);
            this.fgInfResOfe.TabIndex = 3;
            this.fgInfResOfe.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgInfResOfe_AfterEdit);
            this.fgInfResOfe.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgInfResOfe_KeyPressEdit);
            this.fgInfResOfe.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgInfResOfe_AfterDataRefresh);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.White;
            this.tabPage5.Controls.Add(this.btnExpOrd);
            this.tabPage5.Controls.Add(this.btnMosActOrd);
            this.tabPage5.Controls.Add(this.chkMosTodOrd);
            this.tabPage5.Controls.Add(this.fgInfResOrd);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1074, 462);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "Orden";
            // 
            // btnExpOrd
            // 
            this.btnExpOrd.BackColor = System.Drawing.Color.White;
            this.btnExpOrd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpOrd.Location = new System.Drawing.Point(124, 11);
            this.btnExpOrd.Name = "btnExpOrd";
            this.btnExpOrd.Size = new System.Drawing.Size(122, 23);
            this.btnExpOrd.TabIndex = 1;
            this.btnExpOrd.Text = "Exportar";
            this.btnExpOrd.UseVisualStyleBackColor = false;
            this.btnExpOrd.Click += new System.EventHandler(this.btnExpOrd_Click);
            // 
            // btnMosActOrd
            // 
            this.btnMosActOrd.BackColor = System.Drawing.Color.White;
            this.btnMosActOrd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosActOrd.Location = new System.Drawing.Point(6, 11);
            this.btnMosActOrd.Name = "btnMosActOrd";
            this.btnMosActOrd.Size = new System.Drawing.Size(119, 23);
            this.btnMosActOrd.TabIndex = 0;
            this.btnMosActOrd.Text = "&Mostrar/Actulizar";
            this.btnMosActOrd.UseVisualStyleBackColor = false;
            this.btnMosActOrd.Click += new System.EventHandler(this.btnMosActOrd_Click);
            // 
            // chkMosTodOrd
            // 
            this.chkMosTodOrd.AutoSize = true;
            this.chkMosTodOrd.Location = new System.Drawing.Point(267, 17);
            this.chkMosTodOrd.Name = "chkMosTodOrd";
            this.chkMosTodOrd.Size = new System.Drawing.Size(88, 17);
            this.chkMosTodOrd.TabIndex = 2;
            this.chkMosTodOrd.Text = "Mostrar todo";
            this.chkMosTodOrd.UseVisualStyleBackColor = true;
            // 
            // fgInfResOrd
            // 
            this.fgInfResOrd.AllowFiltering = true;
            this.fgInfResOrd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgInfResOrd.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgInfResOrd.Location = new System.Drawing.Point(4, 40);
            this.fgInfResOrd.Name = "fgInfResOrd";
            this.fgInfResOrd.Rows.DefaultSize = 19;
            this.fgInfResOrd.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgInfResOrd.Size = new System.Drawing.Size(1066, 415);
            this.fgInfResOrd.TabIndex = 4;
            this.fgInfResOrd.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgInfResOrd_AfterEdit);
            this.fgInfResOrd.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgInfResOrd_KeyPressEdit);
            this.fgInfResOrd.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgInfResOrd_AfterDataRefresh);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.btnExpPed);
            this.tabPage3.Controls.Add(this.btnMosActPed);
            this.tabPage3.Controls.Add(this.fgDetPed);
            this.tabPage3.Controls.Add(this.gpbDetPed);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1079, 503);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Detalle de pedido";
            // 
            // btnExpPed
            // 
            this.btnExpPed.BackColor = System.Drawing.Color.White;
            this.btnExpPed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpPed.Location = new System.Drawing.Point(124, 182);
            this.btnExpPed.Name = "btnExpPed";
            this.btnExpPed.Size = new System.Drawing.Size(122, 23);
            this.btnExpPed.TabIndex = 13;
            this.btnExpPed.Text = "Exportar";
            this.btnExpPed.UseVisualStyleBackColor = false;
            this.btnExpPed.Click += new System.EventHandler(this.btnExpPed_Click);
            // 
            // btnMosActPed
            // 
            this.btnMosActPed.BackColor = System.Drawing.Color.White;
            this.btnMosActPed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosActPed.Location = new System.Drawing.Point(6, 182);
            this.btnMosActPed.Name = "btnMosActPed";
            this.btnMosActPed.Size = new System.Drawing.Size(119, 23);
            this.btnMosActPed.TabIndex = 12;
            this.btnMosActPed.Text = "&Mostrar/Actulizar";
            this.btnMosActPed.UseVisualStyleBackColor = false;
            this.btnMosActPed.Click += new System.EventHandler(this.btnMosActPed_Click);
            // 
            // fgDetPed
            // 
            this.fgDetPed.AllowFiltering = true;
            this.fgDetPed.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgDetPed.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgDetPed.Location = new System.Drawing.Point(6, 211);
            this.fgDetPed.Name = "fgDetPed";
            this.fgDetPed.Rows.DefaultSize = 19;
            this.fgDetPed.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgDetPed.Size = new System.Drawing.Size(1061, 286);
            this.fgDetPed.TabIndex = 15;
            this.fgDetPed.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgDetPed_KeyPressEdit);
            this.fgDetPed.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgDetPed_AfterDataRefresh);
            this.fgDetPed.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgDetPed_KeyDown);
            // 
            // gpbDetPed
            // 
            this.gpbDetPed.Controls.Add(this.txtCodArtPed);
            this.gpbDetPed.Controls.Add(this.chkMosTodPed);
            this.gpbDetPed.Controls.Add(this.txtOc);
            this.gpbDetPed.Controls.Add(this.label7);
            this.gpbDetPed.Controls.Add(this.txtCantCom);
            this.gpbDetPed.Controls.Add(this.label6);
            this.gpbDetPed.Controls.Add(this.btnCanPed);
            this.gpbDetPed.Controls.Add(this.btnAgrPed);
            this.gpbDetPed.Controls.Add(this.txtPro);
            this.gpbDetPed.Controls.Add(this.label5);
            this.gpbDetPed.Controls.Add(this.txtCat);
            this.gpbDetPed.Controls.Add(this.txtRq);
            this.gpbDetPed.Controls.Add(this.label4);
            this.gpbDetPed.Controls.Add(this.label1);
            this.gpbDetPed.Controls.Add(this.txtDesArtPed);
            this.gpbDetPed.Controls.Add(this.label2);
            this.gpbDetPed.Controls.Add(this.label3);
            this.gpbDetPed.Controls.Add(this.txtCliPed);
            this.gpbDetPed.Controls.Add(this.chkNoSto);
            this.gpbDetPed.Location = new System.Drawing.Point(6, 6);
            this.gpbDetPed.Name = "gpbDetPed";
            this.gpbDetPed.Size = new System.Drawing.Size(967, 170);
            this.gpbDetPed.TabIndex = 8;
            this.gpbDetPed.TabStop = false;
            // 
            // txtCodArtPed
            // 
            this.txtCodArtPed.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodArtPed.ForeColor = System.Drawing.Color.Blue;
            this.txtCodArtPed.Location = new System.Drawing.Point(246, 46);
            this.txtCodArtPed.Name = "txtCodArtPed";
            this.txtCodArtPed.Size = new System.Drawing.Size(100, 21);
            this.txtCodArtPed.TabIndex = 3;
            this.txtCodArtPed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodArtPed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArtPed_KeyPress);
            // 
            // chkMosTodPed
            // 
            this.chkMosTodPed.AutoSize = true;
            this.chkMosTodPed.Location = new System.Drawing.Point(684, 123);
            this.chkMosTodPed.Name = "chkMosTodPed";
            this.chkMosTodPed.Size = new System.Drawing.Size(88, 17);
            this.chkMosTodPed.TabIndex = 11;
            this.chkMosTodPed.Text = "Mostrar todo";
            this.chkMosTodPed.UseVisualStyleBackColor = true;
            // 
            // txtOc
            // 
            this.txtOc.ForeColor = System.Drawing.Color.Blue;
            this.txtOc.Location = new System.Drawing.Point(685, 81);
            this.txtOc.Name = "txtOc";
            this.txtOc.Size = new System.Drawing.Size(76, 21);
            this.txtOc.TabIndex = 8;
            this.txtOc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOc_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(662, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "OC:";
            // 
            // txtCantCom
            // 
            this.txtCantCom.ForeColor = System.Drawing.Color.Blue;
            this.txtCantCom.Location = new System.Drawing.Point(541, 81);
            this.txtCantCom.Name = "txtCantCom";
            this.txtCantCom.Size = new System.Drawing.Size(83, 21);
            this.txtCantCom.TabIndex = 7;
            this.txtCantCom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCantCom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantCom_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(474, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Cant. Com. :";
            // 
            // btnCanPed
            // 
            this.btnCanPed.BackColor = System.Drawing.Color.White;
            this.btnCanPed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCanPed.Location = new System.Drawing.Point(208, 118);
            this.btnCanPed.Name = "btnCanPed";
            this.btnCanPed.Size = new System.Drawing.Size(117, 23);
            this.btnCanPed.TabIndex = 10;
            this.btnCanPed.Text = "Cancelar";
            this.btnCanPed.UseVisualStyleBackColor = false;
            this.btnCanPed.Click += new System.EventHandler(this.btnCanPed_Click);
            // 
            // btnAgrPed
            // 
            this.btnAgrPed.BackColor = System.Drawing.Color.White;
            this.btnAgrPed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgrPed.Location = new System.Drawing.Point(89, 118);
            this.btnAgrPed.Name = "btnAgrPed";
            this.btnAgrPed.Size = new System.Drawing.Size(117, 23);
            this.btnAgrPed.TabIndex = 9;
            this.btnAgrPed.Text = "Agregar";
            this.btnAgrPed.UseVisualStyleBackColor = false;
            this.btnAgrPed.Click += new System.EventHandler(this.btnAgrPed_Click);
            // 
            // txtPro
            // 
            this.txtPro.BackColor = System.Drawing.Color.Silver;
            this.txtPro.ForeColor = System.Drawing.Color.Blue;
            this.txtPro.Location = new System.Drawing.Point(89, 81);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(361, 21);
            this.txtPro.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Proveedor:";
            // 
            // txtCat
            // 
            this.txtCat.ForeColor = System.Drawing.Color.Blue;
            this.txtCat.Location = new System.Drawing.Point(818, 46);
            this.txtCat.Name = "txtCat";
            this.txtCat.Size = new System.Drawing.Size(138, 21);
            this.txtCat.TabIndex = 5;
            // 
            // txtRq
            // 
            this.txtRq.ForeColor = System.Drawing.Color.Blue;
            this.txtRq.Location = new System.Drawing.Point(89, 19);
            this.txtRq.Name = "txtRq";
            this.txtRq.Size = new System.Drawing.Size(100, 21);
            this.txtRq.TabIndex = 0;
            this.txtRq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRq_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(766, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Catálogo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "N° RQ:";
            // 
            // txtDesArtPed
            // 
            this.txtDesArtPed.ForeColor = System.Drawing.Color.Blue;
            this.txtDesArtPed.Location = new System.Drawing.Point(352, 46);
            this.txtDesArtPed.Name = "txtDesArtPed";
            this.txtDesArtPed.Size = new System.Drawing.Size(408, 21);
            this.txtDesArtPed.TabIndex = 4;
            this.txtDesArtPed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArtPed_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(203, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Cliente:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(200, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Articulo:";
            // 
            // txtCliPed
            // 
            this.txtCliPed.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCliPed.ForeColor = System.Drawing.Color.Blue;
            this.txtCliPed.Location = new System.Drawing.Point(246, 19);
            this.txtCliPed.Name = "txtCliPed";
            this.txtCliPed.Size = new System.Drawing.Size(361, 21);
            this.txtCliPed.TabIndex = 1;
            // 
            // chkNoSto
            // 
            this.chkNoSto.AutoSize = true;
            this.chkNoSto.Location = new System.Drawing.Point(89, 53);
            this.chkNoSto.Name = "chkNoSto";
            this.chkNoSto.Size = new System.Drawing.Size(68, 17);
            this.chkNoSto.TabIndex = 2;
            this.chkNoSto.Text = "No Stock";
            this.chkNoSto.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.fgOrdAba);
            this.tabPage1.Controls.Add(this.btnExpAba);
            this.tabPage1.Controls.Add(this.btnMosActAba);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1079, 503);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Orden de abastecimiento";
            // 
            // fgOrdAba
            // 
            this.fgOrdAba.AllowFiltering = true;
            this.fgOrdAba.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgOrdAba.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgOrdAba.Location = new System.Drawing.Point(6, 218);
            this.fgOrdAba.Name = "fgOrdAba";
            this.fgOrdAba.Rows.DefaultSize = 19;
            this.fgOrdAba.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgOrdAba.Size = new System.Drawing.Size(1057, 279);
            this.fgOrdAba.TabIndex = 16;
            this.fgOrdAba.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgOrdAba_KeyPressEdit);
            this.fgOrdAba.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgOrdAba_AfterDataRefresh);
            this.fgOrdAba.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgOrdAba_KeyDown);
            // 
            // btnExpAba
            // 
            this.btnExpAba.BackColor = System.Drawing.Color.White;
            this.btnExpAba.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpAba.Location = new System.Drawing.Point(128, 189);
            this.btnExpAba.Name = "btnExpAba";
            this.btnExpAba.Size = new System.Drawing.Size(118, 23);
            this.btnExpAba.TabIndex = 15;
            this.btnExpAba.Text = "Exportar";
            this.btnExpAba.UseVisualStyleBackColor = false;
            this.btnExpAba.Click += new System.EventHandler(this.btnExpAba_Click);
            // 
            // btnMosActAba
            // 
            this.btnMosActAba.BackColor = System.Drawing.Color.White;
            this.btnMosActAba.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosActAba.Location = new System.Drawing.Point(6, 189);
            this.btnMosActAba.Name = "btnMosActAba";
            this.btnMosActAba.Size = new System.Drawing.Size(120, 23);
            this.btnMosActAba.TabIndex = 14;
            this.btnMosActAba.Text = "&Mostrar/Actulizar";
            this.btnMosActAba.UseVisualStyleBackColor = false;
            this.btnMosActAba.Click += new System.EventHandler(this.btnMosActAba_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gpbFec);
            this.groupBox2.Controls.Add(this.txtCodArtAba);
            this.groupBox2.Controls.Add(this.txtDesArtAba);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtOcAba);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtViaAba);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtCanAba);
            this.groupBox2.Controls.Add(this.txtProAba);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(967, 177);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // gpbFec
            // 
            this.gpbFec.Controls.Add(this.chkMosTodAba);
            this.gpbFec.Controls.Add(this.dtpAprIng);
            this.gpbFec.Controls.Add(this.btnCanAba);
            this.gpbFec.Controls.Add(this.btnAgrAba);
            this.gpbFec.Controls.Add(this.label17);
            this.gpbFec.Controls.Add(this.dtpLlePue);
            this.gpbFec.Controls.Add(this.label16);
            this.gpbFec.Controls.Add(this.dtpEmb);
            this.gpbFec.Controls.Add(this.label15);
            this.gpbFec.Controls.Add(this.dtpEntPro);
            this.gpbFec.Controls.Add(this.label13);
            this.gpbFec.Location = new System.Drawing.Point(7, 101);
            this.gpbFec.Name = "gpbFec";
            this.gpbFec.Size = new System.Drawing.Size(954, 71);
            this.gpbFec.TabIndex = 6;
            this.gpbFec.TabStop = false;
            this.gpbFec.Text = "Fechas";
            // 
            // chkMosTodAba
            // 
            this.chkMosTodAba.AutoSize = true;
            this.chkMosTodAba.Location = new System.Drawing.Point(23, 47);
            this.chkMosTodAba.Name = "chkMosTodAba";
            this.chkMosTodAba.Size = new System.Drawing.Size(88, 17);
            this.chkMosTodAba.TabIndex = 13;
            this.chkMosTodAba.Text = "Mostrar todo";
            this.chkMosTodAba.UseVisualStyleBackColor = true;
            // 
            // dtpAprIng
            // 
            this.dtpAprIng.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAprIng.Location = new System.Drawing.Point(709, 16);
            this.dtpAprIng.Name = "dtpAprIng";
            this.dtpAprIng.Size = new System.Drawing.Size(83, 21);
            this.dtpAprIng.TabIndex = 10;
            this.dtpAprIng.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpAprIng_KeyPress);
            // 
            // btnCanAba
            // 
            this.btnCanAba.BackColor = System.Drawing.Color.White;
            this.btnCanAba.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCanAba.Location = new System.Drawing.Point(828, 43);
            this.btnCanAba.Name = "btnCanAba";
            this.btnCanAba.Size = new System.Drawing.Size(117, 23);
            this.btnCanAba.TabIndex = 12;
            this.btnCanAba.Text = "Cancelar";
            this.btnCanAba.UseVisualStyleBackColor = false;
            this.btnCanAba.Click += new System.EventHandler(this.btnCanAba_Click);
            // 
            // btnAgrAba
            // 
            this.btnAgrAba.BackColor = System.Drawing.Color.White;
            this.btnAgrAba.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgrAba.Location = new System.Drawing.Point(709, 43);
            this.btnAgrAba.Name = "btnAgrAba";
            this.btnAgrAba.Size = new System.Drawing.Size(117, 23);
            this.btnAgrAba.TabIndex = 11;
            this.btnAgrAba.Text = "Agregar";
            this.btnAgrAba.UseVisualStyleBackColor = false;
            this.btnAgrAba.Click += new System.EventHandler(this.btnAgrAba_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(628, 21);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(84, 13);
            this.label17.TabIndex = 32;
            this.label17.Text = "Aprox. Ingreso:";
            // 
            // dtpLlePue
            // 
            this.dtpLlePue.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpLlePue.Location = new System.Drawing.Point(496, 16);
            this.dtpLlePue.Name = "dtpLlePue";
            this.dtpLlePue.Size = new System.Drawing.Size(83, 21);
            this.dtpLlePue.TabIndex = 9;
            this.dtpLlePue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpLlePue_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(408, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 13);
            this.label16.TabIndex = 30;
            this.label16.Text = "Llegada a puerto:";
            // 
            // dtpEmb
            // 
            this.dtpEmb.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEmb.Location = new System.Drawing.Point(291, 16);
            this.dtpEmb.Name = "dtpEmb";
            this.dtpEmb.Size = new System.Drawing.Size(83, 21);
            this.dtpEmb.TabIndex = 8;
            this.dtpEmb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpEmb_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(233, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "Embarque:";
            // 
            // dtpEntPro
            // 
            this.dtpEntPro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEntPro.Location = new System.Drawing.Point(119, 16);
            this.dtpEntPro.Name = "dtpEntPro";
            this.dtpEntPro.Size = new System.Drawing.Size(83, 21);
            this.dtpEntPro.TabIndex = 7;
            this.dtpEntPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpEntPro_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(20, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "Entrega proveedor:";
            // 
            // txtCodArtAba
            // 
            this.txtCodArtAba.ForeColor = System.Drawing.Color.Blue;
            this.txtCodArtAba.Location = new System.Drawing.Point(57, 26);
            this.txtCodArtAba.Name = "txtCodArtAba";
            this.txtCodArtAba.Size = new System.Drawing.Size(100, 21);
            this.txtCodArtAba.TabIndex = 0;
            this.txtCodArtAba.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodArtAba.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArtAba_KeyPress);
            // 
            // txtDesArtAba
            // 
            this.txtDesArtAba.ForeColor = System.Drawing.Color.Blue;
            this.txtDesArtAba.Location = new System.Drawing.Point(160, 26);
            this.txtDesArtAba.Name = "txtDesArtAba";
            this.txtDesArtAba.Size = new System.Drawing.Size(408, 21);
            this.txtDesArtAba.TabIndex = 1;
            this.txtDesArtAba.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArtAba_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "Articulo:";
            // 
            // txtOcAba
            // 
            this.txtOcAba.ForeColor = System.Drawing.Color.Blue;
            this.txtOcAba.Location = new System.Drawing.Point(218, 56);
            this.txtOcAba.Name = "txtOcAba";
            this.txtOcAba.Size = new System.Drawing.Size(102, 21);
            this.txtOcAba.TabIndex = 4;
            this.txtOcAba.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOcAba.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOcAba_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(196, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "OC:";
            // 
            // txtViaAba
            // 
            this.txtViaAba.ForeColor = System.Drawing.Color.Blue;
            this.txtViaAba.Location = new System.Drawing.Point(382, 56);
            this.txtViaAba.Name = "txtViaAba";
            this.txtViaAba.Size = new System.Drawing.Size(83, 21);
            this.txtViaAba.TabIndex = 5;
            this.txtViaAba.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtViaAba.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtViaAba_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(360, 64);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Via:";
            // 
            // txtCanAba
            // 
            this.txtCanAba.ForeColor = System.Drawing.Color.Blue;
            this.txtCanAba.Location = new System.Drawing.Point(57, 56);
            this.txtCanAba.Name = "txtCanAba";
            this.txtCanAba.Size = new System.Drawing.Size(100, 21);
            this.txtCanAba.TabIndex = 3;
            this.txtCanAba.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCanAba.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCanAba_KeyPress);
            // 
            // txtProAba
            // 
            this.txtProAba.BackColor = System.Drawing.Color.Silver;
            this.txtProAba.ForeColor = System.Drawing.Color.Blue;
            this.txtProAba.Location = new System.Drawing.Point(664, 26);
            this.txtProAba.Name = "txtProAba";
            this.txtProAba.Size = new System.Drawing.Size(297, 21);
            this.txtProAba.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(600, 33);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Proveedor:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 64);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Cantidad:";
            // 
            // frmLOG_InfRSV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1102, 546);
            this.Controls.Add(this.tabCon);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmLOG_InfRSV";
            this.Text = "Información para reserva";
            this.Load += new System.EventHandler(this.frmLOG_InfRSV_Load);
            this.tabCon.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabConOfvOrd.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgInfResOfe)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgInfResOrd)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgDetPed)).EndInit();
            this.gpbDetPed.ResumeLayout(false);
            this.gpbDetPed.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgOrdAba)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gpbFec.ResumeLayout(false);
            this.gpbFec.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCon;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabConOfvOrd;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private C1.Win.C1FlexGrid.C1FlexGrid fgInfResOfe;
        private System.Windows.Forms.CheckBox chkMosTodOfe;
        private System.Windows.Forms.Button btnExpOfe;
        private System.Windows.Forms.Button btnMosActOfe;
        private System.Windows.Forms.CheckBox chkMosTodOrd;
        private C1.Win.C1FlexGrid.C1FlexGrid fgInfResOrd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCliPed;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRq;
        private System.Windows.Forms.CheckBox chkNoSto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDesArtPed;
        private System.Windows.Forms.GroupBox gpbDetPed;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.Button btnAgrPed;
        private System.Windows.Forms.Button btnCanPed;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCantCom;
        private System.Windows.Forms.TextBox txtOc;
        private System.Windows.Forms.CheckBox chkMosTodPed;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDetPed;
        private System.Windows.Forms.Button btnExpPed;
        private System.Windows.Forms.Button btnMosActPed;
        private System.Windows.Forms.TextBox txtCodArtPed;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtOcAba;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtViaAba;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCanAba;
        private System.Windows.Forms.TextBox txtProAba;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCodArtAba;
        private System.Windows.Forms.TextBox txtDesArtAba;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox gpbFec;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtpEntPro;
        private System.Windows.Forms.DateTimePicker dtpEmb;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dtpAprIng;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DateTimePicker dtpLlePue;
        private System.Windows.Forms.Button btnCanAba;
        private System.Windows.Forms.Button btnAgrAba;
        private System.Windows.Forms.Button btnExpAba;
        private System.Windows.Forms.Button btnMosActAba;
        private C1.Win.C1FlexGrid.C1FlexGrid fgOrdAba;
        private System.Windows.Forms.Button btnExpOrd;
        private System.Windows.Forms.Button btnMosActOrd;
        private System.Windows.Forms.CheckBox chkMosTodAba;
    }
}