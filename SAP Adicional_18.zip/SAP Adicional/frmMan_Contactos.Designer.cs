﻿namespace SAP_Adicional
{
    partial class frmMan_Contactos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMan_Contactos));
            this.tabManCon = new System.Windows.Forms.TabControl();
            this.tabPagMan = new System.Windows.Forms.TabPage();
            this.gpbBot = new System.Windows.Forms.GroupBox();
            this.btnPri = new System.Windows.Forms.Button();
            this.btnUlt = new System.Windows.Forms.Button();
            this.btnRet = new System.Windows.Forms.Button();
            this.btnAva = new System.Windows.Forms.Button();
            this.lblCanReg = new System.Windows.Forms.Label();
            this.txtCtaDtr = new System.Windows.Forms.TextBox();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtRuc = new System.Windows.Forms.TextBox();
            this.txtCat = new System.Windows.Forms.TextBox();
            this.txtCodCat = new System.Windows.Forms.TextBox();
            this.txtRes = new System.Windows.Forms.TextBox();
            this.txtCodRes = new System.Windows.Forms.TextBox();
            this.txtCar = new System.Windows.Forms.TextBox();
            this.txtCom = new System.Windows.Forms.TextBox();
            this.txtTipCon = new System.Windows.Forms.TextBox();
            this.txtCodTipCon = new System.Windows.Forms.TextBox();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.txtCodPro = new System.Windows.Forms.TextBox();
            this.txtEma2 = new System.Windows.Forms.TextBox();
            this.txtEma1 = new System.Windows.Forms.TextBox();
            this.txtFecNac = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtCel = new System.Windows.Forms.TextBox();
            this.txtTelTra = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTelPar = new System.Windows.Forms.TextBox();
            this.txtDis2 = new System.Windows.Forms.TextBox();
            this.txtCodDis2 = new System.Windows.Forms.TextBox();
            this.txtDirCas = new System.Windows.Forms.TextBox();
            this.txtDis = new System.Windows.Forms.TextBox();
            this.txtCodDis = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDirOfc = new System.Windows.Forms.TextBox();
            this.txtApe = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtCodCon = new System.Windows.Forms.TextBox();
            this.btnVisPre = new System.Windows.Forms.Button();
            this.chkIna = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCer = new System.Windows.Forms.Button();
            this.btnCan = new System.Windows.Forms.Button();
            this.btnBor = new System.Windows.Forms.Button();
            this.btnGua = new System.Windows.Forms.Button();
            this.btnNue = new System.Windows.Forms.Button();
            this.btnMod = new System.Windows.Forms.Button();
            this.tabPagMae = new System.Windows.Forms.TabPage();
            this.btnExpMae = new System.Windows.Forms.Button();
            this.txtFil = new System.Windows.Forms.TextBox();
            this.lblFil = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.fgMae = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabManCon.SuspendLayout();
            this.tabPagMan.SuspendLayout();
            this.gpbBot.SuspendLayout();
            this.tabPagMae.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMae)).BeginInit();
            this.SuspendLayout();
            // 
            // tabManCon
            // 
            this.tabManCon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabManCon.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabManCon.Controls.Add(this.tabPagMan);
            this.tabManCon.Controls.Add(this.tabPagMae);
            this.tabManCon.Location = new System.Drawing.Point(4, 2);
            this.tabManCon.Name = "tabManCon";
            this.tabManCon.SelectedIndex = 0;
            this.tabManCon.Size = new System.Drawing.Size(984, 673);
            this.tabManCon.TabIndex = 0;
            this.tabManCon.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabManCon_Selecting);
            // 
            // tabPagMan
            // 
            this.tabPagMan.AutoScroll = true;
            this.tabPagMan.Controls.Add(this.gpbBot);
            this.tabPagMan.Controls.Add(this.lblCanReg);
            this.tabPagMan.Controls.Add(this.txtCtaDtr);
            this.tabPagMan.Controls.Add(this.txtDni);
            this.tabPagMan.Controls.Add(this.label22);
            this.tabPagMan.Controls.Add(this.txtRuc);
            this.tabPagMan.Controls.Add(this.txtCat);
            this.tabPagMan.Controls.Add(this.txtCodCat);
            this.tabPagMan.Controls.Add(this.txtRes);
            this.tabPagMan.Controls.Add(this.txtCodRes);
            this.tabPagMan.Controls.Add(this.txtCar);
            this.tabPagMan.Controls.Add(this.txtCom);
            this.tabPagMan.Controls.Add(this.txtTipCon);
            this.tabPagMan.Controls.Add(this.txtCodTipCon);
            this.tabPagMan.Controls.Add(this.txtPro);
            this.tabPagMan.Controls.Add(this.txtCodPro);
            this.tabPagMan.Controls.Add(this.txtEma2);
            this.tabPagMan.Controls.Add(this.txtEma1);
            this.tabPagMan.Controls.Add(this.txtFecNac);
            this.tabPagMan.Controls.Add(this.label21);
            this.tabPagMan.Controls.Add(this.txtCel);
            this.tabPagMan.Controls.Add(this.txtTelTra);
            this.tabPagMan.Controls.Add(this.label7);
            this.tabPagMan.Controls.Add(this.txtTelPar);
            this.tabPagMan.Controls.Add(this.txtDis2);
            this.tabPagMan.Controls.Add(this.txtCodDis2);
            this.tabPagMan.Controls.Add(this.txtDirCas);
            this.tabPagMan.Controls.Add(this.txtDis);
            this.tabPagMan.Controls.Add(this.txtCodDis);
            this.tabPagMan.Controls.Add(this.label2);
            this.tabPagMan.Controls.Add(this.txtDirOfc);
            this.tabPagMan.Controls.Add(this.txtApe);
            this.tabPagMan.Controls.Add(this.txtNom);
            this.tabPagMan.Controls.Add(this.txtCodCon);
            this.tabPagMan.Controls.Add(this.btnVisPre);
            this.tabPagMan.Controls.Add(this.chkIna);
            this.tabPagMan.Controls.Add(this.label20);
            this.tabPagMan.Controls.Add(this.label19);
            this.tabPagMan.Controls.Add(this.label18);
            this.tabPagMan.Controls.Add(this.label17);
            this.tabPagMan.Controls.Add(this.label16);
            this.tabPagMan.Controls.Add(this.label15);
            this.tabPagMan.Controls.Add(this.label14);
            this.tabPagMan.Controls.Add(this.label13);
            this.tabPagMan.Controls.Add(this.label12);
            this.tabPagMan.Controls.Add(this.label11);
            this.tabPagMan.Controls.Add(this.label10);
            this.tabPagMan.Controls.Add(this.label9);
            this.tabPagMan.Controls.Add(this.label8);
            this.tabPagMan.Controls.Add(this.label6);
            this.tabPagMan.Controls.Add(this.label5);
            this.tabPagMan.Controls.Add(this.label4);
            this.tabPagMan.Controls.Add(this.label3);
            this.tabPagMan.Controls.Add(this.label1);
            this.tabPagMan.Controls.Add(this.btnCer);
            this.tabPagMan.Controls.Add(this.btnCan);
            this.tabPagMan.Controls.Add(this.btnBor);
            this.tabPagMan.Controls.Add(this.btnGua);
            this.tabPagMan.Controls.Add(this.btnNue);
            this.tabPagMan.Controls.Add(this.btnMod);
            this.tabPagMan.Location = new System.Drawing.Point(4, 25);
            this.tabPagMan.Name = "tabPagMan";
            this.tabPagMan.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagMan.Size = new System.Drawing.Size(976, 644);
            this.tabPagMan.TabIndex = 0;
            this.tabPagMan.Text = " Mantenimiento";
            this.tabPagMan.UseVisualStyleBackColor = true;
            // 
            // gpbBot
            // 
            this.gpbBot.Controls.Add(this.btnPri);
            this.gpbBot.Controls.Add(this.btnUlt);
            this.gpbBot.Controls.Add(this.btnRet);
            this.gpbBot.Controls.Add(this.btnAva);
            this.gpbBot.Location = new System.Drawing.Point(299, 518);
            this.gpbBot.Name = "gpbBot";
            this.gpbBot.Size = new System.Drawing.Size(342, 72);
            this.gpbBot.TabIndex = 36;
            this.gpbBot.TabStop = false;
            // 
            // btnPri
            // 
            this.btnPri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPri.Image = ((System.Drawing.Image)(resources.GetObject("btnPri.Image")));
            this.btnPri.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPri.Location = new System.Drawing.Point(30, 17);
            this.btnPri.Name = "btnPri";
            this.btnPri.Size = new System.Drawing.Size(71, 49);
            this.btnPri.TabIndex = 37;
            this.btnPri.Text = "Primero";
            this.btnPri.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPri.UseVisualStyleBackColor = true;
            this.btnPri.Click += new System.EventHandler(this.btnPri_Click);
            // 
            // btnUlt
            // 
            this.btnUlt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUlt.Image = ((System.Drawing.Image)(resources.GetObject("btnUlt.Image")));
            this.btnUlt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUlt.Location = new System.Drawing.Point(238, 17);
            this.btnUlt.Name = "btnUlt";
            this.btnUlt.Size = new System.Drawing.Size(71, 49);
            this.btnUlt.TabIndex = 40;
            this.btnUlt.Text = "Ultimo";
            this.btnUlt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnUlt.UseVisualStyleBackColor = true;
            this.btnUlt.Click += new System.EventHandler(this.btnUlt_Click);
            // 
            // btnRet
            // 
            this.btnRet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRet.Image = ((System.Drawing.Image)(resources.GetObject("btnRet.Image")));
            this.btnRet.Location = new System.Drawing.Point(99, 17);
            this.btnRet.Name = "btnRet";
            this.btnRet.Size = new System.Drawing.Size(71, 49);
            this.btnRet.TabIndex = 38;
            this.btnRet.Text = "Retroceder";
            this.btnRet.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRet.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRet.UseVisualStyleBackColor = true;
            this.btnRet.Click += new System.EventHandler(this.btnRet_Click);
            // 
            // btnAva
            // 
            this.btnAva.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAva.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAva.Image = ((System.Drawing.Image)(resources.GetObject("btnAva.Image")));
            this.btnAva.Location = new System.Drawing.Point(168, 17);
            this.btnAva.Name = "btnAva";
            this.btnAva.Size = new System.Drawing.Size(71, 49);
            this.btnAva.TabIndex = 39;
            this.btnAva.Text = "Avanzar";
            this.btnAva.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAva.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAva.UseVisualStyleBackColor = true;
            this.btnAva.Click += new System.EventHandler(this.btnAva_Click);
            // 
            // lblCanReg
            // 
            this.lblCanReg.AutoSize = true;
            this.lblCanReg.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCanReg.ForeColor = System.Drawing.Color.Blue;
            this.lblCanReg.Location = new System.Drawing.Point(647, 498);
            this.lblCanReg.Name = "lblCanReg";
            this.lblCanReg.Size = new System.Drawing.Size(0, 14);
            this.lblCanReg.TabIndex = 66;
            // 
            // txtCtaDtr
            // 
            this.txtCtaDtr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCtaDtr.ForeColor = System.Drawing.Color.Blue;
            this.txtCtaDtr.Location = new System.Drawing.Point(299, 491);
            this.txtCtaDtr.Name = "txtCtaDtr";
            this.txtCtaDtr.Size = new System.Drawing.Size(342, 21);
            this.txtCtaDtr.TabIndex = 28;
            this.txtCtaDtr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCtaDtr_KeyPress);
            // 
            // txtDni
            // 
            this.txtDni.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDni.ForeColor = System.Drawing.Color.Blue;
            this.txtDni.Location = new System.Drawing.Point(499, 464);
            this.txtDni.Name = "txtDni";
            this.txtDni.Size = new System.Drawing.Size(142, 21);
            this.txtDni.TabIndex = 27;
            this.txtDni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDni_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(468, 471);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 13);
            this.label22.TabIndex = 63;
            this.label22.Text = "DNI:";
            // 
            // txtRuc
            // 
            this.txtRuc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRuc.ForeColor = System.Drawing.Color.Blue;
            this.txtRuc.Location = new System.Drawing.Point(299, 464);
            this.txtRuc.Name = "txtRuc";
            this.txtRuc.Size = new System.Drawing.Size(164, 21);
            this.txtRuc.TabIndex = 26;
            this.txtRuc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRuc_KeyPress);
            // 
            // txtCat
            // 
            this.txtCat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCat.ForeColor = System.Drawing.Color.Blue;
            this.txtCat.Location = new System.Drawing.Point(346, 437);
            this.txtCat.Name = "txtCat";
            this.txtCat.Size = new System.Drawing.Size(295, 21);
            this.txtCat.TabIndex = 25;
            this.txtCat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCat_KeyPress);
            // 
            // txtCodCat
            // 
            this.txtCodCat.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodCat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodCat.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodCat.Location = new System.Drawing.Point(299, 437);
            this.txtCodCat.Name = "txtCodCat";
            this.txtCodCat.Size = new System.Drawing.Size(48, 21);
            this.txtCodCat.TabIndex = 24;
            // 
            // txtRes
            // 
            this.txtRes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRes.ForeColor = System.Drawing.Color.Blue;
            this.txtRes.Location = new System.Drawing.Point(346, 411);
            this.txtRes.Name = "txtRes";
            this.txtRes.Size = new System.Drawing.Size(295, 21);
            this.txtRes.TabIndex = 23;
            this.txtRes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRes_KeyPress);
            // 
            // txtCodRes
            // 
            this.txtCodRes.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodRes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodRes.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodRes.Location = new System.Drawing.Point(299, 411);
            this.txtCodRes.Name = "txtCodRes";
            this.txtCodRes.Size = new System.Drawing.Size(48, 21);
            this.txtCodRes.TabIndex = 22;
            // 
            // txtCar
            // 
            this.txtCar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCar.ForeColor = System.Drawing.Color.Blue;
            this.txtCar.Location = new System.Drawing.Point(299, 384);
            this.txtCar.Name = "txtCar";
            this.txtCar.Size = new System.Drawing.Size(342, 21);
            this.txtCar.TabIndex = 21;
            this.txtCar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCar_KeyPress);
            // 
            // txtCom
            // 
            this.txtCom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCom.ForeColor = System.Drawing.Color.Blue;
            this.txtCom.Location = new System.Drawing.Point(299, 357);
            this.txtCom.Name = "txtCom";
            this.txtCom.Size = new System.Drawing.Size(342, 21);
            this.txtCom.TabIndex = 20;
            this.txtCom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCom_KeyPress);
            // 
            // txtTipCon
            // 
            this.txtTipCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTipCon.ForeColor = System.Drawing.Color.Blue;
            this.txtTipCon.Location = new System.Drawing.Point(346, 330);
            this.txtTipCon.Name = "txtTipCon";
            this.txtTipCon.Size = new System.Drawing.Size(295, 21);
            this.txtTipCon.TabIndex = 19;
            this.txtTipCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipCon_KeyPress);
            // 
            // txtCodTipCon
            // 
            this.txtCodTipCon.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodTipCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodTipCon.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodTipCon.Location = new System.Drawing.Point(299, 330);
            this.txtCodTipCon.Name = "txtCodTipCon";
            this.txtCodTipCon.Size = new System.Drawing.Size(48, 21);
            this.txtCodTipCon.TabIndex = 18;
            // 
            // txtPro
            // 
            this.txtPro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPro.ForeColor = System.Drawing.Color.Blue;
            this.txtPro.Location = new System.Drawing.Point(346, 303);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(295, 21);
            this.txtPro.TabIndex = 17;
            this.txtPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPro_KeyPress);
            // 
            // txtCodPro
            // 
            this.txtCodPro.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodPro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodPro.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodPro.Location = new System.Drawing.Point(299, 303);
            this.txtCodPro.Name = "txtCodPro";
            this.txtCodPro.Size = new System.Drawing.Size(48, 21);
            this.txtCodPro.TabIndex = 16;
            // 
            // txtEma2
            // 
            this.txtEma2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEma2.ForeColor = System.Drawing.Color.Blue;
            this.txtEma2.Location = new System.Drawing.Point(299, 276);
            this.txtEma2.Name = "txtEma2";
            this.txtEma2.Size = new System.Drawing.Size(342, 21);
            this.txtEma2.TabIndex = 15;
            this.txtEma2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEma2_KeyPress);
            // 
            // txtEma1
            // 
            this.txtEma1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEma1.ForeColor = System.Drawing.Color.Blue;
            this.txtEma1.Location = new System.Drawing.Point(299, 247);
            this.txtEma1.Name = "txtEma1";
            this.txtEma1.Size = new System.Drawing.Size(342, 21);
            this.txtEma1.TabIndex = 14;
            this.txtEma1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEma1_KeyPress);
            // 
            // txtFecNac
            // 
            this.txtFecNac.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFecNac.ForeColor = System.Drawing.Color.Blue;
            this.txtFecNac.Location = new System.Drawing.Point(511, 220);
            this.txtFecNac.Name = "txtFecNac";
            this.txtFecNac.Size = new System.Drawing.Size(130, 21);
            this.txtFecNac.TabIndex = 13;
            this.txtFecNac.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFecNac_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(454, 228);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 13);
            this.label21.TabIndex = 48;
            this.label21.Text = "Fecha nac:";
            // 
            // txtCel
            // 
            this.txtCel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCel.ForeColor = System.Drawing.Color.Blue;
            this.txtCel.Location = new System.Drawing.Point(299, 220);
            this.txtCel.Name = "txtCel";
            this.txtCel.Size = new System.Drawing.Size(143, 21);
            this.txtCel.TabIndex = 12;
            this.txtCel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCel_KeyPress);
            // 
            // txtTelTra
            // 
            this.txtTelTra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelTra.ForeColor = System.Drawing.Color.Blue;
            this.txtTelTra.Location = new System.Drawing.Point(511, 192);
            this.txtTelTra.Name = "txtTelTra";
            this.txtTelTra.Size = new System.Drawing.Size(130, 21);
            this.txtTelTra.TabIndex = 11;
            this.txtTelTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelTra_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(443, 199);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 45;
            this.label7.Text = "Telf. trabajo:";
            // 
            // txtTelPar
            // 
            this.txtTelPar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTelPar.ForeColor = System.Drawing.Color.Blue;
            this.txtTelPar.Location = new System.Drawing.Point(299, 193);
            this.txtTelPar.Name = "txtTelPar";
            this.txtTelPar.Size = new System.Drawing.Size(143, 21);
            this.txtTelPar.TabIndex = 10;
            this.txtTelPar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelPar_KeyPress);
            // 
            // txtDis2
            // 
            this.txtDis2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDis2.ForeColor = System.Drawing.Color.Blue;
            this.txtDis2.Location = new System.Drawing.Point(346, 167);
            this.txtDis2.Name = "txtDis2";
            this.txtDis2.Size = new System.Drawing.Size(295, 21);
            this.txtDis2.TabIndex = 9;
            this.txtDis2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDis2_KeyPress);
            // 
            // txtCodDis2
            // 
            this.txtCodDis2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodDis2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodDis2.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodDis2.Location = new System.Drawing.Point(299, 167);
            this.txtCodDis2.Name = "txtCodDis2";
            this.txtCodDis2.Size = new System.Drawing.Size(48, 21);
            this.txtCodDis2.TabIndex = 8;
            // 
            // txtDirCas
            // 
            this.txtDirCas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDirCas.ForeColor = System.Drawing.Color.Blue;
            this.txtDirCas.Location = new System.Drawing.Point(299, 141);
            this.txtDirCas.Name = "txtDirCas";
            this.txtDirCas.Size = new System.Drawing.Size(342, 21);
            this.txtDirCas.TabIndex = 7;
            this.txtDirCas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDirCas_KeyPress);
            // 
            // txtDis
            // 
            this.txtDis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDis.ForeColor = System.Drawing.Color.Blue;
            this.txtDis.Location = new System.Drawing.Point(346, 115);
            this.txtDis.Name = "txtDis";
            this.txtDis.Size = new System.Drawing.Size(295, 21);
            this.txtDis.TabIndex = 6;
            this.txtDis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDis_KeyPress);
            // 
            // txtCodDis
            // 
            this.txtCodDis.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodDis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodDis.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodDis.Location = new System.Drawing.Point(299, 115);
            this.txtCodDis.Name = "txtCodDis";
            this.txtCodDis.Size = new System.Drawing.Size(48, 21);
            this.txtCodDis.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(250, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 38;
            this.label2.Text = "Nombre:";
            // 
            // txtDirOfc
            // 
            this.txtDirOfc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDirOfc.ForeColor = System.Drawing.Color.Blue;
            this.txtDirOfc.Location = new System.Drawing.Point(299, 88);
            this.txtDirOfc.Name = "txtDirOfc";
            this.txtDirOfc.Size = new System.Drawing.Size(342, 21);
            this.txtDirOfc.TabIndex = 4;
            this.txtDirOfc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDirOfc_KeyPress);
            // 
            // txtApe
            // 
            this.txtApe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtApe.ForeColor = System.Drawing.Color.Blue;
            this.txtApe.Location = new System.Drawing.Point(299, 60);
            this.txtApe.Name = "txtApe";
            this.txtApe.Size = new System.Drawing.Size(342, 21);
            this.txtApe.TabIndex = 3;
            this.txtApe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtApe_KeyPress);
            // 
            // txtNom
            // 
            this.txtNom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNom.ForeColor = System.Drawing.Color.Blue;
            this.txtNom.Location = new System.Drawing.Point(299, 32);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(342, 21);
            this.txtNom.TabIndex = 2;
            this.txtNom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNom_KeyPress);
            // 
            // txtCodCon
            // 
            this.txtCodCon.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodCon.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodCon.Location = new System.Drawing.Point(299, 6);
            this.txtCodCon.Name = "txtCodCon";
            this.txtCodCon.Size = new System.Drawing.Size(127, 21);
            this.txtCodCon.TabIndex = 0;
            this.txtCodCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCon_KeyPress);
            // 
            // btnVisPre
            // 
            this.btnVisPre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVisPre.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVisPre.Image = global::SAP_Adicional.Properties.Resources.prtpv_16;
            this.btnVisPre.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnVisPre.Location = new System.Drawing.Point(99, 307);
            this.btnVisPre.Name = "btnVisPre";
            this.btnVisPre.Size = new System.Drawing.Size(67, 48);
            this.btnVisPre.TabIndex = 35;
            this.btnVisPre.Text = "&Vista previa";
            this.btnVisPre.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnVisPre.UseVisualStyleBackColor = true;
            this.btnVisPre.Click += new System.EventHandler(this.btnVisPre_Click);
            // 
            // chkIna
            // 
            this.chkIna.AutoSize = true;
            this.chkIna.Location = new System.Drawing.Point(471, 10);
            this.chkIna.Name = "chkIna";
            this.chkIna.Size = new System.Drawing.Size(65, 17);
            this.chkIna.TabIndex = 1;
            this.chkIna.Text = "Inactivo";
            this.chkIna.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(213, 498);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 13);
            this.label20.TabIndex = 31;
            this.label20.Text = "Cta. Detracción:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(266, 471);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(32, 13);
            this.label19.TabIndex = 30;
            this.label19.Text = "RUC:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(240, 445);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "Categoria:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(210, 419);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(88, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "Responsabilidad:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(258, 391);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "Cargo:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(240, 365);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Compañia:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(205, 338);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Tipo de contacto:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(242, 313);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Profesión:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(244, 284);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "E - mail 2:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(245, 255);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "E - mail 1:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(255, 228);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Celular:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(218, 199);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Telf. particular:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(254, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Distrito:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(219, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Dirección casa:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(253, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Distrito:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(209, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Dirección oficina:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(249, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Apellido:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(253, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Codigo:";
            // 
            // btnCer
            // 
            this.btnCer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCer.Image = ((System.Drawing.Image)(resources.GetObject("btnCer.Image")));
            this.btnCer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCer.Location = new System.Drawing.Point(99, 267);
            this.btnCer.Name = "btnCer";
            this.btnCer.Size = new System.Drawing.Size(67, 41);
            this.btnCer.TabIndex = 34;
            this.btnCer.Text = "Cerrar";
            this.btnCer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCer.UseVisualStyleBackColor = true;
            this.btnCer.Click += new System.EventHandler(this.btnCer_Click);
            // 
            // btnCan
            // 
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Image = ((System.Drawing.Image)(resources.GetObject("btnCan.Image")));
            this.btnCan.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCan.Location = new System.Drawing.Point(99, 227);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(67, 41);
            this.btnCan.TabIndex = 33;
            this.btnCan.Text = "&Cancelar";
            this.btnCan.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // btnBor
            // 
            this.btnBor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBor.Image = ((System.Drawing.Image)(resources.GetObject("btnBor.Image")));
            this.btnBor.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBor.Location = new System.Drawing.Point(99, 187);
            this.btnBor.Name = "btnBor";
            this.btnBor.Size = new System.Drawing.Size(67, 41);
            this.btnBor.TabIndex = 32;
            this.btnBor.Text = "&Borrar";
            this.btnBor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBor.UseVisualStyleBackColor = true;
            this.btnBor.Click += new System.EventHandler(this.btnBor_Click);
            // 
            // btnGua
            // 
            this.btnGua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGua.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGua.Image = ((System.Drawing.Image)(resources.GetObject("btnGua.Image")));
            this.btnGua.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGua.Location = new System.Drawing.Point(99, 147);
            this.btnGua.Name = "btnGua";
            this.btnGua.Size = new System.Drawing.Size(67, 41);
            this.btnGua.TabIndex = 31;
            this.btnGua.Text = "&Guardar";
            this.btnGua.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGua.UseVisualStyleBackColor = true;
            this.btnGua.Click += new System.EventHandler(this.btnGua_Click);
            // 
            // btnNue
            // 
            this.btnNue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNue.Image = ((System.Drawing.Image)(resources.GetObject("btnNue.Image")));
            this.btnNue.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNue.Location = new System.Drawing.Point(99, 67);
            this.btnNue.Name = "btnNue";
            this.btnNue.Size = new System.Drawing.Size(67, 41);
            this.btnNue.TabIndex = 29;
            this.btnNue.Text = "&Nuevo";
            this.btnNue.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNue.UseVisualStyleBackColor = true;
            this.btnNue.Click += new System.EventHandler(this.btnNue_Click);
            // 
            // btnMod
            // 
            this.btnMod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMod.Image = ((System.Drawing.Image)(resources.GetObject("btnMod.Image")));
            this.btnMod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMod.Location = new System.Drawing.Point(99, 107);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(67, 41);
            this.btnMod.TabIndex = 30;
            this.btnMod.Text = "&Modificar";
            this.btnMod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // tabPagMae
            // 
            this.tabPagMae.Controls.Add(this.btnExpMae);
            this.tabPagMae.Controls.Add(this.txtFil);
            this.tabPagMae.Controls.Add(this.lblFil);
            this.tabPagMae.Controls.Add(this.label23);
            this.tabPagMae.Controls.Add(this.fgMae);
            this.tabPagMae.Location = new System.Drawing.Point(4, 25);
            this.tabPagMae.Name = "tabPagMae";
            this.tabPagMae.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagMae.Size = new System.Drawing.Size(976, 644);
            this.tabPagMae.TabIndex = 1;
            this.tabPagMae.Text = "Maestro";
            this.tabPagMae.UseVisualStyleBackColor = true;
            // 
            // btnExpMae
            // 
            this.btnExpMae.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpMae.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExpMae.Image = ((System.Drawing.Image)(resources.GetObject("btnExpMae.Image")));
            this.btnExpMae.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExpMae.Location = new System.Drawing.Point(838, 12);
            this.btnExpMae.Name = "btnExpMae";
            this.btnExpMae.Size = new System.Drawing.Size(118, 30);
            this.btnExpMae.TabIndex = 3;
            this.btnExpMae.Text = "Exportar Excel";
            this.btnExpMae.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExpMae.UseVisualStyleBackColor = true;
            this.btnExpMae.Click += new System.EventHandler(this.btnExpMae_Click);
            // 
            // txtFil
            // 
            this.txtFil.Location = new System.Drawing.Point(219, 18);
            this.txtFil.Name = "txtFil";
            this.txtFil.Size = new System.Drawing.Size(600, 21);
            this.txtFil.TabIndex = 2;
            this.txtFil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFil_KeyPress);
            // 
            // lblFil
            // 
            this.lblFil.BackColor = System.Drawing.Color.DimGray;
            this.lblFil.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFil.ForeColor = System.Drawing.Color.White;
            this.lblFil.Location = new System.Drawing.Point(55, 18);
            this.lblFil.Name = "lblFil";
            this.lblFil.Size = new System.Drawing.Size(165, 20);
            this.lblFil.TabIndex = 1;
            this.lblFil.Text = "Codigo";
            this.lblFil.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(8, 18);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 20);
            this.label23.TabIndex = 0;
            this.label23.Text = "Filtro:";
            // 
            // fgMae
            // 
            this.fgMae.AllowFiltering = true;
            this.fgMae.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgMae.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgMae.Location = new System.Drawing.Point(7, 60);
            this.fgMae.Name = "fgMae";
            this.fgMae.Rows.DefaultSize = 19;
            this.fgMae.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgMae.Size = new System.Drawing.Size(963, 578);
            this.fgMae.TabIndex = 4;
            this.fgMae.BeforeSort += new C1.Win.C1FlexGrid.SortColEventHandler(this.fgMae_BeforeSort);
            this.fgMae.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgMae_AfterEdit);
            this.fgMae.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgMae_KeyPressEdit);
            this.fgMae.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgMae_AfterDataRefresh);
            this.fgMae.DoubleClick += new System.EventHandler(this.fgMae_DoubleClick);
            // 
            // frmMan_Contactos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 681);
            this.Controls.Add(this.tabManCon);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMan_Contactos";
            this.Text = "BD Recomendadores";
            this.Load += new System.EventHandler(this.frmMan_Contactos_Load);
            this.tabManCon.ResumeLayout(false);
            this.tabPagMan.ResumeLayout(false);
            this.tabPagMan.PerformLayout();
            this.gpbBot.ResumeLayout(false);
            this.tabPagMae.ResumeLayout(false);
            this.tabPagMae.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMae)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabManCon;
        private System.Windows.Forms.TabPage tabPagMan;
        private System.Windows.Forms.TabPage tabPagMae;
        private System.Windows.Forms.Button btnCer;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Button btnBor;
        private System.Windows.Forms.Button btnGua;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.CheckBox chkIna;
        private System.Windows.Forms.Button btnVisPre;
        private System.Windows.Forms.TextBox txtCodCon;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtDirOfc;
        private System.Windows.Forms.TextBox txtCodDis;
        private System.Windows.Forms.TextBox txtDis;
        private System.Windows.Forms.TextBox txtDirCas;
        private System.Windows.Forms.TextBox txtTelPar;
        private System.Windows.Forms.TextBox txtDis2;
        private System.Windows.Forms.TextBox txtCodDis2;
        private System.Windows.Forms.TextBox txtTelTra;
        private System.Windows.Forms.TextBox txtCel;
        private System.Windows.Forms.TextBox txtFecNac;
        private System.Windows.Forms.TextBox txtEma2;
        private System.Windows.Forms.TextBox txtEma1;
        private System.Windows.Forms.TextBox txtTipCon;
        private System.Windows.Forms.TextBox txtCodTipCon;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.TextBox txtCodPro;
        private System.Windows.Forms.TextBox txtCom;
        private System.Windows.Forms.TextBox txtCar;
        private System.Windows.Forms.TextBox txtRes;
        private System.Windows.Forms.TextBox txtCodRes;
        private System.Windows.Forms.TextBox txtCat;
        private System.Windows.Forms.TextBox txtCodCat;
        private System.Windows.Forms.TextBox txtRuc;
        private System.Windows.Forms.TextBox txtDni;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtCtaDtr;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCanReg;
        private C1.Win.C1FlexGrid.C1FlexGrid fgMae;
        private System.Windows.Forms.TextBox txtFil;
        private System.Windows.Forms.Label lblFil;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnExpMae;
        private System.Windows.Forms.Button btnNue;
        private System.Windows.Forms.GroupBox gpbBot;
        private System.Windows.Forms.Button btnPri;
        private System.Windows.Forms.Button btnUlt;
        private System.Windows.Forms.Button btnRet;
        private System.Windows.Forms.Button btnAva;
        private System.Windows.Forms.TextBox txtApe;
    }
}