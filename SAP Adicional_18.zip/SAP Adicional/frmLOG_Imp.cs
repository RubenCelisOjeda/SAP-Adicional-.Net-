﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using CrystalDecisions.CrystalReports.Engine;
using Entidades.LOG_Imp;
using Interfaces;
using SAP_Adicional.Reportes;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_Imp : Form, LOG_Imp
    {
        private NLOG_Imp logImp = new NLOG_Imp();
        private VarGlo varglo = VarGlo.Instance();
        public int NumMov = 0; private Int16 EstDoc = 0; private bool EstMod = false; private int Item = 0; private bool HabFg = false;
        
        
        public frmLOG_Imp()
        {
            InitializeComponent();
        }
       
        private void frmLOG_Imp_Load(object sender, EventArgs e)
        {
            tabConArtCom.SelectedTab = tabPage5; //seleccion el tabPage
            LOG_Imp_HabCon(false); 
            LOG_Imp_ForCol();
            LOG_Imp_TexPre();
            LOG_Imp_SolLec();
            LOG_Imp_SumTot("Articulo");
            LOG_Imp_EstBot("cargar");
          
            if (NumMov != 0)
            {
                LOG_Imp_Rec();
                LOG_Imp_EstBot("abrir");
            }
        }

        void LOG_Imp_SolLec()
        {
            ///Permite solo lectura de los textbox
            txtNumImp.ReadOnly = true;
            txtFecEmi.ReadOnly = true;
            txtCodPro.ReadOnly = true;
            txtCodEnv.ReadOnly = true;
            txtCodEstPag.ReadOnly = true;
            txtCodMon.ReadOnly = true;
            txtCodArt.ReadOnly = true;
        }

        void LOG_Imp_HabCon(bool Estado)
        {
            ///cambia el estado de los  botones
            gpbUltUsu.Enabled = Estado;
            gpbArt.Enabled = Estado;
            gpbOtrDat.Enabled = Estado;
            gpbShiInf.Enabled = Estado;
            gpbShiDet.Enabled = Estado;
            gpbPayTer.Enabled = Estado;
            gpbLal.Enabled = Estado;
            gpbInc.Enabled = Estado;
        }

        void Log_Imp_LimCon()
        {
            /******************************************
            * Nombre: "Limpiar controles(TextBox - MaskedTextBox)"
            * Proposito: <Recorrer los TextBox y MaskedTextBox del formulario que este dentro de cada control>
            * Ouptut : <"Mostrar TextBox y MaskedTextBox vacios">
            * Creado por: Ruben C.
            *****************************************/

            ///recorre TabPage Importacion 
            foreach (Control gpb in tabComImpOtr.TabPages[0].Controls)
            {
                if (gpb is GroupBox)
                {
                    foreach (Control texto in gpb.Controls)
                    {
                        if (texto is TextBox) texto.Text = "";
                        if (texto is MaskedTextBox) ((MaskedTextBox)texto).Text = "";
                    }
                }
            }
            ///recorre TabPage Otros datos
            foreach (Control gpb in tabComImpOtr.TabPages[1].Controls)
            {
                if (gpb is GroupBox)
                {
                    foreach (Control texto in gpb.Controls)
                    {
                        if (texto is TextBox) texto.Text = "";
                        if (texto is MaskedTextBox) texto.Text = "";
                    }
                }
            }

            ///recorre Otro datos del GroupBox
            foreach (Control gpb in gpbOtrDat.Controls)
            {
                if (gpb is TextBox) gpb.Text = "";
                if (gpb is MaskedTextBox) gpb.Text = "";
            }

            ///otros controles
            if (NumMov != 0)
            {
                fgArt.Rows.Count = 1;
                LOG_Imp_SumTot("Articulo");
            }
           
            rdbExWor.Checked = true;
            txtNumImp.Text = "";
            txtFecEmi.Text = DateTime.Now.ToShortDateString();
            chkEnvInt.Checked = false;
            cboLey.SelectedIndex = 0;
            LOG_Imp_TexPre();
        }

        void LOG_Imp_TexPre()
        {
            ///texto predeterminado al cargar el formulario o presionar el boton deshacer
            txtUltDes.Text = "PERU";
            txtInvTo.Text = "TRAZZO ILUMINACION S.A.C";
            txtCon.Text = "LIBERTADORES-274 L27,SAN ISIDRO LIMA,PERU";
            txtPho.Text = "511-6159900";
            txtFax.Text = "511-6159920";
            txtFwd.Text = "Danzas";
            lblUltUsu.Text = "Ultimo usuario:";
            txtDesPayTer.Text = "In advance by Swift Bank Transfer from Trazzo Iluminacion S.A.C.";
            txtDesLab.Text = "All boxed should by printed or sticked with MADE IN ITALY or Country where manufactured,in any size.";
        }
        void LOG_Imp_Rec()
        {
            /******************************************
            * Nombre: "Recuperar datos desde la base de datos"
            * Proposito: <Capturar el NumMov al seleccionar una fila en el reporte de importacion al presionar el boton Abrir>
            * Ouptut : <"Asignar los datos del DataTable a los textbox mostrando los datos del procedimiento Det y Enc">
            * Creado por: Ruben C.
            *****************************************/

            DataSet dsImp = logImp.LOG_Imp_DetImp((Int16)NumMov);
            DataTable dtEncRec = dsImp.Tables["Enc_Rec"];

            ///Flexgrid Articulo - Valida y recupera los valores del (Enc_Rec) asignando los datos
            if (dtEncRec.Rows.Count > 0)
            {
                NumMov = (int)dtEncRec.Rows[0]["NumMov"];
                txtNumImp.Text = (string)dtEncRec.Rows[0]["NumImp"];

                DateTime fecha = (DateTime)dtEncRec.Rows[0]["FecEmi"];
                txtFecEmi.Text = fecha.ToShortDateString();

                txtCodPro.Text = (string)dtEncRec.Rows[0]["CodPro"];
                txtDesPro.Text = (string)dtEncRec.Rows[0]["NomPro"];
                mkbEtd.Text = (string)dtEncRec.Rows[0]["etd"];
                mkbEta.Text = (string)dtEncRec.Rows[0]["eta"];
                mkbFecLLe.Text = (string)dtEncRec.Rows[0]["fecest"];
                EstDoc = (Int16)dtEncRec.Rows[0]["EstDoc"];
                txtCodEnv.Text = dtEncRec.Rows[0]["CodForEnv"].ToString();
                txtDesEnv.Text = (string)dtEncRec.Rows[0]["forenv"];
                txtCodEstPag.Text = dtEncRec.Rows[0]["CodEstPag"].ToString();
                txtDesEstPag.Text = (string)dtEncRec.Rows[0]["EstPag"];
                lblUltUsu.Text = "Última modificación " + dtEncRec.Rows[0]["res"] + " " + dtEncRec.Rows[0]["FecMod"];
                txtInvTo.Text = (string)dtEncRec.Rows[0]["invoiceto"];
                txtCon.Text = (string)dtEncRec.Rows[0]["shipto"];
                txtCouImp.Text = (string)dtEncRec.Rows[0]["CountryImport"];
                txtUltDes.Text = (string)dtEncRec.Rows[0]["ultimatedest"];
                txtPho.Text = (string)dtEncRec.Rows[0]["phone"];
                txtFax.Text = (string)dtEncRec.Rows[0]["fax"];
                txtFwd.Text = (string)dtEncRec.Rows[0]["Forwarder"];
                txtAdd.Text = (string)dtEncRec.Rows[0]["Address"];
                txtPhoDet.Text = (string)dtEncRec.Rows[0]["ForwarderPhone"];
                txtFaxDet.Text = (string)dtEncRec.Rows[0]["ForwarderFax"];
                txtEma.Text = (string)dtEncRec.Rows[0]["email"];
                txtConPer.Text = (string)dtEncRec.Rows[0]["ContactPerson"];
                txtDesPayTer.Text = (string)dtEncRec.Rows[0]["PaymentTerms"];
                txtDesLab.Text = (string)dtEncRec.Rows[0]["labels"];
                txtVia.Text = (string)dtEncRec.Rows[0]["Alias"];

                txtOrdDat.Text = fecha.ToShortDateString();
                txtCodMon.Text = dtEncRec.Rows[0]["codmon"].ToString();
                txtDesMon.Text = (string)dtEncRec.Rows[0]["Moneda"];

                if (dtEncRec.Rows[0]["Incoterm"].ToString() == "0")
                {
                    rdbExWor.Checked = true;
                }
                else
                {
                    rdbFob.Checked = true;
                }

                mkbFecDisDes.Text = (string)dtEncRec.Rows[0]["fecdisdes"];
                txtNomBar.Text = (string)dtEncRec.Rows[0]["nombarnumvue"];
                txtTra.Text = (string)dtEncRec.Rows[0]["awbbltra"];
                txtCodImp.Text = (string)dtEncRec.Rows[0]["CodConImpMar"];
                txtOtrNumImp.Text = (string)dtEncRec.Rows[0]["NumCarImp"];
                chkEnvInt.Checked = Convert.ToInt32(dtEncRec.Rows[0]["EnvInt"]) == 0 ? false : true;
                cboLey.SelectedIndex = Convert.ToInt32(dtEncRec.Rows[0]["CodLey"]);
                mkbOtrFecEntPro.Text = (string)dtEncRec.Rows[0]["FEPE"];
            }

            ///Flexgrid Detalle importacion - articulo
            ///Valida y recorre el (Det_Rec)  mostrando los registros en el grid*/
            if (fgArt.Rows.Count > 1)
            {
                fgArt.Rows.Remove(fgArt.Rows[fgArt.Rows.Count - 1]);
            }


            DataTable dtDetComRec = dsImp.Tables["Det_Rec"];

            if (dtDetComRec.Rows.Count > 0)
            {
                for (int i = 0; i < dtDetComRec.Rows.Count; i++)
                {
                    fgArt.Rows.Add();
                    fgArt.Rows[fgArt.Rows.Count - 1][0] = fgArt.Rows.Count - 1;
                    fgArt.Rows[fgArt.Rows.Count - 1][1] = dtDetComRec.Rows[i]["ItemCode"];
                    fgArt.Rows[fgArt.Rows.Count - 1][2] = dtDetComRec.Rows[i]["NumeroId"];
                    fgArt.Rows[fgArt.Rows.Count - 1][3] = dtDetComRec.Rows[i]["itemname"];
                    fgArt.Rows[fgArt.Rows.Count - 1][4] = dtDetComRec.Rows[i]["Catalogo"];
                    fgArt.Rows[fgArt.Rows.Count - 1][5] = dtDetComRec.Rows[i]["Can"];
                    fgArt.Rows[fgArt.Rows.Count - 1][6] = dtDetComRec.Rows[i]["Costo"];
                    fgArt.Rows[fgArt.Rows.Count - 1][7] = dtDetComRec.Rows[i]["SubTotal"];
                    fgArt.Rows[fgArt.Rows.Count - 1][8] = dtDetComRec.Rows[i]["Obs"];
                    fgArt.Rows[fgArt.Rows.Count - 1][9] = dtDetComRec.Rows[i]["Ocu"];
                    fgArt.Rows[fgArt.Rows.Count - 1][10] = dtDetComRec.Rows[i]["Ord"];
                    fgArt.Rows[fgArt.Rows.Count - 1][11] = dtDetComRec.Rows[i]["FecEntPro"].ToString();
                }
            }

            LOG_Imp_SumTot("Articulo");

            ///Flexgrid Sin codigo.
            ///Valida y recorre el (DetSinStock_Rec)  mostrando los registros en el grid*/
            
            if (fgSinCod.Rows.Count > 1)
            {
                fgSinCod.Rows.Remove(fgSinCod.Rows[fgSinCod.Rows.Count - 1]);
            }

            DataTable dtDetSinStock = dsImp.Tables["DetSinStock_Rec"];

            if (dtDetSinStock.Rows.Count > 0)
            {
                for (int i = 0; i < dtDetSinStock.Rows.Count; i++)
                {

                    string n = dtDetSinStock.Rows[i][0].ToString();
                    
                    fgSinCod.Rows.Add();
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][0] = dtDetSinStock.Rows[i][0]; //Catalogo
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][1] = dtDetSinStock.Rows[i][1]; //DesPro
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][2] = dtDetSinStock.Rows[i][2]; //traduccion
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][3] = dtDetSinStock.Rows[i][3]; //Can
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][4] = dtDetSinStock.Rows[i][4]; //Costo
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][6] = dtDetSinStock.Rows[i][5]; //Partida
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][7] = dtDetSinStock.Rows[i][6]; //Orden
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][8] = dtDetSinStock.Rows[i][7]; //FecEntPro
                }
            }

            LOG_Imp_SumTot("SinCodigo");
            LOG_Imp_CelStySinCod();
        }

        void LOG_Imp_ForCol()
        {
            ///Formato de columna,tipo dato y nombre para cada Flexgrid;
            
            //Articulo

            ///cantidad de columna y fila
            fgArt.Cols.Count = 12;
            fgArt.Rows.Count = 1;

            ///nombre comlumnas
            fgArt.Cols[0].Caption = "Item";
            fgArt.Cols[1].Caption = "Codigo";
            fgArt.Cols[2].Caption = "Id";
            fgArt.Cols[3].Caption = "Descripción";
            fgArt.Cols[4].Caption = "Catálogo";
            fgArt.Cols[5].Caption = "Cant.";
            fgArt.Cols[6].Caption = "Costo";
            fgArt.Cols[7].Caption = "SubTotal";
            fgArt.Cols[8].Caption = "Observaciones";
            fgArt.Cols[9].Caption = "Ocultar";
            fgArt.Cols[10].Caption = "Orden";
            fgArt.Cols[11].Caption = "Fec. Ent. Proveedor";

            ///tamaño columnas
            fgArt.Cols[0].Width = 30;
            fgArt.Cols[2].Width = 30;
            fgArt.Cols[3].Width = 300;
            fgArt.Cols[5].Width = 40;
            fgArt.Cols[6].Width = 50;
            fgArt.Cols[7].Width = 60;
            fgArt.Cols[8].Width = 300;
            fgArt.Cols[9].Width = 50;
            fgArt.Cols[10].Width = 40;
            fgArt.Cols[11].Width = 110;

            ///tipo de dato
            fgArt.Cols[5].DataType = typeof(int);
            fgArt.Cols[7].DataType = typeof(decimal);
            fgArt.Cols[9].DataType = typeof(bool);

            fgArt.Cols[11].DataType = typeof(string);

            ///formato de dato
            fgArt.Cols[5].Format = "0";
            fgArt.Cols[6].Format = "0.00";
            fgArt.Cols[7].Format = "0.00";

            fgArt.Cols[6].AllowEditing = false; //no permite dar check en la columna
            fgArt.Cols[9].AllowEditing = false; //no permite dar check en la columna
            ///columna donde se puede congelar
            fgArt.Cols.Frozen = 4;

            //Componente

            ///cantidad de columna y fila
            fgCom.Cols.Count = 8;
            fgCom.Rows.Count = 2;

            ///nombre columnas
            fgCom.Cols[0].Caption = "Codigo";
            fgCom.Cols[1].Caption = "Id";
            fgCom.Cols[2].Caption = "Catálogo";
            fgCom.Cols[3].Caption = "Descripción";
            fgCom.Cols[4].Caption = "Traducción";
            fgCom.Cols[5].Caption = "Cant.";
            fgCom.Cols[6].Caption = "Costo";
            fgCom.Cols[7].Caption = "Orden";

            ///tamaño columnas
            fgCom.Cols[0].Width = 80;
            fgCom.Cols[1].Width = 30;
            fgCom.Cols[2].Width = 100;
            fgCom.Cols[3].Width = 200;
            fgCom.Cols[4].Width = 200;
            fgCom.Cols[5].Width = 40;
            fgCom.Cols[6].Width = 50;
            fgCom.Cols[7].Width = 40;

            ///tipo de dato
            fgCom.Cols[1].DataType = typeof(string);
            fgCom.Cols[5].DataType = typeof(int);

            ///columna donde se puede congelar
            fgCom.Cols.Frozen = 2;

            //SinCodigo

            ///cantidad de columna y fila
            fgSinCod.Cols.Count = 9;
            fgSinCod.Rows.Count = 2;

            ///nombre columnas
            fgSinCod.Cols[0].Caption = "Catálogo";
            fgSinCod.Cols[1].Caption = "Descripción";
            fgSinCod.Cols[2].Caption = "Traducción";
            fgSinCod.Cols[3].Caption = "Cant";
            fgSinCod.Cols[4].Caption = "Costo";
            fgSinCod.Cols[5].Caption = "SubTotal";
            fgSinCod.Cols[6].Caption = "Partida";
            fgSinCod.Cols[7].Caption = "Orden";
            fgSinCod.Cols[8].Caption = "Fec. Ent. Proveedor";

            ///tamaño columnas
            fgSinCod.Cols[0].Width = 100;
            fgSinCod.Cols[1].Width = 200;
            fgSinCod.Cols[2].Width = 200;
            fgSinCod.Cols[3].Width = 40;
            fgSinCod.Cols[4].Width = 60;
            fgSinCod.Cols[5].Width = 60;
            fgSinCod.Cols[6].Width = 110;
            fgSinCod.Cols[7].Width = 50;
            fgSinCod.Cols[8].Width = 120;


            ///tipo de dato
            fgSinCod.Cols[6].DataType = typeof(string);
            fgSinCod.Cols[5].DataType = typeof(decimal);


            ///formato
            fgSinCod.Cols[5].Format = ".00";

            ///edicion
            //fgSinCod.Cols[5].AllowEditing = false;
            fgSinCod.Rows[fgSinCod.Rows.Count - 1][4] = "Total";
            fgSinCod.Rows[fgSinCod.Rows.Count - 1][5] = 0.00;

            //style
            LOG_Imp_CelStySinCod();
        }
        private void LOG_Imp_CelStySinCod()
        {
            //pinta de color la celda para agregar una nueva fila
            CellRange rg = fgSinCod.GetCellRange(fgSinCod.Rows.Count -1,0);
            rg.StyleNew.BackColor = Color.Gold;
            rg.StyleNew.ForeColor = Color.DarkGray;
            fgSinCod.Rows[fgSinCod.Rows.Count - 1][0] = "Agregar nueva fila";
        }
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Botones(btnNuevo);
        }
        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }

        private void LOG_Imp_EstBot(string BotonEstado)
        {
            ///Habilita o deshabilita los botones segun el estado al presionar.

            bool[] EstadoM = { true };

            switch (BotonEstado)
            {
                case "cargar":
                case "deshacer":
                    EstadoM = matriz(true, true, false, true, true, false, false, false, false, true);
                    break;

                case "nuevo":
                case "modificar":
                    EstadoM = matriz(false, false, true, true, false, false, false, false, false, false);
                    break;

                case "abrir":
                    switch (EstDoc)
                    {
                        case 1: //Generado
                            EstadoM = matriz(true, true, false, true, true, true, true, true, true,true);
                            break;
                        case 4: //anulado
                        case 8: //procesado
                            EstadoM = matriz(true, true, false, true, false, false, false, true, true, true);
                            break;
                    }
                    break;
            }

            this.btnNuevo.Enabled = EstadoM[0];
            this.btnAbrir.Enabled = EstadoM[1];
            this.btnGuardar.Enabled = EstadoM[2];
            this.btnDeshacer.Enabled = EstadoM[3];
            this.btnModificar.Enabled = EstadoM[4];
            this.btnAnu.Enabled = EstadoM[5];
            this.btnPro.Enabled = EstadoM[6];
            this.btnOc.Enabled = EstadoM[7];
            this.btnTra.Enabled = EstadoM[8];
            this.btnSitImp.Enabled = EstadoM[9];
        }
        private void MsgErr()
        {
            MessageBox.Show("No cuenta con acceso para realizar esta operación", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information); return;
        }
        private void Botones(ToolStripButton boton)
        {
            ///Metodo de tipo ToolStripButton para cada boton

            switch (boton.Text)
            {
                case "&Nuevo":

                    /******************************************
                    * Nombre: "Boton nuevo"
                    * Proposito: <Valida el acceso del usuario>
                    * Ouptut : <"Crear un nueva importacion si tiene acceso de lo contrario saldra un mensaje de error">
                    * Creado por: Ruben C.
                    *****************************************/

                    if (logImp.GEN_For_ConAcc(Convert.ToInt16(varglo.CodUsuAct), 6, "Nue", 0) == 1)
                    {
                        HabFg = true;
                        Log_Imp_LimCon();
                        LOG_Imp_HabCon(true);
                        LOG_Imp_EstBot("nuevo");
                        txtDesPro.Focus();
                    }
                    else
                    {
                        MsgErr();
                    }
                    break;

                case "&Abrir":

                   /******************************************
                   * Nombre: "Boton abrir"
                   * Proposito: <Valida que exista el formulario presionado y muestre en caso no exista>
                   * Ouptut : <"Mostrar lista de importaciones al dar doble click y cerrar el formulario">
                   * Creado por: Ruben C.
                   *****************************************/

                    bool Existe;
                    Existe = false;

                    Form frm = this.MdiParent.MdiChildren.FirstOrDefault(x => x is frmGEN_AbrDoc && Convert.ToInt16(x.Tag) == 15);

                    if (frm != null)
                    {
                        frm.BringToFront();
                        frm.Show();
                        Existe = true;
                    }
                    if (Existe == false)
                    {
                        frmGEN_AbrDoc fAbrImp = new frmGEN_AbrDoc();
                        fAbrImp.Text = "Importación";
                        fAbrImp.Tag = 15;
                        fAbrImp.MdiParent = this.MdiParent;
                        fAbrImp.BringToFront();
                        fAbrImp.Show();
                    }
                    this.Dispose();
                    break;

                case "&Guardar":

                    /******************************************
                    * Nombre: "Boton guardar"
                    * Proposito: <Validar que haya los datos en los TextBox y guardar Encabezado y Detalle de la importacion>
                    * Ouptut : <"Generar el mumero de importacion despues de haber guardado">
                    * Creado por: Ruben C.
                    *****************************************/

                    EstDoc = 1; //ponemos el estado

                    if (txtCodPro.Text == "")
                    {
                        MessageBox.Show("Seleccione un proveedor", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDesPro.Focus();
                    }
                    else if (txtCodEnv.Text == "")
                    {
                        MessageBox.Show("Seleccione una forma de envio", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDesEnv.Focus();
                    }
                    else if (txtCodEstPag.Text == "")
                    {
                        MessageBox.Show("Seleccione un estado de pago", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDesEstPag.Focus();
                    }
                    else if (txtCodMon.Text == "")
                    {
                        MessageBox.Show("Seleccione una moneda", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDesMon.Focus();
                    }
                    else if (fgArt.Rows.Count == 2)
                    {
                        MessageBox.Show("No hay ningún producto agregado", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtDesArt.Focus();
                    }
                    else
                    {
                        ///Encabezado -asigna los datos a la entidad LOG_Imp_Enc
                        LOG_Imp_Enc Enc = new LOG_Imp_Enc();
                        Enc.NumMov = NumMov;
                        Enc.NumImp = txtNumImp.Text;
                        Enc.FecEmi = Convert.ToDateTime(txtFecEmi.Text);

                        Enc.CodPro = txtCodPro.Text;
                        Enc.Nompro = txtDesPro.Text;
                        Enc.CodForEnv = Convert.ToInt16(txtCodEnv.Text);
                        Enc.CodEstPag = Convert.ToInt16(txtCodEstPag.Text);
                        Enc.CodMon = Convert.ToInt16(txtCodMon.Text);
                        Enc.FecLleSqo = mkbFecLLe.Text;
                        Enc.Etd = mkbEtd.Text;
                        Enc.Eta = mkbEta.Text;

                        Enc.FecDisDes = mkbFecDisDes.Text;
                        Enc.NomBar = txtNomBar.Text;
                        Enc.AwbTra = txtTra.Text;
                        Enc.CodImp = txtCodImp.Text;
                        Enc.OtrNumImp = txtOtrNumImp.Text;
                        Enc.Fepe = mkbOtrFecEntPro.Text;
                        Enc.EnvInt = Convert.ToInt16(chkEnvInt.Checked == true ? 1 : 0);
                        Enc.CodLey = Convert.ToByte(cboLey.SelectedIndex == -1 ? 0 : (Convert.ToByte(cboLey.SelectedIndex)));

                        ///otr- shiping y details
                        Enc.CouImp = txtCouImp.Text;
                        Enc.UltDest = txtUltDes.Text;
                        Enc.InVoiTo = txtInvTo.Text;
                        Enc.Shipo = txtCon.Text;
                        Enc.Pho = txtPho.Text;
                        Enc.Fax = txtFax.Text;
                        Enc.Fwd = txtFwd.Text;
                        Enc.Adrs = txtAdd.Text;
                        Enc.FwdPho = txtPhoDet.Text;
                        Enc.FwdFax = txtFaxDet.Text;
                        Enc.Ema = txtEma.Text;
                        Enc.ConPer = txtConPer.Text;
                        Enc.PayTer = txtDesPayTer.Text;
                        Enc.Lbs = txtDesLab.Text;

                        if (rdbExWor.Checked) Enc.IncTer = 0;
                        if (rdbFob.Checked) Enc.IncTer = 1;
                        Enc.CodUsu = Convert.ToInt16(varglo.CodUsuAct);

                        ///ejecutamos la consulta
                        Enc.Log_Imp_Enc.Add(Enc);

                        ///detalle articulo - recorre y asigna los datos por cada registro.
                        foreach (Row row in fgArt.Rows)
                        {
                            LOG_Imp_Det Det = new LOG_Imp_Det();

                            if (row.Index > 0  && row.Index < fgArt.Rows.Count -1) ///valida haya mas de 2 filas
                            {
                                Det.CodArt = row[1].ToString();
                                Det.NumId = Convert.ToInt16(row[2].ToString());
                                Det.Can = Convert.ToInt32(row[5].ToString());
                                Det.Cos = Convert.ToDecimal(row[6]);
                                Det.Obs = row[8].ToString();
                                Det.Ocu = Convert.ToBoolean(row[9].ToString());
                                Det.Ord = Convert.ToInt16(row[10]);
                                Det.FecEnPro = row[11].ToString();

                                Enc.Log_Imp_Det.Add(Det);
                            }
                        }

                        ///detalle Sin codigo - recorre y asigna los datos por cada registro.
                        foreach (Row row in fgSinCod.Rows)
                        {
                            LOG_Imp_DetSinSto DetStock = new LOG_Imp_DetSinSto();

                            if (row.Index > 0 && row.Index < fgSinCod.Rows.Count - 1)
                            {
                                DetStock.Ite = Convert.ToInt16(fgSinCod.Rows.Count - 1);
                                DetStock.Cat = row[0].ToString();
                                DetStock.DesPro = row[1].ToString();
                                DetStock.Tra = row[2].ToString();
                                DetStock.Can = Convert.ToDecimal(row[3]);
                                DetStock.Cos = Convert.ToDecimal(row[4]);
                                DetStock.Par = row[6].ToString();
                                DetStock.Ord = Convert.ToByte(row[7]);
                                DetStock.FecEntPro = Convert.ToDateTime(row[8]).ToShortDateString();

                                Enc.Log_Imp_DetSinStock.Add(DetStock);
                            }
                        }

                        logImp.LOG_Imp_Gua_EncDet(Enc); ///ejecutamos al consulta
                        txtNumImp.Text = Enc.NumImp;
                        NumMov = Enc.NumMov;
                        LOG_Imp_EstBot("abrir");
                        LOG_Imp_HabCon(false);
                       
                    }
                    break;

                case "&Deshacer":

                    ///Limpia ,deshabilita los textbox y cambia el estado de los botones

                    Log_Imp_LimCon();
                    LOG_Imp_HabCon(false);
                    EstDoc = 4;
                    LOG_Imp_EstBot("deshacer");

                    fgArt.Rows.Count = 1;

                    LOG_Imp_SumTot("Articulo");
                    NumMov = 0;
                    break;

                case "&Modificar":

                    /******************************************
                    * Nombre: "Boton modificar"
                    * Proposito: <Valida el acceso del usuario>
                    * Ouptut : <"Actuliza los datos ingresados en la importacion o de lo contrario saldra un mensaje de error ">
                    * Creado por: Ruben C.
                    *****************************************/

                    if (logImp.GEN_For_ConAcc(Convert.ToInt16(varglo.CodUsuAct), 6, "Mod", 0) == 1)
                    {
                        HabFg = true;

                        if (fgArt.Rows. Count > 1) fgArt.Cols[9].AllowEditing = true; //no permite dar check en la columna

                        LOG_Imp_HabCon(true);
                        LOG_Imp_EstBot("modificar");
                        txtDesPro.Focus();

                        if (NumMov == 0) txtFecEmi.Text = DateTime.Now.ToShortDateString();
                    }
                    else
                    {
                        MsgErr();
                    }
                    break;

                case "&Anular":

                   /******************************************
                   * Nombre: "Boton anular"
                   * Proposito: <Valida el acceso del usuario>
                   * Ouptut : <"Actualiza el estado del registro a anulado o de lo contrario saldra un mensaje de error ">
                   * Creado por: Ruben C.
                   *****************************************/

                    if (logImp.GEN_For_ConAcc(Convert.ToInt16(varglo.CodUsuAct), 6, "Anu", 0) == 1)
                    {
                        if (NumMov == 0)
                        {
                            MessageBox.Show("No se encontraron datos para anular", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea anular la importación?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (mensaje == DialogResult.Yes)
                        {

                            logImp.Log_Imp_AnuImp((Int16)varglo.CodUsuAct, NumMov);
                            EstDoc = 4;
                            LOG_Imp_EstBot("abrir");
                            MessageBox.Show("Se anulo correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MsgErr();
                    }
                    break;

                case "&Procesar":

                   /******************************************
                   * Nombre: "Boton procesar"
                   * Proposito: <Valida el acceso del usuario>
                   * Ouptut : <"Actualiza el estado del registro a procesado o de lo contrario saldra un mensaje de error ">
                   * Creado por: Ruben C.
                   *****************************************/

                    if (logImp.GEN_For_ConAcc(Convert.ToInt16(varglo.CodUsuAct), 6, "Pro", 0) == 1)
                    {
                        if (NumMov == 0)
                        {
                            MessageBox.Show("No se encontraron datos para procesar", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea procesar la importación?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (mensaje == DialogResult.Yes)
                        {

                            logImp.Log_Imp_ProImp((Int16)varglo.CodUsuAct, NumMov);
                            EstDoc = 8;
                            LOG_Imp_EstBot("abrir");
                            MessageBox.Show("Se proceso correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MsgErr();
                    }
                    break;

                default:
                    break;
            }
        }

        private void btnDeshacer_Click(object sender, EventArgs e)
        {
            Botones(btnDeshacer);
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            Botones(btnAbrir);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Botones(btnModificar);
        }

        private void btnAnu_Click(object sender, EventArgs e)
        {
            Botones(btnAnu);
        }

        private void btnPro_Click(object sender, EventArgs e)
        {
            Botones(btnPro);
        }

        private void ConsultaDatos(string vista, string procedimiento, Int16 param2, string param)
        {
           /******************************************
            * Nombre: "consulta datos"
            * Proposito: <Hacer un filtro por cada textbox al presionar enter con su respectivo procedimiento>
            * Ouptut : <"Mostrar la ventana con los datos">
            * Creado por: Ruben C.
            *****************************************/
           Cursor.Current = Cursors.WaitCursor;

           DataTable dtImp = new DataTable();
           dtImp = logImp.LOG_Imp_Filtros(vista, procedimiento, param2, param);

           if (dtImp.Rows.Count > 1)
           {

               frmConsulta_Varios frm = new frmConsulta_Varios();
               frm.Formulario = 34;
               frm.Text = vista;
               frm.Vista = vista;
               frm.dg.DataSource = dtImp;
               frm.LOG_Imp_Rec = this;
               frm.ShowDialog();
           }
           else if (dtImp.Rows.Count == 1)
           {
               DataRow row = dtImp.Rows[0];

               switch (vista)
               {
                   case "Proveedor":
                       txtCodPro.Text = row["Codigo"].ToString();
                       txtDesPro.Text = row["Proveedor"].ToString();
                       break;

                   case "Envio":
                       txtCodEnv.Text = row["Codigo"].ToString();
                       txtDesEnv.Text = row["Forma Envio"].ToString();
                       txtVia.Text = row["Alias"].ToString();
                       break;

                   case "Estado Pago":
                       txtCodEstPag.Text = row["Codigo"].ToString();
                       txtDesEstPag.Text = row["[Estado Pago]"].ToString();
                       break;

                   case "Moneda":
                       txtCodMon.Text = row["Codigo"].ToString();
                       txtDesMon.Text = row["Moneda"].ToString();
                       break;

                   case "Articulo":
                       txtCodArt.Text = row["Codigo"].ToString();
                       txtDesArt.Text = row["Descripcion"].ToString();
                       txtCat.Text = row["Catalogo"].ToString();
                       txtImp.Text = row["Nombre Extranjero"].ToString() + "|" + row["Catalogo"].ToString();
                       break;

                   default:
                       break;
               }
           }
           else if (dtImp.Rows.Count == 0)
           {
               varglo.Elegi = false;
               MessageBox.Show("No se encontraron registros", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
           }

           Cursor.Current = Cursors.Default;
       }

       public void recdat_Pro(string CodPro, string DesPro)
       {
           txtCodPro.Text = CodPro;
           txtDesPro.Text = DesPro;
       }

       public void recdat_Env(string CodEnv, string DesEnv, string Ali)
       {
           txtCodEnv.Text = CodEnv;
           txtDesEnv.Text = DesEnv;
           txtVia.Text = Ali;
       }

       public void recdat_EstPag(string CodEstPag, string DesEstPag)
       {
           txtCodEstPag.Text = CodEstPag;
           txtDesEstPag.Text = DesEstPag;
       }

       public void recdat_Mon(string CodMon, string DesMon)
       {
           txtCodMon.Text = CodMon;
           txtDesMon.Text = DesMon;
       }

       public void recdat_Art(string CodArt, string DesArt, string Cat, string Can, string NomExt)
       {
           txtCodArt.Text = CodArt;
           txtDesArt.Text = DesArt;
           txtCat.Text = Cat;
           txtImp.Text = NomExt + "|" + Cat;
       }

       private void txtDesPro_KeyPress(object sender, KeyPressEventArgs e)
       {
           if (e.KeyChar == (char)13)
           {
               ConsultaDatos("Proveedor", "Filtro_Proveedor", 0, txtDesPro.Text);
               mkbEtd.Focus();
           }
       }

       private void txtDesEnv_KeyPress(object sender, KeyPressEventArgs e)
       {
           if (e.KeyChar == (char)13)
           {
               ConsultaDatos("Envio", "Filtro_FormaEnvio", 0, txtDesEnv.Text);
               txtDesEstPag.Focus();
           }
       }

       private void txtDesEstPag_KeyPress(object sender, KeyPressEventArgs e)
       {
           if (e.KeyChar == (char)13)
           {
               ConsultaDatos("Estado Pago", "Filtro_EstadoPago", 0, txtDesEstPag.Text);
               txtDesMon.Focus();
           }
       }

       private void txtDesMon_KeyPress(object sender, KeyPressEventArgs e)
       {
           if (e.KeyChar == (char)13)
           {
               ConsultaDatos("Moneda", "Filtro_Monedas", 0, txtDesMon.Text);
               txtDesArt.Focus();
           }
       }

       private void txtDesArt_KeyPress(object sender, KeyPressEventArgs e)
       {
           if (e.KeyChar == (char)13)
           {
               ConsultaDatos("Articulo", "Filtro_3Articulo", 2, txtDesArt.Text);
               txtImp.Focus();
           }
       }

       private void txtCat_KeyPress(object sender, KeyPressEventArgs e)
       {
           if (e.KeyChar == (char)13)
           {
               ConsultaDatos("Articulo", "Filtro_3Articulo", 3, txtCat.Text);
               txtImp.Focus();
           }
       }

       private void btnCanIte_Click(object sender, EventArgs e)
       {
            LOG_Imp_LimArt();
            btnAgrIte.Text = "Agregar item";
            btnBorIte.Enabled = true;
            btnModIte.Enabled = true;
            fgArt.Enabled = true;
        }

       private void btmBorIte_Click(object sender, EventArgs e)
       {
            ///Valida que este seleccionado la fila a borrar y pregunta para confirmar el borrado de la fila.
           if (fgArt.RowSel == fgArt.Rows.Count-1)
           {
                MessageBox.Show("Fila inválida no se puede borrar","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
           }
            
           if (fgArt.IsCellSelected(fgArt.Row, fgArt.Col))
           {
               DialogResult mensaje = MessageBox.Show("¿Esta seguro de eliminar este Item?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

               if (mensaje == DialogResult.Yes)
               {
                   fgArt.Rows.Remove(fgArt.Row);
               }
               else
               {
                   return;
               }
           }
       }

       private void btnAgrIte_Click(object sender, EventArgs e)
       {
            /******************************************
            * Nombre: "Boton agregar item"
            * Proposito: <Agregar los articulos validando las datos ingresados y no repetido>
            * Ouptut : <"mostrar los datos en el FlexGrid Articulo">
            * Creado por: Ruben C.
            *****************************************/

            ///validamos si existe el articulo en el grid
           bool valida = false;
           
           if (fgArt.Rows.Count > 2)
           {
                if (EstMod == false) /// solo valida si no se apreto el boton modificar
                {
                    for (int i = 1; i < fgArt.Rows.Count - 1; i++)
                    {
                        if (fgArt.Rows[i][1].ToString() == txtCodArt.Text)
                        {
                            MessageBox.Show("Ya existe el articulo", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtDesArt.Focus();
                            return;
                        }
                    }
                }
           }

           if (txtCodArt.Text == "")
           {
               MessageBox.Show("Ingerese articulo", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
               txtDesArt.Focus();
           }
           else if (txtCanArt.Text == "")
           {
               MessageBox.Show("Ingerese una cantidad", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
               txtCanArt.Focus();

            }
            else
            {
                //valida si hay 2 filas y borrar la fila de los totales
                if (fgArt.Rows.Count > 1)
                {
                    fgArt.Rows.Remove(fgArt.Rows[fgArt.Rows.Count - 1]);
                }

                decimal costo;
                decimal.TryParse(txtCosArt.Text, out costo);

                if (!valida && !EstMod)
                {
                    fgArt.Rows.Add();
                    Item = fgArt.Rows.Count - 1;
                }
                
                ///se actulziar los datos si el boton modificar se apreto
                fgArt.Rows[Item][0] = fgArt.Rows.Count - 1;
                fgArt.Rows[Item][1] = txtCodArt.Text;
                fgArt.Rows[Item][2] = string.Format("{0:00}", fgArt.Rows.Count - 1);
                fgArt.Rows[Item][3] = txtDesArt.Text;
                fgArt.Rows[Item][4] = txtCat.Text;
                fgArt.Rows[Item][5] = txtCanArt.Text;
                fgArt.Rows[Item][6] = costo;
                fgArt.Rows[Item][7] = Convert.ToDecimal(txtCanArt.Text) * costo;
                fgArt.Rows[Item][8] = txtObs.Text;
                fgArt.Rows[Item][9] = false;
                fgArt.Rows[Item][10] = 0;
                fgArt.Rows[Item][11] = mkbFecEntPro.Text;
                
                LOG_Imp_SumTot("Articulo");
                LOG_Imp_LimArt();
                btnAgrIte.Text = "Agregar item";

                btnBorIte.Enabled = true;
                btnModIte.Enabled = true;
                EstMod = false;
                fgArt.Enabled = true;
                fgArt.Cols[9].AllowEditing = true;
            }
       }

        private void LOG_Imp_SumTot(string Grid)
       {
            /******************************************
            * Nombre: "Suma total"
            * Proposito: <Recorrer una columna  e ir sumando  el valor de cada fila agregada segun el FlexGrid>
            * Ouptut : <"calcular el total de la columna">
            * Creado por: Ruben C.
            *****************************************/
            double SumArt = 0; double SumSinCod = 0; double SimCodSum = 0;

            switch (Grid)
            {
                //agrega una fila y calculo el total
                case "Articulo":
                    for (int i = 1; i < fgArt.Rows.Count; i++)
                    {
                        SumArt += Convert.ToDouble(fgArt.Rows[i][7]);
                    }

                    fgArt.Rows.Add();
                    fgArt.Rows[fgArt.Rows.Count - 1][6] = "Total";
                    fgArt.Rows[fgArt.Rows.Count - 1][7] = SumArt;

                    break;

                //agrega una fila y calculo el total
                case "SinCodigo":

                    //string n = fgSinCod[fgSinCod.Row, 3].ToString();
                    //string n2 = fgSinCod[fgSinCod.Row, 4].ToString();
                    bool error = false;

                    try
                    {
                        fgSinCod.Rows[fgSinCod.Rows.Count - 1][5] = Convert.ToDecimal(fgSinCod[fgSinCod.Row, 3]) * (Convert.ToDecimal(fgSinCod[fgSinCod.Row, 4]));
                    }
                    catch { error = true; }

                    if (error || !error)
                    {
                        for (int i = 1; i < fgSinCod.Rows.Count -1; i++)
                        {
                            SumSinCod += Convert.ToDouble(fgSinCod.Rows[i][5]);
                        }

                        fgSinCod.Rows.Add();
                        fgSinCod.Rows[fgSinCod.Rows.Count - 1][4] = "Total";
                        fgSinCod.Rows[fgSinCod.Rows.Count - 1][5] = SumSinCod;
                    }

                    

                    break;

                //calcula el total
                case "SinCodidoSumar":

                    //valida que sea null y que haya > 2 filas para poder multiplicar los datos,porque cuando se elimina con el suprimir  la fila toma los valores nulos y no se pueden multiplicar
                    //lanzando un error y
                    if (fgSinCod[fgSinCod.RowSel, 3] == null || fgSinCod[fgSinCod.RowSel, 4] == null)
                    {
                        if (fgSinCod.Rows.Count > 2)
                        {
                            fgSinCod.Rows[fgSinCod.Row][5] = Convert.ToDecimal(fgSinCod[fgSinCod.RowSel - 1, 3]) * (Convert.ToDecimal(fgSinCod[fgSinCod.RowSel - 1, 4]));
                            return;
                        }
                    }
                    
                    //valida que halla mas de 2 filas para poder calcular el total de la fila que se esta editando
                    if (fgSinCod.Rows.Count > 2)
                    {
                        fgSinCod.Rows[fgSinCod.RowSel][5] = Convert.ToDecimal(fgSinCod[fgSinCod.RowSel, 3]) * (Convert.ToDecimal(fgSinCod[fgSinCod.RowSel, 4]));
                    }


                    for (int i = 1; i < fgSinCod.Rows.Count -1; i++)
                    {
                        SimCodSum += Convert.ToDouble(fgSinCod.Rows[i][5]);
                    }
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][4] = "Total";
                    fgSinCod.Rows[fgSinCod.Rows.Count - 1][5] = SimCodSum;
                    break;
            }
        }
    
        private void txtImp_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, txtCanArt);
        }
        private void LOG_Imp_LimArt()
        {
            //metodo para limpiar las cajas de texto
            foreach (Control c in gpbArt.Controls)
            {
                if (c is TextBox) c.Text = "";
                if (c is MaskedTextBox) c.Text = "";
            }
        }

        private void txtCanArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite ingresar solo numero
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsSeparator(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            LOG_Imp_EveKeyFoc(e, txtCosArt);
        }

        private void txtCosArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite solo decimal
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsSeparator(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (e.KeyChar == '.' && !txtCosArt.Text.Contains(".")) //verifica si hay un punto decimal
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            LOG_Imp_EveKeyFoc(e, txtObs);
        }

        private void txtObs_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, mkbFecEntPro);
        }

        private void mkbFecEntPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, btnAgrIte);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Botones(btnGuardar);
        }

        private void mkbEtd_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, mkbFecLLe);
        }

        private void mkbFecLLe_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, mkbEta);
        }

        private void mkbEta_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e,txtDesEnv);
        }

        private void LOG_Imp_EveKeyFoc(KeyPressEventArgs e,Control c)
        {
            //Evento para el foco 
            if (e.KeyChar == (char)13)
            {
                c.Focus();
            }
        }

        private void mkbFecDisDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, txtNomBar);
        }

        private void txtNomBar_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, txtTra);
        }

        private void txtTra_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, txtCodImp);
        }

        private void txtCodImp_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, txtNumImp);
        }

        private void txtOtrNumImp_KeyPress(object sender, KeyPressEventArgs e)
        {
            LOG_Imp_EveKeyFoc(e, mkbFecEntPro);
        }

        private void fgArt_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //valida que halla mas de 2 filas y el boton guardar este habilitado 
            if (fgArt.Rows.Count > 2 && btnGuardar.Enabled)
            {
                fgArt.Cols[9].AllowEditing = true;

                //permite solo numeros en la columna orden
                if (e.Col == 10)
                {
                    if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || char.IsSeparator(e.KeyChar))
                    {
                        e.Handled = false;
                    }
                    else
                    {
                        e.Handled = true;
                    }
                }
                else
                {
                    //no permite ingresar en las demas columnas ningun datos
                    e.Handled = true;
                }               
            }
            else
            {
                //no permite ingresar datos
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void fgArt_AfterEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 10)
            {
                if (fgArt[e.Row, 10].ToString() == "" && fgArt.Rows.Count > 2)
                {
                    fgArt[e.Row, 10] = 0;
                }
            }
        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            if (fgArt.IsCellSelected(fgArt.Row,fgArt.Col))
            {
                if (fgArt.RowSel == fgArt.Rows.Count - 1)
                {
                    MessageBox.Show("Fila inválida","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    DialogResult mensaje = MessageBox.Show("¿Desea modificar el item?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (mensaje == DialogResult.Yes)
                    {
                        txtCodArt.Text = fgArt.Rows[fgArt.RowSel][1].ToString();
                        txtDesArt.Text = fgArt.Rows[fgArt.RowSel][3].ToString();
                        txtCat.Text = fgArt.Rows[fgArt.RowSel][4].ToString();
                        txtCanArt.Text = fgArt.Rows[fgArt.RowSel][5].ToString();
                        txtCosArt.Text = Math.Round(Convert.ToDecimal(fgArt.Rows[fgArt.RowSel][6]),2).ToString();
                        txtObs.Text = fgArt.Rows[fgArt.RowSel][8].ToString();

                        Item = fgArt.Row;
                        btnAgrIte.Text = "Actualizar item";

                        EstMod = true;
                        btnBorIte.Enabled = false;
                        btnModIte.Enabled = false;
                        fgArt.Enabled = false;
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }

        private void btnOc_Click(object sender, EventArgs e)
        {
            //valida si selecciona un NumMov
            rptLOG_Imp_OC rpt = new rptLOG_Imp_OC();
            TextObject rptSec = (TextObject)rpt.ReportDefinition.ReportObjects["txtMoneda"];

            string IncTer = "";
            if (rdbExWor.Checked) IncTer = rdbExWor.Text;
            if (rdbFob.Checked) IncTer = rdbFob.Text;

            rptSec.Text = IncTer + txtDesMon.Text;

            rpt.SetParameterValue("@nummov", NumMov);
            MetGlo.CRVisPre(rpt);
            
        }

        private void fgSinCod_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //permite solo editar cuando se modifica
            if (fgSinCod.Rows.Count > 1 && !btnModificar.Enabled) 
            {
                //permite solo numeros
                if (e.Col == 3 || e.Col == 7)
                {
                    if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || char.IsSeparator(e.KeyChar))
                    {
                        e.Handled = false;
                    }
                    else
                    {
                        e.Handled = true;
                    }
                }
            }
            else
            {
                //no permite ingresar datos
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void fgSinCod_AfterEdit(object sender, RowColEventArgs e)
        {
            //verificar que este vacio y sea la ultima fila para poder dar el nombre po defecto
            if (fgSinCod[e.Row, e.Col].ToString() == "" && fgSinCod.Row == fgSinCod.Rows.Count - 1)
            {
                fgSinCod[e.Row, e.Col] = "Agregar nueva fila";
            }

            //valida y retorna cuando esta el texto por defecto
            if (fgSinCod[e.Row, e.Col].ToString() == "Agregar nueva fila")
            {
                return;
            }

            //valida que solo se de por defecto el texto cuando sea la ultima fila y se halla ingresado vacio o no haya escrito nada
            if (fgSinCod[e.Row, e.Col].ToString().Trim() == "" && fgSinCod.RowSel == fgSinCod.Rows.Count -1)
            {
                fgSinCod[e.Row, e.Col] = "Agregar nueva fila";
                return;
            }


            //valida que se halla ingresado un dato para agregar los valores por defecto
            //valores por defecto cuando agrega en la primera celda
            if (fgSinCod[e.Row, e.Col].ToString() != ""  )
            {
                if (fgSinCod.Rows[e.Row][3] == null || fgSinCod.Rows[e.Row][4] == null || fgSinCod.Rows[e.Row][5] == null || fgSinCod.Rows[e.Row][8] == null)
                {
                    fgSinCod[e.Row, 1] = "Vacio";
                    fgSinCod[e.Row, 2] = "Vacio";
                    fgSinCod[e.Row, 3] = 0;
                    fgSinCod[e.Row, 4] = 0;
                    fgSinCod[e.Row, 6] = "Vacio";
                    fgSinCod[e.Row, 7] = 0;
                    fgSinCod[e.Row, 8] = DateTime.Now.Date.ToShortDateString();
                }
            }

            //valida que halla un valor y que sea en la ultima fila para poder agregar una nueva fila
            //pone en blanco la fila actual cada vez que se agrega
            if (fgSinCod[e.Row, e.Col].ToString() != "" && fgSinCod.Row == fgSinCod.Rows.Count - 1)
            {
                
                //pinta la celda anterior en blanco
                CellStyle Sty = fgSinCod.Styles.Add("Catálogo");
                Sty.BackColor = Color.White;
                fgSinCod.SetCellStyle(e.Row, e.Col, Sty);

                LOG_Imp_SumTot("SinCodigo");
                LOG_Imp_CelStySinCod();
            }

            //valida  que halla dato y calculo los totales
            if(fgSinCod[fgSinCod.Row, fgSinCod.Col].ToString() != "")
            {
                LOG_Imp_SumTot("SinCodidoSumar");
            }
        }
        private void fgSinCod_KeyDown(object sender, KeyEventArgs e)
        {
            if (HabFg)
            {
                if (e.KeyCode == Keys.Delete)
                {
                    //valida que solo se pueda borrar las filas menos la ultima
                    if (fgSinCod.RowSel != fgSinCod.Rows.Count - 1)
                    {

                        DialogResult mensaje = MessageBox.Show("¿Esta seguro de borrar el este item?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (mensaje == DialogResult.Yes)
                        {
                            fgSinCod.Rows.Remove(fgSinCod.Row);
                            LOG_Imp_SumTot("SinCodidoSumar");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Fila inválida no se puede borrar", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

            HabFg = false;
        }

        private void fgSinCod_StartEdit(object sender, RowColEventArgs e)
        {
            //valida que halla 2 filas y deshabilit1a la ultima fila menos la primera celda de la primera columna
            if (e.Row == fgSinCod.Rows.Count -1 && e.Col != 0 )
            {
                e.Cancel = true;
            }
            if (e.Row == fgSinCod.Rows.Count -1 && e.Col == 0)
            {
                fgSinCod[e.Row, e.Col] = "";
            }
        }

        private void btnTra_Click(object sender, EventArgs e)
        {
            //valida si selecciona un NumMov
            rptLOG_Imp_Tra rpt = new rptLOG_Imp_Tra();
            rpt.SetParameterValue("@nummov", NumMov);
            MetGlo.CRVisPre(rpt);
        }

        private void btnSitImp_Click(object sender, EventArgs e)
        {
            rptLOG_Imp_rep_SitImp rpt = new rptLOG_Imp_rep_SitImp();
            MetGlo.CRVisPre(rpt);
        }
    }
}
