﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using CrystalDecisions.CrystalReports.Engine;
using Interfaces;
using SAP_Adicional.Reportes;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Entidades.Ruta_Online;

namespace SAP_Adicional
{
    public partial class frmRuta_Online : Form,Ruta_Online
    {
        private NRuta_Online nRo = new NRuta_Online();
        private VarGlo varglo = VarGlo.Instance();
        private string _cliente = "";
        private byte _estDat;
        private string _mensaje = "";

        public frmRuta_Online()
        {
            InitializeComponent();
            MetGlo.SeleccionTexto(this);
            MetGlo.BackColorText(this);
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor; //cursor cargando
            MetGlo.ExportarExcel(this.fgRutOnl, this.Text);

            Cursor.Current = Cursors.Default; //cursor por defecto
        }
        private void btnAct_Click(object sender, EventArgs e)
        {
            _estDat = 0; //estado del grid con lo datos
            Cursor.Current = Cursors.WaitCursor;
            this.Ruta_Online_Rec_Cortes();
            this.Ruta_Online_RecPro();
            Cursor.Current = Cursors.Default;
        }
        
        private void Ruta_Online_Rec_Cortes()
        {
            DataTable dtRecRut = new DataTable();
            dtRecRut = nRo.Ruta_Online_RecCor(Convert.ToDateTime(this.dtpFecRutOnl.Value.Date));

            this.lblInfo.Text = "";
            if (dtRecRut.Rows.Count > 0) //valida si hay datos
            {
                this.lblInfo.Text = " Tiene establecido el corte de una ruta";
            }
            else
            {
                this.lblInfo.Text = "No se han establecido cortes de ruta";
            }
        }
        private void Ruta_Online_RecPro()
        {
            //Recupera los datos en el grid

            DataTable dtRecPro = new DataTable();
            dtRecPro = nRo.Ruta_Online_RecPro(this.dtpFecRutOnl.Value.Date, this.chkTod.Checked);

            if (dtRecPro.Rows.Count > 0) 
            {
                this.fgRutOnl.DataSource = dtRecPro;
            }
            else
            {
                //limpiamos el grid
                DataTable dtClear = new DataTable();
                dtClear.Clear();
                this.fgRutOnl.DataSource = dtClear;

                _mensaje = "No se encontraron datos";
                this.Ruta_Online_MosMsgStrip(_mensaje,Color.Red);
                this.dtpFecRutOnl.Focus();
                return;
            }
        }

        private void btnAceAte_Click(object sender, EventArgs e)
        {
            Int16 Valor = nRo.Ruta_Online_RecVerMov(this.dtpFecRutOnl.Value.Date);  //ejecuta el procedimiento

            switch (Valor) //verificamos el valor
            {
                case 3:
                    _mensaje = "No se completo la operación.Falta asignar Transportista a algunas rutas";
                    this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                    return;
            }

            DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea pasar la movilidad de esta ruta?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (mensaje == DialogResult.Yes) //validamos la respuesta
            {
                Ruta_Online_ItemEnc item = new Ruta_Online_ItemEnc()
                {
                    FecRuta = this.dtpFecRutOnl.Value.Date,
                    CodUsu = Convert.ToInt16(varglo.CodUsuAct),
                };

                //ejecutamos el procedimiento
                nRo.Ruta_Online_InsAteMon(item); 
                _mensaje = "Se paso la movilidad correctamente";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.Green);
                return;
            }
            else
            {
                return;
            }
        }

        private void btnAnu_Click(object sender, EventArgs e)
        {
            //valida que haya seleccionado una fila
            if (this.fgRutOnl.IsCellSelected(this.fgRutOnl.Row, this.fgRutOnl.Col)) 
            {
                if (_estDat == 0)
                {
                    //valida si esta tentida
                    if (Convert.ToInt32(this.fgRutOnl[this.fgRutOnl.Row, 17].ToString()) != 0)
                    {
                        _mensaje = "Esta ruta ya esta Atendida";
                        this.Ruta_Online_MosMsgStrip(_mensaje, Color.Red);
                        this.dtpFecRutOnl.Focus();
                        return;
                    }
                    else
                    {
                        DialogResult mensaje = MessageBox.Show("¿Está seguro de Anular este ítem de la ruta?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        //valida la respuesta
                        if (mensaje == DialogResult.Yes) 
                        {
                            Int16 numMov = Convert.ToInt16(this.fgRutOnl[fgRutOnl.Row, 0]);

                            Ruta_Online_ItemEnc item = new Ruta_Online_ItemEnc()
                            {
                                CodUsu = Convert.ToInt16(varglo.CodUsuAct),
                                NumMov = numMov,
                            };

                            nRo.Ruta_Online_ActRutPro(item);
                            this.fgRutOnl.Rows.Remove(this.fgRutOnl.Row);
                            return;
                        }
                    }
                }
                else
                {
                    if (Convert.ToInt32(this.fgRutOnl[this.fgRutOnl.Row, 15].ToString()) != 0)
                    {
                        _mensaje = "Esta ruta ya esta Atendida, no se puede cambiar la fecha";
                        this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.dtpFecRutOnl.Focus();
                        return;
                    }
                    else
                    {
                        DialogResult mensaje = MessageBox.Show("¿Está seguro de Anular este ítem de la ruta?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        //valida la respuesta
                        if (mensaje == DialogResult.Yes) 
                        {
                            Int16 numMov = Convert.ToInt16(this.fgRutOnl[this.fgRutOnl.Row, 0]);

                            Ruta_Online_ItemEnc item = new Ruta_Online_ItemEnc()
                            {
                                CodUsu = Convert.ToInt16(varglo.CodUsuAct),
                                NumMov = numMov,
                            };

                            nRo.Ruta_Online_ActRutPro(item);
                            this.fgRutOnl.Rows.Remove(fgRutOnl.Row);

                            _mensaje = "Se anulo correctamente el item";
                            this.Ruta_Online_MosMsgStrip(_mensaje, Color.Green);

                            return;
                        }
                    }
                }
            }
            else
            {
                _mensaje = "No se encontraron datos,seleccione otra fecha";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.Red);
                this.dtpFecRutOnl.Focus();
                return;
            }
        }

        private void btnImp_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            frmVisor f = new frmVisor();
            rptRuta repRut = new rptRuta();

            //Valida si hay datos en elte textBox
            if (this.txtCodCorRut.Text == "" & this.txtCodTra.Text == "" & this.txtCodTra.Visible & this.txtDesTra.Visible)
            {
                _mensaje = "Asigne una ruta y/o transportista";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                this.txtDesCorRut.Focus();
                return;
            }

            if (this.txtCodCorRut.Text == "" & this.txtCodTra.Text != "")
            {
                _mensaje = "Asigne una ruta";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                this.txtDesCorRut.Focus();
                return;
            }

            //reporte con solo fecha
            if (this.chkRutCor.Checked == false) 
            {
                string CodRutCor = "";
                if (this.txtCodCorRut.Text == "")
                {
                    CodRutCor = null;
                }
                else
                {
                    CodRutCor = this.txtCodCorRut.Text;
                }

                repRut.SetParameterValue("@CodRutCor", CodRutCor);
                repRut.SetParameterValue("@Transportista", null);
            }

            //reporte con fecha y ruta seleccionada
            if (this.chkRutCor.Checked & this.txtCodCorRut.Text != ""  & this.txtCodTra.Text == "")
            {
                repRut.SetParameterValue("@CodRutCor", Convert.ToInt16(this.txtCodCorRut.Text));
                repRut.SetParameterValue("@Transportista", null);
            }

            //reporte con fecha y transportista seleccionada
            if (this.chkRutCor.Checked & this.txtCodCorRut.Text == ""  & this.txtCodTra.Text != "") 
            {
                repRut.SetParameterValue("@CodRutCor", null);
                repRut.SetParameterValue("@Transportista", Convert.ToInt16(this.txtCodTra.Text));
            }

            //reporte con fecha y transportista seleccionada
            if (this.chkRutCor.Checked & this.txtCodCorRut.Text != "" & this.txtCodTra.Text != "") 
            {
                repRut.SetParameterValue("@CodRutCor", Convert.ToInt16(this.txtCodCorRut.Text));
                repRut.SetParameterValue("@Transportista", Convert.ToInt16(this.txtCodTra.Text));
            }

            //parametros se ejecuta en las 3 codiciones
            repRut.SetParameterValue("@Tipo", Convert.ToInt16(this.chkRutCor.Checked));
            repRut.SetParameterValue("@Fecha",this.dtpFecRutOnl.Value.Date);

            MetGlo.CRVisPre(repRut);
            Cursor.Current = Cursors.Default;
        }

        private void btnCamFec_Click(object sender, EventArgs e)
        {
            DataTable dtRecPro = new DataTable();
            dtRecPro = nRo.Ruta_Online_RecPro(this.dtpFecRutOnl.Value.Date, this.chkTod.Checked);

            //valida si hay datos
            if (dtRecPro.Rows.Count > 0) 
            {
                //valida si hay datos pero no ha consultado la fecha
                if (dtRecPro.Rows.Count > 0 && this.fgRutOnl.IsCellSelected(this.fgRutOnl.Row, this.fgRutOnl.Col)) 
                {
                    //valida si ah seleccionado una fila
                    if (this.fgRutOnl.IsCellSelected(this.fgRutOnl.Row, this.fgRutOnl.Col)) 
                    {
                        //valida si ya esta atentida el registro
                        switch (_estDat)
                        {
                            case 0:
                                if (Convert.ToInt32(this.fgRutOnl[this.fgRutOnl.Row, 17].ToString()) != 0)
                                {
                                    _mensaje = "Esta ruta ya esta Atendida, no se puede cambiar la fecha.";
                                    this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                                    this.btnCamFec.Focus();
                                    return;
                                }
                                break;

                            case 1:
                                if (Convert.ToInt32(this.fgRutOnl[this.fgRutOnl.Row, 15].ToString()) != 0)
                                {
                                    _mensaje = "Esta ruta ya esta Atendida, no se puede cambiar la fecha.";
                                    this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);                                    
                                    this.btnCamFec.Focus();
                                    return;
                                }
                                break;
                        }

                        //recuperamos los datos  y asignamos 
                        DataTable dtRecItemEnc = new DataTable();
                        dtRecItemEnc = nRo.Ruta_Online_RecItemEnc(Convert.ToInt32(this.fgRutOnl.Rows[this.fgRutOnl.Row][0])); //parametro N° movimiento

                        if (dtRecItemEnc.Rows.Count > 0)
                        {
                            this.txtCliCF.Text = dtRecItemEnc.Rows[0]["Cliente"].ToString();
                            this.txtNumRQCF.Text = dtRecItemEnc.Rows[0]["NumRQ"].ToString();
                            this.txtRutCF.Text = dtRecItemEnc.Rows[0]["Ruta"].ToString();
                            this.txtEncCF.Text = dtRecItemEnc.Rows[0]["Encargo"].ToString();

                            DateTime fecha  = Convert.ToDateTime(dtRecItemEnc.Rows[0]["FechaRuta"].ToString());
                            this.txtFecCF.Text = fecha.ToShortDateString();

                            DateTime hora = Convert.ToDateTime(dtRecItemEnc.Rows[0]["FechaRuta"].ToString());
                            this.txtHorCF.Text = hora.ToShortTimeString();
                        }
                        else
                        {
                            return;
                        }

                        //ocultamos controlesy mostramos el panel
                        this.pnlPri.Enabled = false;
                        this.fgRutOnl.Enabled = false;
                        this.pnlCabmFec.Visible = true;
                        this.btnExp.Enabled = false;
                    }
                    else
                    {
                        _mensaje = "Debe seleccionar una fila.";
                        this.Ruta_Online_MosMsgStrip(_mensaje, Color.Red);
                        this.btnCamFec.Focus();
                        return;
                    }
                }
                else
                {
                    _mensaje = "Consulte la fecha,hay datos.";
                    this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                    this.btnAct.Focus();
                    return;
                }
            }
            else
            {
                _mensaje = "No se encontraron datos para mostrar,consulte una fecha.";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                this.dtpFecRutOnl.Focus();
            }
        }

        private void btnPen_Click(object sender, EventArgs e)
        {
            _estDat = 1;

            //limpiamos la grilla
            DataTable dtClear = new DataTable();
            dtClear.Clear();
            this.fgRutOnl.DataSource = dtClear;
          
            //llenamos los datos
            DataTable dtRecProPen = new DataTable();
            dtRecProPen = nRo.Ruta_Online_RecProPen();

            if (dtRecProPen.Rows.Count > 0) //valida si hay datos
            {
                this.fgRutOnl.DataSource = dtRecProPen;
            }
            else
            {
                _mensaje = "No se encontraron los datos.";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
            }
        }

        private void frmRuta_Online_Load(object sender, EventArgs e)
        {
            this.txtCodCorRut.ReadOnly = true;
            this.txtCodTra.ReadOnly = true;
            this.fgRutOnl.Styles.Normal.WordWrap = true;
            this.lblInfo.ForeColor = Color.Blue;
            this.pnlCabmFec.Visible = false;           
            this.Ruta_OnlineCentrarControl();
            this.tmrDat.Enabled = true;
            this.tmrDat.Start();
        }

        private void Ruta_Online_FormatoGeneral()
        {
            try
            {
                this.fgRutOnl.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                this.fgRutOnl.SelectionMode = SelectionModeEnum.Row;
                this.fgRutOnl.VisualStyle = VisualStyle.Office2010Silver;
                this.fgRutOnl.Styles.Alternate.BackColor = Color.LightBlue;
                this.fgRutOnl.Styles.Highlight.BackColor = Color.Blue;
                this.fgRutOnl.Styles.Highlight.ForeColor = Color.White;
                this.fgRutOnl.AllowFreezing = AllowFreezingEnum.Both;
                this.fgRutOnl.Cols.Frozen = 3;
            }
            catch(Exception ex)
            {
                return;
            }
        }

        private void Ruta_Online_Rec_Dis()
        {
            //Recupera el distrito

            try
            {
                CellStyle styleDis;
                DataTable dtRecDis = new DataTable();
                dtRecDis = nRo.Ruta_Online_RecDis();

                ListDictionary lisDis = new ListDictionary();

                for (int i = 0; i <= dtRecDis.Rows.Count - 1; i++)
                {
                    string key = dtRecDis.Rows[i][0].ToString();
                    string value = dtRecDis.Rows[i][1].ToString();
                    lisDis.Add(key, value);
                }

                styleDis = fgRutOnl.Styles.Add("Distrito");
                styleDis.DataMap = lisDis;
                this.fgRutOnl.Cols["Distrito"].Style = styleDis;
            }
            catch { }
        }

        private void Ruta_Online_RecArePro()
        {
            //Recupera el area 

            try
            {
                CellStyle styleArePro;
                DataTable dtRecDis = new DataTable();
                dtRecDis = nRo.Ruta_Online_RecArePro();

                ListDictionary lisArePro = new ListDictionary();

                for (int ArePro = 0; ArePro <= dtRecDis.Rows.Count - 1; ArePro++)
                {
                    string key = dtRecDis.Rows[ArePro][0].ToString();
                    string value = dtRecDis.Rows[ArePro][1].ToString();

                    lisArePro.Add(key, value);
                }

                styleArePro = fgRutOnl.Styles.Add("Area Procedente");
                styleArePro.DataMap = lisArePro;
                this.fgRutOnl.Cols["Area Procedente"].Style = styleArePro;
            }
            catch { }
        }

        private void Ruta_Online_Rec_Trans()
        {
            //Recupera el transportista
            try
            {
                CellStyle styleRut;
                DataTable dtRecTra = new DataTable();
                dtRecTra = nRo.Ruta_Online_RecTrans();

                ListDictionary lisTra = new ListDictionary();

                for (int i = 0; i <= dtRecTra.Rows.Count - 1; i++)
                {
                    string key = dtRecTra.Rows[i][0].ToString();
                    string value = dtRecTra.Rows[i][1].ToString();
                    lisTra.Add(key, value);
                }

                styleRut = fgRutOnl.Styles.Add("Transp");
                styleRut.DataMap = lisTra;
                this.fgRutOnl.Cols["Transp"].Style = styleRut;
            }
            catch { }
        }

        private void Ruta_Online_Rec_Tip()
        {
            //Recupera el tipo
            try
            {
                CellStyle styleDis;
                ListDictionary lisDis = new ListDictionary();

                 lisDis.Add("1","Enviar");
                 lisDis.Add("2", "Recoger");

                styleDis = fgRutOnl.Styles.Add("Tipo");
                styleDis.DataMap = lisDis;
                this.fgRutOnl.Cols["Tipo"].Style = styleDis;
            }
            catch { }
        }
        private void Ruta_Oneline_SizeColumnas()
        {
            try
            {
                switch (_estDat)
                {
                    case 0:
                        //visible columnas
                        this.fgRutOnl.Cols[0].Visible = false; //N° movimiento
                        this.fgRutOnl.Cols["codcorped"].Visible = false;
                        this.fgRutOnl.Cols["Monto"].Visible = false;

                        //nombre columnas
                        this.fgRutOnl.Cols["corte"].Caption = "Corte";

                        //tamaño de columnas
                        this.fgRutOnl.Cols["Corte"].Width = 50;
                        this.fgRutOnl.Cols["Ruta"].Width = 50;
                        this.fgRutOnl.Cols[4].Width = 60;
                        this.fgRutOnl.Cols["Hora"].Width = 60;
                        this.fgRutOnl.Cols["Distrito"].Width = 80;
                        this.fgRutOnl.Cols["Tipo"].Width = 60;
                        this.fgRutOnl.Cols["Encargo"].Width = 170;
                        this.fgRutOnl.Cols["NumDoc"].Width = 80;
                        this.fgRutOnl.Cols["NumDocFin"].Width = 80;
                        this.fgRutOnl.Cols["Atendido"].Width = 70;
                        this.fgRutOnl.Cols["N° Veces"].Width = 80;
                        this.fgRutOnl.Cols["Tipo de Ruta"].Width = 70;
                        this.fgRutOnl.Cols["Tipo de pedido"].Width = 110;

                        //tipo de dato
                        this.fgRutOnl.Cols["Atendido"].Style.DataType = typeof(bool);
                        this.fgRutOnl.Cols["Atendido"].Style.ImageAlign = ImageAlignEnum.CenterCenter;

                        //tamaño de filas
                        this.fgRutOnl.Rows[0].Height = 25;

                        for (int i =1; i < this.fgRutOnl.Rows.Count;i++)
                        {
                            this.fgRutOnl.Rows[i].Height = 50;
                        }
                        break;

                    case 1:

                        //visible columnas
                        this.fgRutOnl.Cols[0].Visible = false; //N° Movimiento
                        this.fgRutOnl.Cols["CodigoRuta"].Visible = false;
                        this.fgRutOnl.Cols["HoraOpcion"].Visible = false;

                        //tamaño de columnas
                        this.fgRutOnl.Cols["Ruta"].Width = 50;
                        this.fgRutOnl.Cols[3].Width = 40; //N° R
                        this.fgRutOnl.Cols["Hora"].Width = 65;
                        this.fgRutOnl.Cols["Tipo"].Width = 60;
                        this.fgRutOnl.Cols["Atendido"].Width = 50;
                        this.fgRutOnl.Cols["Instalacion"].Width = 150;
                        this.fgRutOnl.Cols["Obs"].Width = 80;
                        this.fgRutOnl.Cols["Monto"].Width = 60;
                        this.fgRutOnl.Cols["N° Veces"].Width = 50;

                        //tipo de dato
                        this.fgRutOnl.Cols["Atendido"].Style.DataType = typeof(bool);
                        this.fgRutOnl.Cols["Atendido"].Style.ImageAlign = ImageAlignEnum.CenterCenter;

                        //tamaño de filas
                        this.fgRutOnl.Rows[0].Height = 25; //N° Movimiento
                        break;          
                                     
                    default:
                        break;
                }

                this.Ruta_Oneline_DesignColumnas();

            } catch { }
        }

        private void Ruta_Oneline_DesignColumnas()
        {
            try
            {
                this.fgRutOnl.AllowMerging = AllowMergingEnum.Free;
                this.fgRutOnl.Cols[2].AllowMerging = true;
            }
            catch { }
        }

        private void Ruta_Online_ConsultaDatos(string vista, string procedimiento, string param1)
        {
            //Filtra los datos al presionar enter

            DataTable dtFiltro = new DataTable();
            dtFiltro = nRo.Ruta_Online_Filtros(vista, procedimiento, param1); //ejecuta el procedimiento

            if (dtFiltro.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 4;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFiltro;
                frm.Ruta_Online_Rec = this;
                frm.ShowDialog();
            }
            else if (dtFiltro.Rows.Count == 1)
            {
                DataRow row = dtFiltro.Rows[0];

                switch (vista)
                {
                    case "Rutas":
                    case "Corte":
                        this.txtCodCorRut.Text = row["Codigo"].ToString();
                        this.txtDesCorRut.Text = row["Descripcion"].ToString();
                        break;

                    case "Transportista":
                        this.txtCodTra.Text = row["Codigo"].ToString();
                        this.txtDesTra.Text = row["Empleado"].ToString();
                        break;

                    default:
                        break;
                }
            }
            else if (dtFiltro.Rows.Count == 0)
            {
                varglo.Elegi = false;
                _mensaje = "No se encontraron registros";
                this.Ruta_Online_MosMsgStrip(_mensaje,Color.Red);
            }
        }

        public void recdat_Ruta_Online_RutCor(string CodRutCor, string DesRutCor)
        {
            this.txtCodCorRut.Text = CodRutCor;
            this.txtDesCorRut.Text = DesRutCor;
        }

        public void recdat_Ruta_Online_Tra(string CodTra, string DesTra)
        {
            this.txtCodTra.Text = CodTra;
            this.txtDesTra.Text = DesTra;
        }

        private void txtDesCor_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                if (this.chkRutCor.Checked) //valida si hay check
                {
                    this.Ruta_Online_ConsultaDatos("Rutas", "Filtro_Rutas", this.txtDesCorRut.Text.Trim());
                    this.txtDesTra.Focus();
                }
                else
                {
                    this.Ruta_Online_ConsultaDatos("Corte", "Filtro_ALM_CorPed", this.txtDesCorRut.Text.Trim());
                    this.btnImp.Focus();
                }
            }
        }

        private void txtDesTra_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Online_ConsultaDatos("Transportista", "Filtro_Empleados", this.txtDesTra.Text.Trim());
                this.btnImp.Focus();
            }
        }

        private void chkRutCor_CheckedChanged(object sender, EventArgs e)
        {
            //valida si hay check en la ruta del corte
            if (this.chkRutCor.Checked) 
            {
                this.lblCorRut.Text = "Ruta";
                this.lblTra.Visible = true;
                this.txtCodTra.Visible = true;
                this.txtDesTra.Visible = true;
            }
            else
            {
                this.lblCorRut.Text = "Corte";
                this.lblTra.Visible = false;
                this.txtCodTra.Visible = false;
                this.txtDesTra.Visible = false;
            }

            //Texto predeterminado
            this.txtCodCorRut.Text = "";
            this.txtDesCorRut.Text = "Presione enter o ingrese un corte";
            this.txtDesTra.ForeColor = Color.DimGray;

            this.txtCodTra.Text = "";
            this.txtDesTra.Text = "Presione enter o ingrese un transportista";
            this.txtDesTra.ForeColor = Color.DimGray;

            this.txtDesCorRut.Focus();
        }

        private void fgRutOnl_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.Ruta_Oneline_SizeColumnas();
            this.Ruta_Online_FormatoGeneral();
            this.Ruta_Online_Rec_Dis();
            this.Ruta_Online_Rec_Trans();
            this.Ruta_Online_Rec_Tip();
            this.Ruta_Online_RecArePro();
        }

        private void fgRutOnl_AfterEdit(object sender, RowColEventArgs e)
        {
            Int16 numMov = 0;
            string valor = "";

            switch (_estDat) 
            {
                case 0:

                    //columnas que se van actualizar
                    if (e.Col == 6 || e.Col == 7 || e.Col == 8 || e.Col == 9 || e.Col == 10 || e.Col == 16 || 
                                    e.Col == 17 || e.Col == 18 || e.Col == 19  || e.Col == 24 || e.Col == 25) 

                    {
                        //toma los valores
                        numMov = Convert.ToInt16(this.fgRutOnl[e.Row, 0]);
                        valor = Convert.ToString(this.fgRutOnl[e.Row, e.Col]);

                        //ejecutamos el procedimiento
                        if (e.Col == 6 & Convert.ToInt32(fgRutOnl[e.Row, 4]) == 0) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor); 

                        //validamos las columnas y ejecutamos el procedimiento
                        if (e.Col == 6 & Convert.ToInt32(this.fgRutOnl[e.Row, 4]) != 0)
                        {
                            _mensaje = "No se puede mofidicar este valor,ya que proviene de un RQ";
                            this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                            
                            this.fgRutOnl[e.Row, 6] = "";
                            this.fgRutOnl[e.Row, 6] = _cliente; //retorna el valor a la celda
                            return;
                        }

                        if (e.Col == 7) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 8) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 9) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 10) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 16) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);

                        //asignando valores
                        bool estado = Convert.ToBoolean(this.fgRutOnl[e.Row, 17]);
                        Int16 rq = Convert.ToInt16(this.fgRutOnl[e.Row, 4]);

                        if (e.Col == 17) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat, estado, rq);
                        if (e.Col == 18) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 19) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 24) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);
                        if (e.Col == 25) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor);

                        //validamos la columna  y ejecutamos el procedimiento ruta de programacion
                        Ruta_Online_ItemEnc Item = new Ruta_Online_ItemEnc()
                        {
                            CodUsu = Convert.ToInt16(varglo.CodUsuAct),
                            NumMov = numMov,
                        };
                       

                        if (e.Col == 6 || e.Col == 7 || e.Col == 8 || e.Col == 9 || e.Col == 10 || e.Col == 16) nRo.Ruta_Online_ActFecMod(Item);
                    }
                    break;


                case 1://cuando selecciona el boton pendientes

                    if (e.Col == 5 || e.Col == 7 || e.Col == 8 || e.Col == 9 || e.Col == 14 || e.Col == 15  || e.Col == 16)
                    {
                        numMov = Convert.ToInt16(this.fgRutOnl[e.Row, 0]);
                        valor = Convert.ToString(this.fgRutOnl[e.Row, e.Col]);

                        //ejecutamos el procedimiento
                        if (e.Col == 5 & Convert.ToInt32(fgRutOnl[e.Row, 3]) == 0) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);

                        if (e.Col == 5 & Convert.ToInt32(fgRutOnl[e.Row, 3]) != 0)
                        {
                            _mensaje = "No se puede mofidicar este valor,ya que proviene de un RQ";
                            this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);

                            this.fgRutOnl[e.Row, 5] = "";
                            this.fgRutOnl[e.Row, 5] = nRo;
                            return;
                        }

                        if (e.Col == 7) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);
                        if (e.Col == 8) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);
                        if (e.Col == 9) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);
                        if (e.Col == 14) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);
                        if (e.Col == 15) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);
                        if (e.Col == 16) nRo.Ruta_Online_ActCol(numMov, Convert.ToInt16(e.Col), valor, _estDat);
                    }

                    break;
                default:
                    break;
            }
        }

        private void lblCer_Click(object sender, EventArgs e)
        {
            //oculta el panel
            this.pnlCabmFec.Visible = false;
            this.pnlPri.Enabled = true;
            this.fgRutOnl.Enabled = true;
            this.btnExp.Enabled = true;
        }

        private void Ruta_OnlineCentrarControl()
        {
            this.pnlCabmFec.Location = new Point((this.Width / 2) - (this.pnlCabmFec.Size.Width / 2), (this.Height / 2) - (this.pnlCabmFec.Size.Height / 2));
            this.pnlCabmFec.Anchor = AnchorStyles.None;
        }

        private void fgRutOnl_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            switch (_estDat)
            {
                case 0:

                    //columnas codnde se pueden editar
                    if (e.Col == 6 || e.Col == 7 || e.Col == 8 || e.Col == 9 || e.Col == 10 || 
                        e.Col == 16 || e.Col == 17 || e.Col == 18 || e.Col == 19 || e.Col == 24 || e.Col == 25) 
                    {
                        if (e.KeyChar != 3 || e.KeyChar != 27)
                        {
                            e.Handled = false;
                        }
                    }
                    else
                    {
                        //no permite editar
                        e.Handled = true; 
                    }
                    break;

                case 1:

                    //cuando selecciona el boton  pendientes
                    if (e.Col == 5 || e.Col == 7 || e.Col == 8 || e.Col == 9 || e.Col == 14 || e.Col == 15 || e.Col == 16)
                    {
                        if (e.KeyChar != 3 || e.KeyChar != 27)
                        {
                            e.Handled = false;
                        }
                    }
                    else
                    {
                        //no permite editar
                        e.Handled = true; 
                    }
                    break;

                default:
                    break;
            }
        }

        private void fgRutOnl_StartEdit(object sender, RowColEventArgs e)
        {
            //valida si viene por pendientes o actuliza todo
            switch (_estDat) 
            {
                case 0:
                    _cliente = this.fgRutOnl[e.Row, 6].ToString();
                    break;

                case 1:
                    _cliente = this.fgRutOnl[e.Row, 5].ToString();
                    break;

                default:
                    break;
            }
        }

        private void dtpFec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.btnAct.Focus();
            }
        }

        private void btnCamAct_Click(object sender, EventArgs e)
        {
            string fecAct = DateTime.Now.ToShortDateString();

            if (Convert.ToDateTime(this.txtFecCF.Text )  < Convert.ToDateTime(fecAct)) //valida si la fecha es menor a la actual
            {
                _mensaje = "La Fecha de la ruta no puede ser menor a la fecha actual";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.DodgerBlue);
                return;
            }
            else
            {
                try
                {
                    //asignamos los datos a la entidad
                    Ruta_Online_ItemEnc Item = new Ruta_Online_ItemEnc()
                    {
                        FecRuta = Convert.ToDateTime(this.txtFecCF.Text),
                        CodUsu = Convert.ToInt16(varglo.CodUsuAct),
                        NumMov = Convert.ToInt16(this.fgRutOnl.Rows[this.fgRutOnl.Row][0]),
                    };



                    nRo.Ruta_Online_ActItemEnc(Item); //ejecutamos el procedimiento
                    this.pnlCabmFec.Visible = false; //ocultamos el panel

                    //habilitamos los controles
                    this.pnlPri.Enabled = true;
                    this.fgRutOnl.Enabled = true;
                    this.btnExp.Enabled = true;

                }
                catch (Exception ex)
                {
                    return;
                }
            }
        }

        private void txtMin_TextChanged(object sender, EventArgs e)
        {
            if (this.txtMin.Text == "")
            {
                return;
            }

            if (this.txtMin.Text == "0")
            {
                _mensaje = "Numero de minuto inválido";
                this.Ruta_Online_MosMsgStrip(_mensaje, Color.Red);
                this.txtMin.Focus();
                return;
            }

            if (this.txtMin.Text == "1")
            {
                this.lblMin.Text = "Minuto";
            }
            else
            {
                this.lblMin.Text = "Minutos";
            }

            this.tmrDat.Enabled = false;
            this.tmrDat.Enabled = true;
            this.tmrDat.Interval = Convert.ToInt32(this.txtMin.Text) * 60000;
        }

        private void  Ruta_Online_Rec_DatTim()
        {
            DataTable dtRecDatTim = new DataTable();
            dtRecDatTim = nRo.Ruta_Online_RecDatTim(Convert.ToDateTime(this.dtpFecRutOnl.Value.Date));

            //valida si ha datos
            if (dtRecDatTim.Rows.Count > 0) 
            {
                //vuelve a recuperar los datos
                this.Ruta_Online_RecPro();

                //muesta la notificación
                this.ntfRut.Visible = true;
                this.ntfRut.ShowBalloonTip(120000, "Ruta Online", "Se ha programado una nueva ruta", ToolTipIcon.Warning);

                frmRuta_OnlineAviso frmAvi = new frmRuta_OnlineAviso();
                frmAvi.fgRutOnlAvi.DataSource = dtRecDatTim;
                frmAvi.Show();
            }
            else
            {
                return;
            }
        }
        
        private void tmrInicio_Tick(object sender, EventArgs e)
        {
            frmRuta_OnlineAviso frmAvi = new frmRuta_OnlineAviso();
            frmAvi.ShowDialog();
        }

        private void tmrFinal_Tick(object sender, EventArgs e)
        {
            frmRuta_OnlineAviso frmAvi = new frmRuta_OnlineAviso();
            frmAvi.Close();
        }

        private void tmrDat_Tick(object sender, EventArgs e)
        {
            //Recupera los cortes
            this.Ruta_Online_Rec_Cortes();

            //mostrar el formulario con los datos 
            this.Ruta_Online_Rec_DatTim();
        }

        private void ntfRut_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //oculta a al hora de hacer doble click en el icono de la notificacion
            this.ntfRut.Visible = false; 
        }

        private void txtMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (Char.IsSeparator(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtDesCorRut_Enter(object sender, EventArgs e)
        {
            if (this.txtDesCorRut.Text == "Presione enter o ingrese un corte")
            {
                this.txtDesCorRut.Text = "";
                this.txtDesCorRut.ForeColor = Color.Black;
            }
        }

        private void txtDesCorRut_Leave(object sender, EventArgs e)
        {
            if (this.txtDesCorRut.Text == "")
            {
                this.txtDesCorRut.Text = "Presione enter o ingrese un corte";
                this.txtDesCorRut.ForeColor = Color.DimGray;
            }
        }

        private void txtDesTra_Enter(object sender, EventArgs e)
        {
            if (this.txtDesTra.Text == "Presione enter o ingrese un transportista")
            {
                this.txtDesTra.Text = "";
                this.txtDesTra.ForeColor = Color.Black;
            }
        }

        private void txtDesTra_Leave(object sender, EventArgs e)
        {
            if (this.txtDesTra.Text == "")
            {
                this.txtDesTra.Text = "Presione enter o ingrese un transportista";
                this.txtDesTra.ForeColor = Color.DimGray;
            }
        }

        private void Ruta_Online_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }
    }
}
