﻿using CapaNegocio;
using CrystalDecisions.CrystalReports.Engine;
using SAP_Adicional.Reportes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.Shared;

namespace SAP_Adicional
{
    public partial class frmALM_repDis : Form
    {
        NConsultas nc = new NConsultas();

        public frmALM_repDis()
        {
            InitializeComponent();
        }

        public int Comparacion(DateTime time1, DateTime tim2)
        {
            if (time1.Date > tim2.Date)
            {
                MessageBox.Show("La fecha de inicio no puede ser mayor a la fecha final");
                return 1;
            }
            else if (tim2.Date > DateTime.Now.Date)
            {
                MessageBox.Show("La fecha final no puede ser mayor a la actual");
                return 1;
            }
            else
            {
                return 0;
            }
        }

        #region
        public void ConsultaDatos(int r, string procedimiento, DateTime param1, DateTime param2)
        {
            //ConnectionInfo crConnectionInfo = new ConnectionInfo(); ;
            //Database crDatabase;
            //Tables crTables;
            //Table crTable;
            //TableLogOnInfo crTableLogOnInfo;

            ReportDocument rpt;

            DataTable dt = new DataTable();
            dt = nc.ALM_repDis_TipRutVen(procedimiento, param1, param2);
            if (Comparacion(param1, param2) == 1)
            {
                return;
            }

            //crConnectionInfo.ServerName = "zeus";
            //crConnectionInfo.DatabaseName = VarGlo.Instance().Base; // Las tablas para el informe están siempre en la base de datos global.
            //crConnectionInfo.IntegratedSecurity = true;

            //
            if (dt.Rows.Count > 0)
            {
                switch (r)
                {
                    case 1:
                        rpt = new rptALM_repDis_TipRut1();
                        break;
                    case 2:
                        rpt = new rptALM_repDis_TipRut2();
                        break;
                    case 3:
                        rpt = new rptALM_repDis_TipRut3();
                        break;
                    case 4:
                        rpt = new rptALM_repDis_TipRut4();
                        break;
                    case 5:
                        rpt = new rptALM_repDis_TipRut5();
                        break;
                    case 6:
                        rpt = new rptALM_repDis_TipVen1();
                        break;
                    case 7:
                        rpt = new rptALM_repDis_TipVen2();
                        break;
                    case 8:
                        rpt = new rptALM_repDis_TipVen3();
                        break;
                    case 9:
                        rpt = new rptALM_repDis_TipVen4();
                        break;
                    case 10:
                        rpt = new rptALM_repDis_TipVen5();
                        break;
                    case 11:
                        rpt = new rptALM_repDis_TipVen6();
                        break;
                    default:
                        rpt = new rptALM_repDis_TipVen7();
                        break;
               
                }
                                    
                rpt.SetParameterValue("@fecini", param1.Date);
                rpt.SetParameterValue("@fecfin", param2.Date);

                MetGlo.CRVisPre(rpt);
            }
            else
            {
                MessageBox.Show("No hay datos encontrados");
                return;
            }
        }
        #endregion
        #region
        private void dtpSegTipR1_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipR1_,e);
        }

        private void dtpSegTipR1__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos1, e);
        }

        private void dtpSegTipR2_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipR2_, e);
        }

        private void dtpSegTipR2__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos2, e);
        }

        private void dtpSegTipR3_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipR3_, e);
        }

        private void dtpSegTipR3__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos3, e);
        }

        private void dtpSegTipR4_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipR4_, e);
        }

        private void dtpSegTipR4__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos4, e);
        }

        private void dtpSegTipR5_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipR5_, e);
        }

        private void dtpSegTipR5__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos5, e);
        }

        private void dtpSegTipV1_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV1_, e);
        }

        private void dtpSegTipV1__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos6, e);
        }

        private void dtpSegTipV2_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV2_, e);
        }

        private void dtpSegTipV2__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos7, e);
        }

        private void dtpSegTipV3_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV3_, e);
        }

        private void dtpSegTipV3__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos8, e);
        }

        private void dtpSegTipV4_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV4_, e);
        }

        private void dtpSegTipV4__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos9, e);
        }

        private void dtpSegTipV5_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV5_, e);
        }

        private void dtpSegTipV5__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos10, e);
        }

        public void EventoBoton (Control control ,KeyPressEventArgs e)
        {
            if (e.KeyChar == (char) 13)
            {
                control.Focus();
            }
        }

        #endregion
        #region

        private void btnMos1_Click(object sender, EventArgs e)
        {
            ConsultaDatos(1, "ALM_repDis_TipRut1", dtpSegTipR1.Value.Date, dtpSegTipR1_.Value.Date);
        }
        private void btnMos2_Click(object sender, EventArgs e)
        {
            ConsultaDatos(2, "ALM_repDis_TipRut2_1", dtpSegTipR2.Value.Date, dtpSegTipR2_.Value.Date);
        }

        private void btnMos3_Click(object sender, EventArgs e)
        {
            ConsultaDatos(3, "ALM_repDis_TipRut3", dtpSegTipR3.Value.Date, dtpSegTipR3_.Value.Date);
        }

        private void btnMos4_Click(object sender, EventArgs e)
        {
            ConsultaDatos(4, "ALM_repDis_TipRut4", dtpSegTipR4.Value.Date, dtpSegTipR4_.Value.Date);
        }

        private void btnMos5_Click(object sender, EventArgs e)
        {
            ConsultaDatos(5, "ALM_repDis_TipRut5", dtpSegTipR5.Value.Date, dtpSegTipR5_.Value.Date);
        }

        private void btnMos6_Click(object sender, EventArgs e)
        {
            ConsultaDatos(6, "ALM_repDis_TipVen1", dtpSegTipV1.Value.Date, dtpSegTipV1_.Value.Date);
        }

        private void btnMos7_Click(object sender, EventArgs e)
        {
            ConsultaDatos(7, "ALM_repDis_TipVen2_1", dtpSegTipV2.Value.Date, dtpSegTipV2_.Value.Date);
        }

        private void btnMos8_Click(object sender, EventArgs e)
        {
            ConsultaDatos(8, "ALM_repDis_TipVen3", dtpSegTipV3.Value.Date, dtpSegTipV3_.Value.Date);
        }

        private void btnMos9_Click(object sender, EventArgs e)
        {
            ConsultaDatos(9, "ALM_repDis_TipVen4", dtpSegTipV4.Value.Date, dtpSegTipV4_.Value.Date);
        }

        private void btnMos10_Click(object sender, EventArgs e)
        {
            ConsultaDatos(10, "ALM_repDis_TipVen5", dtpSegTipV5.Value.Date, dtpSegTipV5_.Value.Date);
        }
        private void btnMos11_Click(object sender, EventArgs e)
        {
            ConsultaDatos(11, "ALM_repDis_TipVen6", dtpSegTipV6.Value.Date, dtpSegTipV6_.Value.Date);
        }
        private void btnMos12_Click(object sender, EventArgs e)
        {
            ConsultaDatos(12, "ALM_repDis_TipVen7", dtpSegTipV7.Value.Date, dtpSegTipV7_.Value.Date);
        }
        #endregion
        private void dtpSegTipV6_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV6_, e);
        }

        private void dtpSegTipV6__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos11, e);
        }

        private void dtpSegTipV7_KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(dtpSegTipV7_, e);
        }

        private void dtpSegTipV7__KeyPress(object sender, KeyPressEventArgs e)
        {
            EventoBoton(btnMos12, e);
        }
    }
}
