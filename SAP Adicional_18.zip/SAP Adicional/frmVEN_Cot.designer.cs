﻿namespace SAP_Adicional
{
    partial class frmVEN_Cot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVEN_Cot));
            this.btnAbrir = new System.Windows.Forms.ToolStripButton();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.btnDeshacer = new System.Windows.Forms.ToolStripButton();
            this.btnModificar = new System.Windows.Forms.ToolStripButton();
            this.btnOpcImp = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.btnAprobar = new System.Windows.Forms.ToolStripButton();
            this.btnMigrarSAP = new System.Windows.Forms.ToolStripButton();
            this.btnDuplicar = new System.Windows.Forms.ToolStripButton();
            this.tbpArtCom = new System.Windows.Forms.TabPage();
            this.btnAgrCom = new System.Windows.Forms.Button();
            this.btnCanCom = new System.Windows.Forms.Button();
            this.btnBorCom = new System.Windows.Forms.Button();
            this.lblInfoItem = new System.Windows.Forms.Label();
            this.fgCom = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.fgDet = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtPorDes = new System.Windows.Forms.TextBox();
            this.btnAgrItem = new System.Windows.Forms.Button();
            this.txtSim = new System.Windows.Forms.TextBox();
            this.txtSubTot = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtIGV = new System.Windows.Forms.TextBox();
            this.lblIGVUnit = new System.Windows.Forms.Label();
            this.txtValNet = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtVenBru = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtCan = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.txtCodArtCom = new System.Windows.Forms.TextBox();
            this.tbAmb = new System.Windows.Forms.TabControl();
            this.tbpAmb = new System.Windows.Forms.TabPage();
            this.lblAmbTot = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.fgAmb = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnAgrAmb = new System.Windows.Forms.Button();
            this.btnEliAmb = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtCodAmb = new System.Windows.Forms.TextBox();
            this.txtCanAmb = new System.Windows.Forms.TextBox();
            this.txtAmb = new System.Windows.Forms.TextBox();
            this.tbpObs = new System.Windows.Forms.TabPage();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.btnModItem = new System.Windows.Forms.Button();
            this.btnBorItem = new System.Windows.Forms.Button();
            this.btnCanItem = new System.Windows.Forms.Button();
            this.tbpOtrArt = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCanItemAA = new System.Windows.Forms.Button();
            this.btnBorItemAA = new System.Windows.Forms.Button();
            this.txtRutImaTec = new System.Windows.Forms.TextBox();
            this.btnRutImaTec = new System.Windows.Forms.Button();
            this.label78 = new System.Windows.Forms.Label();
            this.txtRutIma2 = new System.Windows.Forms.TextBox();
            this.btnRutIma2 = new System.Windows.Forms.Button();
            this.label77 = new System.Windows.Forms.Label();
            this.fgDetAA = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.txtAmbAA = new System.Windows.Forms.TextBox();
            this.txtSubTotAA = new System.Windows.Forms.TextBox();
            this.txtIGVAA = new System.Windows.Forms.TextBox();
            this.txtValNetAA = new System.Windows.Forms.TextBox();
            this.txtRutIma = new System.Windows.Forms.TextBox();
            this.btnRutIma = new System.Windows.Forms.Button();
            this.txtDescAA = new System.Windows.Forms.TextBox();
            this.txtPorDesAA = new System.Windows.Forms.TextBox();
            this.txtPreUniAA = new System.Windows.Forms.TextBox();
            this.txtDesAA = new System.Windows.Forms.TextBox();
            this.txtCanAA = new System.Windows.Forms.TextBox();
            this.txtCodAmbAA = new System.Windows.Forms.TextBox();
            this.btnModItemAA = new System.Windows.Forms.Button();
            this.btnAgrAA = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.lblIGVUnitAA = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtObsAA = new System.Windows.Forms.TextBox();
            this.txtVenBruAA = new System.Windows.Forms.TextBox();
            this.tbpEnc = new System.Windows.Forms.TabPage();
            this.grpObs = new System.Windows.Forms.GroupBox();
            this.btnExp = new System.Windows.Forms.Button();
            this.txtObsExt = new System.Windows.Forms.TextBox();
            this.grbInfRec = new System.Windows.Forms.GroupBox();
            this.txtFam = new System.Windows.Forms.TextBox();
            this.txtCodFam = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.txtSubLin = new System.Windows.Forms.TextBox();
            this.txtCodSubLin = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtTip = new System.Windows.Forms.TextBox();
            this.txtCodTip = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtLinPro = new System.Windows.Forms.TextBox();
            this.txtCodLinPro = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtFalEn = new System.Windows.Forms.TextBox();
            this.txtCodFalEn = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtNomAdi = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtMot = new System.Windows.Forms.TextBox();
            this.txtRec = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCodMot = new System.Windows.Forms.TextBox();
            this.txtCodRec = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.btnDirObr = new System.Windows.Forms.Button();
            this.btnDirCli = new System.Windows.Forms.Button();
            this.txtCodTipDoc = new System.Windows.Forms.TextBox();
            this.txtDocEntry = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDocNum = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtRUCDNI = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCli = new System.Windows.Forms.TextBox();
            this.btnVinRQ = new System.Windows.Forms.Button();
            this.txtTipVen = new System.Windows.Forms.TextBox();
            this.txtCenVen = new System.Windows.Forms.TextBox();
            this.txtVen = new System.Windows.Forms.TextBox();
            this.txtCliCon = new System.Windows.Forms.TextBox();
            this.txtDim = new System.Windows.Forms.TextBox();
            this.txtTipObr = new System.Windows.Forms.TextBox();
            this.txtRub = new System.Windows.Forms.TextBox();
            this.txtTipVenRel = new System.Windows.Forms.TextBox();
            this.txtCodTipVen = new System.Windows.Forms.TextBox();
            this.txtCodCenVen = new System.Windows.Forms.TextBox();
            this.txtCodVen = new System.Windows.Forms.TextBox();
            this.txtCodCliCon = new System.Windows.Forms.TextBox();
            this.txtDirObr = new System.Windows.Forms.TextBox();
            this.txtDirCli = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtCodCli = new System.Windows.Forms.TextBox();
            this.txtNomCot = new System.Windows.Forms.TextBox();
            this.txtRQ = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSigPag = new System.Windows.Forms.Button();
            this.grpFacTipVen = new System.Windows.Forms.GroupBox();
            this.txtPag = new System.Windows.Forms.TextBox();
            this.txtTie = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.grbAdmRQ = new System.Windows.Forms.GroupBox();
            this.txtAdmRQ = new System.Windows.Forms.TextBox();
            this.txtCodAdmRQ = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.gpbCubre = new System.Windows.Forms.GroupBox();
            this.gpbMoneda = new System.Windows.Forms.GroupBox();
            this.btnCan = new System.Windows.Forms.Button();
            this.btnAce = new System.Windows.Forms.Button();
            this.rdbSol = new System.Windows.Forms.RadioButton();
            this.rdbDol = new System.Windows.Forms.RadioButton();
            this.tbPri = new System.Windows.Forms.TabControl();
            this.tbpArtSim = new System.Windows.Forms.TabPage();
            this.lblArtInfoItem = new System.Windows.Forms.Label();
            this.txtArtPrecio = new System.Windows.Forms.TextBox();
            this.txtCodArt = new System.Windows.Forms.TextBox();
            this.fgArtDet = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.txtArtDesc = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtArtPorDes = new System.Windows.Forms.TextBox();
            this.btnArtAgrItem = new System.Windows.Forms.Button();
            this.txtArtSubTot = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtArtIGV = new System.Windows.Forms.TextBox();
            this.lblArtIGVUnit = new System.Windows.Forms.Label();
            this.txtArtValNet = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtArtVenBru = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtArtCan = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.txtArtDes = new System.Windows.Forms.TextBox();
            this.tbArtAmb = new System.Windows.Forms.TabControl();
            this.tbpArtAmb = new System.Windows.Forms.TabPage();
            this.lblArtAmbTot = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.fgArtAmb = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnArtAgrAmb = new System.Windows.Forms.Button();
            this.btnArtEliAmb = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.txtArtCodAmb = new System.Windows.Forms.TextBox();
            this.txtArtCanAmb = new System.Windows.Forms.TextBox();
            this.txtArtAmb = new System.Windows.Forms.TextBox();
            this.tbpArtObs = new System.Windows.Forms.TabPage();
            this.txtArtObs = new System.Windows.Forms.TextBox();
            this.btnArtModItem = new System.Windows.Forms.Button();
            this.btnArtBorItem = new System.Windows.Forms.Button();
            this.btnArtCanItem = new System.Windows.Forms.Button();
            this.fgAmbTodos = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.fgComTodos = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.pnTot = new System.Windows.Forms.Panel();
            this.txtMar = new System.Windows.Forms.TextBox();
            this.txtCosTot = new System.Windows.Forms.TextBox();
            this.txtTotGen = new System.Windows.Forms.TextBox();
            this.txtTotIGV = new System.Windows.Forms.TextBox();
            this.txtTotValVen = new System.Windows.Forms.TextBox();
            this.txtTotDes = new System.Windows.Forms.TextBox();
            this.txtTotPorDes = new System.Windows.Forms.TextBox();
            this.txtTotVenBru = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.lblIGVTotal = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.fgArtAmbTodos = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tlsBot = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.btnOpc = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmiDesTot = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.ofdRutIma = new System.Windows.Forms.OpenFileDialog();
            this.fgDetArtAAItemTodos = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.gbItmArtComCubre = new System.Windows.Forms.GroupBox();
            this.gbArtAAItem = new System.Windows.Forms.GroupBox();
            this.btnAceAAIte = new System.Windows.Forms.Button();
            this.txtComRecAAIte = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.txtPorDesAAIte = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.txtCodProCat = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.txtMedAA = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.txtNegIte = new System.Windows.Forms.TextBox();
            this.txtCodNegIte = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.txtTC = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.btnCanAAIte = new System.Windows.Forms.Button();
            this.txtDesArtComAA = new System.Windows.Forms.TextBox();
            this.txtIteArtComAA = new System.Windows.Forms.TextBox();
            this.label106 = new System.Windows.Forms.Label();
            this.fgDetArtAAItem = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnCanIteAA = new System.Windows.Forms.Button();
            this.btnEliIteAA = new System.Windows.Forms.Button();
            this.btnModIteAA = new System.Windows.Forms.Button();
            this.btnAgrIteAA = new System.Windows.Forms.Button();
            this.txtObsAAItem = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.txtValVen = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.txtValVenSinIGV = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.txtCalPreVen = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.txtComTotDolInt = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.txtComTotDolFOB = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.txtCosIntTot = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.txtCosAdiNac = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.txtCosInt = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.txtFacImp = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.txtPorDesFOB = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.txtDesIteAA = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.txtCosFobFinUS = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.txtCosFobUS = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.txtCosFob = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.txtCanAAItem = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.txtMed = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.txtMatBasMue = new System.Windows.Forms.TextBox();
            this.txtCodMatBasMue = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.txtColPro = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.txtCodPro = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.txtMarAA = new System.Windows.Forms.TextBox();
            this.txtCodMarAA = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.txtSubFam = new System.Windows.Forms.TextBox();
            this.txtCodSubFam = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.txtFamAA = new System.Windows.Forms.TextBox();
            this.txtCodFamAA = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.txtSubLinAA = new System.Windows.Forms.TextBox();
            this.txtCodSubLinAA = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.txtLin = new System.Windows.Forms.TextBox();
            this.txtCodLin = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.txtFecEmi = new System.Windows.Forms.TextBox();
            this.gbIteCat = new System.Windows.Forms.GroupBox();
            this.fgAACatIte = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnCanAACat = new System.Windows.Forms.Button();
            this.btnAceAACat = new System.Windows.Forms.Button();
            this.txtComRec = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.txtEnv = new System.Windows.Forms.TextBox();
            this.txtCodEnv = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txtNeg = new System.Windows.Forms.TextBox();
            this.txtCodNeg = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.tbpArtCom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDet)).BeginInit();
            this.tbAmb.SuspendLayout();
            this.tbpAmb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAmb)).BeginInit();
            this.tbpObs.SuspendLayout();
            this.tbpOtrArt.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetAA)).BeginInit();
            this.tbpEnc.SuspendLayout();
            this.grpObs.SuspendLayout();
            this.grbInfRec.SuspendLayout();
            this.grpFacTipVen.SuspendLayout();
            this.grbAdmRQ.SuspendLayout();
            this.gpbCubre.SuspendLayout();
            this.gpbMoneda.SuspendLayout();
            this.tbPri.SuspendLayout();
            this.tbpArtSim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArtDet)).BeginInit();
            this.tbArtAmb.SuspendLayout();
            this.tbpArtAmb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArtAmb)).BeginInit();
            this.tbpArtObs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAmbTodos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgComTodos)).BeginInit();
            this.pnTot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArtAmbTodos)).BeginInit();
            this.tlsBot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetArtAAItemTodos)).BeginInit();
            this.gbItmArtComCubre.SuspendLayout();
            this.gbArtAAItem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetArtAAItem)).BeginInit();
            this.gbIteCat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAACatIte)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAbrir
            // 
            this.btnAbrir.Image = ((System.Drawing.Image)(resources.GetObject("btnAbrir.Image")));
            this.btnAbrir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(34, 33);
            this.btnAbrir.Text = "&Abrir";
            this.btnAbrir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAbrir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbrir.Click += new System.EventHandler(this.btnAbrir_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(50, 33);
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnDeshacer
            // 
            this.btnDeshacer.Image = ((System.Drawing.Image)(resources.GetObject("btnDeshacer.Image")));
            this.btnDeshacer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDeshacer.Name = "btnDeshacer";
            this.btnDeshacer.Size = new System.Drawing.Size(56, 33);
            this.btnDeshacer.Text = "&Deshacer";
            this.btnDeshacer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDeshacer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDeshacer.Click += new System.EventHandler(this.btnDeshacer_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(54, 33);
            this.btnModificar.Text = "&Modificar";
            this.btnModificar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnModificar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnOpcImp
            // 
            this.btnOpcImp.Image = ((System.Drawing.Image)(resources.GetObject("btnOpcImp.Image")));
            this.btnOpcImp.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnOpcImp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpcImp.Name = "btnOpcImp";
            this.btnOpcImp.Size = new System.Drawing.Size(67, 33);
            this.btnOpcImp.Text = "Opc. &Imp...";
            this.btnOpcImp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnOpcImp.Click += new System.EventHandler(this.btnOpcImp_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 36);
            // 
            // btnAprobar
            // 
            this.btnAprobar.Image = ((System.Drawing.Image)(resources.GetObject("btnAprobar.Image")));
            this.btnAprobar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAprobar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAprobar.Name = "btnAprobar";
            this.btnAprobar.Size = new System.Drawing.Size(50, 33);
            this.btnAprobar.Text = "A&probar";
            this.btnAprobar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAprobar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAprobar.Click += new System.EventHandler(this.btnAprobar_Click);
            // 
            // btnMigrarSAP
            // 
            this.btnMigrarSAP.Image = ((System.Drawing.Image)(resources.GetObject("btnMigrarSAP.Image")));
            this.btnMigrarSAP.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMigrarSAP.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMigrarSAP.Name = "btnMigrarSAP";
            this.btnMigrarSAP.Size = new System.Drawing.Size(63, 33);
            this.btnMigrarSAP.Text = "Migrar &SAP";
            this.btnMigrarSAP.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMigrarSAP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMigrarSAP.Click += new System.EventHandler(this.btnMigrarSAP_Click);
            // 
            // btnDuplicar
            // 
            this.btnDuplicar.Image = ((System.Drawing.Image)(resources.GetObject("btnDuplicar.Image")));
            this.btnDuplicar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDuplicar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDuplicar.Name = "btnDuplicar";
            this.btnDuplicar.Size = new System.Drawing.Size(49, 33);
            this.btnDuplicar.Text = "D&uplicar";
            this.btnDuplicar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDuplicar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDuplicar.Click += new System.EventHandler(this.btnDuplicar_Click);
            // 
            // tbpArtCom
            // 
            this.tbpArtCom.Controls.Add(this.btnAgrCom);
            this.tbpArtCom.Controls.Add(this.btnCanCom);
            this.tbpArtCom.Controls.Add(this.btnBorCom);
            this.tbpArtCom.Controls.Add(this.lblInfoItem);
            this.tbpArtCom.Controls.Add(this.fgCom);
            this.tbpArtCom.Controls.Add(this.fgDet);
            this.tbpArtCom.Controls.Add(this.txtDesc);
            this.tbpArtCom.Controls.Add(this.label32);
            this.tbpArtCom.Controls.Add(this.txtPorDes);
            this.tbpArtCom.Controls.Add(this.btnAgrItem);
            this.tbpArtCom.Controls.Add(this.txtSim);
            this.tbpArtCom.Controls.Add(this.txtSubTot);
            this.tbpArtCom.Controls.Add(this.label28);
            this.tbpArtCom.Controls.Add(this.txtIGV);
            this.tbpArtCom.Controls.Add(this.lblIGVUnit);
            this.tbpArtCom.Controls.Add(this.txtValNet);
            this.tbpArtCom.Controls.Add(this.label26);
            this.tbpArtCom.Controls.Add(this.txtVenBru);
            this.tbpArtCom.Controls.Add(this.label25);
            this.tbpArtCom.Controls.Add(this.txtCan);
            this.tbpArtCom.Controls.Add(this.label24);
            this.tbpArtCom.Controls.Add(this.label23);
            this.tbpArtCom.Controls.Add(this.label22);
            this.tbpArtCom.Controls.Add(this.label21);
            this.tbpArtCom.Controls.Add(this.label20);
            this.tbpArtCom.Controls.Add(this.txtPrecio);
            this.tbpArtCom.Controls.Add(this.txtDes);
            this.tbpArtCom.Controls.Add(this.txtCodArtCom);
            this.tbpArtCom.Controls.Add(this.tbAmb);
            this.tbpArtCom.Controls.Add(this.btnModItem);
            this.tbpArtCom.Controls.Add(this.btnBorItem);
            this.tbpArtCom.Controls.Add(this.btnCanItem);
            this.tbpArtCom.Location = new System.Drawing.Point(4, 22);
            this.tbpArtCom.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbpArtCom.Name = "tbpArtCom";
            this.tbpArtCom.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbpArtCom.Size = new System.Drawing.Size(1319, 596);
            this.tbpArtCom.TabIndex = 1;
            this.tbpArtCom.Text = "2. Articulo Compuesto";
            this.tbpArtCom.UseVisualStyleBackColor = true;
            this.tbpArtCom.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnAgrCom
            // 
            this.btnAgrCom.Location = new System.Drawing.Point(8, 552);
            this.btnAgrCom.Name = "btnAgrCom";
            this.btnAgrCom.Size = new System.Drawing.Size(70, 23);
            this.btnAgrCom.TabIndex = 32;
            this.btnAgrCom.Text = "Agregar";
            this.btnAgrCom.UseVisualStyleBackColor = true;
            this.btnAgrCom.Click += new System.EventHandler(this.btnAgrCom_Click);
            // 
            // btnCanCom
            // 
            this.btnCanCom.Location = new System.Drawing.Point(143, 552);
            this.btnCanCom.Name = "btnCanCom";
            this.btnCanCom.Size = new System.Drawing.Size(70, 23);
            this.btnCanCom.TabIndex = 33;
            this.btnCanCom.Text = "Cantidad";
            this.btnCanCom.UseVisualStyleBackColor = true;
            this.btnCanCom.Click += new System.EventHandler(this.btnCanCom_Click);
            // 
            // btnBorCom
            // 
            this.btnBorCom.Location = new System.Drawing.Point(75, 552);
            this.btnBorCom.Name = "btnBorCom";
            this.btnBorCom.Size = new System.Drawing.Size(70, 23);
            this.btnBorCom.TabIndex = 34;
            this.btnBorCom.Text = "Borrar";
            this.btnBorCom.UseVisualStyleBackColor = true;
            this.btnBorCom.Click += new System.EventHandler(this.btnBorCom_Click);
            // 
            // lblInfoItem
            // 
            this.lblInfoItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoItem.ForeColor = System.Drawing.Color.Red;
            this.lblInfoItem.Location = new System.Drawing.Point(978, 31);
            this.lblInfoItem.Name = "lblInfoItem";
            this.lblInfoItem.Size = new System.Drawing.Size(105, 22);
            this.lblInfoItem.TabIndex = 31;
            // 
            // fgCom
            // 
            this.fgCom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgCom.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.XpThemes;
            this.fgCom.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgCom.Location = new System.Drawing.Point(216, 440);
            this.fgCom.Name = "fgCom";
            this.fgCom.Rows.Count = 1;
            this.fgCom.Rows.DefaultSize = 19;
            this.fgCom.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgCom.Size = new System.Drawing.Size(1050, 135);
            this.fgCom.TabIndex = 30;
            this.fgCom.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgCom_StartEdit);
            this.fgCom.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgCom_AfterEdit);
            this.fgCom.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgCom_KeyPressEdit);
            this.fgCom.Click += new System.EventHandler(this.fgCom_Click);
            // 
            // fgDet
            // 
            this.fgDet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgDet.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.XpThemes;
            this.fgDet.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgDet.Location = new System.Drawing.Point(217, 130);
            this.fgDet.Name = "fgDet";
            this.fgDet.Rows.Count = 1;
            this.fgDet.Rows.DefaultSize = 19;
            this.fgDet.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgDet.Size = new System.Drawing.Size(1049, 302);
            this.fgDet.TabIndex = 29;
            this.fgDet.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgDet_KeyPressEdit);
            this.fgDet.Click += new System.EventHandler(this.fgDet_Click);
            // 
            // txtDesc
            // 
            this.txtDesc.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDesc.Location = new System.Drawing.Point(512, 53);
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.ReadOnly = true;
            this.txtDesc.Size = new System.Drawing.Size(68, 21);
            this.txtDesc.TabIndex = 28;
            this.txtDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(479, 57);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(34, 13);
            this.label32.TabIndex = 27;
            this.label32.Text = "Desc:";
            // 
            // txtPorDes
            // 
            this.txtPorDes.Location = new System.Drawing.Point(431, 53);
            this.txtPorDes.Name = "txtPorDes";
            this.txtPorDes.Size = new System.Drawing.Size(37, 21);
            this.txtPorDes.TabIndex = 26;
            this.txtPorDes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPorDes.TextChanged += new System.EventHandler(this.txtPorDes_TextChanged);
            this.txtPorDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPorDes_KeyPress);
            this.txtPorDes.Leave += new System.EventHandler(this.txtPorDes_Leave);
            // 
            // btnAgrItem
            // 
            this.btnAgrItem.Location = new System.Drawing.Point(215, 103);
            this.btnAgrItem.Name = "btnAgrItem";
            this.btnAgrItem.Size = new System.Drawing.Size(92, 23);
            this.btnAgrItem.TabIndex = 19;
            this.btnAgrItem.Text = "Agregar Item";
            this.btnAgrItem.UseVisualStyleBackColor = true;
            this.btnAgrItem.Click += new System.EventHandler(this.btnAgrItem_Click);
            // 
            // txtSim
            // 
            this.txtSim.Location = new System.Drawing.Point(903, 27);
            this.txtSim.Name = "txtSim";
            this.txtSim.Size = new System.Drawing.Size(64, 21);
            this.txtSim.TabIndex = 4;
            // 
            // txtSubTot
            // 
            this.txtSubTot.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSubTot.Location = new System.Drawing.Point(903, 53);
            this.txtSubTot.Name = "txtSubTot";
            this.txtSubTot.ReadOnly = true;
            this.txtSubTot.Size = new System.Drawing.Size(64, 21);
            this.txtSubTot.TabIndex = 18;
            this.txtSubTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(847, 57);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(56, 13);
            this.label28.TabIndex = 17;
            this.label28.Text = "Sub Total:";
            // 
            // txtIGV
            // 
            this.txtIGV.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtIGV.Location = new System.Drawing.Point(778, 53);
            this.txtIGV.Name = "txtIGV";
            this.txtIGV.ReadOnly = true;
            this.txtIGV.Size = new System.Drawing.Size(65, 21);
            this.txtIGV.TabIndex = 16;
            this.txtIGV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblIGVUnit
            // 
            this.lblIGVUnit.Location = new System.Drawing.Point(724, 56);
            this.lblIGVUnit.Name = "lblIGVUnit";
            this.lblIGVUnit.Size = new System.Drawing.Size(58, 13);
            this.lblIGVUnit.TabIndex = 15;
            // 
            // txtValNet
            // 
            this.txtValNet.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtValNet.Location = new System.Drawing.Point(648, 53);
            this.txtValNet.Name = "txtValNet";
            this.txtValNet.ReadOnly = true;
            this.txtValNet.Size = new System.Drawing.Size(68, 21);
            this.txtValNet.TabIndex = 14;
            this.txtValNet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(383, 57);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 13);
            this.label26.TabIndex = 11;
            this.label26.Text = "Desc.%:";
            // 
            // txtVenBru
            // 
            this.txtVenBru.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtVenBru.Location = new System.Drawing.Point(307, 53);
            this.txtVenBru.Name = "txtVenBru";
            this.txtVenBru.ReadOnly = true;
            this.txtVenBru.Size = new System.Drawing.Size(66, 21);
            this.txtVenBru.TabIndex = 10;
            this.txtVenBru.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(259, 57);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(50, 13);
            this.label25.TabIndex = 9;
            this.label25.Text = "V. Bruta:";
            // 
            // txtCan
            // 
            this.txtCan.Location = new System.Drawing.Point(215, 53);
            this.txtCan.Name = "txtCan";
            this.txtCan.Size = new System.Drawing.Size(37, 21);
            this.txtCan.TabIndex = 8;
            this.txtCan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCan.TextChanged += new System.EventHandler(this.txtCan_TextChanged);
            this.txtCan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCan_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(586, 57);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 13);
            this.label24.TabIndex = 13;
            this.label24.Text = "Valor Neto:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(180, 57);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(34, 13);
            this.label23.TabIndex = 7;
            this.label23.Text = "Cant:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(29, 57);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(62, 13);
            this.label22.TabIndex = 5;
            this.label22.Text = "Precio Unit:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(859, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Simbolo:";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(33, 29);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Art. Comp:";
            // 
            // txtPrecio
            // 
            this.txtPrecio.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtPrecio.Location = new System.Drawing.Point(99, 53);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.ReadOnly = true;
            this.txtPrecio.Size = new System.Drawing.Size(70, 21);
            this.txtPrecio.TabIndex = 6;
            this.txtPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDes
            // 
            this.txtDes.Location = new System.Drawing.Point(171, 27);
            this.txtDes.MaxLength = 100;
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(671, 21);
            this.txtDes.TabIndex = 2;
            this.txtDes.TextChanged += new System.EventHandler(this.txtDes_TextChanged);
            this.txtDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDes_KeyPress);
            // 
            // txtCodArtCom
            // 
            this.txtCodArtCom.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodArtCom.Location = new System.Drawing.Point(99, 27);
            this.txtCodArtCom.MaxLength = 6;
            this.txtCodArtCom.Name = "txtCodArtCom";
            this.txtCodArtCom.Size = new System.Drawing.Size(70, 21);
            this.txtCodArtCom.TabIndex = 1;
            this.txtCodArtCom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodArtCom.TextChanged += new System.EventHandler(this.txtCodArtCom_TextChanged);
            this.txtCodArtCom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArtCom_KeyPress);
            // 
            // tbAmb
            // 
            this.tbAmb.Controls.Add(this.tbpAmb);
            this.tbAmb.Controls.Add(this.tbpObs);
            this.tbAmb.Location = new System.Drawing.Point(8, 106);
            this.tbAmb.Name = "tbAmb";
            this.tbAmb.SelectedIndex = 0;
            this.tbAmb.Size = new System.Drawing.Size(207, 360);
            this.tbAmb.TabIndex = 23;
            // 
            // tbpAmb
            // 
            this.tbpAmb.Controls.Add(this.lblAmbTot);
            this.tbpAmb.Controls.Add(this.label63);
            this.tbpAmb.Controls.Add(this.fgAmb);
            this.tbpAmb.Controls.Add(this.btnAgrAmb);
            this.tbpAmb.Controls.Add(this.btnEliAmb);
            this.tbpAmb.Controls.Add(this.label31);
            this.tbpAmb.Controls.Add(this.label30);
            this.tbpAmb.Controls.Add(this.label29);
            this.tbpAmb.Controls.Add(this.txtCodAmb);
            this.tbpAmb.Controls.Add(this.txtCanAmb);
            this.tbpAmb.Controls.Add(this.txtAmb);
            this.tbpAmb.Location = new System.Drawing.Point(4, 22);
            this.tbpAmb.Name = "tbpAmb";
            this.tbpAmb.Padding = new System.Windows.Forms.Padding(3);
            this.tbpAmb.Size = new System.Drawing.Size(199, 334);
            this.tbpAmb.TabIndex = 0;
            this.tbpAmb.Text = "Ambientes";
            this.tbpAmb.UseVisualStyleBackColor = true;
            // 
            // lblAmbTot
            // 
            this.lblAmbTot.ForeColor = System.Drawing.Color.Red;
            this.lblAmbTot.Location = new System.Drawing.Point(150, 310);
            this.lblAmbTot.Name = "lblAmbTot";
            this.lblAmbTot.Size = new System.Drawing.Size(35, 13);
            this.lblAmbTot.TabIndex = 11;
            this.lblAmbTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.ForeColor = System.Drawing.Color.Red;
            this.label63.Location = new System.Drawing.Point(120, 310);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 13);
            this.label63.TabIndex = 10;
            this.label63.Text = "Total:";
            // 
            // fgAmb
            // 
            this.fgAmb.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.XpThemes;
            this.fgAmb.ColumnInfo = "1,1,0,0,0,95,Columns:";
            this.fgAmb.Location = new System.Drawing.Point(7, 80);
            this.fgAmb.Name = "fgAmb";
            this.fgAmb.Rows.Count = 1;
            this.fgAmb.Rows.DefaultSize = 19;
            this.fgAmb.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgAmb.Size = new System.Drawing.Size(183, 224);
            this.fgAmb.TabIndex = 9;
            this.fgAmb.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgAmb_KeyPressEdit);
            this.fgAmb.AfterAddRow += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgAmb_AfterAddRow);
            this.fgAmb.DoubleClick += new System.EventHandler(this.fgAmb_DoubleClick);
            // 
            // btnAgrAmb
            // 
            this.btnAgrAmb.Location = new System.Drawing.Point(6, 53);
            this.btnAgrAmb.Name = "btnAgrAmb";
            this.btnAgrAmb.Size = new System.Drawing.Size(92, 21);
            this.btnAgrAmb.TabIndex = 7;
            this.btnAgrAmb.Text = "Agregar";
            this.btnAgrAmb.UseVisualStyleBackColor = true;
            this.btnAgrAmb.Click += new System.EventHandler(this.btnAgrAmb_Click);
            // 
            // btnEliAmb
            // 
            this.btnEliAmb.Location = new System.Drawing.Point(97, 53);
            this.btnEliAmb.Name = "btnEliAmb";
            this.btnEliAmb.Size = new System.Drawing.Size(92, 21);
            this.btnEliAmb.TabIndex = 8;
            this.btnEliAmb.Text = "Eliminar";
            this.btnEliAmb.UseVisualStyleBackColor = true;
            this.btnEliAmb.Click += new System.EventHandler(this.btnEliAmb_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(156, 10);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(34, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = "Cant.";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(46, 10);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 13);
            this.label30.TabIndex = 1;
            this.label30.Text = "Ambiente:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 10);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Cod.";
            // 
            // txtCodAmb
            // 
            this.txtCodAmb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodAmb.Location = new System.Drawing.Point(8, 26);
            this.txtCodAmb.Name = "txtCodAmb";
            this.txtCodAmb.ReadOnly = true;
            this.txtCodAmb.Size = new System.Drawing.Size(36, 21);
            this.txtCodAmb.TabIndex = 3;
            // 
            // txtCanAmb
            // 
            this.txtCanAmb.Location = new System.Drawing.Point(158, 26);
            this.txtCanAmb.Name = "txtCanAmb";
            this.txtCanAmb.Size = new System.Drawing.Size(28, 21);
            this.txtCanAmb.TabIndex = 5;
            this.txtCanAmb.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCanAmb.TextChanged += new System.EventHandler(this.txtCanAmb_TextChanged);
            this.txtCanAmb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCanAmb_KeyPress);
            // 
            // txtAmb
            // 
            this.txtAmb.Location = new System.Drawing.Point(45, 26);
            this.txtAmb.Name = "txtAmb";
            this.txtAmb.Size = new System.Drawing.Size(112, 21);
            this.txtAmb.TabIndex = 4;
            this.txtAmb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmb_KeyPress);
            // 
            // tbpObs
            // 
            this.tbpObs.Controls.Add(this.txtObs);
            this.tbpObs.Location = new System.Drawing.Point(4, 22);
            this.tbpObs.Name = "tbpObs";
            this.tbpObs.Padding = new System.Windows.Forms.Padding(3);
            this.tbpObs.Size = new System.Drawing.Size(199, 334);
            this.tbpObs.TabIndex = 1;
            this.tbpObs.Text = "Observ.";
            this.tbpObs.UseVisualStyleBackColor = true;
            // 
            // txtObs
            // 
            this.txtObs.Location = new System.Drawing.Point(9, 9);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(179, 287);
            this.txtObs.TabIndex = 0;
            // 
            // btnModItem
            // 
            this.btnModItem.Location = new System.Drawing.Point(305, 103);
            this.btnModItem.Name = "btnModItem";
            this.btnModItem.Size = new System.Drawing.Size(92, 23);
            this.btnModItem.TabIndex = 20;
            this.btnModItem.Text = "Modificar Item";
            this.btnModItem.UseVisualStyleBackColor = true;
            this.btnModItem.Click += new System.EventHandler(this.btnModItem_Click);
            // 
            // btnBorItem
            // 
            this.btnBorItem.Location = new System.Drawing.Point(395, 103);
            this.btnBorItem.Name = "btnBorItem";
            this.btnBorItem.Size = new System.Drawing.Size(92, 23);
            this.btnBorItem.TabIndex = 21;
            this.btnBorItem.Text = "Borrar Item";
            this.btnBorItem.UseVisualStyleBackColor = true;
            this.btnBorItem.Click += new System.EventHandler(this.btnBorItem_Click);
            // 
            // btnCanItem
            // 
            this.btnCanItem.Location = new System.Drawing.Point(485, 103);
            this.btnCanItem.Name = "btnCanItem";
            this.btnCanItem.Size = new System.Drawing.Size(92, 23);
            this.btnCanItem.TabIndex = 22;
            this.btnCanItem.Text = "Cancelar Item";
            this.btnCanItem.UseVisualStyleBackColor = true;
            this.btnCanItem.Click += new System.EventHandler(this.btnCanItem_Click);
            // 
            // tbpOtrArt
            // 
            this.tbpOtrArt.Controls.Add(this.panel1);
            this.tbpOtrArt.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbpOtrArt.Location = new System.Drawing.Point(4, 22);
            this.tbpOtrArt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbpOtrArt.Name = "tbpOtrArt";
            this.tbpOtrArt.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbpOtrArt.Size = new System.Drawing.Size(1319, 596);
            this.tbpOtrArt.TabIndex = 2;
            this.tbpOtrArt.Text = "3. Articulo Compuesto sin código";
            this.tbpOtrArt.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.btnCanItemAA);
            this.panel1.Controls.Add(this.btnBorItemAA);
            this.panel1.Controls.Add(this.txtRutImaTec);
            this.panel1.Controls.Add(this.btnRutImaTec);
            this.panel1.Controls.Add(this.label78);
            this.panel1.Controls.Add(this.txtRutIma2);
            this.panel1.Controls.Add(this.btnRutIma2);
            this.panel1.Controls.Add(this.label77);
            this.panel1.Controls.Add(this.fgDetAA);
            this.panel1.Controls.Add(this.txtAmbAA);
            this.panel1.Controls.Add(this.txtSubTotAA);
            this.panel1.Controls.Add(this.txtIGVAA);
            this.panel1.Controls.Add(this.txtValNetAA);
            this.panel1.Controls.Add(this.txtRutIma);
            this.panel1.Controls.Add(this.btnRutIma);
            this.panel1.Controls.Add(this.txtDescAA);
            this.panel1.Controls.Add(this.txtPorDesAA);
            this.panel1.Controls.Add(this.txtPreUniAA);
            this.panel1.Controls.Add(this.txtDesAA);
            this.panel1.Controls.Add(this.txtCanAA);
            this.panel1.Controls.Add(this.txtCodAmbAA);
            this.panel1.Controls.Add(this.btnModItemAA);
            this.panel1.Controls.Add(this.btnAgrAA);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.lblIGVUnitAA);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.txtObsAA);
            this.panel1.Controls.Add(this.txtVenBruAA);
            this.panel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.panel1.Location = new System.Drawing.Point(10, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1303, 579);
            this.panel1.TabIndex = 0;
            // 
            // btnCanItemAA
            // 
            this.btnCanItemAA.Location = new System.Drawing.Point(965, 157);
            this.btnCanItemAA.Name = "btnCanItemAA";
            this.btnCanItemAA.Size = new System.Drawing.Size(105, 21);
            this.btnCanItemAA.TabIndex = 17;
            this.btnCanItemAA.Text = "Cancelar Item";
            this.btnCanItemAA.UseVisualStyleBackColor = true;
            this.btnCanItemAA.Click += new System.EventHandler(this.btnCanItemAA_Click);
            // 
            // btnBorItemAA
            // 
            this.btnBorItemAA.Location = new System.Drawing.Point(862, 157);
            this.btnBorItemAA.Name = "btnBorItemAA";
            this.btnBorItemAA.Size = new System.Drawing.Size(105, 21);
            this.btnBorItemAA.TabIndex = 38;
            this.btnBorItemAA.Text = "Borrar Item";
            this.btnBorItemAA.UseVisualStyleBackColor = true;
            this.btnBorItemAA.Click += new System.EventHandler(this.btnBorItemAA_Click);
            // 
            // txtRutImaTec
            // 
            this.txtRutImaTec.Location = new System.Drawing.Point(783, 68);
            this.txtRutImaTec.Name = "txtRutImaTec";
            this.txtRutImaTec.Size = new System.Drawing.Size(258, 21);
            this.txtRutImaTec.TabIndex = 35;
            this.txtRutImaTec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRutImaTec_KeyPress);
            // 
            // btnRutImaTec
            // 
            this.btnRutImaTec.Location = new System.Drawing.Point(1041, 68);
            this.btnRutImaTec.Name = "btnRutImaTec";
            this.btnRutImaTec.Size = new System.Drawing.Size(28, 21);
            this.btnRutImaTec.TabIndex = 36;
            this.btnRutImaTec.Text = "...";
            this.btnRutImaTec.UseVisualStyleBackColor = true;
            this.btnRutImaTec.Click += new System.EventHandler(this.btnRutImaTec_Click);
            // 
            // label78
            // 
            this.label78.Location = new System.Drawing.Point(730, 64);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(55, 27);
            this.label78.TabIndex = 37;
            this.label78.Text = "Ruta Img. Tecnica:";
            // 
            // txtRutIma2
            // 
            this.txtRutIma2.Location = new System.Drawing.Point(435, 68);
            this.txtRutIma2.Name = "txtRutIma2";
            this.txtRutIma2.Size = new System.Drawing.Size(258, 21);
            this.txtRutIma2.TabIndex = 32;
            this.txtRutIma2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRutIma2_KeyPress);
            // 
            // btnRutIma2
            // 
            this.btnRutIma2.Location = new System.Drawing.Point(693, 68);
            this.btnRutIma2.Name = "btnRutIma2";
            this.btnRutIma2.Size = new System.Drawing.Size(28, 21);
            this.btnRutIma2.TabIndex = 33;
            this.btnRutIma2.Text = "...";
            this.btnRutIma2.UseVisualStyleBackColor = true;
            this.btnRutIma2.Click += new System.EventHandler(this.btnRutIma2_Click);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(376, 71);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(61, 13);
            this.label77.TabIndex = 34;
            this.label77.Text = "Ruta Img2:";
            // 
            // fgDetAA
            // 
            this.fgDetAA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgDetAA.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgDetAA.Location = new System.Drawing.Point(12, 185);
            this.fgDetAA.Name = "fgDetAA";
            this.fgDetAA.Rows.Count = 1;
            this.fgDetAA.Rows.DefaultSize = 19;
            this.fgDetAA.Size = new System.Drawing.Size(1280, 369);
            this.fgDetAA.TabIndex = 14;
            this.fgDetAA.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgDetAA_KeyPressEdit);
            this.fgDetAA.Click += new System.EventHandler(this.fgDetAA_Click);
            this.fgDetAA.DoubleClick += new System.EventHandler(this.fgDetAA_DoubleClick);
            this.fgDetAA.Enter += new System.EventHandler(this.fgDetAA_Enter);
            this.fgDetAA.Leave += new System.EventHandler(this.fgDetAA_Leave);
            // 
            // txtAmbAA
            // 
            this.txtAmbAA.Location = new System.Drawing.Point(783, 15);
            this.txtAmbAA.Name = "txtAmbAA";
            this.txtAmbAA.Size = new System.Drawing.Size(288, 21);
            this.txtAmbAA.TabIndex = 2;
            this.txtAmbAA.TextChanged += new System.EventHandler(this.txtAmbAA_TextChanged);
            this.txtAmbAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmbAA_KeyPress);
            // 
            // txtSubTotAA
            // 
            this.txtSubTotAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSubTotAA.Location = new System.Drawing.Point(1011, 42);
            this.txtSubTotAA.Name = "txtSubTotAA";
            this.txtSubTotAA.ReadOnly = true;
            this.txtSubTotAA.Size = new System.Drawing.Size(60, 21);
            this.txtSubTotAA.TabIndex = 10;
            this.txtSubTotAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSubTotAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSubTotAA_KeyPress);
            // 
            // txtIGVAA
            // 
            this.txtIGVAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtIGVAA.Location = new System.Drawing.Point(866, 43);
            this.txtIGVAA.Name = "txtIGVAA";
            this.txtIGVAA.ReadOnly = true;
            this.txtIGVAA.Size = new System.Drawing.Size(60, 21);
            this.txtIGVAA.TabIndex = 9;
            this.txtIGVAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIGVAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIGVAA_KeyPress);
            // 
            // txtValNetAA
            // 
            this.txtValNetAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtValNetAA.Location = new System.Drawing.Point(720, 42);
            this.txtValNetAA.Name = "txtValNetAA";
            this.txtValNetAA.ReadOnly = true;
            this.txtValNetAA.Size = new System.Drawing.Size(60, 21);
            this.txtValNetAA.TabIndex = 8;
            this.txtValNetAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtRutIma
            // 
            this.txtRutIma.Location = new System.Drawing.Point(71, 68);
            this.txtRutIma.Name = "txtRutIma";
            this.txtRutIma.Size = new System.Drawing.Size(258, 21);
            this.txtRutIma.TabIndex = 11;
            this.txtRutIma.TextChanged += new System.EventHandler(this.txtRutIma_TextChanged);
            this.txtRutIma.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRutIma_KeyPress);
            // 
            // btnRutIma
            // 
            this.btnRutIma.Location = new System.Drawing.Point(329, 68);
            this.btnRutIma.Name = "btnRutIma";
            this.btnRutIma.Size = new System.Drawing.Size(28, 21);
            this.btnRutIma.TabIndex = 12;
            this.btnRutIma.Text = "...";
            this.btnRutIma.UseVisualStyleBackColor = true;
            this.btnRutIma.Click += new System.EventHandler(this.btnRuta_Click);
            // 
            // txtDescAA
            // 
            this.txtDescAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDescAA.Location = new System.Drawing.Point(586, 42);
            this.txtDescAA.Name = "txtDescAA";
            this.txtDescAA.ReadOnly = true;
            this.txtDescAA.Size = new System.Drawing.Size(60, 21);
            this.txtDescAA.TabIndex = 7;
            this.txtDescAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDescAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDescAA_KeyPress);
            // 
            // txtPorDesAA
            // 
            this.txtPorDesAA.Location = new System.Drawing.Point(455, 42);
            this.txtPorDesAA.Name = "txtPorDesAA";
            this.txtPorDesAA.Size = new System.Drawing.Size(60, 21);
            this.txtPorDesAA.TabIndex = 6;
            this.txtPorDesAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPorDesAA.TextChanged += new System.EventHandler(this.txtPorDesAA_TextChanged);
            this.txtPorDesAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPorDesAA_KeyPress);
            this.txtPorDesAA.Leave += new System.EventHandler(this.txtPorDesAA_Leave);
            // 
            // txtPreUniAA
            // 
            this.txtPreUniAA.Location = new System.Drawing.Point(198, 42);
            this.txtPreUniAA.Name = "txtPreUniAA";
            this.txtPreUniAA.Size = new System.Drawing.Size(60, 21);
            this.txtPreUniAA.TabIndex = 4;
            this.txtPreUniAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPreUniAA.TextChanged += new System.EventHandler(this.txtPreUniAA_TextChanged);
            this.txtPreUniAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPreUniAA_KeyPress);
            // 
            // txtDesAA
            // 
            this.txtDesAA.Location = new System.Drawing.Point(71, 15);
            this.txtDesAA.Name = "txtDesAA";
            this.txtDesAA.Size = new System.Drawing.Size(575, 21);
            this.txtDesAA.TabIndex = 0;
            this.txtDesAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesAA_KeyPress);
            // 
            // txtCanAA
            // 
            this.txtCanAA.Location = new System.Drawing.Point(71, 42);
            this.txtCanAA.Name = "txtCanAA";
            this.txtCanAA.Size = new System.Drawing.Size(60, 21);
            this.txtCanAA.TabIndex = 3;
            this.txtCanAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCanAA.TextChanged += new System.EventHandler(this.txtCanAA_TextChanged);
            this.txtCanAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCanAA_KeyPress);
            // 
            // txtCodAmbAA
            // 
            this.txtCodAmbAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodAmbAA.Location = new System.Drawing.Point(720, 15);
            this.txtCodAmbAA.Name = "txtCodAmbAA";
            this.txtCodAmbAA.ReadOnly = true;
            this.txtCodAmbAA.Size = new System.Drawing.Size(60, 21);
            this.txtCodAmbAA.TabIndex = 1;
            this.txtCodAmbAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnModItemAA
            // 
            this.btnModItemAA.Location = new System.Drawing.Point(759, 157);
            this.btnModItemAA.Name = "btnModItemAA";
            this.btnModItemAA.Size = new System.Drawing.Size(105, 21);
            this.btnModItemAA.TabIndex = 15;
            this.btnModItemAA.Text = "Modificar Item";
            this.btnModItemAA.UseVisualStyleBackColor = true;
            this.btnModItemAA.Click += new System.EventHandler(this.btnModItemAA_Click);
            // 
            // btnAgrAA
            // 
            this.btnAgrAA.Location = new System.Drawing.Point(656, 157);
            this.btnAgrAA.Name = "btnAgrAA";
            this.btnAgrAA.Size = new System.Drawing.Size(105, 21);
            this.btnAgrAA.TabIndex = 14;
            this.btnAgrAA.Text = "Agregar Item";
            this.btnAgrAA.UseVisualStyleBackColor = true;
            this.btnAgrAA.Click += new System.EventHandler(this.btnAgrAA_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(662, 46);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(61, 13);
            this.label42.TabIndex = 25;
            this.label42.Text = "Valor Neto:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(411, 45);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(48, 13);
            this.label43.TabIndex = 24;
            this.label43.Text = "Desc %:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(158, 46);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(43, 13);
            this.label44.TabIndex = 23;
            this.label44.Text = "P. Unit:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(26, 18);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(47, 13);
            this.label45.TabIndex = 22;
            this.label45.Text = "Articulo:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(956, 46);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(56, 13);
            this.label38.TabIndex = 21;
            this.label38.Text = "Sub Total:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(18, 71);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 13);
            this.label39.TabIndex = 20;
            this.label39.Text = "Ruta Img:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(278, 45);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(50, 13);
            this.label40.TabIndex = 19;
            this.label40.Text = "V. Bruta:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(41, 97);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(30, 13);
            this.label41.TabIndex = 18;
            this.label41.Text = "Obs:";
            // 
            // lblIGVUnitAA
            // 
            this.lblIGVUnitAA.AutoSize = true;
            this.lblIGVUnitAA.Location = new System.Drawing.Point(814, 45);
            this.lblIGVUnitAA.Name = "lblIGVUnitAA";
            this.lblIGVUnitAA.Size = new System.Drawing.Size(54, 13);
            this.lblIGVUnitAA.TabIndex = 17;
            this.lblIGVUnitAA.Text = "IGV 18%:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(550, 46);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(38, 13);
            this.label36.TabIndex = 16;
            this.label36.Text = "Dscto:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(19, 46);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(54, 13);
            this.label35.TabIndex = 15;
            this.label35.Text = "Cantidad:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(666, 18);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(56, 13);
            this.label27.TabIndex = 14;
            this.label27.Text = "Ambiente:";
            // 
            // txtObsAA
            // 
            this.txtObsAA.Location = new System.Drawing.Point(71, 97);
            this.txtObsAA.Multiline = true;
            this.txtObsAA.Name = "txtObsAA";
            this.txtObsAA.Size = new System.Drawing.Size(1000, 53);
            this.txtObsAA.TabIndex = 13;
            this.txtObsAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtObsAA_KeyPress);
            // 
            // txtVenBruAA
            // 
            this.txtVenBruAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtVenBruAA.Location = new System.Drawing.Point(328, 42);
            this.txtVenBruAA.Name = "txtVenBruAA";
            this.txtVenBruAA.ReadOnly = true;
            this.txtVenBruAA.Size = new System.Drawing.Size(60, 21);
            this.txtVenBruAA.TabIndex = 5;
            this.txtVenBruAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtVenBruAA.TextChanged += new System.EventHandler(this.txtVenBruAA_TextChanged);
            this.txtVenBruAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVenBruAA_KeyPress);
            // 
            // tbpEnc
            // 
            this.tbpEnc.AutoScroll = true;
            this.tbpEnc.Controls.Add(this.grpObs);
            this.tbpEnc.Controls.Add(this.grbInfRec);
            this.tbpEnc.Controls.Add(this.txtNomAdi);
            this.tbpEnc.Controls.Add(this.label61);
            this.tbpEnc.Controls.Add(this.txtMot);
            this.tbpEnc.Controls.Add(this.txtRec);
            this.tbpEnc.Controls.Add(this.label15);
            this.tbpEnc.Controls.Add(this.txtCodMot);
            this.tbpEnc.Controls.Add(this.txtCodRec);
            this.tbpEnc.Controls.Add(this.label58);
            this.tbpEnc.Controls.Add(this.btnDirObr);
            this.tbpEnc.Controls.Add(this.btnDirCli);
            this.tbpEnc.Controls.Add(this.txtCodTipDoc);
            this.tbpEnc.Controls.Add(this.txtDocEntry);
            this.tbpEnc.Controls.Add(this.label19);
            this.tbpEnc.Controls.Add(this.txtDocNum);
            this.tbpEnc.Controls.Add(this.label18);
            this.tbpEnc.Controls.Add(this.txtRUCDNI);
            this.tbpEnc.Controls.Add(this.label17);
            this.tbpEnc.Controls.Add(this.txtEmail);
            this.tbpEnc.Controls.Add(this.label16);
            this.tbpEnc.Controls.Add(this.txtCli);
            this.tbpEnc.Controls.Add(this.btnVinRQ);
            this.tbpEnc.Controls.Add(this.txtTipVen);
            this.tbpEnc.Controls.Add(this.txtCenVen);
            this.tbpEnc.Controls.Add(this.txtVen);
            this.tbpEnc.Controls.Add(this.txtCliCon);
            this.tbpEnc.Controls.Add(this.txtDim);
            this.tbpEnc.Controls.Add(this.txtTipObr);
            this.tbpEnc.Controls.Add(this.txtRub);
            this.tbpEnc.Controls.Add(this.txtTipVenRel);
            this.tbpEnc.Controls.Add(this.txtCodTipVen);
            this.tbpEnc.Controls.Add(this.txtCodCenVen);
            this.tbpEnc.Controls.Add(this.txtCodVen);
            this.tbpEnc.Controls.Add(this.txtCodCliCon);
            this.tbpEnc.Controls.Add(this.txtDirObr);
            this.tbpEnc.Controls.Add(this.txtDirCli);
            this.tbpEnc.Controls.Add(this.txtTel);
            this.tbpEnc.Controls.Add(this.txtCodCli);
            this.tbpEnc.Controls.Add(this.txtNomCot);
            this.tbpEnc.Controls.Add(this.txtRQ);
            this.tbpEnc.Controls.Add(this.label14);
            this.tbpEnc.Controls.Add(this.label13);
            this.tbpEnc.Controls.Add(this.label12);
            this.tbpEnc.Controls.Add(this.label11);
            this.tbpEnc.Controls.Add(this.label10);
            this.tbpEnc.Controls.Add(this.label9);
            this.tbpEnc.Controls.Add(this.label8);
            this.tbpEnc.Controls.Add(this.label7);
            this.tbpEnc.Controls.Add(this.label6);
            this.tbpEnc.Controls.Add(this.label5);
            this.tbpEnc.Controls.Add(this.label4);
            this.tbpEnc.Controls.Add(this.label3);
            this.tbpEnc.Controls.Add(this.label2);
            this.tbpEnc.Controls.Add(this.label1);
            this.tbpEnc.Controls.Add(this.btnSigPag);
            this.tbpEnc.Controls.Add(this.grpFacTipVen);
            this.tbpEnc.Controls.Add(this.grbAdmRQ);
            this.tbpEnc.Location = new System.Drawing.Point(4, 22);
            this.tbpEnc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbpEnc.Name = "tbpEnc";
            this.tbpEnc.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbpEnc.Size = new System.Drawing.Size(1319, 596);
            this.tbpEnc.TabIndex = 0;
            this.tbpEnc.Text = "1. Encabezado";
            this.tbpEnc.UseVisualStyleBackColor = true;
            // 
            // grpObs
            // 
            this.grpObs.Controls.Add(this.btnExp);
            this.grpObs.Controls.Add(this.txtObsExt);
            this.grpObs.Location = new System.Drawing.Point(445, 292);
            this.grpObs.Name = "grpObs";
            this.grpObs.Size = new System.Drawing.Size(269, 130);
            this.grpObs.TabIndex = 59;
            this.grpObs.TabStop = false;
            this.grpObs.Text = "Solución para reclamo o postventa";
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(82, 102);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(88, 22);
            this.btnExp.TabIndex = 1;
            this.btnExp.Text = "&Expandir";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // txtObsExt
            // 
            this.txtObsExt.Location = new System.Drawing.Point(9, 17);
            this.txtObsExt.Multiline = true;
            this.txtObsExt.Name = "txtObsExt";
            this.txtObsExt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtObsExt.Size = new System.Drawing.Size(252, 79);
            this.txtObsExt.TabIndex = 0;
            // 
            // grbInfRec
            // 
            this.grbInfRec.Controls.Add(this.txtFam);
            this.grbInfRec.Controls.Add(this.txtCodFam);
            this.grbInfRec.Controls.Add(this.label74);
            this.grbInfRec.Controls.Add(this.txtSubLin);
            this.grbInfRec.Controls.Add(this.txtCodSubLin);
            this.grbInfRec.Controls.Add(this.label68);
            this.grbInfRec.Controls.Add(this.txtTip);
            this.grbInfRec.Controls.Add(this.txtCodTip);
            this.grbInfRec.Controls.Add(this.label55);
            this.grbInfRec.Controls.Add(this.txtLinPro);
            this.grbInfRec.Controls.Add(this.txtCodLinPro);
            this.grbInfRec.Controls.Add(this.label48);
            this.grbInfRec.Controls.Add(this.txtFalEn);
            this.grbInfRec.Controls.Add(this.txtCodFalEn);
            this.grbInfRec.Controls.Add(this.label37);
            this.grbInfRec.Location = new System.Drawing.Point(806, 244);
            this.grbInfRec.Name = "grbInfRec";
            this.grbInfRec.Size = new System.Drawing.Size(395, 185);
            this.grbInfRec.TabIndex = 57;
            this.grbInfRec.TabStop = false;
            this.grbInfRec.Text = "Información de reclamos";
            this.grbInfRec.Visible = false;
            // 
            // txtFam
            // 
            this.txtFam.Location = new System.Drawing.Point(218, 142);
            this.txtFam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFam.Name = "txtFam";
            this.txtFam.Size = new System.Drawing.Size(158, 21);
            this.txtFam.TabIndex = 43;
            this.txtFam.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFam_KeyPress);
            // 
            // txtCodFam
            // 
            this.txtCodFam.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodFam.Location = new System.Drawing.Point(162, 142);
            this.txtCodFam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodFam.Name = "txtCodFam";
            this.txtCodFam.ReadOnly = true;
            this.txtCodFam.Size = new System.Drawing.Size(55, 21);
            this.txtCodFam.TabIndex = 42;
            this.txtCodFam.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(17, 147);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(43, 13);
            this.label74.TabIndex = 41;
            this.label74.Text = "Familia:";
            // 
            // txtSubLin
            // 
            this.txtSubLin.Location = new System.Drawing.Point(218, 114);
            this.txtSubLin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSubLin.Name = "txtSubLin";
            this.txtSubLin.Size = new System.Drawing.Size(158, 21);
            this.txtSubLin.TabIndex = 40;
            this.txtSubLin.TextChanged += new System.EventHandler(this.txtSubLin_TextChanged);
            this.txtSubLin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSubLin_KeyPress);
            // 
            // txtCodSubLin
            // 
            this.txtCodSubLin.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodSubLin.Location = new System.Drawing.Point(162, 114);
            this.txtCodSubLin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodSubLin.Name = "txtCodSubLin";
            this.txtCodSubLin.ReadOnly = true;
            this.txtCodSubLin.Size = new System.Drawing.Size(55, 21);
            this.txtCodSubLin.TabIndex = 39;
            this.txtCodSubLin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodSubLin.TextChanged += new System.EventHandler(this.txtCodSubLin_TextChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(17, 118);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(57, 13);
            this.label68.TabIndex = 38;
            this.label68.Text = "Sub Linea:";
            // 
            // txtTip
            // 
            this.txtTip.Location = new System.Drawing.Point(218, 86);
            this.txtTip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTip.Name = "txtTip";
            this.txtTip.Size = new System.Drawing.Size(158, 21);
            this.txtTip.TabIndex = 37;
            this.txtTip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTip_KeyPress);
            // 
            // txtCodTip
            // 
            this.txtCodTip.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodTip.Location = new System.Drawing.Point(162, 86);
            this.txtCodTip.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodTip.Name = "txtCodTip";
            this.txtCodTip.ReadOnly = true;
            this.txtCodTip.Size = new System.Drawing.Size(55, 21);
            this.txtCodTip.TabIndex = 36;
            this.txtCodTip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodTip.TextChanged += new System.EventHandler(this.txtCodTip_TextChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(17, 91);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(31, 13);
            this.label55.TabIndex = 35;
            this.label55.Text = "Tipo:";
            // 
            // txtLinPro
            // 
            this.txtLinPro.Location = new System.Drawing.Point(218, 58);
            this.txtLinPro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLinPro.Name = "txtLinPro";
            this.txtLinPro.Size = new System.Drawing.Size(158, 21);
            this.txtLinPro.TabIndex = 34;
            this.txtLinPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLinPro_KeyPress);
            // 
            // txtCodLinPro
            // 
            this.txtCodLinPro.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodLinPro.Location = new System.Drawing.Point(162, 58);
            this.txtCodLinPro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodLinPro.Name = "txtCodLinPro";
            this.txtCodLinPro.ReadOnly = true;
            this.txtCodLinPro.Size = new System.Drawing.Size(55, 21);
            this.txtCodLinPro.TabIndex = 33;
            this.txtCodLinPro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodLinPro.TextChanged += new System.EventHandler(this.txtCodLinPro_TextChanged);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(17, 61);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(145, 13);
            this.label48.TabIndex = 32;
            this.label48.Text = "Linea de producto o servicio:";
            // 
            // txtFalEn
            // 
            this.txtFalEn.Location = new System.Drawing.Point(218, 30);
            this.txtFalEn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFalEn.Name = "txtFalEn";
            this.txtFalEn.Size = new System.Drawing.Size(158, 21);
            this.txtFalEn.TabIndex = 31;
            this.txtFalEn.TextChanged += new System.EventHandler(this.txtFalEn_TextChanged);
            this.txtFalEn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFalEn_KeyPress);
            // 
            // txtCodFalEn
            // 
            this.txtCodFalEn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodFalEn.Location = new System.Drawing.Point(162, 30);
            this.txtCodFalEn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodFalEn.Name = "txtCodFalEn";
            this.txtCodFalEn.ReadOnly = true;
            this.txtCodFalEn.Size = new System.Drawing.Size(55, 21);
            this.txtCodFalEn.TabIndex = 30;
            this.txtCodFalEn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodFalEn.TextChanged += new System.EventHandler(this.txtCodFalEn_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(17, 32);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(48, 13);
            this.label37.TabIndex = 0;
            this.label37.Text = "Falla En:";
            // 
            // txtNomAdi
            // 
            this.txtNomAdi.Location = new System.Drawing.Point(157, 539);
            this.txtNomAdi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNomAdi.Name = "txtNomAdi";
            this.txtNomAdi.Size = new System.Drawing.Size(636, 21);
            this.txtNomAdi.TabIndex = 53;
            this.txtNomAdi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomAdi_KeyPress);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(30, 542);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(108, 13);
            this.label61.TabIndex = 52;
            this.label61.Text = "Nombre de Adicional:";
            // 
            // txtMot
            // 
            this.txtMot.Location = new System.Drawing.Point(231, 55);
            this.txtMot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMot.Name = "txtMot";
            this.txtMot.Size = new System.Drawing.Size(197, 21);
            this.txtMot.TabIndex = 50;
            this.txtMot.TextChanged += new System.EventHandler(this.txtMot_TextChanged);
            this.txtMot.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMot_KeyPress);
            // 
            // txtRec
            // 
            this.txtRec.Location = new System.Drawing.Point(231, 513);
            this.txtRec.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRec.Name = "txtRec";
            this.txtRec.Size = new System.Drawing.Size(562, 21);
            this.txtRec.TabIndex = 46;
            this.txtRec.Click += new System.EventHandler(this.txtRec_Click);
            this.txtRec.TextChanged += new System.EventHandler(this.txtRec_TextChanged);
            this.txtRec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRec_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(29, 516);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 13);
            this.label15.TabIndex = 44;
            this.label15.Text = "Recomendador:";
            // 
            // txtCodMot
            // 
            this.txtCodMot.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodMot.Location = new System.Drawing.Point(157, 55);
            this.txtCodMot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodMot.Name = "txtCodMot";
            this.txtCodMot.ReadOnly = true;
            this.txtCodMot.Size = new System.Drawing.Size(73, 21);
            this.txtCodMot.TabIndex = 49;
            this.txtCodMot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodRec
            // 
            this.txtCodRec.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodRec.Location = new System.Drawing.Point(157, 513);
            this.txtCodRec.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodRec.Name = "txtCodRec";
            this.txtCodRec.ReadOnly = true;
            this.txtCodRec.Size = new System.Drawing.Size(73, 21);
            this.txtCodRec.TabIndex = 45;
            this.txtCodRec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(30, 62);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(119, 13);
            this.label58.TabIndex = 48;
            this.label58.Text = "Motivo de la cotización:";
            // 
            // btnDirObr
            // 
            this.btnDirObr.Location = new System.Drawing.Point(799, 185);
            this.btnDirObr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDirObr.Name = "btnDirObr";
            this.btnDirObr.Size = new System.Drawing.Size(33, 24);
            this.btnDirObr.TabIndex = 23;
            this.btnDirObr.Text = "...";
            this.btnDirObr.UseVisualStyleBackColor = true;
            // 
            // btnDirCli
            // 
            this.btnDirCli.Location = new System.Drawing.Point(799, 156);
            this.btnDirCli.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDirCli.Name = "btnDirCli";
            this.btnDirCli.Size = new System.Drawing.Size(33, 24);
            this.btnDirCli.TabIndex = 20;
            this.btnDirCli.Text = "...";
            this.btnDirCli.UseVisualStyleBackColor = true;
            // 
            // txtCodTipDoc
            // 
            this.txtCodTipDoc.Location = new System.Drawing.Point(799, 133);
            this.txtCodTipDoc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodTipDoc.Name = "txtCodTipDoc";
            this.txtCodTipDoc.Size = new System.Drawing.Size(33, 21);
            this.txtCodTipDoc.TabIndex = 17;
            this.txtCodTipDoc.Visible = false;
            // 
            // txtDocEntry
            // 
            this.txtDocEntry.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtDocEntry.Location = new System.Drawing.Point(575, 29);
            this.txtDocEntry.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDocEntry.Name = "txtDocEntry";
            this.txtDocEntry.ReadOnly = true;
            this.txtDocEntry.Size = new System.Drawing.Size(58, 21);
            this.txtDocEntry.TabIndex = 5;
            this.txtDocEntry.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(520, 33);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "DocEntry:";
            // 
            // txtDocNum
            // 
            this.txtDocNum.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtDocNum.Location = new System.Drawing.Point(370, 30);
            this.txtDocNum.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDocNum.Name = "txtDocNum";
            this.txtDocNum.ReadOnly = true;
            this.txtDocNum.Size = new System.Drawing.Size(58, 21);
            this.txtDocNum.TabIndex = 3;
            this.txtDocNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(300, 33);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "SAP DocNum:";
            // 
            // txtRUCDNI
            // 
            this.txtRUCDNI.Location = new System.Drawing.Point(624, 132);
            this.txtRUCDNI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRUCDNI.Name = "txtRUCDNI";
            this.txtRUCDNI.Size = new System.Drawing.Size(169, 21);
            this.txtRUCDNI.TabIndex = 16;
            this.txtRUCDNI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(573, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "RUC/DNI:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(389, 132);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(178, 21);
            this.txtEmail.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(355, 135);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Email:";
            // 
            // txtCli
            // 
            this.txtCli.Location = new System.Drawing.Point(231, 107);
            this.txtCli.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCli.Name = "txtCli";
            this.txtCli.Size = new System.Drawing.Size(562, 21);
            this.txtCli.TabIndex = 10;
            this.txtCli.TextChanged += new System.EventHandler(this.txtCli_TextChanged);
            this.txtCli.Enter += new System.EventHandler(this.txtCli_Enter);
            this.txtCli.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCli_KeyPress);
            // 
            // btnVinRQ
            // 
            this.btnVinRQ.Location = new System.Drawing.Point(232, 27);
            this.btnVinRQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVinRQ.Name = "btnVinRQ";
            this.btnVinRQ.Size = new System.Drawing.Size(27, 24);
            this.btnVinRQ.TabIndex = 1;
            this.btnVinRQ.Text = "...";
            this.btnVinRQ.UseVisualStyleBackColor = true;
            this.btnVinRQ.Click += new System.EventHandler(this.btnVinRQ_Click);
            // 
            // txtTipVen
            // 
            this.txtTipVen.Location = new System.Drawing.Point(231, 289);
            this.txtTipVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTipVen.Name = "txtTipVen";
            this.txtTipVen.Size = new System.Drawing.Size(197, 21);
            this.txtTipVen.TabIndex = 35;
            this.txtTipVen.TextChanged += new System.EventHandler(this.txtTipVen_TextChanged);
            this.txtTipVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipVen_KeyPress);
            // 
            // txtCenVen
            // 
            this.txtCenVen.Location = new System.Drawing.Point(231, 263);
            this.txtCenVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCenVen.Name = "txtCenVen";
            this.txtCenVen.Size = new System.Drawing.Size(197, 21);
            this.txtCenVen.TabIndex = 32;
            this.txtCenVen.TextChanged += new System.EventHandler(this.txtCenVen_TextChanged);
            this.txtCenVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCenVen_KeyPress);
            // 
            // txtVen
            // 
            this.txtVen.Location = new System.Drawing.Point(231, 237);
            this.txtVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtVen.Name = "txtVen";
            this.txtVen.Size = new System.Drawing.Size(197, 21);
            this.txtVen.TabIndex = 29;
            this.txtVen.TextChanged += new System.EventHandler(this.txtVen_TextChanged);
            this.txtVen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVen_KeyPress);
            // 
            // txtCliCon
            // 
            this.txtCliCon.Location = new System.Drawing.Point(231, 211);
            this.txtCliCon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCliCon.Name = "txtCliCon";
            this.txtCliCon.Size = new System.Drawing.Size(562, 21);
            this.txtCliCon.TabIndex = 26;
            this.txtCliCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCliCon_KeyPress);
            // 
            // txtDim
            // 
            this.txtDim.Location = new System.Drawing.Point(231, 393);
            this.txtDim.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDim.Name = "txtDim";
            this.txtDim.Size = new System.Drawing.Size(197, 21);
            this.txtDim.TabIndex = 43;
            this.txtDim.Click += new System.EventHandler(this.txtDim_Click);
            this.txtDim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDim_KeyPress);
            // 
            // txtTipObr
            // 
            this.txtTipObr.Location = new System.Drawing.Point(231, 367);
            this.txtTipObr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTipObr.Name = "txtTipObr";
            this.txtTipObr.Size = new System.Drawing.Size(197, 21);
            this.txtTipObr.TabIndex = 41;
            this.txtTipObr.TextChanged += new System.EventHandler(this.txtTipObr_TextChanged);
            this.txtTipObr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipObr_KeyPress);
            // 
            // txtRub
            // 
            this.txtRub.Location = new System.Drawing.Point(231, 341);
            this.txtRub.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRub.Name = "txtRub";
            this.txtRub.Size = new System.Drawing.Size(197, 21);
            this.txtRub.TabIndex = 39;
            this.txtRub.TextChanged += new System.EventHandler(this.txtRub_TextChanged);
            this.txtRub.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRub_KeyPress);
            // 
            // txtTipVenRel
            // 
            this.txtTipVenRel.Location = new System.Drawing.Point(231, 315);
            this.txtTipVenRel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTipVenRel.Name = "txtTipVenRel";
            this.txtTipVenRel.Size = new System.Drawing.Size(197, 21);
            this.txtTipVenRel.TabIndex = 37;
            this.txtTipVenRel.TextChanged += new System.EventHandler(this.txtTipVenRel_TextChanged);
            this.txtTipVenRel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipVenRel_KeyPress);
            // 
            // txtCodTipVen
            // 
            this.txtCodTipVen.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodTipVen.Location = new System.Drawing.Point(157, 289);
            this.txtCodTipVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodTipVen.Name = "txtCodTipVen";
            this.txtCodTipVen.ReadOnly = true;
            this.txtCodTipVen.Size = new System.Drawing.Size(73, 21);
            this.txtCodTipVen.TabIndex = 34;
            this.txtCodTipVen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodTipVen.TextChanged += new System.EventHandler(this.txtCodTipVen_TextChanged);
            // 
            // txtCodCenVen
            // 
            this.txtCodCenVen.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodCenVen.Location = new System.Drawing.Point(157, 263);
            this.txtCodCenVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodCenVen.Name = "txtCodCenVen";
            this.txtCodCenVen.ReadOnly = true;
            this.txtCodCenVen.Size = new System.Drawing.Size(73, 21);
            this.txtCodCenVen.TabIndex = 31;
            this.txtCodCenVen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodCenVen.TextChanged += new System.EventHandler(this.txtCodCenVen_TextChanged);
            // 
            // txtCodVen
            // 
            this.txtCodVen.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodVen.Location = new System.Drawing.Point(157, 237);
            this.txtCodVen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodVen.Name = "txtCodVen";
            this.txtCodVen.ReadOnly = true;
            this.txtCodVen.Size = new System.Drawing.Size(73, 21);
            this.txtCodVen.TabIndex = 28;
            this.txtCodVen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodCliCon
            // 
            this.txtCodCliCon.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodCliCon.Location = new System.Drawing.Point(157, 211);
            this.txtCodCliCon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodCliCon.Name = "txtCodCliCon";
            this.txtCodCliCon.ReadOnly = true;
            this.txtCodCliCon.Size = new System.Drawing.Size(73, 21);
            this.txtCodCliCon.TabIndex = 25;
            this.txtCodCliCon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDirObr
            // 
            this.txtDirObr.Location = new System.Drawing.Point(157, 185);
            this.txtDirObr.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDirObr.Name = "txtDirObr";
            this.txtDirObr.Size = new System.Drawing.Size(636, 21);
            this.txtDirObr.TabIndex = 22;
            // 
            // txtDirCli
            // 
            this.txtDirCli.Location = new System.Drawing.Point(157, 159);
            this.txtDirCli.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDirCli.Name = "txtDirCli";
            this.txtDirCli.Size = new System.Drawing.Size(636, 21);
            this.txtDirCli.TabIndex = 19;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(157, 133);
            this.txtTel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(192, 21);
            this.txtTel.TabIndex = 12;
            this.txtTel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodCli
            // 
            this.txtCodCli.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodCli.Location = new System.Drawing.Point(157, 107);
            this.txtCodCli.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodCli.Name = "txtCodCli";
            this.txtCodCli.ReadOnly = true;
            this.txtCodCli.Size = new System.Drawing.Size(73, 21);
            this.txtCodCli.TabIndex = 9;
            this.txtCodCli.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNomCot
            // 
            this.txtNomCot.Location = new System.Drawing.Point(157, 81);
            this.txtNomCot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNomCot.Name = "txtNomCot";
            this.txtNomCot.Size = new System.Drawing.Size(636, 21);
            this.txtNomCot.TabIndex = 7;
            this.txtNomCot.TextChanged += new System.EventHandler(this.txtNomCot_TextChanged);
            this.txtNomCot.Enter += new System.EventHandler(this.txtNomCot_Enter);
            this.txtNomCot.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomCot_KeyPress);
            // 
            // txtRQ
            // 
            this.txtRQ.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtRQ.Location = new System.Drawing.Point(157, 29);
            this.txtRQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRQ.Name = "txtRQ";
            this.txtRQ.Size = new System.Drawing.Size(73, 21);
            this.txtRQ.TabIndex = 0;
            this.txtRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(30, 400);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 13);
            this.label14.TabIndex = 42;
            this.label14.Text = "Dimensión:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(30, 374);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 13);
            this.label13.TabIndex = 40;
            this.label13.Text = "Tipo de Obra:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 348);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 38;
            this.label12.Text = "Rubro:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 322);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 13);
            this.label11.TabIndex = 36;
            this.label11.Text = "Tipo de Venta Relativo:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 296);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 13);
            this.label10.TabIndex = 33;
            this.label10.Text = "Tipo de Venta:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 270);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "Centro de Venta:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 244);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "Empleado de ventas:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 218);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Persona de contacto:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Dirección Obra";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Dirección Cliente:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Telefono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Cliente:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nombre de la Venta:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "N° RQ:";
            // 
            // btnSigPag
            // 
            this.btnSigPag.Location = new System.Drawing.Point(839, 524);
            this.btnSigPag.Name = "btnSigPag";
            this.btnSigPag.Size = new System.Drawing.Size(109, 21);
            this.btnSigPag.TabIndex = 47;
            this.btnSigPag.Text = "Siguiente";
            this.btnSigPag.UseVisualStyleBackColor = true;
            this.btnSigPag.Click += new System.EventHandler(this.btnSigPag_Click);
            // 
            // grpFacTipVen
            // 
            this.grpFacTipVen.Controls.Add(this.txtPag);
            this.grpFacTipVen.Controls.Add(this.txtTie);
            this.grpFacTipVen.Controls.Add(this.label59);
            this.grpFacTipVen.Controls.Add(this.label60);
            this.grpFacTipVen.Location = new System.Drawing.Point(22, 422);
            this.grpFacTipVen.Name = "grpFacTipVen";
            this.grpFacTipVen.Size = new System.Drawing.Size(771, 81);
            this.grpFacTipVen.TabIndex = 51;
            this.grpFacTipVen.TabStop = false;
            this.grpFacTipVen.Text = "Facturación por tipo de venta";
            // 
            // txtPag
            // 
            this.txtPag.Location = new System.Drawing.Point(209, 45);
            this.txtPag.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPag.Name = "txtPag";
            this.txtPag.Size = new System.Drawing.Size(197, 21);
            this.txtPag.TabIndex = 43;
            // 
            // txtTie
            // 
            this.txtTie.Location = new System.Drawing.Point(209, 19);
            this.txtTie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTie.Name = "txtTie";
            this.txtTie.Size = new System.Drawing.Size(197, 21);
            this.txtTie.TabIndex = 41;
            this.txtTie.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTie_KeyPress);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(8, 52);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(86, 13);
            this.label59.TabIndex = 42;
            this.label59.Text = "Opción de Pago:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(8, 26);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(45, 13);
            this.label60.TabIndex = 40;
            this.label60.Text = "Tiempo:";
            // 
            // grbAdmRQ
            // 
            this.grbAdmRQ.Controls.Add(this.txtAdmRQ);
            this.grbAdmRQ.Controls.Add(this.txtCodAdmRQ);
            this.grbAdmRQ.Controls.Add(this.label62);
            this.grbAdmRQ.Location = new System.Drawing.Point(22, 554);
            this.grbAdmRQ.Name = "grbAdmRQ";
            this.grbAdmRQ.Size = new System.Drawing.Size(594, 39);
            this.grbAdmRQ.TabIndex = 58;
            this.grbAdmRQ.TabStop = false;
            // 
            // txtAdmRQ
            // 
            this.txtAdmRQ.Location = new System.Drawing.Point(209, 11);
            this.txtAdmRQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAdmRQ.Name = "txtAdmRQ";
            this.txtAdmRQ.Size = new System.Drawing.Size(197, 21);
            this.txtAdmRQ.TabIndex = 59;
            this.txtAdmRQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdmRQ_KeyPress);
            // 
            // txtCodAdmRQ
            // 
            this.txtCodAdmRQ.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCodAdmRQ.Location = new System.Drawing.Point(135, 11);
            this.txtCodAdmRQ.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodAdmRQ.Name = "txtCodAdmRQ";
            this.txtCodAdmRQ.ReadOnly = true;
            this.txtCodAdmRQ.Size = new System.Drawing.Size(73, 21);
            this.txtCodAdmRQ.TabIndex = 58;
            this.txtCodAdmRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(8, 16);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(110, 13);
            this.label62.TabIndex = 57;
            this.label62.Text = "Administrador de RQ:";
            // 
            // gpbCubre
            // 
            this.gpbCubre.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gpbCubre.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.gpbCubre.Controls.Add(this.gpbMoneda);
            this.gpbCubre.Location = new System.Drawing.Point(1822, 285);
            this.gpbCubre.Name = "gpbCubre";
            this.gpbCubre.Size = new System.Drawing.Size(342, 273);
            this.gpbCubre.TabIndex = 4;
            this.gpbCubre.TabStop = false;
            // 
            // gpbMoneda
            // 
            this.gpbMoneda.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.gpbMoneda.Controls.Add(this.btnCan);
            this.gpbMoneda.Controls.Add(this.btnAce);
            this.gpbMoneda.Controls.Add(this.rdbSol);
            this.gpbMoneda.Controls.Add(this.rdbDol);
            this.gpbMoneda.Location = new System.Drawing.Point(14, 39);
            this.gpbMoneda.Name = "gpbMoneda";
            this.gpbMoneda.Size = new System.Drawing.Size(314, 193);
            this.gpbMoneda.TabIndex = 5;
            this.gpbMoneda.TabStop = false;
            this.gpbMoneda.Visible = false;
            // 
            // btnCan
            // 
            this.btnCan.Location = new System.Drawing.Point(162, 141);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(109, 21);
            this.btnCan.TabIndex = 3;
            this.btnCan.Text = "Cancelar";
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // btnAce
            // 
            this.btnAce.Location = new System.Drawing.Point(43, 141);
            this.btnAce.Name = "btnAce";
            this.btnAce.Size = new System.Drawing.Size(109, 21);
            this.btnAce.TabIndex = 2;
            this.btnAce.Text = "Aceptar";
            this.btnAce.UseVisualStyleBackColor = true;
            this.btnAce.Click += new System.EventHandler(this.btnAce_Click);
            // 
            // rdbSol
            // 
            this.rdbSol.AutoSize = true;
            this.rdbSol.Location = new System.Drawing.Point(110, 94);
            this.rdbSol.Name = "rdbSol";
            this.rdbSol.Size = new System.Drawing.Size(50, 17);
            this.rdbSol.TabIndex = 1;
            this.rdbSol.Text = "Soles";
            this.rdbSol.UseVisualStyleBackColor = true;
            this.rdbSol.CheckedChanged += new System.EventHandler(this.rdbSol_CheckedChanged_1);
            // 
            // rdbDol
            // 
            this.rdbDol.AutoSize = true;
            this.rdbDol.Checked = true;
            this.rdbDol.Location = new System.Drawing.Point(110, 49);
            this.rdbDol.Name = "rdbDol";
            this.rdbDol.Size = new System.Drawing.Size(61, 17);
            this.rdbDol.TabIndex = 0;
            this.rdbDol.TabStop = true;
            this.rdbDol.Text = "Dolares";
            this.rdbDol.UseVisualStyleBackColor = true;
            this.rdbDol.CheckedChanged += new System.EventHandler(this.rdbDol_CheckedChanged_1);
            // 
            // tbPri
            // 
            this.tbPri.Controls.Add(this.tbpEnc);
            this.tbPri.Controls.Add(this.tbpArtCom);
            this.tbPri.Controls.Add(this.tbpOtrArt);
            this.tbPri.Controls.Add(this.tbpArtSim);
            this.tbPri.Location = new System.Drawing.Point(4, 39);
            this.tbPri.Name = "tbPri";
            this.tbPri.SelectedIndex = 0;
            this.tbPri.Size = new System.Drawing.Size(1327, 622);
            this.tbPri.TabIndex = 5;
            // 
            // tbpArtSim
            // 
            this.tbpArtSim.Controls.Add(this.lblArtInfoItem);
            this.tbpArtSim.Controls.Add(this.txtArtPrecio);
            this.tbpArtSim.Controls.Add(this.txtCodArt);
            this.tbpArtSim.Controls.Add(this.fgArtDet);
            this.tbpArtSim.Controls.Add(this.txtArtDesc);
            this.tbpArtSim.Controls.Add(this.label46);
            this.tbpArtSim.Controls.Add(this.txtArtPorDes);
            this.tbpArtSim.Controls.Add(this.btnArtAgrItem);
            this.tbpArtSim.Controls.Add(this.txtArtSubTot);
            this.tbpArtSim.Controls.Add(this.label47);
            this.tbpArtSim.Controls.Add(this.txtArtIGV);
            this.tbpArtSim.Controls.Add(this.lblArtIGVUnit);
            this.tbpArtSim.Controls.Add(this.txtArtValNet);
            this.tbpArtSim.Controls.Add(this.label49);
            this.tbpArtSim.Controls.Add(this.txtArtVenBru);
            this.tbpArtSim.Controls.Add(this.label50);
            this.tbpArtSim.Controls.Add(this.txtArtCan);
            this.tbpArtSim.Controls.Add(this.label51);
            this.tbpArtSim.Controls.Add(this.label52);
            this.tbpArtSim.Controls.Add(this.label53);
            this.tbpArtSim.Controls.Add(this.label54);
            this.tbpArtSim.Controls.Add(this.txtArtDes);
            this.tbpArtSim.Controls.Add(this.tbArtAmb);
            this.tbpArtSim.Controls.Add(this.btnArtModItem);
            this.tbpArtSim.Controls.Add(this.btnArtBorItem);
            this.tbpArtSim.Controls.Add(this.btnArtCanItem);
            this.tbpArtSim.Location = new System.Drawing.Point(4, 22);
            this.tbpArtSim.Name = "tbpArtSim";
            this.tbpArtSim.Padding = new System.Windows.Forms.Padding(3);
            this.tbpArtSim.Size = new System.Drawing.Size(1319, 596);
            this.tbpArtSim.TabIndex = 3;
            this.tbpArtSim.Text = "4. Articulo Simple";
            this.tbpArtSim.UseVisualStyleBackColor = true;
            // 
            // lblArtInfoItem
            // 
            this.lblArtInfoItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArtInfoItem.ForeColor = System.Drawing.Color.Red;
            this.lblArtInfoItem.Location = new System.Drawing.Point(979, 28);
            this.lblArtInfoItem.Name = "lblArtInfoItem";
            this.lblArtInfoItem.Size = new System.Drawing.Size(105, 22);
            this.lblArtInfoItem.TabIndex = 55;
            // 
            // txtArtPrecio
            // 
            this.txtArtPrecio.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtPrecio.Location = new System.Drawing.Point(101, 55);
            this.txtArtPrecio.Name = "txtArtPrecio";
            this.txtArtPrecio.ReadOnly = true;
            this.txtArtPrecio.Size = new System.Drawing.Size(70, 21);
            this.txtArtPrecio.TabIndex = 34;
            this.txtArtPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtArtPrecio.DoubleClick += new System.EventHandler(this.txtArtPrecio_DoubleClick);
            // 
            // txtCodArt
            // 
            this.txtCodArt.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodArt.Location = new System.Drawing.Point(101, 29);
            this.txtCodArt.MaxLength = 9;
            this.txtCodArt.Name = "txtCodArt";
            this.txtCodArt.Size = new System.Drawing.Size(77, 21);
            this.txtCodArt.TabIndex = 31;
            this.txtCodArt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodArt.TextChanged += new System.EventHandler(this.txtCodArt_TextChanged);
            this.txtCodArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArt_KeyPress);
            // 
            // fgArtDet
            // 
            this.fgArtDet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgArtDet.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.XpThemes;
            this.fgArtDet.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgArtDet.Location = new System.Drawing.Point(224, 132);
            this.fgArtDet.Name = "fgArtDet";
            this.fgArtDet.Rows.Count = 1;
            this.fgArtDet.Rows.DefaultSize = 19;
            this.fgArtDet.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgArtDet.Size = new System.Drawing.Size(1068, 443);
            this.fgArtDet.TabIndex = 54;
            this.fgArtDet.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgArtDet_KeyPressEdit);
            this.fgArtDet.Click += new System.EventHandler(this.fgArtDet_Click);
            // 
            // txtArtDesc
            // 
            this.txtArtDesc.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtDesc.Location = new System.Drawing.Point(519, 55);
            this.txtArtDesc.Name = "txtArtDesc";
            this.txtArtDesc.ReadOnly = true;
            this.txtArtDesc.Size = new System.Drawing.Size(68, 21);
            this.txtArtDesc.TabIndex = 53;
            this.txtArtDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(486, 59);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(34, 13);
            this.label46.TabIndex = 52;
            this.label46.Text = "Desc:";
            // 
            // txtArtPorDes
            // 
            this.txtArtPorDes.Location = new System.Drawing.Point(438, 55);
            this.txtArtPorDes.Name = "txtArtPorDes";
            this.txtArtPorDes.Size = new System.Drawing.Size(37, 21);
            this.txtArtPorDes.TabIndex = 51;
            this.txtArtPorDes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtArtPorDes.TextChanged += new System.EventHandler(this.txtArtPorDes_TextChanged);
            this.txtArtPorDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArtPorDes_KeyPress);
            this.txtArtPorDes.Leave += new System.EventHandler(this.txtArtPorDes_Leave);
            // 
            // btnArtAgrItem
            // 
            this.btnArtAgrItem.Location = new System.Drawing.Point(222, 105);
            this.btnArtAgrItem.Name = "btnArtAgrItem";
            this.btnArtAgrItem.Size = new System.Drawing.Size(92, 23);
            this.btnArtAgrItem.TabIndex = 46;
            this.btnArtAgrItem.Text = "Agregar Item";
            this.btnArtAgrItem.UseVisualStyleBackColor = true;
            this.btnArtAgrItem.Click += new System.EventHandler(this.btnArtAgrItem_Click);
            // 
            // txtArtSubTot
            // 
            this.txtArtSubTot.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtSubTot.Location = new System.Drawing.Point(909, 56);
            this.txtArtSubTot.Name = "txtArtSubTot";
            this.txtArtSubTot.ReadOnly = true;
            this.txtArtSubTot.Size = new System.Drawing.Size(64, 21);
            this.txtArtSubTot.TabIndex = 45;
            this.txtArtSubTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(853, 60);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(56, 13);
            this.label47.TabIndex = 44;
            this.label47.Text = "Sub Total:";
            // 
            // txtArtIGV
            // 
            this.txtArtIGV.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtIGV.Location = new System.Drawing.Point(784, 56);
            this.txtArtIGV.Name = "txtArtIGV";
            this.txtArtIGV.ReadOnly = true;
            this.txtArtIGV.Size = new System.Drawing.Size(65, 21);
            this.txtArtIGV.TabIndex = 43;
            this.txtArtIGV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblArtIGVUnit
            // 
            this.lblArtIGVUnit.Location = new System.Drawing.Point(729, 60);
            this.lblArtIGVUnit.Name = "lblArtIGVUnit";
            this.lblArtIGVUnit.Size = new System.Drawing.Size(58, 13);
            this.lblArtIGVUnit.TabIndex = 42;
            // 
            // txtArtValNet
            // 
            this.txtArtValNet.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtValNet.Location = new System.Drawing.Point(655, 55);
            this.txtArtValNet.Name = "txtArtValNet";
            this.txtArtValNet.ReadOnly = true;
            this.txtArtValNet.Size = new System.Drawing.Size(68, 21);
            this.txtArtValNet.TabIndex = 41;
            this.txtArtValNet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(390, 59);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(49, 13);
            this.label49.TabIndex = 39;
            this.label49.Text = "Desc.%:";
            // 
            // txtArtVenBru
            // 
            this.txtArtVenBru.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtVenBru.Location = new System.Drawing.Point(314, 55);
            this.txtArtVenBru.Name = "txtArtVenBru";
            this.txtArtVenBru.ReadOnly = true;
            this.txtArtVenBru.Size = new System.Drawing.Size(66, 21);
            this.txtArtVenBru.TabIndex = 38;
            this.txtArtVenBru.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(266, 59);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(50, 13);
            this.label50.TabIndex = 37;
            this.label50.Text = "V. Bruta:";
            // 
            // txtArtCan
            // 
            this.txtArtCan.Location = new System.Drawing.Point(222, 55);
            this.txtArtCan.Name = "txtArtCan";
            this.txtArtCan.Size = new System.Drawing.Size(37, 21);
            this.txtArtCan.TabIndex = 36;
            this.txtArtCan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtArtCan.TextChanged += new System.EventHandler(this.txtArtCan_TextChanged);
            this.txtArtCan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArtCan_KeyPress);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(593, 59);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(61, 13);
            this.label51.TabIndex = 40;
            this.label51.Text = "Valor Neto:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(187, 59);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(34, 13);
            this.label52.TabIndex = 35;
            this.label52.Text = "Cant:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(41, 59);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(62, 13);
            this.label53.TabIndex = 33;
            this.label53.Text = "Precio Unit:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(55, 31);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(47, 13);
            this.label54.TabIndex = 30;
            this.label54.Text = "Articulo:";
            // 
            // txtArtDes
            // 
            this.txtArtDes.Location = new System.Drawing.Point(178, 29);
            this.txtArtDes.MaxLength = 100;
            this.txtArtDes.Name = "txtArtDes";
            this.txtArtDes.Size = new System.Drawing.Size(795, 21);
            this.txtArtDes.TabIndex = 32;
            this.txtArtDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArtDes_KeyPress);
            // 
            // tbArtAmb
            // 
            this.tbArtAmb.Controls.Add(this.tbpArtAmb);
            this.tbArtAmb.Controls.Add(this.tbpArtObs);
            this.tbArtAmb.Location = new System.Drawing.Point(15, 108);
            this.tbArtAmb.Name = "tbArtAmb";
            this.tbArtAmb.SelectedIndex = 0;
            this.tbArtAmb.Size = new System.Drawing.Size(207, 455);
            this.tbArtAmb.TabIndex = 50;
            // 
            // tbpArtAmb
            // 
            this.tbpArtAmb.Controls.Add(this.lblArtAmbTot);
            this.tbpArtAmb.Controls.Add(this.label56);
            this.tbpArtAmb.Controls.Add(this.fgArtAmb);
            this.tbpArtAmb.Controls.Add(this.btnArtAgrAmb);
            this.tbpArtAmb.Controls.Add(this.btnArtEliAmb);
            this.tbpArtAmb.Controls.Add(this.label57);
            this.tbpArtAmb.Controls.Add(this.label72);
            this.tbpArtAmb.Controls.Add(this.label73);
            this.tbpArtAmb.Controls.Add(this.txtArtCodAmb);
            this.tbpArtAmb.Controls.Add(this.txtArtCanAmb);
            this.tbpArtAmb.Controls.Add(this.txtArtAmb);
            this.tbpArtAmb.Location = new System.Drawing.Point(4, 22);
            this.tbpArtAmb.Name = "tbpArtAmb";
            this.tbpArtAmb.Padding = new System.Windows.Forms.Padding(3);
            this.tbpArtAmb.Size = new System.Drawing.Size(199, 429);
            this.tbpArtAmb.TabIndex = 0;
            this.tbpArtAmb.Text = "Ambientes";
            this.tbpArtAmb.UseVisualStyleBackColor = true;
            // 
            // lblArtAmbTot
            // 
            this.lblArtAmbTot.ForeColor = System.Drawing.Color.Red;
            this.lblArtAmbTot.Location = new System.Drawing.Point(150, 407);
            this.lblArtAmbTot.Name = "lblArtAmbTot";
            this.lblArtAmbTot.Size = new System.Drawing.Size(35, 13);
            this.lblArtAmbTot.TabIndex = 11;
            this.lblArtAmbTot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.ForeColor = System.Drawing.Color.Red;
            this.label56.Location = new System.Drawing.Point(120, 407);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 13);
            this.label56.TabIndex = 10;
            this.label56.Text = "Total:";
            // 
            // fgArtAmb
            // 
            this.fgArtAmb.BorderStyle = C1.Win.C1FlexGrid.Util.BaseControls.BorderStyleEnum.XpThemes;
            this.fgArtAmb.ColumnInfo = "1,1,0,0,0,95,Columns:";
            this.fgArtAmb.Location = new System.Drawing.Point(7, 80);
            this.fgArtAmb.Name = "fgArtAmb";
            this.fgArtAmb.Rows.Count = 1;
            this.fgArtAmb.Rows.DefaultSize = 19;
            this.fgArtAmb.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgArtAmb.Size = new System.Drawing.Size(183, 310);
            this.fgArtAmb.TabIndex = 9;
            this.fgArtAmb.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgArtAmb_KeyPressEdit);
            this.fgArtAmb.DoubleClick += new System.EventHandler(this.fgArtAmb_DoubleClick);
            // 
            // btnArtAgrAmb
            // 
            this.btnArtAgrAmb.Location = new System.Drawing.Point(6, 53);
            this.btnArtAgrAmb.Name = "btnArtAgrAmb";
            this.btnArtAgrAmb.Size = new System.Drawing.Size(92, 21);
            this.btnArtAgrAmb.TabIndex = 7;
            this.btnArtAgrAmb.Text = "Agregar";
            this.btnArtAgrAmb.UseVisualStyleBackColor = true;
            this.btnArtAgrAmb.Click += new System.EventHandler(this.btnArtAgrAmb_Click);
            // 
            // btnArtEliAmb
            // 
            this.btnArtEliAmb.Location = new System.Drawing.Point(97, 53);
            this.btnArtEliAmb.Name = "btnArtEliAmb";
            this.btnArtEliAmb.Size = new System.Drawing.Size(92, 21);
            this.btnArtEliAmb.TabIndex = 8;
            this.btnArtEliAmb.Text = "Eliminar";
            this.btnArtEliAmb.UseVisualStyleBackColor = true;
            this.btnArtEliAmb.Click += new System.EventHandler(this.btnArtEliAmb_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(156, 10);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(34, 13);
            this.label57.TabIndex = 2;
            this.label57.Text = "Cant.";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(46, 10);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(56, 13);
            this.label72.TabIndex = 1;
            this.label72.Text = "Ambiente:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(6, 10);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(30, 13);
            this.label73.TabIndex = 0;
            this.label73.Text = "Cod.";
            // 
            // txtArtCodAmb
            // 
            this.txtArtCodAmb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtArtCodAmb.Location = new System.Drawing.Point(8, 26);
            this.txtArtCodAmb.Name = "txtArtCodAmb";
            this.txtArtCodAmb.ReadOnly = true;
            this.txtArtCodAmb.Size = new System.Drawing.Size(36, 21);
            this.txtArtCodAmb.TabIndex = 3;
            // 
            // txtArtCanAmb
            // 
            this.txtArtCanAmb.Location = new System.Drawing.Point(158, 26);
            this.txtArtCanAmb.Name = "txtArtCanAmb";
            this.txtArtCanAmb.Size = new System.Drawing.Size(28, 21);
            this.txtArtCanAmb.TabIndex = 5;
            this.txtArtCanAmb.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtArtCanAmb.TextChanged += new System.EventHandler(this.txtArtCanAmb_TextChanged);
            this.txtArtCanAmb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArtCanAmb_KeyPress);
            // 
            // txtArtAmb
            // 
            this.txtArtAmb.Location = new System.Drawing.Point(45, 26);
            this.txtArtAmb.Name = "txtArtAmb";
            this.txtArtAmb.Size = new System.Drawing.Size(112, 21);
            this.txtArtAmb.TabIndex = 4;
            this.txtArtAmb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArtAmb_KeyPress);
            // 
            // tbpArtObs
            // 
            this.tbpArtObs.Controls.Add(this.txtArtObs);
            this.tbpArtObs.Location = new System.Drawing.Point(4, 22);
            this.tbpArtObs.Name = "tbpArtObs";
            this.tbpArtObs.Padding = new System.Windows.Forms.Padding(3);
            this.tbpArtObs.Size = new System.Drawing.Size(199, 429);
            this.tbpArtObs.TabIndex = 1;
            this.tbpArtObs.Text = "Observ.";
            this.tbpArtObs.UseVisualStyleBackColor = true;
            // 
            // txtArtObs
            // 
            this.txtArtObs.Location = new System.Drawing.Point(9, 9);
            this.txtArtObs.Multiline = true;
            this.txtArtObs.Name = "txtArtObs";
            this.txtArtObs.Size = new System.Drawing.Size(179, 414);
            this.txtArtObs.TabIndex = 0;
            // 
            // btnArtModItem
            // 
            this.btnArtModItem.Location = new System.Drawing.Point(312, 105);
            this.btnArtModItem.Name = "btnArtModItem";
            this.btnArtModItem.Size = new System.Drawing.Size(92, 23);
            this.btnArtModItem.TabIndex = 47;
            this.btnArtModItem.Text = "Modificar Item";
            this.btnArtModItem.UseVisualStyleBackColor = true;
            this.btnArtModItem.Click += new System.EventHandler(this.btnArtModItem_Click);
            // 
            // btnArtBorItem
            // 
            this.btnArtBorItem.Location = new System.Drawing.Point(402, 105);
            this.btnArtBorItem.Name = "btnArtBorItem";
            this.btnArtBorItem.Size = new System.Drawing.Size(92, 23);
            this.btnArtBorItem.TabIndex = 48;
            this.btnArtBorItem.Text = "Borrar Item";
            this.btnArtBorItem.UseVisualStyleBackColor = true;
            this.btnArtBorItem.Click += new System.EventHandler(this.btnArtBorItem_Click);
            // 
            // btnArtCanItem
            // 
            this.btnArtCanItem.Location = new System.Drawing.Point(492, 105);
            this.btnArtCanItem.Name = "btnArtCanItem";
            this.btnArtCanItem.Size = new System.Drawing.Size(92, 23);
            this.btnArtCanItem.TabIndex = 49;
            this.btnArtCanItem.Text = "Cancelar Item";
            this.btnArtCanItem.UseVisualStyleBackColor = true;
            this.btnArtCanItem.Click += new System.EventHandler(this.btnArtCanItem_Click);
            // 
            // fgAmbTodos
            // 
            this.fgAmbTodos.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgAmbTodos.Location = new System.Drawing.Point(4, 727);
            this.fgAmbTodos.Name = "fgAmbTodos";
            this.fgAmbTodos.Rows.Count = 1;
            this.fgAmbTodos.Rows.DefaultSize = 19;
            this.fgAmbTodos.Size = new System.Drawing.Size(638, 69);
            this.fgAmbTodos.TabIndex = 12;
            this.fgAmbTodos.Visible = false;
            // 
            // fgComTodos
            // 
            this.fgComTodos.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgComTodos.Location = new System.Drawing.Point(648, 727);
            this.fgComTodos.Name = "fgComTodos";
            this.fgComTodos.Rows.Count = 1;
            this.fgComTodos.Rows.DefaultSize = 19;
            this.fgComTodos.Size = new System.Drawing.Size(577, 69);
            this.fgComTodos.TabIndex = 13;
            this.fgComTodos.Visible = false;
            // 
            // pnTot
            // 
            this.pnTot.Controls.Add(this.txtMar);
            this.pnTot.Controls.Add(this.txtCosTot);
            this.pnTot.Controls.Add(this.txtTotGen);
            this.pnTot.Controls.Add(this.txtTotIGV);
            this.pnTot.Controls.Add(this.txtTotValVen);
            this.pnTot.Controls.Add(this.txtTotDes);
            this.pnTot.Controls.Add(this.txtTotPorDes);
            this.pnTot.Controls.Add(this.txtTotVenBru);
            this.pnTot.Controls.Add(this.label71);
            this.pnTot.Controls.Add(this.label70);
            this.pnTot.Controls.Add(this.label69);
            this.pnTot.Controls.Add(this.lblIGVTotal);
            this.pnTot.Controls.Add(this.label67);
            this.pnTot.Controls.Add(this.label66);
            this.pnTot.Controls.Add(this.label65);
            this.pnTot.Controls.Add(this.label64);
            this.pnTot.Location = new System.Drawing.Point(2, 667);
            this.pnTot.Name = "pnTot";
            this.pnTot.Size = new System.Drawing.Size(1117, 52);
            this.pnTot.TabIndex = 14;
            // 
            // txtMar
            // 
            this.txtMar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtMar.Location = new System.Drawing.Point(1037, 14);
            this.txtMar.Name = "txtMar";
            this.txtMar.ReadOnly = true;
            this.txtMar.Size = new System.Drawing.Size(67, 21);
            this.txtMar.TabIndex = 14;
            this.txtMar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCosTot
            // 
            this.txtCosTot.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCosTot.Location = new System.Drawing.Point(902, 14);
            this.txtCosTot.Name = "txtCosTot";
            this.txtCosTot.ReadOnly = true;
            this.txtCosTot.Size = new System.Drawing.Size(67, 21);
            this.txtCosTot.TabIndex = 12;
            this.txtCosTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotGen
            // 
            this.txtTotGen.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotGen.Location = new System.Drawing.Point(754, 14);
            this.txtTotGen.Name = "txtTotGen";
            this.txtTotGen.ReadOnly = true;
            this.txtTotGen.Size = new System.Drawing.Size(67, 21);
            this.txtTotGen.TabIndex = 10;
            this.txtTotGen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotIGV
            // 
            this.txtTotIGV.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotIGV.Location = new System.Drawing.Point(631, 14);
            this.txtTotIGV.Name = "txtTotIGV";
            this.txtTotIGV.ReadOnly = true;
            this.txtTotIGV.Size = new System.Drawing.Size(67, 21);
            this.txtTotIGV.TabIndex = 8;
            this.txtTotIGV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotValVen
            // 
            this.txtTotValVen.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotValVen.Location = new System.Drawing.Point(501, 14);
            this.txtTotValVen.Name = "txtTotValVen";
            this.txtTotValVen.ReadOnly = true;
            this.txtTotValVen.Size = new System.Drawing.Size(67, 21);
            this.txtTotValVen.TabIndex = 6;
            this.txtTotValVen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotDes
            // 
            this.txtTotDes.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotDes.Location = new System.Drawing.Point(348, 14);
            this.txtTotDes.Name = "txtTotDes";
            this.txtTotDes.ReadOnly = true;
            this.txtTotDes.Size = new System.Drawing.Size(67, 21);
            this.txtTotDes.TabIndex = 4;
            this.txtTotDes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotPorDes
            // 
            this.txtTotPorDes.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotPorDes.Location = new System.Drawing.Point(206, 14);
            this.txtTotPorDes.Name = "txtTotPorDes";
            this.txtTotPorDes.ReadOnly = true;
            this.txtTotPorDes.Size = new System.Drawing.Size(67, 21);
            this.txtTotPorDes.TabIndex = 2;
            this.txtTotPorDes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotVenBru
            // 
            this.txtTotVenBru.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotVenBru.Location = new System.Drawing.Point(82, 14);
            this.txtTotVenBru.Name = "txtTotVenBru";
            this.txtTotVenBru.ReadOnly = true;
            this.txtTotVenBru.Size = new System.Drawing.Size(67, 21);
            this.txtTotVenBru.TabIndex = 0;
            this.txtTotVenBru.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(991, 17);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(47, 13);
            this.label71.TabIndex = 15;
            this.label71.Text = "Margen:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(837, 17);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(66, 13);
            this.label70.TabIndex = 13;
            this.label70.Text = "Costo Total:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(720, 17);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(35, 13);
            this.label69.TabIndex = 11;
            this.label69.Text = "Total:";
            // 
            // lblIGVTotal
            // 
            this.lblIGVTotal.AutoSize = true;
            this.lblIGVTotal.Location = new System.Drawing.Point(578, 17);
            this.lblIGVTotal.Name = "lblIGVTotal";
            this.lblIGVTotal.Size = new System.Drawing.Size(54, 13);
            this.lblIGVTotal.TabIndex = 9;
            this.lblIGVTotal.Text = "IGV 18%:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(436, 17);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(66, 13);
            this.label67.TabIndex = 7;
            this.label67.Text = "Valor Venta:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(282, 17);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(67, 13);
            this.label66.TabIndex = 5;
            this.label66.Text = "Monto Desc:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(162, 17);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(45, 13);
            this.label65.TabIndex = 3;
            this.label65.Text = "%Desc:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(15, 17);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(68, 13);
            this.label64.TabIndex = 1;
            this.label64.Text = "Venta Bruta:";
            // 
            // fgArtAmbTodos
            // 
            this.fgArtAmbTodos.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgArtAmbTodos.Location = new System.Drawing.Point(4, 814);
            this.fgArtAmbTodos.Name = "fgArtAmbTodos";
            this.fgArtAmbTodos.Rows.Count = 1;
            this.fgArtAmbTodos.Rows.DefaultSize = 19;
            this.fgArtAmbTodos.Size = new System.Drawing.Size(638, 69);
            this.fgArtAmbTodos.TabIndex = 15;
            this.fgArtAmbTodos.Visible = false;
            // 
            // tlsBot
            // 
            this.tlsBot.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlsBot.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.btnAbrir,
            this.btnGuardar,
            this.btnDeshacer,
            this.btnModificar,
            this.btnOpcImp,
            this.toolStripSeparator,
            this.btnAprobar,
            this.btnMigrarSAP,
            this.btnDuplicar,
            this.btnOpc});
            this.tlsBot.Location = new System.Drawing.Point(0, 0);
            this.tlsBot.Name = "tlsBot";
            this.tlsBot.Size = new System.Drawing.Size(1924, 36);
            this.tlsBot.TabIndex = 16;
            this.tlsBot.Text = "toolStrip1";
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("btnNuevo.Image")));
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(42, 33);
            this.btnNuevo.Text = "&Nuevo";
            this.btnNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnOpc
            // 
            this.btnOpc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiDesTot});
            this.btnOpc.Image = ((System.Drawing.Image)(resources.GetObject("btnOpc.Image")));
            this.btnOpc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpc.Name = "btnOpc";
            this.btnOpc.Size = new System.Drawing.Size(64, 33);
            this.btnOpc.Text = "Opciones";
            this.btnOpc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // tsmiDesTot
            // 
            this.tsmiDesTot.Name = "tsmiDesTot";
            this.tsmiDesTot.Size = new System.Drawing.Size(152, 22);
            this.tsmiDesTot.Text = "Descuento Total";
            this.tsmiDesTot.Click += new System.EventHandler(this.tsmiDesTot_Click);
            // 
            // ofdRutIma
            // 
            this.ofdRutIma.FileName = "openFileDialog1";
            // 
            // fgDetArtAAItemTodos
            // 
            this.fgDetArtAAItemTodos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgDetArtAAItemTodos.ColumnInfo = "1,0,0,0,0,85,Columns:";
            this.fgDetArtAAItemTodos.Location = new System.Drawing.Point(654, 814);
            this.fgDetArtAAItemTodos.Name = "fgDetArtAAItemTodos";
            this.fgDetArtAAItemTodos.Rows.Count = 1;
            this.fgDetArtAAItemTodos.Rows.DefaultSize = 17;
            this.fgDetArtAAItemTodos.Size = new System.Drawing.Size(1931, 71);
            this.fgDetArtAAItemTodos.TabIndex = 83;
            this.fgDetArtAAItemTodos.Visible = false;
            // 
            // gbItmArtComCubre
            // 
            this.gbItmArtComCubre.Controls.Add(this.gbArtAAItem);
            this.gbItmArtComCubre.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.gbItmArtComCubre.Location = new System.Drawing.Point(1354, 14);
            this.gbItmArtComCubre.Name = "gbItmArtComCubre";
            this.gbItmArtComCubre.Size = new System.Drawing.Size(1322, 774);
            this.gbItmArtComCubre.TabIndex = 84;
            this.gbItmArtComCubre.TabStop = false;
            this.gbItmArtComCubre.Visible = false;
            // 
            // gbArtAAItem
            // 
            this.gbArtAAItem.Controls.Add(this.btnAceAAIte);
            this.gbArtAAItem.Controls.Add(this.txtComRecAAIte);
            this.gbArtAAItem.Controls.Add(this.label99);
            this.gbArtAAItem.Controls.Add(this.txtPorDesAAIte);
            this.gbArtAAItem.Controls.Add(this.label111);
            this.gbArtAAItem.Controls.Add(this.txtCodProCat);
            this.gbArtAAItem.Controls.Add(this.label110);
            this.gbArtAAItem.Controls.Add(this.txtMedAA);
            this.gbArtAAItem.Controls.Add(this.label109);
            this.gbArtAAItem.Controls.Add(this.txtNegIte);
            this.gbArtAAItem.Controls.Add(this.txtCodNegIte);
            this.gbArtAAItem.Controls.Add(this.label108);
            this.gbArtAAItem.Controls.Add(this.txtTC);
            this.gbArtAAItem.Controls.Add(this.label107);
            this.gbArtAAItem.Controls.Add(this.btnCanAAIte);
            this.gbArtAAItem.Controls.Add(this.txtDesArtComAA);
            this.gbArtAAItem.Controls.Add(this.txtIteArtComAA);
            this.gbArtAAItem.Controls.Add(this.label106);
            this.gbArtAAItem.Controls.Add(this.fgDetArtAAItem);
            this.gbArtAAItem.Controls.Add(this.checkBox1);
            this.gbArtAAItem.Controls.Add(this.btnCanIteAA);
            this.gbArtAAItem.Controls.Add(this.btnEliIteAA);
            this.gbArtAAItem.Controls.Add(this.btnModIteAA);
            this.gbArtAAItem.Controls.Add(this.btnAgrIteAA);
            this.gbArtAAItem.Controls.Add(this.txtObsAAItem);
            this.gbArtAAItem.Controls.Add(this.label105);
            this.gbArtAAItem.Controls.Add(this.txtValVen);
            this.gbArtAAItem.Controls.Add(this.label100);
            this.gbArtAAItem.Controls.Add(this.txtValVenSinIGV);
            this.gbArtAAItem.Controls.Add(this.label101);
            this.gbArtAAItem.Controls.Add(this.txtCalPreVen);
            this.gbArtAAItem.Controls.Add(this.label102);
            this.gbArtAAItem.Controls.Add(this.txtComTotDolInt);
            this.gbArtAAItem.Controls.Add(this.label103);
            this.gbArtAAItem.Controls.Add(this.txtComTotDolFOB);
            this.gbArtAAItem.Controls.Add(this.label97);
            this.gbArtAAItem.Controls.Add(this.txtCosIntTot);
            this.gbArtAAItem.Controls.Add(this.label98);
            this.gbArtAAItem.Controls.Add(this.txtCosAdiNac);
            this.gbArtAAItem.Controls.Add(this.label95);
            this.gbArtAAItem.Controls.Add(this.txtCosInt);
            this.gbArtAAItem.Controls.Add(this.label96);
            this.gbArtAAItem.Controls.Add(this.txtFacImp);
            this.gbArtAAItem.Controls.Add(this.label94);
            this.gbArtAAItem.Controls.Add(this.txtPorDesFOB);
            this.gbArtAAItem.Controls.Add(this.label93);
            this.gbArtAAItem.Controls.Add(this.txtDesIteAA);
            this.gbArtAAItem.Controls.Add(this.label92);
            this.gbArtAAItem.Controls.Add(this.txtCosFobFinUS);
            this.gbArtAAItem.Controls.Add(this.label91);
            this.gbArtAAItem.Controls.Add(this.txtCosFobUS);
            this.gbArtAAItem.Controls.Add(this.label90);
            this.gbArtAAItem.Controls.Add(this.txtCosFob);
            this.gbArtAAItem.Controls.Add(this.label89);
            this.gbArtAAItem.Controls.Add(this.txtCanAAItem);
            this.gbArtAAItem.Controls.Add(this.label88);
            this.gbArtAAItem.Controls.Add(this.txtMed);
            this.gbArtAAItem.Controls.Add(this.label87);
            this.gbArtAAItem.Controls.Add(this.txtMatBasMue);
            this.gbArtAAItem.Controls.Add(this.txtCodMatBasMue);
            this.gbArtAAItem.Controls.Add(this.label86);
            this.gbArtAAItem.Controls.Add(this.txtColPro);
            this.gbArtAAItem.Controls.Add(this.label85);
            this.gbArtAAItem.Controls.Add(this.txtPro);
            this.gbArtAAItem.Controls.Add(this.txtCodPro);
            this.gbArtAAItem.Controls.Add(this.label84);
            this.gbArtAAItem.Controls.Add(this.txtMarAA);
            this.gbArtAAItem.Controls.Add(this.txtCodMarAA);
            this.gbArtAAItem.Controls.Add(this.label83);
            this.gbArtAAItem.Controls.Add(this.txtSubFam);
            this.gbArtAAItem.Controls.Add(this.txtCodSubFam);
            this.gbArtAAItem.Controls.Add(this.label82);
            this.gbArtAAItem.Controls.Add(this.txtFamAA);
            this.gbArtAAItem.Controls.Add(this.txtCodFamAA);
            this.gbArtAAItem.Controls.Add(this.label81);
            this.gbArtAAItem.Controls.Add(this.txtSubLinAA);
            this.gbArtAAItem.Controls.Add(this.txtCodSubLinAA);
            this.gbArtAAItem.Controls.Add(this.label80);
            this.gbArtAAItem.Controls.Add(this.txtLin);
            this.gbArtAAItem.Controls.Add(this.txtCodLin);
            this.gbArtAAItem.Controls.Add(this.label79);
            this.gbArtAAItem.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbArtAAItem.Location = new System.Drawing.Point(44, 137);
            this.gbArtAAItem.Name = "gbArtAAItem";
            this.gbArtAAItem.Size = new System.Drawing.Size(1125, 507);
            this.gbArtAAItem.TabIndex = 18;
            this.gbArtAAItem.TabStop = false;
            this.gbArtAAItem.Text = "Items para articulos compuestos sin código";
            // 
            // btnAceAAIte
            // 
            this.btnAceAAIte.Location = new System.Drawing.Point(436, 458);
            this.btnAceAAIte.Name = "btnAceAAIte";
            this.btnAceAAIte.Size = new System.Drawing.Size(105, 21);
            this.btnAceAAIte.TabIndex = 100;
            this.btnAceAAIte.Text = "Aceptar";
            this.btnAceAAIte.UseVisualStyleBackColor = true;
            this.btnAceAAIte.Click += new System.EventHandler(this.btnAceAAIte_Click);
            // 
            // txtComRecAAIte
            // 
            this.txtComRecAAIte.BackColor = System.Drawing.Color.White;
            this.txtComRecAAIte.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComRecAAIte.Location = new System.Drawing.Point(819, 228);
            this.txtComRecAAIte.Name = "txtComRecAAIte";
            this.txtComRecAAIte.Size = new System.Drawing.Size(46, 18);
            this.txtComRecAAIte.TabIndex = 98;
            this.txtComRecAAIte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label99
            // 
            this.label99.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(767, 231);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(53, 11);
            this.label99.TabIndex = 99;
            this.label99.Text = "Com. Rec.:";
            // 
            // txtPorDesAAIte
            // 
            this.txtPorDesAAIte.Location = new System.Drawing.Point(690, 228);
            this.txtPorDesAAIte.Name = "txtPorDesAAIte";
            this.txtPorDesAAIte.Size = new System.Drawing.Size(60, 18);
            this.txtPorDesAAIte.TabIndex = 96;
            this.txtPorDesAAIte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(647, 231);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(41, 11);
            this.label111.TabIndex = 97;
            this.label111.Text = "Desc %:";
            // 
            // txtCodProCat
            // 
            this.txtCodProCat.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodProCat.Location = new System.Drawing.Point(948, 100);
            this.txtCodProCat.Name = "txtCodProCat";
            this.txtCodProCat.Size = new System.Drawing.Size(158, 18);
            this.txtCodProCat.TabIndex = 94;
            // 
            // label110
            // 
            this.label110.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(871, 97);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(78, 28);
            this.label110.TabIndex = 95;
            this.label110.Text = "Cod. Proveedor / Catalogo:";
            // 
            // txtMedAA
            // 
            this.txtMedAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedAA.Location = new System.Drawing.Point(71, 100);
            this.txtMedAA.Name = "txtMedAA";
            this.txtMedAA.Size = new System.Drawing.Size(148, 18);
            this.txtMedAA.TabIndex = 92;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(29, 103);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(42, 11);
            this.label109.TabIndex = 93;
            this.label109.Text = "Medidas:";
            // 
            // txtNegIte
            // 
            this.txtNegIte.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNegIte.Location = new System.Drawing.Point(727, 22);
            this.txtNegIte.Name = "txtNegIte";
            this.txtNegIte.ReadOnly = true;
            this.txtNegIte.Size = new System.Drawing.Size(111, 18);
            this.txtNegIte.TabIndex = 90;
            // 
            // txtCodNegIte
            // 
            this.txtCodNegIte.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodNegIte.Location = new System.Drawing.Point(690, 22);
            this.txtCodNegIte.Name = "txtCodNegIte";
            this.txtCodNegIte.Size = new System.Drawing.Size(37, 18);
            this.txtCodNegIte.TabIndex = 89;
            this.txtCodNegIte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(643, 25);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(41, 11);
            this.label108.TabIndex = 91;
            this.label108.Text = "Negocio:";
            // 
            // txtTC
            // 
            this.txtTC.BackColor = System.Drawing.Color.White;
            this.txtTC.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTC.Location = new System.Drawing.Point(948, 124);
            this.txtTC.Name = "txtTC";
            this.txtTC.Size = new System.Drawing.Size(46, 18);
            this.txtTC.TabIndex = 87;
            this.txtTC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(927, 127);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(21, 11);
            this.label107.TabIndex = 88;
            this.label107.Text = "TC:";
            // 
            // btnCanAAIte
            // 
            this.btnCanAAIte.Location = new System.Drawing.Point(538, 458);
            this.btnCanAAIte.Name = "btnCanAAIte";
            this.btnCanAAIte.Size = new System.Drawing.Size(105, 21);
            this.btnCanAAIte.TabIndex = 86;
            this.btnCanAAIte.Text = "Cancelar";
            this.btnCanAAIte.UseVisualStyleBackColor = true;
            this.btnCanAAIte.Click += new System.EventHandler(this.btnCanAAIte_Click);
            // 
            // txtDesArtComAA
            // 
            this.txtDesArtComAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDesArtComAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesArtComAA.Location = new System.Drawing.Point(108, 22);
            this.txtDesArtComAA.Name = "txtDesArtComAA";
            this.txtDesArtComAA.ReadOnly = true;
            this.txtDesArtComAA.Size = new System.Drawing.Size(518, 18);
            this.txtDesArtComAA.TabIndex = 84;
            // 
            // txtIteArtComAA
            // 
            this.txtIteArtComAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtIteArtComAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIteArtComAA.Location = new System.Drawing.Point(71, 22);
            this.txtIteArtComAA.Name = "txtIteArtComAA";
            this.txtIteArtComAA.Size = new System.Drawing.Size(37, 18);
            this.txtIteArtComAA.TabIndex = 83;
            this.txtIteArtComAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(20, 25);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(50, 11);
            this.label106.TabIndex = 85;
            this.label106.Text = "Art. Com.:";
            // 
            // fgDetArtAAItem
            // 
            this.fgDetArtAAItem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgDetArtAAItem.ColumnInfo = "1,0,0,0,0,85,Columns:";
            this.fgDetArtAAItem.Location = new System.Drawing.Point(25, 262);
            this.fgDetArtAAItem.Name = "fgDetArtAAItem";
            this.fgDetArtAAItem.Rows.Count = 1;
            this.fgDetArtAAItem.Rows.DefaultSize = 17;
            this.fgDetArtAAItem.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgDetArtAAItem.Size = new System.Drawing.Size(1081, 184);
            this.fgDetArtAAItem.TabIndex = 82;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(65, 233);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(113, 15);
            this.checkBox1.TabIndex = 81;
            this.checkBox1.Text = "Mantener información";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnCanIteAA
            // 
            this.btnCanIteAA.Location = new System.Drawing.Point(509, 228);
            this.btnCanIteAA.Name = "btnCanIteAA";
            this.btnCanIteAA.Size = new System.Drawing.Size(105, 21);
            this.btnCanIteAA.TabIndex = 80;
            this.btnCanIteAA.Text = "Cancelar Item";
            this.btnCanIteAA.UseVisualStyleBackColor = true;
            // 
            // btnEliIteAA
            // 
            this.btnEliIteAA.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnEliIteAA.Location = new System.Drawing.Point(406, 228);
            this.btnEliIteAA.Name = "btnEliIteAA";
            this.btnEliIteAA.Size = new System.Drawing.Size(105, 21);
            this.btnEliIteAA.TabIndex = 79;
            this.btnEliIteAA.Text = "Eliminar Item";
            this.btnEliIteAA.UseVisualStyleBackColor = true;
            // 
            // btnModIteAA
            // 
            this.btnModIteAA.Location = new System.Drawing.Point(303, 228);
            this.btnModIteAA.Name = "btnModIteAA";
            this.btnModIteAA.Size = new System.Drawing.Size(105, 21);
            this.btnModIteAA.TabIndex = 78;
            this.btnModIteAA.Text = "Modificar Item";
            this.btnModIteAA.UseVisualStyleBackColor = true;
            this.btnModIteAA.Click += new System.EventHandler(this.btnModIteAA_Click);
            // 
            // btnAgrIteAA
            // 
            this.btnAgrIteAA.Location = new System.Drawing.Point(200, 228);
            this.btnAgrIteAA.Name = "btnAgrIteAA";
            this.btnAgrIteAA.Size = new System.Drawing.Size(105, 21);
            this.btnAgrIteAA.TabIndex = 77;
            this.btnAgrIteAA.Text = "Agregar Item";
            this.btnAgrIteAA.UseVisualStyleBackColor = true;
            this.btnAgrIteAA.Click += new System.EventHandler(this.btnAgrIteAA_Click);
            // 
            // txtObsAAItem
            // 
            this.txtObsAAItem.BackColor = System.Drawing.Color.White;
            this.txtObsAAItem.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtObsAAItem.Location = new System.Drawing.Point(276, 176);
            this.txtObsAAItem.Multiline = true;
            this.txtObsAAItem.Name = "txtObsAAItem";
            this.txtObsAAItem.Size = new System.Drawing.Size(830, 34);
            this.txtObsAAItem.TabIndex = 75;
            this.txtObsAAItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label105
            // 
            this.label105.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(249, 179);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(25, 10);
            this.label105.TabIndex = 76;
            this.label105.Text = "Obs.:";
            // 
            // txtValVen
            // 
            this.txtValVen.BackColor = System.Drawing.Color.White;
            this.txtValVen.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValVen.Location = new System.Drawing.Point(172, 175);
            this.txtValVen.Name = "txtValVen";
            this.txtValVen.Size = new System.Drawing.Size(46, 18);
            this.txtValVen.TabIndex = 69;
            this.txtValVen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtValVen.TextChanged += new System.EventHandler(this.txtValVen_TextChanged);
            // 
            // label100
            // 
            this.label100.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(131, 175);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(41, 14);
            this.label100.TabIndex = 70;
            this.label100.Text = "Px / VV:";
            // 
            // txtValVenSinIGV
            // 
            this.txtValVenSinIGV.BackColor = System.Drawing.Color.White;
            this.txtValVenSinIGV.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValVenSinIGV.Location = new System.Drawing.Point(70, 175);
            this.txtValVenSinIGV.Name = "txtValVenSinIGV";
            this.txtValVenSinIGV.Size = new System.Drawing.Size(46, 18);
            this.txtValVenSinIGV.TabIndex = 67;
            this.txtValVenSinIGV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label101
            // 
            this.label101.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(48, 178);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(22, 14);
            this.label101.TabIndex = 68;
            this.label101.Text = "VV:";
            // 
            // txtCalPreVen
            // 
            this.txtCalPreVen.BackColor = System.Drawing.Color.White;
            this.txtCalPreVen.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalPreVen.Location = new System.Drawing.Point(1060, 151);
            this.txtCalPreVen.Name = "txtCalPreVen";
            this.txtCalPreVen.Size = new System.Drawing.Size(46, 18);
            this.txtCalPreVen.TabIndex = 65;
            this.txtCalPreVen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label102
            // 
            this.label102.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(1006, 149);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(54, 23);
            this.label102.TabIndex = 66;
            this.label102.Text = "Calculo Px VTA o VV:";
            // 
            // txtComTotDolInt
            // 
            this.txtComTotDolInt.BackColor = System.Drawing.Color.White;
            this.txtComTotDolInt.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComTotDolInt.Location = new System.Drawing.Point(948, 151);
            this.txtComTotDolInt.Name = "txtComTotDolInt";
            this.txtComTotDolInt.Size = new System.Drawing.Size(46, 18);
            this.txtComTotDolInt.TabIndex = 63;
            this.txtComTotDolInt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label103
            // 
            this.label103.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(869, 148);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(85, 23);
            this.label103.TabIndex = 64;
            this.label103.Text = "Compra total dolares internado: ";
            // 
            // txtComTotDolFOB
            // 
            this.txtComTotDolFOB.BackColor = System.Drawing.Color.White;
            this.txtComTotDolFOB.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComTotDolFOB.Location = new System.Drawing.Point(819, 152);
            this.txtComTotDolFOB.Name = "txtComTotDolFOB";
            this.txtComTotDolFOB.Size = new System.Drawing.Size(46, 18);
            this.txtComTotDolFOB.TabIndex = 61;
            this.txtComTotDolFOB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label97
            // 
            this.label97.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(758, 149);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(60, 23);
            this.label97.TabIndex = 62;
            this.label97.Text = "Compra total dolares FOB:";
            // 
            // txtCosIntTot
            // 
            this.txtCosIntTot.BackColor = System.Drawing.Color.White;
            this.txtCosIntTot.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCosIntTot.Location = new System.Drawing.Point(704, 151);
            this.txtCosIntTot.Name = "txtCosIntTot";
            this.txtCosIntTot.Size = new System.Drawing.Size(46, 18);
            this.txtCosIntTot.TabIndex = 59;
            this.txtCosIntTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosIntTot.TextChanged += new System.EventHandler(this.txtCosIntTot_TextChanged);
            // 
            // label98
            // 
            this.label98.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(629, 150);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(77, 22);
            this.label98.TabIndex = 60;
            this.label98.Text = "COST. INTERN. TOTAL:";
            // 
            // txtCosAdiNac
            // 
            this.txtCosAdiNac.BackColor = System.Drawing.Color.White;
            this.txtCosAdiNac.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCosAdiNac.Location = new System.Drawing.Point(579, 151);
            this.txtCosAdiNac.Name = "txtCosAdiNac";
            this.txtCosAdiNac.Size = new System.Drawing.Size(46, 18);
            this.txtCosAdiNac.TabIndex = 57;
            this.txtCosAdiNac.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosAdiNac.TextChanged += new System.EventHandler(this.txtCosAdiNac_TextChanged);
            // 
            // label95
            // 
            this.label95.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(483, 155);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(96, 13);
            this.label95.TabIndex = 58;
            this.label95.Text = "COST. ADIC. NAC.:";
            // 
            // txtCosInt
            // 
            this.txtCosInt.BackColor = System.Drawing.Color.White;
            this.txtCosInt.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCosInt.Location = new System.Drawing.Point(410, 151);
            this.txtCosInt.Name = "txtCosInt";
            this.txtCosInt.Size = new System.Drawing.Size(46, 18);
            this.txtCosInt.TabIndex = 55;
            this.txtCosInt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosInt.TextChanged += new System.EventHandler(this.txtCosInt_TextChanged);
            // 
            // label96
            // 
            this.label96.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(350, 154);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(61, 14);
            this.label96.TabIndex = 56;
            this.label96.Text = "COST. INT.:";
            // 
            // txtFacImp
            // 
            this.txtFacImp.BackColor = System.Drawing.Color.White;
            this.txtFacImp.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFacImp.Location = new System.Drawing.Point(276, 151);
            this.txtFacImp.Name = "txtFacImp";
            this.txtFacImp.Size = new System.Drawing.Size(46, 18);
            this.txtFacImp.TabIndex = 53;
            this.txtFacImp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label94
            // 
            this.label94.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(240, 148);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(36, 23);
            this.label94.TabIndex = 54;
            this.label94.Text = "Factor Import:";
            // 
            // txtPorDesFOB
            // 
            this.txtPorDesFOB.BackColor = System.Drawing.Color.White;
            this.txtPorDesFOB.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPorDesFOB.Location = new System.Drawing.Point(173, 151);
            this.txtPorDesFOB.Name = "txtPorDesFOB";
            this.txtPorDesFOB.Size = new System.Drawing.Size(46, 18);
            this.txtPorDesFOB.TabIndex = 51;
            this.txtPorDesFOB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label93
            // 
            this.label93.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(125, 148);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(49, 23);
            this.label93.TabIndex = 52;
            this.label93.Text = "%Dscto para FOB:";
            // 
            // txtDesIteAA
            // 
            this.txtDesIteAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesIteAA.Location = new System.Drawing.Point(71, 48);
            this.txtDesIteAA.Name = "txtDesIteAA";
            this.txtDesIteAA.Size = new System.Drawing.Size(555, 18);
            this.txtDesIteAA.TabIndex = 49;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(10, 48);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(54, 11);
            this.label92.TabIndex = 50;
            this.label92.Text = "Descripción:";
            // 
            // txtCosFobFinUS
            // 
            this.txtCosFobFinUS.BackColor = System.Drawing.Color.White;
            this.txtCosFobFinUS.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCosFobFinUS.Location = new System.Drawing.Point(71, 151);
            this.txtCosFobFinUS.Name = "txtCosFobFinUS";
            this.txtCosFobFinUS.Size = new System.Drawing.Size(46, 18);
            this.txtCosFobFinUS.TabIndex = 47;
            this.txtCosFobFinUS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosFobFinUS.TextChanged += new System.EventHandler(this.txtCosFobFinUS_TextChanged);
            // 
            // label91
            // 
            this.label91.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(16, 151);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(61, 24);
            this.label91.TabIndex = 48;
            this.label91.Text = "COST FOB Final US$:";
            // 
            // txtCosFobUS
            // 
            this.txtCosFobUS.BackColor = System.Drawing.Color.White;
            this.txtCosFobUS.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCosFobUS.Location = new System.Drawing.Point(1060, 124);
            this.txtCosFobUS.Name = "txtCosFobUS";
            this.txtCosFobUS.Size = new System.Drawing.Size(46, 18);
            this.txtCosFobUS.TabIndex = 45;
            this.txtCosFobUS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosFobUS.TextChanged += new System.EventHandler(this.txtCosFobUS_TextChanged);
            // 
            // label90
            // 
            this.label90.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(1006, 123);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(61, 22);
            this.label90.TabIndex = 46;
            this.label90.Text = "COST FOB US$:";
            // 
            // txtCosFob
            // 
            this.txtCosFob.BackColor = System.Drawing.Color.White;
            this.txtCosFob.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCosFob.Location = new System.Drawing.Point(819, 124);
            this.txtCosFob.Name = "txtCosFob";
            this.txtCosFob.Size = new System.Drawing.Size(46, 18);
            this.txtCosFob.TabIndex = 43;
            this.txtCosFob.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCosFob.TextChanged += new System.EventHandler(this.txtCosFob_TextChanged);
            // 
            // label89
            // 
            this.label89.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(787, 123);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(32, 23);
            this.label89.TabIndex = 44;
            this.label89.Text = "COST FOB:";
            // 
            // txtCanAAItem
            // 
            this.txtCanAAItem.BackColor = System.Drawing.Color.White;
            this.txtCanAAItem.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCanAAItem.Location = new System.Drawing.Point(704, 124);
            this.txtCanAAItem.Name = "txtCanAAItem";
            this.txtCanAAItem.Size = new System.Drawing.Size(46, 18);
            this.txtCanAAItem.TabIndex = 41;
            this.txtCanAAItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCanAAItem.TextChanged += new System.EventHandler(this.txtCanAAItem_TextChanged);
            this.txtCanAAItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCanAAItem_KeyPress);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(679, 127);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(25, 11);
            this.label88.TabIndex = 42;
            this.label88.Text = "Can:";
            // 
            // txtMed
            // 
            this.txtMed.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMed.Location = new System.Drawing.Point(276, 124);
            this.txtMed.Name = "txtMed";
            this.txtMed.Size = new System.Drawing.Size(349, 18);
            this.txtMed.TabIndex = 39;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(234, 127);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(42, 11);
            this.label87.TabIndex = 40;
            this.label87.Text = "Medidas:";
            // 
            // txtMatBasMue
            // 
            this.txtMatBasMue.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatBasMue.Location = new System.Drawing.Point(108, 124);
            this.txtMatBasMue.Name = "txtMatBasMue";
            this.txtMatBasMue.Size = new System.Drawing.Size(111, 18);
            this.txtMatBasMue.TabIndex = 37;
            this.txtMatBasMue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMatBasMue_KeyPress);
            // 
            // txtCodMatBasMue
            // 
            this.txtCodMatBasMue.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodMatBasMue.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodMatBasMue.Location = new System.Drawing.Point(71, 124);
            this.txtCodMatBasMue.Name = "txtCodMatBasMue";
            this.txtCodMatBasMue.Size = new System.Drawing.Size(37, 18);
            this.txtCodMatBasMue.TabIndex = 36;
            this.txtCodMatBasMue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label86
            // 
            this.label86.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(10, 123);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(66, 23);
            this.label86.TabIndex = 38;
            this.label86.Text = "Material Base de Mueble:";
            // 
            // txtColPro
            // 
            this.txtColPro.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColPro.Location = new System.Drawing.Point(704, 100);
            this.txtColPro.Name = "txtColPro";
            this.txtColPro.Size = new System.Drawing.Size(161, 18);
            this.txtColPro.TabIndex = 34;
            // 
            // label85
            // 
            this.label85.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(653, 103);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(52, 11);
            this.label85.TabIndex = 35;
            this.label85.Text = "Color Prod:";
            // 
            // txtPro
            // 
            this.txtPro.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPro.Location = new System.Drawing.Point(349, 100);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(276, 18);
            this.txtPro.TabIndex = 31;
            this.txtPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPro_KeyPress);
            // 
            // txtCodPro
            // 
            this.txtCodPro.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodPro.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodPro.Location = new System.Drawing.Point(276, 100);
            this.txtCodPro.Name = "txtCodPro";
            this.txtCodPro.Size = new System.Drawing.Size(76, 18);
            this.txtCodPro.TabIndex = 30;
            this.txtCodPro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(227, 103);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(51, 11);
            this.label84.TabIndex = 32;
            this.label84.Text = "Proveedor:";
            // 
            // txtMarAA
            // 
            this.txtMarAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMarAA.Location = new System.Drawing.Point(985, 76);
            this.txtMarAA.Name = "txtMarAA";
            this.txtMarAA.Size = new System.Drawing.Size(121, 18);
            this.txtMarAA.TabIndex = 28;
            this.txtMarAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMarAA_KeyPress);
            // 
            // txtCodMarAA
            // 
            this.txtCodMarAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodMarAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodMarAA.Location = new System.Drawing.Point(948, 76);
            this.txtCodMarAA.Name = "txtCodMarAA";
            this.txtCodMarAA.Size = new System.Drawing.Size(37, 18);
            this.txtCodMarAA.TabIndex = 27;
            this.txtCodMarAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(916, 79);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(33, 11);
            this.label83.TabIndex = 29;
            this.label83.Text = "Marca:";
            // 
            // txtSubFam
            // 
            this.txtSubFam.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubFam.Location = new System.Drawing.Point(741, 76);
            this.txtSubFam.Name = "txtSubFam";
            this.txtSubFam.Size = new System.Drawing.Size(123, 18);
            this.txtSubFam.TabIndex = 25;
            this.txtSubFam.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSubFam_KeyPress);
            // 
            // txtCodSubFam
            // 
            this.txtCodSubFam.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodSubFam.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodSubFam.Location = new System.Drawing.Point(704, 76);
            this.txtCodSubFam.Name = "txtCodSubFam";
            this.txtCodSubFam.Size = new System.Drawing.Size(37, 18);
            this.txtCodSubFam.TabIndex = 24;
            this.txtCodSubFam.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(651, 79);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(54, 11);
            this.label82.TabIndex = 26;
            this.label82.Text = "SubFamilia:";
            // 
            // txtFamAA
            // 
            this.txtFamAA.BackColor = System.Drawing.Color.White;
            this.txtFamAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFamAA.Location = new System.Drawing.Point(514, 76);
            this.txtFamAA.Name = "txtFamAA";
            this.txtFamAA.Size = new System.Drawing.Size(111, 18);
            this.txtFamAA.TabIndex = 22;
            this.txtFamAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFamAA_KeyPress);
            // 
            // txtCodFamAA
            // 
            this.txtCodFamAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodFamAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodFamAA.Location = new System.Drawing.Point(477, 76);
            this.txtCodFamAA.Name = "txtCodFamAA";
            this.txtCodFamAA.Size = new System.Drawing.Size(37, 18);
            this.txtCodFamAA.TabIndex = 21;
            this.txtCodFamAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(440, 79);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(38, 11);
            this.label81.TabIndex = 23;
            this.label81.Text = "Familia:";
            // 
            // txtSubLinAA
            // 
            this.txtSubLinAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubLinAA.Location = new System.Drawing.Point(313, 76);
            this.txtSubLinAA.Name = "txtSubLinAA";
            this.txtSubLinAA.Size = new System.Drawing.Size(111, 18);
            this.txtSubLinAA.TabIndex = 19;
            this.txtSubLinAA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSubLinAA_KeyPress);
            // 
            // txtCodSubLinAA
            // 
            this.txtCodSubLinAA.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodSubLinAA.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodSubLinAA.Location = new System.Drawing.Point(276, 76);
            this.txtCodSubLinAA.Name = "txtCodSubLinAA";
            this.txtCodSubLinAA.Size = new System.Drawing.Size(37, 18);
            this.txtCodSubLinAA.TabIndex = 18;
            this.txtCodSubLinAA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(233, 79);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(45, 11);
            this.label80.TabIndex = 20;
            this.label80.Text = "SubLinea:";
            // 
            // txtLin
            // 
            this.txtLin.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLin.Location = new System.Drawing.Point(108, 76);
            this.txtLin.Name = "txtLin";
            this.txtLin.Size = new System.Drawing.Size(111, 18);
            this.txtLin.TabIndex = 16;
            this.txtLin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLin_KeyPress);
            // 
            // txtCodLin
            // 
            this.txtCodLin.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodLin.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodLin.Location = new System.Drawing.Point(71, 76);
            this.txtCodLin.Name = "txtCodLin";
            this.txtCodLin.Size = new System.Drawing.Size(37, 18);
            this.txtCodLin.TabIndex = 15;
            this.txtCodLin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(43, 79);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(29, 11);
            this.label79.TabIndex = 17;
            this.label79.Text = "Linea:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(571, 14);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(75, 13);
            this.label33.TabIndex = 7;
            this.label33.Text = "Nº Cotización:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(744, 14);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(93, 13);
            this.label34.TabIndex = 9;
            this.label34.Text = "Fecha de emisión:";
            // 
            // txtNum
            // 
            this.txtNum.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNum.Location = new System.Drawing.Point(646, 11);
            this.txtNum.Name = "txtNum";
            this.txtNum.ReadOnly = true;
            this.txtNum.Size = new System.Drawing.Size(82, 21);
            this.txtNum.TabIndex = 6;
            this.txtNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFecEmi
            // 
            this.txtFecEmi.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtFecEmi.Location = new System.Drawing.Point(837, 11);
            this.txtFecEmi.Name = "txtFecEmi";
            this.txtFecEmi.ReadOnly = true;
            this.txtFecEmi.Size = new System.Drawing.Size(82, 21);
            this.txtFecEmi.TabIndex = 8;
            this.txtFecEmi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbIteCat
            // 
            this.gbIteCat.Controls.Add(this.fgAACatIte);
            this.gbIteCat.Controls.Add(this.btnCanAACat);
            this.gbIteCat.Controls.Add(this.btnAceAACat);
            this.gbIteCat.Location = new System.Drawing.Point(305, 725);
            this.gbIteCat.Name = "gbIteCat";
            this.gbIteCat.Size = new System.Drawing.Size(337, 281);
            this.gbIteCat.TabIndex = 85;
            this.gbIteCat.TabStop = false;
            this.gbIteCat.Text = "Items (Catalogo)";
            this.gbIteCat.Visible = false;
            // 
            // fgAACatIte
            // 
            this.fgAACatIte.ColumnInfo = "3,0,0,0,0,95,Columns:";
            this.fgAACatIte.Location = new System.Drawing.Point(10, 24);
            this.fgAACatIte.Name = "fgAACatIte";
            this.fgAACatIte.Rows.Count = 10;
            this.fgAACatIte.Rows.DefaultSize = 19;
            this.fgAACatIte.Size = new System.Drawing.Size(313, 210);
            this.fgAACatIte.TabIndex = 2;
            this.fgAACatIte.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgAACatIte_AfterEdit);
            this.fgAACatIte.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgAACatIte_KeyPressEdit);
            // 
            // btnCanAACat
            // 
            this.btnCanAACat.Location = new System.Drawing.Point(181, 249);
            this.btnCanAACat.Name = "btnCanAACat";
            this.btnCanAACat.Size = new System.Drawing.Size(139, 22);
            this.btnCanAACat.TabIndex = 1;
            this.btnCanAACat.Text = "Cancelar";
            this.btnCanAACat.UseVisualStyleBackColor = true;
            this.btnCanAACat.Click += new System.EventHandler(this.btnCanAACat_Click);
            // 
            // btnAceAACat
            // 
            this.btnAceAACat.Location = new System.Drawing.Point(17, 249);
            this.btnAceAACat.Name = "btnAceAACat";
            this.btnAceAACat.Size = new System.Drawing.Size(139, 22);
            this.btnAceAACat.TabIndex = 0;
            this.btnAceAACat.Text = "Aceptar";
            this.btnAceAACat.UseVisualStyleBackColor = true;
            this.btnAceAACat.Click += new System.EventHandler(this.btnAceAACat_Click);
            // 
            // txtComRec
            // 
            this.txtComRec.BackColor = System.Drawing.Color.White;
            this.txtComRec.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComRec.Location = new System.Drawing.Point(1710, 686);
            this.txtComRec.Name = "txtComRec";
            this.txtComRec.Size = new System.Drawing.Size(60, 21);
            this.txtComRec.TabIndex = 92;
            this.txtComRec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtComRec.Visible = false;
            // 
            // label104
            // 
            this.label104.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(1651, 689);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(61, 11);
            this.label104.TabIndex = 93;
            this.label104.Text = "Com. Rec.:";
            this.label104.Visible = false;
            // 
            // txtEnv
            // 
            this.txtEnv.Location = new System.Drawing.Point(1513, 684);
            this.txtEnv.Name = "txtEnv";
            this.txtEnv.Size = new System.Drawing.Size(126, 21);
            this.txtEnv.TabIndex = 90;
            this.txtEnv.Visible = false;
            this.txtEnv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEnv_KeyPress);
            // 
            // txtCodEnv
            // 
            this.txtCodEnv.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodEnv.Location = new System.Drawing.Point(1452, 684);
            this.txtCodEnv.Name = "txtCodEnv";
            this.txtCodEnv.Size = new System.Drawing.Size(60, 21);
            this.txtCodEnv.TabIndex = 89;
            this.txtCodEnv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodEnv.Visible = false;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(1416, 687);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(37, 13);
            this.label76.TabIndex = 91;
            this.label76.Text = "Envio:";
            this.label76.Visible = false;
            // 
            // txtNeg
            // 
            this.txtNeg.Location = new System.Drawing.Point(1256, 684);
            this.txtNeg.Name = "txtNeg";
            this.txtNeg.Size = new System.Drawing.Size(126, 21);
            this.txtNeg.TabIndex = 87;
            this.txtNeg.Visible = false;
            this.txtNeg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNeg_KeyPress);
            // 
            // txtCodNeg
            // 
            this.txtCodNeg.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodNeg.Location = new System.Drawing.Point(1195, 684);
            this.txtCodNeg.Name = "txtCodNeg";
            this.txtCodNeg.Size = new System.Drawing.Size(60, 21);
            this.txtCodNeg.TabIndex = 86;
            this.txtCodNeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodNeg.Visible = false;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(1148, 687);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(49, 13);
            this.label75.TabIndex = 88;
            this.label75.Text = "Negocio:";
            this.label75.Visible = false;
            // 
            // frmVEN_Cot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 953);
            this.Controls.Add(this.txtComRec);
            this.Controls.Add(this.label104);
            this.Controls.Add(this.txtEnv);
            this.Controls.Add(this.txtCodEnv);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.txtNeg);
            this.Controls.Add(this.txtCodNeg);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.gbIteCat);
            this.Controls.Add(this.gbItmArtComCubre);
            this.Controls.Add(this.txtFecEmi);
            this.Controls.Add(this.fgDetArtAAItemTodos);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.fgArtAmbTodos);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.gpbCubre);
            this.Controls.Add(this.fgComTodos);
            this.Controls.Add(this.fgAmbTodos);
            this.Controls.Add(this.tbPri);
            this.Controls.Add(this.pnTot);
            this.Controls.Add(this.tlsBot);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmVEN_Cot";
            this.Text = "COTIZADOR";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.frmVEN_Cot_Activated);
            this.Load += new System.EventHandler(this.frmVEN_Cot_Load);
            this.Resize += new System.EventHandler(this.frmVEN_Cot_Resize);
            this.tbpArtCom.ResumeLayout(false);
            this.tbpArtCom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgDet)).EndInit();
            this.tbAmb.ResumeLayout(false);
            this.tbpAmb.ResumeLayout(false);
            this.tbpAmb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAmb)).EndInit();
            this.tbpObs.ResumeLayout(false);
            this.tbpObs.PerformLayout();
            this.tbpOtrArt.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetAA)).EndInit();
            this.tbpEnc.ResumeLayout(false);
            this.tbpEnc.PerformLayout();
            this.grpObs.ResumeLayout(false);
            this.grpObs.PerformLayout();
            this.grbInfRec.ResumeLayout(false);
            this.grbInfRec.PerformLayout();
            this.grpFacTipVen.ResumeLayout(false);
            this.grpFacTipVen.PerformLayout();
            this.grbAdmRQ.ResumeLayout(false);
            this.grbAdmRQ.PerformLayout();
            this.gpbCubre.ResumeLayout(false);
            this.gpbMoneda.ResumeLayout(false);
            this.gpbMoneda.PerformLayout();
            this.tbPri.ResumeLayout(false);
            this.tbpArtSim.ResumeLayout(false);
            this.tbpArtSim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArtDet)).EndInit();
            this.tbArtAmb.ResumeLayout(false);
            this.tbpArtAmb.ResumeLayout(false);
            this.tbpArtAmb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArtAmb)).EndInit();
            this.tbpArtObs.ResumeLayout(false);
            this.tbpArtObs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAmbTodos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgComTodos)).EndInit();
            this.pnTot.ResumeLayout(false);
            this.pnTot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgArtAmbTodos)).EndInit();
            this.tlsBot.ResumeLayout(false);
            this.tlsBot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetArtAAItemTodos)).EndInit();
            this.gbItmArtComCubre.ResumeLayout(false);
            this.gbArtAAItem.ResumeLayout(false);
            this.gbArtAAItem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDetArtAAItem)).EndInit();
            this.gbIteCat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgAACatIte)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        //private System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.ToolStripButton btnAbrir;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton btnDeshacer;
        private System.Windows.Forms.ToolStripButton btnModificar;
        private System.Windows.Forms.ToolStripButton btnOpcImp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton btnAprobar;
        private System.Windows.Forms.ToolStripButton btnMigrarSAP;
        private System.Windows.Forms.ToolStripButton btnDuplicar;
        private System.Windows.Forms.TabPage tbpEnc;
        private System.Windows.Forms.TextBox txtCli;
        private System.Windows.Forms.Button btnVinRQ;
        private System.Windows.Forms.TextBox txtRec;
        private System.Windows.Forms.TextBox txtTipVen;
        private System.Windows.Forms.TextBox txtCenVen;
        private System.Windows.Forms.TextBox txtVen;
        private System.Windows.Forms.TextBox txtCliCon;
        private System.Windows.Forms.TextBox txtCodRec;
        private System.Windows.Forms.TextBox txtDim;
        private System.Windows.Forms.TextBox txtTipObr;
        private System.Windows.Forms.TextBox txtRub;
        private System.Windows.Forms.TextBox txtTipVenRel;
        private System.Windows.Forms.TextBox txtCodTipVen;
        private System.Windows.Forms.TextBox txtCodCenVen;
        private System.Windows.Forms.TextBox txtCodVen;
        private System.Windows.Forms.TextBox txtCodCliCon;
        private System.Windows.Forms.TextBox txtDirObr;
        private System.Windows.Forms.TextBox txtDirCli;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtCodCli;
        private System.Windows.Forms.TextBox txtNomCot;
        private System.Windows.Forms.TextBox txtRQ;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tbpArtCom;
        private System.Windows.Forms.TabPage tbpOtrArt;
        private System.Windows.Forms.TextBox txtRUCDNI;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtDocEntry;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtDocNum;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtCodTipDoc;
        private System.Windows.Forms.Button btnDirObr;
        private System.Windows.Forms.Button btnDirCli;
        private System.Windows.Forms.Button btnCanItem;
        private System.Windows.Forms.Button btnBorItem;
        private System.Windows.Forms.Button btnModItem;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtIGV;
        private System.Windows.Forms.TextBox txtValNet;
        private System.Windows.Forms.TextBox txtVenBru;
        private System.Windows.Forms.TextBox txtCan;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtSubTot;
        private System.Windows.Forms.TextBox txtSim;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.TextBox txtCodArtCom;
        private System.Windows.Forms.TabControl tbAmb;
        private System.Windows.Forms.TabPage tbpAmb;
        private System.Windows.Forms.TextBox txtCodAmb;
        private System.Windows.Forms.TextBox txtCanAmb;
        private System.Windows.Forms.TextBox txtAmb;
        private System.Windows.Forms.TabPage tbpObs;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lblIGVUnit;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnSigPag;
        private System.Windows.Forms.GroupBox gpbCubre;
        private System.Windows.Forms.GroupBox gpbMoneda;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Button btnAce;
        private System.Windows.Forms.RadioButton rdbSol;
        private System.Windows.Forms.RadioButton rdbDol;
        private System.Windows.Forms.Button btnAgrItem;
        private System.Windows.Forms.TabControl tbPri;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.TextBox txtPorDes;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button btnAgrAmb;
        private System.Windows.Forms.Button btnEliAmb;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label lblIGVUnitAA;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtObsAA;
        private System.Windows.Forms.TextBox txtRutIma;
        private System.Windows.Forms.TextBox txtValNetAA;
        private System.Windows.Forms.TextBox txtIGVAA;
        private System.Windows.Forms.TextBox txtSubTotAA;
        private System.Windows.Forms.TextBox txtAmbAA;
        private System.Windows.Forms.TextBox txtCodAmbAA;
        private System.Windows.Forms.TextBox txtCanAA;
        private System.Windows.Forms.TextBox txtPreUniAA;
        private System.Windows.Forms.TextBox txtVenBruAA;
        private System.Windows.Forms.TextBox txtPorDesAA;
        private System.Windows.Forms.TextBox txtDescAA;
        private System.Windows.Forms.TextBox txtDesAA;
        private System.Windows.Forms.TabPage tbpArtSim;
        private System.Windows.Forms.TextBox txtMot;
        private System.Windows.Forms.TextBox txtCodMot;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox grpFacTipVen;
        private System.Windows.Forms.TextBox txtPag;
        private System.Windows.Forms.TextBox txtTie;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtNomAdi;
        private System.Windows.Forms.Label label61;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDet;
        private C1.Win.C1FlexGrid.C1FlexGrid fgAmbTodos;
        private C1.Win.C1FlexGrid.C1FlexGrid fgComTodos;
        private C1.Win.C1FlexGrid.C1FlexGrid fgAmb;
        private System.Windows.Forms.Label lblAmbTot;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label lblInfoItem;
        private System.Windows.Forms.Button btnAgrCom;
        private System.Windows.Forms.Button btnCanCom;
        private System.Windows.Forms.Button btnBorCom;
        private System.Windows.Forms.Panel pnTot;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtTotDes;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtTotPorDes;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtTotVenBru;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txtTotGen;
        private System.Windows.Forms.Label lblIGVTotal;
        private System.Windows.Forms.TextBox txtTotIGV;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtTotValVen;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtMar;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtCosTot;
        public C1.Win.C1FlexGrid.C1FlexGrid fgCom;
        private System.Windows.Forms.Button btnCanItemAA;
        private System.Windows.Forms.Button btnModItemAA;
        private System.Windows.Forms.Button btnAgrAA;
        private System.Windows.Forms.Button btnRutIma;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDetAA;
        private C1.Win.C1FlexGrid.C1FlexGrid fgArtDet;
        private System.Windows.Forms.TextBox txtArtDesc;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtArtPorDes;
        private System.Windows.Forms.Button btnArtAgrItem;
        private System.Windows.Forms.TextBox txtArtSubTot;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtArtIGV;
        private System.Windows.Forms.Label lblArtIGVUnit;
        private System.Windows.Forms.TextBox txtArtValNet;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtArtVenBru;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtArtCan;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtArtPrecio;
        private System.Windows.Forms.TextBox txtArtDes;
        private System.Windows.Forms.TextBox txtCodArt;
        private System.Windows.Forms.TabControl tbArtAmb;
        private System.Windows.Forms.TabPage tbpArtAmb;
        private System.Windows.Forms.Label lblArtAmbTot;
        private System.Windows.Forms.Label label56;
        private C1.Win.C1FlexGrid.C1FlexGrid fgArtAmb;
        private System.Windows.Forms.Button btnArtAgrAmb;
        private System.Windows.Forms.Button btnArtEliAmb;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox txtArtCodAmb;
        private System.Windows.Forms.TextBox txtArtCanAmb;
        private System.Windows.Forms.TextBox txtArtAmb;
        private System.Windows.Forms.TabPage tbpArtObs;
        private System.Windows.Forms.TextBox txtArtObs;
        private System.Windows.Forms.Button btnArtModItem;
        private System.Windows.Forms.Button btnArtBorItem;
        private System.Windows.Forms.Button btnArtCanItem;
        private C1.Win.C1FlexGrid.C1FlexGrid fgArtAmbTodos;
        private System.Windows.Forms.Label lblArtInfoItem;
        private System.Windows.Forms.GroupBox grbInfRec;
        private System.Windows.Forms.TextBox txtFam;
        private System.Windows.Forms.TextBox txtCodFam;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox txtSubLin;
        private System.Windows.Forms.TextBox txtCodSubLin;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtTip;
        private System.Windows.Forms.TextBox txtCodTip;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtLinPro;
        private System.Windows.Forms.TextBox txtCodLinPro;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtFalEn;
        private System.Windows.Forms.TextBox txtCodFalEn;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ToolStrip tlsBot;
        private System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.TextBox txtRutImaTec;
        private System.Windows.Forms.Button btnRutImaTec;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox txtRutIma2;
        private System.Windows.Forms.Button btnRutIma2;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.OpenFileDialog ofdRutIma;
        private System.Windows.Forms.GroupBox grbAdmRQ;
        private System.Windows.Forms.TextBox txtAdmRQ;
        private System.Windows.Forms.TextBox txtCodAdmRQ;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.GroupBox grpObs;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.TextBox txtObsExt;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDetArtAAItemTodos;
        private System.Windows.Forms.GroupBox gbItmArtComCubre;
        private System.Windows.Forms.GroupBox gbArtAAItem;
        private System.Windows.Forms.Button btnCanAAIte;
        private System.Windows.Forms.TextBox txtDesArtComAA;
        private System.Windows.Forms.TextBox txtIteArtComAA;
        private System.Windows.Forms.Label label106;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDetArtAAItem;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnCanIteAA;
        private System.Windows.Forms.Button btnEliIteAA;
        private System.Windows.Forms.Button btnModIteAA;
        private System.Windows.Forms.Button btnAgrIteAA;
        private System.Windows.Forms.TextBox txtObsAAItem;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox txtValVen;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox txtValVenSinIGV;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.TextBox txtCalPreVen;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.TextBox txtComTotDolInt;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox txtComTotDolFOB;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox txtCosIntTot;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox txtCosAdiNac;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox txtCosInt;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox txtFacImp;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox txtPorDesFOB;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox txtDesIteAA;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox txtCosFobFinUS;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox txtCosFobUS;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox txtCosFob;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox txtCanAAItem;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox txtMed;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txtMatBasMue;
        private System.Windows.Forms.TextBox txtCodMatBasMue;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox txtColPro;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.TextBox txtCodPro;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox txtMarAA;
        private System.Windows.Forms.TextBox txtCodMarAA;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox txtSubFam;
        private System.Windows.Forms.TextBox txtCodSubFam;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtFamAA;
        private System.Windows.Forms.TextBox txtCodFamAA;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtSubLinAA;
        private System.Windows.Forms.TextBox txtCodSubLinAA;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox txtLin;
        private System.Windows.Forms.TextBox txtCodLin;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox txtFecEmi;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtTC;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.TextBox txtNegIte;
        private System.Windows.Forms.TextBox txtCodNegIte;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox txtMedAA;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.TextBox txtCodProCat;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.GroupBox gbIteCat;
        private C1.Win.C1FlexGrid.C1FlexGrid fgAACatIte;
        private System.Windows.Forms.Button btnCanAACat;
        private System.Windows.Forms.Button btnAceAACat;
        private System.Windows.Forms.TextBox txtComRecAAIte;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox txtPorDesAAIte;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Button btnAceAAIte;
        private System.Windows.Forms.TextBox txtComRec;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox txtEnv;
        private System.Windows.Forms.TextBox txtCodEnv;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox txtNeg;
        private System.Windows.Forms.TextBox txtCodNeg;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Button btnBorItemAA;
        private System.Windows.Forms.ToolStripDropDownButton btnOpc;
        private System.Windows.Forms.ToolStripMenuItem tsmiDesTot;
        //private System.Windows.Forms.ToolStripButton toolStripButton2;
        //private System.Windows.Forms.ToolStripButton toolStripButton3;
        //private System.Windows.Forms.ToolStripButton toolStripButton4;
        //private System.Windows.Forms.ToolStripButton toolStripButton5;
        //private System.Windows.Forms.ToolStripButton toolStripButton6;
        //private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        //private System.Windows.Forms.ToolStripButton toolStripButton7;
        //private System.Windows.Forms.ToolStripButton toolStripButton8;
        //private System.Windows.Forms.ToolStripButton toolStripButton9;
    }
}