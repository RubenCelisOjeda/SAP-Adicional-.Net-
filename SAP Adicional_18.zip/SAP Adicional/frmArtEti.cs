﻿using CapaNegocio;
using Interfaces;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmArtEti : Form, ArtEti
    {
        //[DllImport("kernel32.dll", SetLastError = true)]

        //static extern SafeFileHandle CreateFile(string lpFileName, FileAccess dwDesiredAccess,
        //uint dwShareMode, IntPtr lpSecurityAttributes, FileMode dwCreationDisposition,
        //uint dwFlagsAndAttributes, IntPtr hTemplateFile);
        //public static Dictionary<string, string> zplComando = new Dictionary<string,string>();

        private NConsultas nc = new NConsultas();
        private NArtEti artEti = new NArtEti();
        private VarGlo varglo = VarGlo.Instance();
        private string _mensaje = "";


        public frmArtEti()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private void frmArtEti_Load(object sender, EventArgs e)
        {
            this.ArtEti_TexSoloLectura();
            this.ArtEti_RecImp();
        }
        private void ArtEti_RecImp()
        {
            foreach (string printer in System.Drawing.Printing.PrinterSettings.InstalledPrinters)
            {
                this.cboImp.Items.Add(printer);
            }
        }
        private void txtCodSap_Enter(object sender, EventArgs e)
        {
            if (this.txtCodSap.Text == "(Código SAP)")
            {
                this.txtCodSap.Text = "";
                this.txtCodSap.ForeColor = Color.Silver;
            }
        }

        private void txtCodSap_Leave(object sender, EventArgs e)
        {
            //Codigo para que aparezca el nombre por defecto del texto
            if (this.txtCodSap.Text == "")
            {
                this.txtCodSap.Text = "(Código SAP)";
                this.txtCodSap.ForeColor = Color.Silver;
            }
        }

        private void txtCodXtr_Enter(object sender, EventArgs e)
        {
            //Codigo para poder limpiar el texto y poder editar
            if (this.txtCodXtr.Text == "(Código XTrazzo)")
            {
                this.txtCodXtr.Text = "";
                this.txtCodXtr.ForeColor = Color.Silver;
            }
        }

        private void txtCodXtr_Leave(object sender, EventArgs e)
        {
            if (this.txtCodXtr.Text == "")
            {
                this.txtCodXtr.Text = "(Código XTrazzo)";
                this.txtCodXtr.ForeColor = Color.Silver;
            }
        }

        private void txtDes_Enter(object sender, EventArgs e)
        {
            if (this.txtDes.Text == "(Descripción)")
            {
                this.txtDes.Text = "";
                this.txtDes.ForeColor = Color.Silver;
            }
        }

        private void txtDes_Leave(object sender, EventArgs e)
        {
            if (this.txtDes.Text == "")
            {
                this.txtDes.Text = "(Descripción)";
                this.txtDes.ForeColor = Color.Silver;
            }
        }
        private void ArtEti_ConsultaDatos(string vista, string procedimiento, string param1,Int16 param2)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable dtFiltro = new DataTable();
            dtFiltro = artEti.ArtEti_Filtros(vista, procedimiento, param1, param2); //ejecuta el procedimiento
            
            //Valida si hay datos en la consulta
            if (dtFiltro.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 9;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFiltro;
                frm.ArtEti_Rec = this;
                frm.ShowDialog();
            }
            else if (dtFiltro.Rows.Count == 1)
            {
                DataRow row = dtFiltro.Rows[0];

                switch (vista)
                {
                    case "Codigo Articulo":
                    case "Articulo Descripcion":

                        this.txtCodSap.Text = row["ItemCode"].ToString();
                        this.txtCodXtr.Text = row["CodXtrazzo"].ToString();
                        this.txtDes.Text = row["ItemName"].ToString();
                        this.txtCod.Text = row["ItemCode"].ToString();
                        this.txtDesArt.Text = row["ItemName"].ToString();
                        this.txtClaGen.Text = row["ClasificacionGeneral"].ToString();
                        this.txtNomUni.Text = row["NombreUnico"].ToString();
                        this.txtCarAdi.Text = row["CaracteristicaAdicional"].ToString();
                        break;

                    default:
                        break;
                }
            }
            else if (dtFiltro.Rows.Count == 0)
            {
                varglo.Elegi = false;
                _mensaje = "No se encontraron registros";
                this.ArtEti_MosMsgStrip(_mensaje,Color.Red);
            }

            Cursor.Current = Cursors.Default;
        }

        public void recdat_ArtEtic_Dat(string CodSAp, string CodXtra, string Des, string Cod, string DesArt, string ClaGen, string NomUni, string CarAdi)
        {
            //Obtiene los datos desde la interfaces cuando se hace doble click en el grid
            this.txtCodSap.Text = CodSAp;
            this.txtCodXtr.Text = CodXtra;
            this.txtDes.Text = Des;
            this.txtCod.Text = Cod;
            this.txtDesArt.Text = DesArt;
            this.txtClaGen.Text = ClaGen;
            this.txtNomUni.Text = NomUni;
            this.txtCarAdi.Text = CarAdi;
        }

        private void txtCodSap_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ArtEti_ConsultaDatos("Codigo Articulo","ALM_ArtEti_Imp", this.txtCodSap.Text,2);
                this.txtCodXtr.Focus();
            }
        }

        private void txtCodXtr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ArtEti_ConsultaDatos("Codigo Articulo", "ALM_ArtEti_Imp", this.txtCodXtr.Text, 3);
                this.txtDes.Focus();
            }
        }

        private void txtDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ArtEti_ConsultaDatos("Codigo Articulo", "ALM_ArtEti_Imp", this.txtDes.Text, 1);
                this.btnEtiPeq.Focus();
            }
        }
        private void ArtEti_TexSoloLectura()
        {
            this.txtCod.ReadOnly = true;
            this.txtDesArt.ReadOnly = true;
            this.txtClaGen.ReadOnly = true;
            this.txtNomUni.ReadOnly = true;
            this.txtCarAdi.ReadOnly = true;
        }

        private void btnEtiPeq_Click(object sender, EventArgs e)
        {
            if (this.txtCan.Text == "" | this.txtCan.Text.Equals("0"))
            {
                _mensaje = "Ingrese una cantidad para imprimir";
                this.ArtEti_MosMsgStrip(_mensaje, Color.DodgerBlue);
                this.txtCan.Focus();
                return;
            }
           
            this.ArtEti_ValTexVacio();

        }


        private void PrintLabel()
        {
            StringBuilder zpl = new StringBuilder();
            zpl.Append("${");
            zpl.Append("^XA~TA000~JSN^MNW^^MTT^PON^PMN^LH0,0^JMA^PR2,2~SD15^PW800^MD5^JUS^LRN^C10");

            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO20,30^APN,20,10^FD" + txtClaGen.Text + "^FS");
            zpl.Append("^FB250,1,,C");
            zpl.Append("^FO0,50^AQN,20,10^FD" + txtNomUni.Text + "^FS");
            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO20,80^APN,20,10^FD" + txtCarAdi.Text + "^FS");
            zpl.Append("^BY1,3^FO10,100^B3N,N,40,N,N");
            zpl.Append("^FD" + txtCod + "^FS");
            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO20,145^AQN,10,4^FD" + txtCod.Text + "*" + nc.FechaServidor() + "^FS");

            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO280,30^APN,20,10^FD" + txtClaGen.Text + "^FS");
            zpl.Append("^FB250,1,,C");
            zpl.Append("^FO260,50^AQN,20,10^FD" + txtNomUni.Text + "^FS");
            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO280,80^APN,20,10^FD" + txtCarAdi.Text + "^FS");
            zpl.Append("^BY1,3^FO10,100^B3N,N,40,N,N");
            zpl.Append("^FD" + txtCod + "^FS");
            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO280,145^AQN,10,4^FD" + txtCod.Text + "*" + nc.FechaServidor() + "^FS");

            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO550,30^APN,20,10^FD" + txtClaGen.Text + "^FS");
            zpl.Append("^FB250,1,,C");
            zpl.Append("^FO530,50^AQN,20,10^FD" + txtNomUni.Text + "^FS");
            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO280,80^APN,20,10^FD" + txtCarAdi.Text + "^FS");
            zpl.Append("^BY1,3^FO540,100^B3N,N,40,N,N");
            zpl.Append("^FD" + txtCod + "^FS");
            zpl.Append("^FB230,1,,C");
            zpl.Append("^FO550,145^AQN,10,4^FD" + txtCod.Text + "*" + nc.FechaServidor() + "^FS");

            zpl.Append("^PQ" + txtCan.Text + ",,,Y");
            zpl.Append("^XZ");
            zpl.Append("}$");

            //RawPrinterHelper

            //StreamWriter sw = null;
            //sw.Write(zpl);
            //System.Diagnostics.ProcessStartInfo sinf = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + command);
            //PrintDialog pd = new PrintDialog();
            //pd.PrintToFile = true;
            //pd.
            //pd.UseEXDialog = true;
            //pd.PrinterSettings = new System.Drawing.Printing.PrinterSettings();

            //if (DialogResult.OK == pd.ShowDialog(this))
            //{
            //    RawPrinterHelper.SendStringToPrinter(pd.PrinterSettings.PrinterName, label.ToString());
            //}
            //return;
        }

        //public class RawPrinterHelper
        //{
        //    // Structure and API declarions:
        //    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        //    public class DOCINFOA
        //    {
        //        [MarshalAs(UnmanagedType.LPStr)]
        //        public string pDocName;
        //        [MarshalAs(UnmanagedType.LPStr)]
        //        public string pOutputFile;
        //        [MarshalAs(UnmanagedType.LPStr)]
        //        public string pDataType;
        //    }
        //    [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);

        //    [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool ClosePrinter(IntPtr hPrinter);

        //    [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);

        //    [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool EndDocPrinter(IntPtr hPrinter);

        //    [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool StartPagePrinter(IntPtr hPrinter);

        //    [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool EndPagePrinter(IntPtr hPrinter);

        //    [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        //    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);

        //    // SendBytesToPrinter()
        //    // When the function is given a printer name and an unmanaged array
        //    // of bytes, the function sends those bytes to the print queue.
        //    // Returns true on success, false on failure.
        //    public static bool SendBytesToPrinter(string szPrinterName, IntPtr pBytes, Int32 dwCount)
        //    {
        //        Int32 dwError = 0, dwWritten = 0;
        //        IntPtr hPrinter = new IntPtr(0);
        //        DOCINFOA di = new DOCINFOA();
        //        bool bSuccess = false; // Assume failure unless you specifically succeed.

        //        di.pDocName = "My C#.NET RAW Document";
        //        di.pDataType = "RAW";

        //        // Open the printer.
        //        if (OpenPrinter(szPrinterName.Normalize(), out hPrinter, IntPtr.Zero))
        //        {
        //            // Start a document.
        //            if (StartDocPrinter(hPrinter, 1, di))
        //            {
        //                // Start a page.
        //                if (StartPagePrinter(hPrinter))
        //                {
        //                    // Write your bytes.
        //                    bSuccess = WritePrinter(hPrinter, pBytes, dwCount, out dwWritten);
        //                    EndPagePrinter(hPrinter);
        //                }
        //                EndDocPrinter(hPrinter);
        //            }
        //            ClosePrinter(hPrinter);
        //        }
        //        // If you did not succeed, GetLastError may give more information
        //        // about why not.
        //        if (bSuccess == false)
        //        {
        //            dwError = Marshal.GetLastWin32Error();
        //        }
        //        return bSuccess;
        //    }

        //    public static bool SendFileToPrinter(string szPrinterName, string szFileName)
        //    {
        //        // Open the file.
        //        FileStream fs = new FileStream(szFileName, FileMode.Open);
        //        // Create a BinaryReader on the file.
        //        BinaryReader br = new BinaryReader(fs);
        //        // Dim an array of bytes big enough to hold the file's contents.
        //        Byte[] bytes = new Byte[fs.Length];
        //        bool bSuccess = false;
        //        // Your unmanaged pointer.
        //        IntPtr pUnmanagedBytes = new IntPtr(0);
        //        int nLength;

        //        nLength = Convert.ToInt32(fs.Length);
        //        // Read the contents of the file into the array.
        //        bytes = br.ReadBytes(nLength);
        //        // Allocate some unmanaged memory for those bytes.
        //        pUnmanagedBytes = Marshal.AllocCoTaskMem(nLength);
        //        // Copy the managed byte array into the unmanaged array.
        //        Marshal.Copy(bytes, 0, pUnmanagedBytes, nLength);
        //        // Send the unmanaged bytes to the printer.
        //        bSuccess = SendBytesToPrinter(szPrinterName, pUnmanagedBytes, nLength);
        //        // Free the unmanaged memory that you allocated earlier.
        //        Marshal.FreeCoTaskMem(pUnmanagedBytes);
        //        return bSuccess;
        //    }
        //    public static bool SendStringToPrinter(string szPrinterName, string szString)
        //    {
        //        IntPtr pBytes;
        //        Int32 dwCount;
        //        // How many characters are in the string?
        //        dwCount = szString.Length;
        //        // Assume that the printer is expecting ANSI text, and then convert
        //        // the string to ANSI text.
        //        pBytes = Marshal.StringToCoTaskMemAnsi(szString);
        //        // Send the converted ANSI string to the printer.
        //        SendBytesToPrinter(szPrinterName, pBytes, dwCount);
        //        Marshal.FreeCoTaskMem(pBytes);
        //        return true;
        //    }
        //}


        private void ArtEti_ValTexVacio()
        {
            //Valida que ningun texto este vacio
            
            if (Convert.ToInt32(this.txtCan.Text) < 7 )
            {
                _mensaje = "Ingrese una cantidad";
                this.ArtEti_MosMsgStrip(_mensaje, Color.Red);
                this.txtCan.Focus();
            }
            else if(this.txtClaGen.Text == "")
            {
                this.txtClaGen.Focus();
            }
            else if (this.txtNomUni.Text == "")
            {
                this.txtNomUni.Focus();
            }
            else if(this.txtCarAdi.Text == "")
            {
                this.txtCarAdi.Focus();
            }
            else
            {
                return;
            }
        }

        private void priDoc_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           
        }

        private void ArtEti_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }

        private void btnCal_Click(object sender, EventArgs e)
        {

        }

        private void btnEtiMed_Click(object sender, EventArgs e)
        {

        }

        private void btnEtiGra_Click(object sender, EventArgs e)
        {

        }
    }
}
