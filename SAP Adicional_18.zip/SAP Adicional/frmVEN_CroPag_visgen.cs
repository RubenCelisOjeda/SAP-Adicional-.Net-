﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmVEN_CroPag_visgen : Form
    {
        NVEN_CroPag nvc = new NVEN_CroPag();
        NConsultas nc = new NConsultas();

        VarGlo varglo = VarGlo.Instance();

        Int16 Columna;

        public frmVEN_CroPag_visgen()
        {
            InitializeComponent();
        }

        private void frmVEN_CroPag_visgen_Load(object sender, EventArgs e)
        {
            MostrarDatos();
        }

         private void btnMosAct_Click(object sender, EventArgs e)
        {
            
        }

        private void MostrarDatos()
        {
            fg.DataSource = nvc.VEN_CroPag_visgen(0, "Inicial");
        }


        private void FormatoColumnas()
        {
            fg.Cols["NumMov"].Visible = false;
            fg.Cols["N° Cro"].Width = 70;
            fg.Cols["Cliente"].Width = 350;
            fg.Cols["Fec. Emision"].Width = 70;
            fg.Cols["RQ"].Width = 70;
            fg.Cols["Observaciones"].Width = 350;
            fg.Cols["Creado por"].Width = 100;
            fg.Cols["Modificado por"].Width = 100;
            fg.Cols["Fec. Ult. Mod."].Width = 140;
            fg.Cols["Fec. Ult. Mod."].Format = "dd/mm/yyyy hh:mm:ss tt";
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoColumnas();
            FormatoGeneral();
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }
        private void FormatoGeneral()
        {        
            fg.Cols.Frozen = 4;
            fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;
            fg.AllowFreezing = AllowFreezingEnum.Both;
        }

        private void ExportarExcel()
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch { }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            ExportarExcel();
        }

        private void fg_DoubleClick(object sender, EventArgs e)
        {
            frmVEN_CroPag f = new frmVEN_CroPag();

            if (Convert.ToInt32(fg.Cols[0][fg.RowSel]) == 0)
            {
                MessageBox.Show("No se encontro el número de Movimiento", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            else
            {
                f.Show();
                f.MdiParent = this.MdiParent;                
                f.NumMov = Convert.ToInt32(fg.Cols[0][fg.RowSel]);
                f.RecuperarDatos();
                f.VEN_CroPag_EstBot("abrir");                
                this.Close();
            }

        }

        private void btnNueCro_Click(object sender, EventArgs e)
        {
            frmVEN_CroPag f = new frmVEN_CroPag();

            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 3, "nue", 0) == 1)
            {
                f.Show();
                f.MdiParent = this.MdiParent;
                f.btnNuevo.PerformClick();
                f.Origen = 1;//entra por fuera
                
            }
            else
            {
                MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void txtFiltro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (this.lblFiltro.Text == "") return;

            if (e.KeyChar == 13)
            {

                try
                {

                    fg.DataSource = nvc.VEN_CroPag_visgen(Columna, txtFiltro.Text);

                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString(), "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void fg_BeforeSort(object sender, SortColEventArgs e)
        {
            Columna = (Int16)e.Col;

            this.lblFiltro.Text = fg.Cols[e.Col].Name;
            this.txtFiltro.Focus();
        }
    }
}
