﻿namespace SAP_Adicional
{
    partial class frmGEN_SAP_IniSes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUsu = new System.Windows.Forms.TextBox();
            this.txtPas = new System.Windows.Forms.TextBox();
            this.btnAce = new System.Windows.Forms.Button();
            this.btnCan = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pb = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            this.SuspendLayout();
            // 
            // txtUsu
            // 
            this.txtUsu.Location = new System.Drawing.Point(186, 90);
            this.txtUsu.Name = "txtUsu";
            this.txtUsu.Size = new System.Drawing.Size(124, 20);
            this.txtUsu.TabIndex = 0;
            this.txtUsu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsu_KeyPress);
            // 
            // txtPas
            // 
            this.txtPas.Location = new System.Drawing.Point(186, 125);
            this.txtPas.Name = "txtPas";
            this.txtPas.Size = new System.Drawing.Size(124, 20);
            this.txtPas.TabIndex = 1;
            this.txtPas.UseSystemPasswordChar = true;
            this.txtPas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPas_KeyPress);
            // 
            // btnAce
            // 
            this.btnAce.Location = new System.Drawing.Point(119, 165);
            this.btnAce.Name = "btnAce";
            this.btnAce.Size = new System.Drawing.Size(94, 22);
            this.btnAce.TabIndex = 2;
            this.btnAce.Text = "Aceptar";
            this.btnAce.UseVisualStyleBackColor = true;
            this.btnAce.Click += new System.EventHandler(this.btnAce_Click);
            // 
            // btnCan
            // 
            this.btnCan.Location = new System.Drawing.Point(237, 165);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(94, 22);
            this.btnCan.TabIndex = 3;
            this.btnCan.Text = "Cancelar";
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(134, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Usuario:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(124, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password:";
            // 
            // pb
            // 
            this.pb.Image = global::SAP_Adicional.Properties.Resources.SAP_Busi_One_PCG8_130_R_p;
            this.pb.Location = new System.Drawing.Point(5, 2);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(208, 53);
            this.pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb.TabIndex = 6;
            this.pb.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(161, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Ingrese un usuario SAP valido:";
            // 
            // frmGEN_SAP_IniSes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 251);
            this.ControlBox = false;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCan);
            this.Controls.Add(this.btnAce);
            this.Controls.Add(this.txtPas);
            this.Controls.Add(this.txtUsu);
            this.KeyPreview = true;
            this.Name = "frmGEN_SAP_IniSes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SAP - Validar usuario";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmGEN_SAP_IniSes_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUsu;
        private System.Windows.Forms.TextBox txtPas;
        private System.Windows.Forms.Button btnAce;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.Label label3;
    }
}