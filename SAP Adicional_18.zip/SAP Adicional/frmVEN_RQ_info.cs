﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using Microsoft.Office.Interop;
using C1.Win.C1FlexGrid;
using System.IO;
using System.Diagnostics;

namespace SAP_Adicional
{
    public partial class frmVEN_RQ_info : Form, frmVEN_RQ_Info
    {

        NConsultas nc = new NConsultas();

        public frmVEN_RQ_info()
        {
            InitializeComponent();
        }

        public void recdat_frmVEN_RQ_info(string rq, string cli)
        {
            this.txtRQ.Text = rq;
            this.txtCli.Text = cli;
        }

        private void txtRQ_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 13)
            {
                DataTable dt = new DataTable();
                
                dt = nc.RecuperaInfoRQ("RQ", "VEN_RQ_Info", 1, txtRQ.Text);

                DataRow row = dt.Rows[0];

                txtRQ.Text = row["N° RQ"].ToString();
                txtCli.Text = row["Cliente"].ToString();
                //
                btnMost.Focus();
            }
        }

        private void btnMost_Click(object sender, EventArgs e)
        {
            if (txtRQ.Text == "")
            {
                MessageBox.Show("Debe ingresar un numero de rq","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information);
                txtRQ.Focus();
                return;
            }

            int CanFil;

            this.fg.DataSource = nc.VEN_RQ_info(int.Parse(txtRQ.Text));

            CanFil = fg.Rows.Count;                        

            if (CanFil == 0)
            {
                MessageBox.Show("No se encontraron datos para el RQ seleccionado");
            }
        }

        private void txtRQ_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmVEN_RQ_info_Load(object sender, EventArgs e)
        {                       

             
        }

        private void txtCli_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 13)
            {
                DataTable dt = new DataTable();

                dt = nc.RecuperaInfoRQ("RQ", "VEN_RQ_Info", 2, this.txtCli.Text);
                
                if (dt.Rows.Count > 1)
                {
                    
                    frmConsulta_Varios frm = new frmConsulta_Varios();
                    frm.Formulario = 25;
                    frm.Text = "RQ";
                    frm.Vista = "RQ";
                    frm.dg.DataSource = dt;
                    frm.f = this;
                    frm.ShowDialog();
                }
                else
                {
                    DataRow row = dt.Rows[0];

                    txtRQ.Text = row["N° RQ"].ToString();
                    txtCli.Text = row["Cliente"].ToString();
                    //
                    btnMost.Focus();
                }
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            DateTime Hoy = DateTime.Now;

            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");

            // save grid as sheet in the book
            FileFlags flags = FileFlags.IncludeFixedCells;
            //fg.SaveGrid(dlg.FileName, FileFormatEnum.Excel, flags);

            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";

            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);

            Process.Start(Ruta);
        }

        private void txtCli_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            fg.AutoResize = true;
            ////fg.Styles.Alternate.BackColor = Color.LightBlue;
            //fg.Cols.Frozen = 3;
            //fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            //fg.VisualStyle = VisualStyle.Office2010Silver;
            //fg.Styles.Alternate.BackColor = Color.LightBlue;
            //fg.Styles.Highlight.BackColor = Color.Blue;
            //fg.Styles.Highlight.ForeColor = Color.White;
            //fg.AllowFreezing = AllowFreezingEnum.Both;
            fg.Cols[4].Visible = false;

            fg.Cols[2].Width = 300;

            for (int i = 4; i < fg.Cols.Count; i++)
            {
                fg.Cols[i].Width = 70;
            }
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }
    }
}
