﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmCambiarContraseña : Form
    {
        NCam_Contra nc = new NCam_Contra();
        public frmCambiarContraseña()
        {
            InitializeComponent();
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            Close();
          
        }

        private void btnAce_Click(object sender, EventArgs e)
        {          
            if (string.IsNullOrEmpty(txtUsu.Text))
            {
                MessageBox.Show("Ingrese su Usuario","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                txtUsu.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtCla.Text))
            {
                MessageBox.Show("Ingrese su Clave", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCla.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtNueCla.Text))
            {
                MessageBox.Show("Ingrese su nueva clave", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNueCla.Focus();
                return;
            }
            else if (string.IsNullOrEmpty(txtConCla.Text))
            {
                MessageBox.Show("Ingrese la confirmación de la nueva clave", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtConCla.Focus();
                return;
            }
            else if (txtNueCla.Text != txtConCla.Text)
            {
                MessageBox.Show("Las claves no coinciden..!!", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNueCla.Clear();
                txtConCla.Clear();
                txtNueCla.Focus();
                return;
            }
            else
            {

                if (nc.Val_UsuarioClave(VarGlo.Instance().CodUsuAct, txtCla.Text,false) == true)
                {
                     DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea cambiar su clave de acceso?", "Mensaje del sisema", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                
                    if (mensaje == DialogResult.Yes)
                    {
                        nc.Act_UsuarioClave(Convert.ToInt16(VarGlo.Instance().CodUsuAct),txtNueCla.Text);                       
                        txtUsu.Clear();
                        txtCla.Clear();
                        txtNueCla.Clear();
                        txtConCla.Clear();
                        this.Close();
                        MessageBox.Show("Se realizaron los cambios satisfactoriamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("No se reconoce la clave anterior,ingrese nuevamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCla.Clear();
                    txtCla.Focus();
                    return;
                }          
            }
        }

        private void frmCambiarContraseña_Load(object sender, EventArgs e)
        {
            Cam_Contra_RecUsuEmp();
        }
        private void Cam_Contra_RecUsuEmp()
        {
            DataTable RecUsu = new DataTable();
            RecUsu = nc.Rec_UsuarioEmpleado(Convert.ToInt16(VarGlo.Instance().CodUsuAct));
            if (RecUsu.Rows.Count > 0)
            {
                txtUsu.Text = RecUsu.Rows[0]["Usuario"].ToString();
                txtUsu.ReadOnly = true;
                txtUsu.Font = new Font("Tahoma", 12, GraphicsUnit.Pixel);
                txtCla.Focus();
                return;
            }
            else
            {
                MessageBox.Show("No se encontraron datos","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            
        }

        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtCla.Focus();
            }
        }

        private void txtCla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtNueCla.Focus();
            }
        }

        private void txtNueCla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtConCla.Focus();
            }
        }

        private void txtConCla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnAce.Focus();
            }
        }
    }
}
