﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using C1.Win.C1FlexGrid;
using System.Diagnostics;
using CapaNegocio;

namespace SAP_Adicional
{
    public static class MetGlo
    {
        private static NConsultas nc = new NConsultas();

        public static void BackColorBtn(Control control)
        {
            foreach (Control c in control.Controls)
            {
                if (c is Button)
                {
                    c.MouseEnter += delegate
                    {
                        c.ForeColor = System.Drawing.Color.Black;
                        c.BackColor = System.Drawing.Color.Gold;
                        

                    };
                    c.MouseLeave += delegate
                    {
                        c.ForeColor = System.Drawing.Color.White;
                        c.BackColor = System.Drawing.Color.FromArgb(60, 60, 60);
                    };
                }
            }
        }

        public static void SeleccionTexto(Control control)
        {
            foreach (Control c in control.Controls)
            {
                if (c.HasChildren) SeleccionTexto(c);
                {
                    if(c is TextBox)
                    {
                        c.Enter += delegate
                        {
                            ((TextBox)c).SelectAll();
                            //t.HideSelection = false;
                        };
                        c.Leave += delegate
                        {
                            ((TextBox)c).SelectionLength = 0;
                        };
                    }
                }
            }

        }

        public static void BackColorText(Control control)
        {
            foreach (Control c in control.Controls)
            {
                if (c.HasChildren) BackColorText(c);
                {
                    if (c is TextBox)
                    {
                        System.Drawing.Color color = c.BackColor;

                        c.Enter += delegate
                        {
                            c.BackColor = System.Drawing.Color.Gold;

                        };
                        c.Leave += delegate
                        {
                            c.BackColor = color;
                        };
                    } 
                    
                }
            }
        }

        public static void CRVisPre(ReportDocument rpt)
        {
            Cursor.Current = Cursors.WaitCursor; //cursor cargando

            ConnectionInfo crConnectionInfo = new ConnectionInfo();
            Database crDatabase;
            Tables crTables;
            Table crTable;
            TableLogOnInfo crTableLogOnInfo;

            // Las tablas para el informe están siempre en la base de datos global.
            crConnectionInfo.ServerName = "zeus";
            crConnectionInfo.DatabaseName = VarGlo.Instance().Base; 
            crConnectionInfo.IntegratedSecurity = true;

            crDatabase = rpt.Database; // Obtener la colección de tablas del objeto de informe
            crTables = crDatabase.Tables;

            for (int i = 0; i < crTables.Count; i++)
            {
                crTable = crTables[i];
                crTableLogOnInfo = crTable.LogOnInfo;
                crTableLogOnInfo.ConnectionInfo = crConnectionInfo;
                crTable.ApplyLogOnInfo(crTableLogOnInfo);
            }

            frmVisor f = new frmVisor();

            f.MdiParent = (frmPri)Application.OpenForms["frmPri"];
            f.crv.ReportSource = rpt;
            f.crv.Zoom(120);
            f.WindowState = FormWindowState.Maximized;
            f.Show();

            Cursor.Current = Cursors.Default; //cursor por defecto
        }

        public static void ExportarExcel(C1FlexGrid fg, string Texto)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor; //cursor cargando
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + Texto + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
                Cursor.Current = Cursors.Default; //cursor por defecto

            }
            catch (Exception ex)
            {
                return;
            }
        }

        public static bool ValCodArtGen_Sap(string codArtSap,string baseSap)
        {
            return nc.ValCodArtGenSap(codArtSap, baseSap);
        }

        public static bool ValRqGenSap(string rq, string baseSap)
        {
            return nc.ValRqGenSap(rq, baseSap);
        }

        public static byte GEN_AccByDoc(Int32 codEmp, Int16 codDoc, string campo, byte acc)
        {
            return nc.GEN_AccByDoc(codEmp, codDoc, campo,acc);
        }
    }
}
