﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_rep_InfRSV : Form
    {
        private NConsultas nCon = new NConsultas();
        public frmLOG_rep_InfRSV()
        {
            InitializeComponent();
        }

        private void btnMosAct_Click(object sender, EventArgs e)
        {
            //Recupera y muestra en el grid los datos 

            Cursor.Current = Cursors.WaitCursor;

            DataTable dtInfRes = null;
            dtInfRes = this.nCon.LOG_rep_InfRSV_RecInfRes(Convert.ToInt16(this.chkEliDes.Checked));

            if (dtInfRes.Rows.Count > 0)
            {
                this.fgInfRes.DataSource = dtInfRes;
            }
            else
            {
                dtInfRes.Clear();
                this.fgInfRes.DataSource = dtInfRes;
                this.LOG_rep_InfRSV_MosMsgStrip("No se encontraron datos",Color.DodgerBlue);
            }

            Cursor.Current = Cursors.Default;
        }

        private void LOG_rep_InfRSV_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }
        private void LOG_rep_InfRSV_ForGen()
        {
            //formato general del grid
            this.fgInfRes.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            this.fgInfRes.VisualStyle = VisualStyle.Office2010Silver;
            this.fgInfRes.Styles.Alternate.BackColor = Color.LightBlue;
            this.fgInfRes.Styles.Highlight.BackColor = Color.Blue;
            this.fgInfRes.Styles.Highlight.ForeColor = Color.White;
            this.fgInfRes.AllowFreezing = AllowFreezingEnum.Both;
            this.fgInfRes.Cols.Frozen = 2;
        }

        private void fgInfRes_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.LOG_rep_InfRSV_ForGen();
            this.LOG_rep_InfRSV_ForCol();
        }

        private void btnExpInfRes_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(this.fgInfRes,this.Text);
        }
        private void LOG_rep_InfRSV_ForCol()
        {
            //Anchio de las columnas
            this.fgInfRes.Cols["NumRQ"].Width = 50;
            this.fgInfRes.Cols["cliente"].Width = 200;
            this.fgInfRes.Cols["Articulo"].Width = 550;
            this.fgInfRes.Cols["Des"].Width = 40;
            this.fgInfRes.Cols["OFV"].Width = 40;
            this.fgInfRes.Cols["ORV"].Width = 40;
            this.fgInfRes.Cols["RSV"].Width = 40;
            this.fgInfRes.Cols["RSt"].Width = 40;
            this.fgInfRes.Cols["CL"].Width = 40;
            this.fgInfRes.Cols["AVD"].Width = 40;
            this.fgInfRes.Cols["Ent"].Width = 40;
            this.fgInfRes.Cols["Fac"].Width = 40;
            this.fgInfRes.Cols["Comp"].Width = 40;
            this.fgInfRes.Cols["Pendiente"].Width = 70;
            this.fgInfRes.Cols["Proveedor"].Width = 400;
            this.fgInfRes.Cols["SQO"].Width = 40;
            this.fgInfRes.Cols["SIS"].Width = 40;
            this.fgInfRes.Cols["AOP"].Width = 40;
            this.fgInfRes.Cols["PRD"].Width = 40;
            this.fgInfRes.Cols["AC"].Width = 40;
            this.fgInfRes.Cols["DT"].Width = 40;
            this.fgInfRes.Cols["SHO"].Width = 40;
            this.fgInfRes.Cols["IMP"].Width = 40;
            this.fgInfRes.Cols["ISP"].Width = 40;
            this.fgInfRes.Cols["RSV"].Width = 40;
            this.fgInfRes.Cols["RST"].Width = 40;
            this.fgInfRes.Cols["Fecha Aprox. Ingreso"].Width = 120;
            this.fgInfRes.Cols["Vendedor"].Width = 120;

            //columnas ocultadas
            this.fgInfRes.Cols["RSV1"].Visible = false;
            this.fgInfRes.Cols["RST1"].Visible = false;

            //Formato de tipo de dato 1 grupo de columnas
            for (int col = 5; col <= 14; col++)
            {
                this.fgInfRes.Cols[col].Format = "0.#";
            }

            //Formato de tipo de dato 2 grupo de columnas
            for (int col = 18; col <= 29; col++)
            {
                this.fgInfRes.Cols[col].Format = "0.#";
            }
        }

        private void fgInfRes_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }
    }
}
