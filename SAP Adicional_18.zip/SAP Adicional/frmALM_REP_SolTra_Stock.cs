﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_REP_SolTra_Stock : Form
    {
        NConsultas nc = new NConsultas();
        public frmALM_REP_SolTra_Stock()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtpInicio.Checked == true && dtpFinal.Checked == true)
                {
                    this.fg.DataSource = nc.ALM_rep_SolTra_Stock(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text));

                    FormatoGrid();
                }
            }
            catch
            {

            }
 
        }

        private void FormatoGrid()
        {
            fg.Cols.Frozen = 2;
            fg.Cols[7].Format = "0.00";

            fg.Cols[1].Width = 70;
            fg.Cols[2].Width = 70;
            fg.Cols[4].Width= 300;
            fg.Cols[5].Width = 80;
            fg.Cols[6].Width = 400;
            fg.Cols[7].Width = 60;
            fg.Cols[8].Width = 45;
            fg.Cols[9].Width = 45;
            fg.Cols[10].Width =80;

            for (int i = 11; i <= 20; i++)
            {
                fg.Cols[i].Width = 60;
                fg.Cols[i].Format = "0.00";
            }

            this.fg.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;

        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if(e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }

        }

        private void btnExp_Click(object sender, EventArgs e)
        {

            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }
    }
}
