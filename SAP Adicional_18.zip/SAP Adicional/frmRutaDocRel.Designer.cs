﻿namespace SAP_Adicional
{
    partial class frmRutaDocRel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRutaDocRel));
            this.label1 = new System.Windows.Forms.Label();
            this.fgRutRel = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.txtNumMov = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblRq = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFecRut = new System.Windows.Forms.Label();
            this.cboTipDoc = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNumDoc = new System.Windows.Forms.TextBox();
            this.btnSelDoc = new System.Windows.Forms.Button();
            this.btnAgr = new System.Windows.Forms.Button();
            this.lblMensaje = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fgRutRel)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "N° Mov:";
            // 
            // fgRutRel
            // 
            this.fgRutRel.AllowFiltering = true;
            this.fgRutRel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgRutRel.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgRutRel.Location = new System.Drawing.Point(12, 116);
            this.fgRutRel.Name = "fgRutRel";
            this.fgRutRel.Rows.DefaultSize = 19;
            this.fgRutRel.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgRutRel.Size = new System.Drawing.Size(556, 166);
            this.fgRutRel.TabIndex = 7;
            this.fgRutRel.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgRutRel_KeyPressEdit);
            this.fgRutRel.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgRutRel_KeyDown);
            // 
            // txtNumMov
            // 
            this.txtNumMov.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtNumMov.Location = new System.Drawing.Point(60, 30);
            this.txtNumMov.Name = "txtNumMov";
            this.txtNumMov.Size = new System.Drawing.Size(100, 21);
            this.txtNumMov.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(173, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "N° RQ:";
            // 
            // lblRq
            // 
            this.lblRq.BackColor = System.Drawing.Color.LightGray;
            this.lblRq.Location = new System.Drawing.Point(217, 30);
            this.lblRq.Name = "lblRq";
            this.lblRq.Size = new System.Drawing.Size(81, 20);
            this.lblRq.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(304, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Fecha Ruta:";
            // 
            // lblFecRut
            // 
            this.lblFecRut.BackColor = System.Drawing.Color.LightGray;
            this.lblFecRut.Location = new System.Drawing.Point(371, 30);
            this.lblFecRut.Name = "lblFecRut";
            this.lblFecRut.Size = new System.Drawing.Size(81, 20);
            this.lblFecRut.TabIndex = 2;
            // 
            // cboTipDoc
            // 
            this.cboTipDoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipDoc.FormattingEnabled = true;
            this.cboTipDoc.Items.AddRange(new object[] {
            "1 - Entrega",
            "2 - Solicitud de Traslado",
            "3 - Traslado",
            "4 - Herramientas"});
            this.cboTipDoc.Location = new System.Drawing.Point(60, 57);
            this.cboTipDoc.Name = "cboTipDoc";
            this.cboTipDoc.Size = new System.Drawing.Size(192, 21);
            this.cboTipDoc.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tipo Doc:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(269, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "N° Doc:";
            // 
            // txtNumDoc
            // 
            this.txtNumDoc.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtNumDoc.Location = new System.Drawing.Point(314, 57);
            this.txtNumDoc.Name = "txtNumDoc";
            this.txtNumDoc.Size = new System.Drawing.Size(100, 21);
            this.txtNumDoc.TabIndex = 4;
            // 
            // btnSelDoc
            // 
            this.btnSelDoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelDoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSelDoc.Image = ((System.Drawing.Image)(resources.GetObject("btnSelDoc.Image")));
            this.btnSelDoc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSelDoc.Location = new System.Drawing.Point(420, 54);
            this.btnSelDoc.Name = "btnSelDoc";
            this.btnSelDoc.Size = new System.Drawing.Size(154, 24);
            this.btnSelDoc.TabIndex = 5;
            this.btnSelDoc.Text = "Seleccionar Documento";
            this.btnSelDoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSelDoc.UseVisualStyleBackColor = true;
            this.btnSelDoc.Click += new System.EventHandler(this.btnSelDoc_Click);
            // 
            // btnAgr
            // 
            this.btnAgr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAgr.Image = ((System.Drawing.Image)(resources.GetObject("btnAgr.Image")));
            this.btnAgr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgr.Location = new System.Drawing.Point(12, 87);
            this.btnAgr.Name = "btnAgr";
            this.btnAgr.Size = new System.Drawing.Size(128, 23);
            this.btnAgr.TabIndex = 6;
            this.btnAgr.Text = "&Agregar";
            this.btnAgr.UseVisualStyleBackColor = true;
            this.btnAgr.Click += new System.EventHandler(this.btnAgr_Click);
            // 
            // lblMensaje
            // 
            this.lblMensaje.AutoSize = true;
            this.lblMensaje.Location = new System.Drawing.Point(417, 91);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(0, 13);
            this.lblMensaje.TabIndex = 5;
            // 
            // frmRutaDocRel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 294);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.btnAgr);
            this.Controls.Add(this.btnSelDoc);
            this.Controls.Add(this.cboTipDoc);
            this.Controls.Add(this.txtNumDoc);
            this.Controls.Add(this.txtNumMov);
            this.Controls.Add(this.fgRutRel);
            this.Controls.Add(this.lblFecRut);
            this.Controls.Add(this.lblRq);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmRutaDocRel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ruta - Documentos Relacionados";
            this.Load += new System.EventHandler(this.frmRutaDocRel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fgRutRel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboTipDoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNumDoc;
        public C1.Win.C1FlexGrid.C1FlexGrid fgRutRel;
        private System.Windows.Forms.Button btnAgr;
        public System.Windows.Forms.Label lblFecRut;
        public System.Windows.Forms.Label lblRq;
        public System.Windows.Forms.TextBox txtNumMov;
        public System.Windows.Forms.Button btnSelDoc;
        public System.Windows.Forms.Label lblMensaje;
    }
}