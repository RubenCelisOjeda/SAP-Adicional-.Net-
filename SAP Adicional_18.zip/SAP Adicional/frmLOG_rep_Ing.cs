﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_rep_Ing : Form
    {
        private  NConsultas nc = new NConsultas();  
          
        public frmLOG_rep_Ing()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            DataTable dtRepIng = nc.LOG_rep_Ing(Convert.ToDateTime(dtpInicio.Value.Date), 
                                                Convert.ToDateTime(dtpFinal.Value.Date));

            if (dtRepIng.Rows.Count > 0)
            {
                this.fgRepIng.DataSource = dtpFinal;
            }
            else
            {
                DataTable dtClear = new DataTable();
                dtClear.Clear();

                this.fgRepIng.DataSource = dtClear;
            }

             this.LOG_rep_Ing_FormatoGeneral();
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fgRepIng.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch  (Exception ex)
            {
                return;
            }            
        }

        public void LOG_rep_Ing_FormatoGeneral()
        {
            this.fgRepIng.Cols[0].Width = 110;
            this.fgRepIng.Cols[1].Width = 390;
            this.fgRepIng.Cols[2].Width = 270;

            this.fgRepIng.Cols.Frozen = 3;
            //fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            //fg.Styles.Alternate.BackColor = Color.LightBlue;
            //fg.Styles.Highlight.BackColor = Color.Blue;
            //fg.Styles.Highlight.ForeColor = Color.White;
            //fg.AllowFreezing = AllowFreezingEnum.Both;

            //CellStyle s = fg.Styles[CellStyleEnum.Subtotal0];
            //s.BackColor = Color.Yellow;
            //s.ForeColor = Color.Blue;
            for (int i = 3; i < this.fgRepIng.Cols.Count; i++)
            {
                this.fgRepIng.Cols[i].Width = 75;
                this.fgRepIng.Cols[i].Format = "0.00";
            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar !=3  && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void frmLOG_rep_Ing_Load(object sender, EventArgs e)
        {

        }
    }
}
