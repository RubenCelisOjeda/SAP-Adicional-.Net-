﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using Entidades.OPE_Pro;

namespace SAP_Adicional
{
    public partial class frmOPE_Pro_ingact : Form,  OPE_Pro_Filtros
    {
        NConsultas nc = new NConsultas();
        NOPE_Pro nop = new NOPE_Pro();
        VarGlo varglo = VarGlo.Instance();

        Boolean EstModIte;
        Boolean SERSUP;
        Boolean EstMod;

        public frmOPE_Pro_ingact()
        {
            InitializeComponent();
            FormatoDTV();
            
        }

        public void recdat_OPE_Pro_RQ(string rq, string cli, string vend)
        {
            this.txtRQ.Text = rq;
            this.txtSocNeg.Text = cli;
            this.txtVen.Text = vend;
        }

        private void btnAgrRQ_Click(object sender, EventArgs e)
        {            

            //Validaciones
            if (string.IsNullOrEmpty(this.txtCodTip.Text))
                { MessageBox.Show("Debe elegir un Tipo "); this.txtTipo.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtRQ.Text))
            { MessageBox.Show("Debe elegir un RQ"); this.txtRQ.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtSocNeg.Text))
            {                MessageBox.Show("Presione enter en el campo RQ para cargar los valores del mismo");this.txtSocNeg.Focus(); return;            }

            if (string.IsNullOrEmpty(this.txtCodCom.Text))
                { MessageBox.Show("Debe elegir una Complejidad"); this.txtCom.Focus(); return; }            

            if (string.IsNullOrEmpty(this.txtCodDis.Text))
                { MessageBox.Show("Debe elegir un Diseño"); this.txtDise.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtCodIngOpe.Text))
                { MessageBox.Show("Debe elegir un Ing. Operaciones"); this.txtIngOpe.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtCodSup.Text))
            { MessageBox.Show("Debe elegir un Supervisor"); this.txtSup.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtCodAdmPed.Text))
            { MessageBox.Show("Debe elegir un Adm. Pedidos"); this.txtAdmPed.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtCodTipPre.Text))
            { MessageBox.Show("Debe elegir un Tipo de Predio"); this.txtTipPre.Focus(); return; }
            
            foreach (DataGridViewRow row in dgvRQ.Rows)
            {
                if ((row.Cells["RQ"].Value).ToString() == this.txtRQ.Text && EstModIte == false && Convert.ToInt16(row.Cells["RQ"].Value) != 0)
                {
                    MessageBox.Show("El número de RQ ya fue seleccionado"); return;
                }
            }

            if (EstModIte == true)
            {
                dgvRQ.Rows.RemoveAt(dgvRQ.CurrentRow.Index);
            }

            //Agregamos la fila al dgvDet
            string[] rowDet = new string[]
                                    {chkTip.Checked.ToString(), chkPen.Checked.ToString(), SERSUP.ToString(), this.txtCodTip.Text,
                                    this.txtTipo.Text,this.txtRQ.Text, this.txtSocNeg.Text,this.txtCodCom.Text,
                                    this.txtCom.Text, this.txtCodTipPre.Text, this.txtTipPre.Text, 
                                    this.txtVen.Text, this.txtCodDis.Text, this.txtDise.Text,
                                    this.txtCodIngOpe.Text, this.txtIngOpe.Text, this.txtCodSup.Text, this.txtSup.Text,
                                    this.txtCodAdmPed.Text, this.txtAdmPed.Text};

            dgvRQ.Rows.Add(rowDet);

            this.btnCan.PerformClick();

            EstMod = true;
        }

        private void FormatoDTV()
        {
            dgvRQ.ColumnCount = 17;

            //Detalle (Articulos Compuestos)
            DataGridViewCheckBoxColumn Col1 = new DataGridViewCheckBoxColumn();            
            Col1.Name = "Tipico";
            Col1.HeaderText = "Tipico";
            dgvRQ.Columns.Insert(0, Col1);
            //dgvRQ.Columns.Add(Col1);
            //dgvRQ.Columns[0].Name = "Tipico";

            DataGridViewCheckBoxColumn Col2 = new DataGridViewCheckBoxColumn();
            Col2.Name = "Pendiente";
            Col2.HeaderText = "Pendiente";
            dgvRQ.Columns.Insert(1, Col2);

            DataGridViewCheckBoxColumn Col3 = new DataGridViewCheckBoxColumn();
            Col3.Name = "SUP";
            Col3.HeaderText = "SUP";
            dgvRQ.Columns.Insert(2, Col3);


            dgvRQ.Columns[3].Name = "CodTip";
            dgvRQ.Columns[4].Name = "Tipo";
            dgvRQ.Columns[5].Name = "RQ";
            dgvRQ.Columns[6].Name = "Socio Negocio";
            dgvRQ.Columns[7].Name = "CodCom";
            dgvRQ.Columns[8].Name = "Complejidad";
            dgvRQ.Columns[9].Name = "CodTipPre";
            dgvRQ.Columns[10].Name = "Tipo Predio";
            dgvRQ.Columns[11].Name = "Vendedor";
            dgvRQ.Columns[12].Name = "CodDis";
            dgvRQ.Columns[13].Name = "Diseño";
            dgvRQ.Columns[14].Name = "CodIngOpe";
            dgvRQ.Columns[15].Name = "Ing. Operaciones";
            dgvRQ.Columns[16].Name = "CodSup";
            dgvRQ.Columns[17].Name = "Supervisor";
            dgvRQ.Columns[18].Name = "CodAdmPed";
            dgvRQ.Columns[19].Name = "Adm. Pedidos";


            //dgvRQ.Columns.Add(Col3);   


            ////Columna combo
            //DataGridViewComboBoxColumn cmbColTip = new DataGridViewComboBoxColumn();
            //cmbColTip.HeaderText = "Tipo";
            //cmbColTip.Name = "Tipo";

            //cmbColTip.DataSource = nop.OPE_Pro_Tipo();
            //cmbColTip.ValueMember = "Cod";
            //cmbColTip.DisplayMember = "Des";
            //dgvRQ.Columns.Add(cmbColTip);

            //dgvRQ.Columns["Tipo"].DisplayIndex = 2;

            //Ancho de columnas, fuente, visible y frozen

            dgvRQ.Font = new Font("Tahoma", 7);

            dgvRQ.Columns[3].Frozen = true;
            dgvRQ.RowHeadersVisible = false;

            dgvRQ.Columns[0].Width = 50; //Tipico
            dgvRQ.Columns[1].Width = 60;//Pendiente
            dgvRQ.Columns[2].Width = 50;//SUP
            dgvRQ.Columns[3].Visible = false; //CodTip
            dgvRQ.Columns[4].Width = 90;//Tipo
            dgvRQ.Columns[5].Width = 40; //RQ
            dgvRQ.Columns[6].Width = 300;//Socio negocio
            dgvRQ.Columns[7].Visible = false;//CodCom
            dgvRQ.Columns[8].Width = 110;//Complejidad
            dgvRQ.Columns[9].Visible = false;//CodTipPre
            dgvRQ.Columns[10].Width = 110;//Tipo Predio
            dgvRQ.Columns[11].Width = 150; //Vendedor
            dgvRQ.Columns[12].Visible = false;//CodDis
            dgvRQ.Columns[13].Width = 150;//Diseño
            dgvRQ.Columns[14].Visible = false;//CodIngOpe
            dgvRQ.Columns[15].Width = 150;//Ing. Operaciones
            dgvRQ.Columns[16].Visible = false; //CodSup
            dgvRQ.Columns[17].Width = 150; //Supervisor
            dgvRQ.Columns[18].Visible = false;//CodAdmPed
            dgvRQ.Columns[19].Width = 150;//Adm.Pedido

        }

        private void frmOPE_Pro_ingact_Load(object sender, EventArgs e)
        {
            if(this.txtNumMov.Text != "")
            {
                Buscar();                
            }  

        }

        public void LimpiarControles()
        {
            this.txtNumMov.Text = "";
            this.txtNom.Text = "";
            this.txtDir.Text = "";
            this.txtDir.Text = "";
            this.txtFecIng.Text = "";

            this.txtFecIng.Text = nc.FechaServidor();
            
        }

        private void btnCreAct_Click(object sender, EventArgs e)
        {
            //Revisamos que se agregue la informacion de nombre, direccion y distrito
            if (this.txtNom.Text == "") { MessageBox.Show("Debe ingresar un nombre."); this.txtNom.Focus(); return; }
            if (this.txtDir.Text == "") { MessageBox.Show("Debe ingresar una dirección."); this.txtDir.Focus(); return; }
            if (this.txtDis.Text == "") { MessageBox.Show("Debe ingresar un distrito."); this.txtDis.Focus(); return; }

            //Validamos fecha
            DateTime fecha;

            mtxtFecIns.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;

            if (String.IsNullOrEmpty(mtxtFecIns.Text))
            {
                MessageBox.Show("Debe ingresar una fecha de instalacion", "SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                mtxtFecIns.Focus(); return;
            }

            if (!String.IsNullOrEmpty(mtxtFecIns.Text) & mtxtFecIns.MaskFull == true)
            {
                mtxtFecIns.TextMaskFormat = MaskFormat.IncludeLiterals;

                if (!DateTime.TryParse(mtxtFecIns.Text, out fecha))
                {
                    MessageBox.Show("Fecha de finalización incorrecta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mtxtFecIns.Focus();
                    return;
                }
            }
            else if (!String.IsNullOrEmpty(mtxtFecIns.Text) & mtxtFecIns.MaskFull == false)
            {
                MessageBox.Show("Debe llenar todos los valores en la fecha aprox. de instalacion", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mtxtFecIns.Focus();
                return;
            }
            
            //Revisamos que por lo menos se tenga un RQ ingresado
            if (this.dgvRQ.Rows.Count == 0) { MessageBox.Show("Debe seleccionar un RQ para el proyecto."); this.btnAgrRQ.Focus(); return; }
            //

            //Entidad encabezado de OPE_Pro
            OPE_Pro Enc = new OPE_Pro();

            Enc.NumMov = Convert.ToInt64(string.IsNullOrEmpty(this.txtNumMov.Text) ? "0" : this.txtNumMov.Text);
            Enc.NomPro = this.txtNom.Text;
            Enc.DirPro = this.txtDir.Text;
            Enc.DisPro = this.txtDis.Text;        
            Enc.FecAprIns = Convert.ToDateTime(this.mtxtFecIns.Text);
            Enc.CodUsu = varglo.CodUsuAct;

            Int16 CorPen = 0;
            //Recorremos el datagridview para agregar las lineas de detalle cero
            foreach (DataGridViewRow row in dgvRQ.Rows)
            {
                OPE_Pro_Det0 Det0 = new OPE_Pro_Det0();

                //Det0.NumMov = Convert.ToInt64(this.txtNumMov.Text);
                Det0.Tipico = Convert.ToBoolean(row.Cells["Tipico"].Value);
                Det0.Pendiente = Convert.ToBoolean(row.Cells["Pendiente"].Value);
                Det0.CodTip = Convert.ToInt16(row.Cells["CodTip"].Value);
                Det0.RQ = Convert.ToInt32(row.Cells["RQ"].Value);
                Det0.SocNeg = (row.Cells["Socio Negocio"].Value).ToString();
                Det0.CodCom = Convert.ToInt16(row.Cells["CodCom"].Value);
                Det0.CodTipPre = Convert.ToInt16(row.Cells["CodTipPre"].Value);
                Det0.Ven= (row.Cells["Vendedor"].Value).ToString();
                Det0.CodDis = Convert.ToInt32(row.Cells["CodDis"].Value);
                Det0.CodIngOpe = Convert.ToInt32(row.Cells["CodIngOpe"].Value);
                Det0.CodSup = Convert.ToInt32(row.Cells["CodSup"].Value);
                Det0.CodAdmPed = Convert.ToInt32(row.Cells["CodAdmPed"].Value);
                //Det0.Sup = Convert.ToBoolean(row.Cells["SUP"].Value);
                
                //Aumentamos el valor de la variable correlativo pendiente, unicamente si la fila es del tipo pendiente 
                //para que no choque con la columna RQ que va a tener el valor Cero, de lo contrario pasamos cero
                if (Convert.ToBoolean(row.Cells["Pendiente"].Value) == true || Convert.ToBoolean(row.Cells["Tipico"].Value) == true)
                {
                    Det0.CorTipPen = CorPen;
                    CorPen++;
                }
                else
                {
                    Det0.CorTipPen = 0;
                }

                Enc.Det0.Add(Det0);
            }

            //Pasamos la entidad para guardar
            nop.OPE_Pro_InsertarEditar(Enc);            
            //Recuperamos el numero de movimiento
            this.txtNumMov.Text = Enc.NumMov.ToString();

            EstMod = false;

        }

        private void dgvRQ_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void txtTipo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTipo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo", "Filtro_OPE_Pro_Tipo", this.txtTipo.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    if (chkTip.Checked == true || chkPen.Checked == true)
                    {
                        txtCom.Focus();
                    }
                    else
                    {
                        txtRQ.Focus();
                    }                    
                }
            }
        }

        public void ConsultaDatos(string vista, string procedimiento, string param1, string param2)
        {
            DataTable dt = new DataTable();

            dt = nc.OPE_Pro_Filtros(vista, procedimiento, param1, param2);
            
            if (dt.Rows.Count > 1)
            {

                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 39;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.OPE_Pro = this;
                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Tipo":
                        txtCodTip.Text = row["Codigo"].ToString();
                        txtTipo.Text = row["Tipo"].ToString();
                        txtRQ.Focus();
                        break;
                    case "RQ":
                        txtRQ.Text = row["N° RQ"].ToString();
                        txtSocNeg.Text = row["Cliente"].ToString();
                        txtVen.Text = row["Vendedor"].ToString();
                        SERSUP = Convert.ToBoolean(row["SERSUP"].ToString());
                        txtCom.Focus();
                        break;
                    case "Complejidad":
                        txtCodCom.Text = row["Codigo"].ToString();
                        txtCom.Text = row["Complejidad"].ToString();
                        this.txtTipPre.Focus();
                        break;
                    case "Tipo Predio":
                        txtCodTipPre.Text = row["Codigo"].ToString();
                        txtTipPre.Text = row["TipoPredio"].ToString();
                        this.txtDise.Focus();
                        break;
                    case "Diseño":
                        txtCodDis.Text = row["Codigo"].ToString();
                        txtDise.Text = row["Diseño"].ToString();
                        this.txtIngOpe.Focus();
                        break;
                    case "Ing. Operaciones":
                        txtCodIngOpe.Text = row["Codigo"].ToString();
                        txtIngOpe.Text = row["Ing. Operaciones"].ToString();
                        this.txtSup.Focus();
                        break;
                    case "Supervisor":
                        this.txtCodSup.Text = row["Codigo"].ToString();
                        this.txtSup.Text = row["Supervisor"].ToString();
                        this.txtAdmPed.Focus();
                        break;
                    case "Adm. Pedidos":
                        this.txtCodAdmPed.Text = row["Codigo"].ToString();
                        this.txtSup.Text = row["Adm. Pedidos"].ToString();
                        this.btnAgrRQ.Focus();
                        break;
                    default:
                        break;
                }
            }
            else if (dt.Rows.Count == 0 && vista == "RQ")
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros, revise si el RQ esta agregado en otro proyecto.", "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional");
            }
        }

        private void txtRQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            Int64 nummov;

            nummov = 0;

            if (!string.IsNullOrEmpty(this.txtNumMov.Text))
            {
                nummov = Convert.ToInt64(txtNumMov.Text);
            }


            if (e.KeyChar == 13)
            {
                ConsultaDatos("RQ", "OPE_Pro_RQ_info", this.txtRQ.Text, nummov.ToString());

                if (varglo.Elegi == true)
                {
                    txtCom.Focus();
                }
            }
        }

        public void recdat_OPE_Pro_Tipo(string CodTip, string Tipo)
        {
            this.txtCodTip.Text = CodTip;
            this.txtTipo.Text = Tipo;
        }

        public void recdat_OPE_Pro_Complejidad(string CodCom, string Com)
        {
            this.txtCodCom.Text = CodCom;
            this.txtCom.Text = Com;
        }

        public void recdat_OPE_Pro_Diseño(string CodDis, string Dis)
        {
            this.txtCodDis.Text = CodDis;
            this.txtDise.Text = Dis;
        }

        public void recdat_OPE_Pro_IngOpe(string CodIngOpe, string IngOpe)
        {
            this.txtCodIngOpe.Text = CodIngOpe;
            this.txtIngOpe.Text = IngOpe;
        }

        public void recdat_OPE_Pro_Supervisor(string CodSup, string Sup)
        {
            this.txtCodSup.Text = CodSup;
            this.txtSup.Text = Sup;
        }

        public void recdat_OPE_Pro_AdmPed(string CodAdmPed, string AdmPed)
        {
            this.txtCodAdmPed.Text = CodAdmPed;
            this.txtAdmPed.Text = AdmPed;
        }

        private void txtCom_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                if (string.IsNullOrEmpty(this.txtCodTip.Text))
                { MessageBox.Show("Primero debe elegir un tipo","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information); this.txtTipo.Focus(); return; }

                ConsultaDatos("Complejidad", "Filtro_OPE_Pro_Com", this.txtCom.Text.Trim(), this.txtCodTip.Text);

                if (varglo.Elegi == true)
                {
                    txtTipPre.Focus();
                }
            }
        }

        private void txtDise_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Diseño", "Filtro_OPE_Pro_Diseño", this.txtDise.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    txtIngOpe.Focus();
                }
            }
        }

        private void txtIngOpe_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Ing. Operaciones", "Filtro_OPE_Pro_IngOpe", this.txtIngOpe.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    txtSup.Focus();
                }
            }
        }

        private void txtAdmPed_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Adm. Pedidos", "Filtro_OPE_Pro_AdmPed", this.txtAdmPed.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    btnAgrRQ.Focus();
                }
            }
        }

        private void txtSup_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Supervisor", "Filtro_OPE_Pro_Sup", this.txtSup.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    txtAdmPed.Focus();
                }
            }
        }

        private void chkPen_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPen.Checked == true)
            {
                chkTip.Checked = false;
                this.txtRQ.Text = "00000"; this.txtRQ.Enabled = false;
                this.txtSocNeg.Text = "PENDIENTE";
            }
            else
            {
                this.txtRQ.Text = ""; this.txtRQ.Enabled = true;
                this.txtSocNeg.Text = ""; 
            }
        }

        private void chkTip_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTip.Checked == true)
            {
                chkPen.Checked = false;
                this.txtRQ.Text = "00000"; this.txtRQ.Enabled = false;
                this.txtSocNeg.Text = "TIPICO"; 
                this.txtVen.Text = "TIPICO"; this.txtVen.Enabled = false;                
            }
            else
            {
                this.txtRQ.Text = ""; this.txtRQ.Enabled = true;
                this.txtSocNeg.Text = ""; 
                this.txtVen.Text = ""; this.txtVen.Enabled = true;
            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            chkTip.Enabled = true; chkPen.Enabled = true;
            txtRQ.Enabled = true; dgvRQ.Enabled = true;

            this.chkTip.Checked = false; this.chkPen.Checked = false;
            this.txtCodTip.Text = ""; this.txtTipo.Text = "";
            this.txtRQ.Text = ""; this.txtSocNeg.Text = "";
            this.txtCodCom.Text = ""; this.txtCom.Text = "";
            this.txtCodTipPre.Text = ""; this.txtTipPre.Text = "";
            this.txtVen.Text = ""; this.txtCodDis.Text = "";
            this.txtDise.Text = ""; this.txtCodIngOpe.Text = "";
            this.txtIngOpe.Text = ""; this.txtCodSup.Text = "";
            this.txtSup.Text = ""; this.txtCodAdmPed.Text = "";
            this.txtAdmPed.Text = ""; 

            EstModIte = false;            

            this.chkTip.Focus();
        }

        private void txtNom_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                this.txtDir.Focus();

            }
        }

        private void txtDir_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                this.txtDis.Focus();

            }
        }

        private void txtDis_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                this.chkTip.Focus();

            }
        }

        private void chkTip_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                this.chkPen.Focus();

            }
        }

        public void Buscar()
        {
            DataSet dsOPE_Pro = new DataSet();

            dsOPE_Pro = nop.OPE_Pro_rec(Convert.ToInt32(this.txtNumMov.Text));

            DataTable OPE_Pro_Enc = dsOPE_Pro.Tables["OPE_Pro_Enc"];

            this.txtNom.Text = OPE_Pro_Enc.Rows[0]["NomPro"].ToString();
            this.txtDir.Text = OPE_Pro_Enc.Rows[0]["DirPro"].ToString();
            this.txtDis.Text = OPE_Pro_Enc.Rows[0]["DisPro"].ToString();
            this.mtxtFecIns.Text = OPE_Pro_Enc.Rows[0]["FecAprIns"].ToString();

            DateTime fecha = Convert.ToDateTime(OPE_Pro_Enc.Rows[0]["FecEmi"].ToString());

            this.txtFecIng.Text = fecha.ToShortDateString() ;

            DataTable OPE_Pro_Det0 = dsOPE_Pro.Tables["OPE_Pro_Det0"];

            foreach (DataRow row in OPE_Pro_Det0.Rows)
            {
                string[] rowDet = new string[]
                                   {row["Tipico"].ToString(), row["Pendiente"].ToString(), row["SERSUP"].ToString(), row["CodTip"].ToString(), 
                                    row["Tipo"].ToString(),row["RQ"].ToString(), row["SocNeg"].ToString(),row["CodCom"].ToString(),
                                    row["Complejidad"].ToString(), row["CodTipPre"].ToString(), row["TipoPredio"].ToString(),
                                    row["Ven"].ToString(), row["CodDis"].ToString(), row["Diseño"].ToString(),
                                    row["CodIngOpe"].ToString(), row["IngOpe"].ToString(), row["CodSup"].ToString(), row["Sup"].ToString(),
                                    row["CodAdmPed"].ToString(), row["AdmPed"].ToString()};

                dgvRQ.Rows.Add(rowDet);

            }          
        }

        private void txtTipPre_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 13)
            {

                ConsultaDatos("Tipo Predio", "Filtro_OPE_Pro_TipPre", this.txtTipPre.Text,"");

                if (varglo.Elegi == true)
                {
                    txtDise.Focus();
                }
            }

        }

        public void recdat_OPE_Pro_TipoPredio(string CodTipPre, string TipPre)
        {
            this.txtCodTipPre.Text = CodTipPre;
            this.txtTipPre.Text = TipPre;
        }

        private void dgvRQ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 46)
            {

                DataTable dt = new DataTable();

                dt = nc.OPE_Pro_Filtros("OPE_Pro_Det1", "OPE_Pro_Det1_rq_rec", Convert.ToString(dgvRQ.CurrentRow.Cells[4].Value), "");

                if (dt.Rows.Count != 0)
                {
                    MessageBox.Show("No puede eliminar esta fila, el RQ contiene informacion en acuerdos comerciales", "SAP Adicional");
                }
                else
                {
                    DialogResult result = MessageBox.Show("¿Esta seguro de eliminar este RQ de la lista?", "SAP Adicional", MessageBoxButtons.YesNo);

                    if (result == DialogResult.Yes)
                    {
                        dgvRQ.Rows.RemoveAt(dgvRQ.CurrentRow.Index);
                    }
                }
                                
            }
        }

        private void dgvRQ_DoubleClick(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Desea modificar esta linea", "SAP Adicional", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                this.chkTip.Checked = Convert.ToBoolean(dgvRQ.CurrentRow.Cells[0].Value.ToString());
                this.chkPen.Checked = Convert.ToBoolean(dgvRQ.CurrentRow.Cells[1].Value.ToString());

                this.txtCodTip.Text = dgvRQ.CurrentRow.Cells[3].Value.ToString();
                this.txtTipo.Text = dgvRQ.CurrentRow.Cells[4].Value.ToString();
                this.txtRQ.Text = dgvRQ.CurrentRow.Cells[5].Value.ToString();
                this.txtSocNeg.Text = dgvRQ.CurrentRow.Cells[6].Value.ToString();
                this.txtCodCom.Text = dgvRQ.CurrentRow.Cells[7].Value.ToString();
                this.txtCom.Text = dgvRQ.CurrentRow.Cells[8].Value.ToString();
                this.txtCodTipPre.Text = dgvRQ.CurrentRow.Cells[9].Value.ToString();
                this.txtTipPre.Text = dgvRQ.CurrentRow.Cells[10].Value.ToString();
                this.txtVen.Text = dgvRQ.CurrentRow.Cells[11].Value.ToString();
                this.txtCodDis.Text = dgvRQ.CurrentRow.Cells[12].Value.ToString();
                this.txtDise.Text = dgvRQ.CurrentRow.Cells[13].Value.ToString();
                this.txtCodIngOpe.Text = dgvRQ.CurrentRow.Cells[14].Value.ToString();
                this.txtIngOpe.Text = dgvRQ.CurrentRow.Cells[15].Value.ToString();
                this.txtCodSup.Text = dgvRQ.CurrentRow.Cells[16].Value.ToString();
                this.txtSup.Text = dgvRQ.CurrentRow.Cells[17].Value.ToString();
                this.txtCodAdmPed.Text = dgvRQ.CurrentRow.Cells[18].Value.ToString();
                this.txtAdmPed.Text = dgvRQ.CurrentRow.Cells[19].Value.ToString();
            
                EstModIte = true;

                //Si la linea contiene un numero de RQ diferente de cero, deshabilitamos los checks de Tipico, Pendiente y el cuadro de texto del RQ.

                if (Convert.ToInt32(txtRQ.Text) != 0)
                {
                    chkTip.Enabled = false;
                    chkPen.Enabled = false;
                    txtRQ.Enabled = false;
                    dgvRQ.Enabled = false;
                }
                else
                {
                    chkTip.Focus();
                }                
            }
            
        }

        private void txtRQ_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvRQ_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvRQ.CurrentCell.ColumnIndex == 0 || dgvRQ.CurrentCell.ColumnIndex == 1 || dgvRQ.CurrentCell.ColumnIndex == 2)
            {
                e.Cancel = true;
            }
        }

        private void dgvRQ_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //Referenciamos el control TextBox subyacente en la celda actual.

            TextBox cellTextBox = (DataGridViewTextBoxEditingControl)e.Control;

            cellTextBox.ReadOnly = true;
        }

        private void frmOPE_Pro_ingact_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (EstMod == true)
            {
                DialogResult result = MessageBox.Show("¿Desea guardar las modificaciones antes de cerrar?","SAP Adicional",MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    btnCreAct.PerformClick();
                }
            }
        }

        private void frmOPE_Pro_ingact_Shown(object sender, EventArgs e)
        {
            this.txtNom.Focus();
        }

        private void dgvRQ_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
