﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmVEN_REP_Ingresos : Form
    {
        NConsultas nc = new NConsultas();
        DataTable dt;
        public frmVEN_REP_Ingresos()
        {
            InitializeComponent();
        }

        private void frmVEN_REP_Ingresos_Load(object sender, EventArgs e)
        {
            fg.AutoResize = true;
            fg.Styles.Normal.WordWrap = true;
            fg.Rows.Count = 1;
            fg.Cols.Count = 1;
            fg.Rows[0].Height = 50;
        }
        private void btnMos_Click(object sender, EventArgs e)
        {
            if (dtpIni.Checked == false && dtpFin.Checked == false)
            {
                return;
            }
            else
            {
                this.dt = nc.VEN_rep_Ing(dtpIni.Value, dtpFin.Value);
                this.fg.DataSource = dt;
            }                         
        }    
        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFin.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }
      
        private void btnExp_Click(object sender, EventArgs e)
        {
            //Expor();
            ExportExcel();
        }
        private void dgv_AfterDataRefresh(object sender, System.ComponentModel.ListChangedEventArgs e)
        {
            fg.Rows.Frozen = 1;
            Formato();
            Totales();
        }
       public void Formato()
        {


            fg.AutoResize = true;            
            fg.Cols.Frozen = 3;
            fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;
            fg.AllowFreezing = AllowFreezingEnum.Both;

            CellStyle s = fg.Styles[CellStyleEnum.Subtotal0];
            s.BackColor = Color.Yellow;
            s.ForeColor = Color.Blue;

            fg.Cols[10].TextAlign = TextAlignEnum.RightCenter;
            fg.Cols[11].TextAlign = TextAlignEnum.RightCenter;

            fg.Cols[10].Format = "#,###.00";
            fg.Cols[11].Format = "#,###.00";
            fg.Cols[12].Format = "#,###.00";
            fg.Cols[13].Format = "#,###.00";

            fg.Cols[0].Width = 80; //N° de Recibo
            fg.Cols[2].Width = 300; //CardName
            fg.Cols[3].Width = 70; //RQ / N° Ficha Hist
            fg.Cols[6].Width = 150; //Tipo
            fg.Cols[13].Width = 100; //Mnt Nto 
            fg.Cols[15].Width = 200; //Recomendador

        }
        public void ExportExcel( )
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";

            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);

        }

        private void dgv_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar !=27)
            {
                e.Handled = true;
            }
        }

        private void dgv_AfterFilter(object sender, EventArgs e)
        {
            Totales();
        }

        private void Totales()
        {

            fg.Subtotal(AggregateEnum.Sum, 0, -1, -1, 10,  "TOTAL");
            fg.Subtotal(AggregateEnum.Sum, 0, -1, -1, 11, "TOTAL");
            if (fg.Rows.Count > 1) fg.Cols[0][1] = "TOTALES";

        }

        private void fg_Click(object sender, EventArgs e)
        {

        }

        //public void Expor()
        //{
        //    C1.Win.C1FlexGrid.C1FlexGrid = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
        //    DataGridView1.MultiSelect = true;
        //    DataGridView1.SelectAll();
        //    DataObject dataObj = DataGridView1.GetClipboardContent();
        //    if (dataObj != null)
        //        Clipboard.SetDataObject(dataObj);

        //    Microsoft.Office.Interop.Excel.Application xlexcel;
        //    Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
        //    Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
        //    object misValue = System.Reflection.Missing.Value;
        //    xlexcel = new Excel.Application();
        //    xlexcel.Visible = true;
        //    xlWorkBook = xlexcel.Workbooks.Add(misValue);
        //    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
        //    Excel.Range rango = (Excel.Range)xlWorkSheet.Cells[1, 1];
        //    rango.Select();
        //    xlWorkSheet.PasteSpecial(rango, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);

        //    // la primera fila en negrita, centrada y con fondo gris
        //    Excel.Range fila1 = (Excel.Range)xlWorkSheet.Rows[1];
        //    fila1.Select();
        //    fila1.EntireRow.Font.Bold = true;
        //    fila1.EntireRow.HorizontalAlignment = HorizontalAlignment.Center;
        //    fila1.EntireRow.Interior.Color = Color.Gray;

        //    // si la primera celda de la primera columna está vacía, elimino la primera columna
        //    // esto se puede omitir, pero lo dejo para ver cómo se podrían añadir/eliminar datos a posteriori
        //    Excel.Range c1f1 = (Excel.Range)xlWorkSheet.Cells[1, 1];
        //    if (c1f1.Text == "")
        //    {
        //        Excel.Range columna1 = (Excel.Range)xlWorkSheet.Columns[1];
        //        columna1.Select();
        //        columna1.Delete();
        //    }

        //    // selecciono la primera celda de la primera columna
        //    Excel.Range c1 = (Excel.Range)xlWorkSheet.Cells[1, 1];
        //    c1.Select();

        //    DataGridView1.ClearSelection();
        //    DataGridView1.MultiSelect = false;
        //}

    }
}
