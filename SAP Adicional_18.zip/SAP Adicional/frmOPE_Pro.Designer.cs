﻿namespace SAP_Adicional
{
    partial class frmOPE_Pro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOPE_Pro));
            this.dgvRQ = new System.Windows.Forms.DataGridView();
            this.tlsBot = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.btnAbrir = new System.Windows.Forms.ToolStripButton();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.btnModificar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.btnTer = new System.Windows.Forms.ToolStripButton();
            this.btnPar = new System.Windows.Forms.ToolStripSplitButton();
            this.tsrMAct = new System.Windows.Forms.ToolStripMenuItem();
            this.btnArc = new System.Windows.Forms.ToolStripButton();
            this.tbcPro = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pnlAcuCom = new System.Windows.Forms.Panel();
            this.gbDetCosSer = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtPro_TotConUti = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtPro_TotSinUti = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtPro_Uti = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtPro_GasGen = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtPro_CosInd = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtPro_CosDir = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtIns_TotConUti = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtIns_TotSinUti = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtIns_Uti = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtIns_GasGen = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtIns_CosInd = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtIns_CosDir = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtSup_TotConUti = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtSup_TotSinUti = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtSup_Uti = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtSup_GasGen = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtSup_CosInd = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtSup_CosDir = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtDis_TotConUti = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtDis_TotSinUti = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtDis_Uti = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtDis_GasGen = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtDis_CosInd = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtDis_CosDir = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.gbDetConSer = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtPro_CosPro_Sol = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtPro_CanPanConLic_Und = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtPro_CanModRepAmp_Und = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtPro_CanBotSenDri_Und = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtPro_DurEst_Dia = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtIns_CosMat_Sol = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtIns_CosTraNoc_Sol = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtIns_CanPruLuc_Und = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtIns_CanViaMov_Und = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtIns_CanVisCoo_Und = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtIns_CanTecDia_Und = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtIns_DurEst_Dia = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSup_CanPrueMeg_Und = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtSup_CanPruMueDobAlt_Und = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtSup_CanPruMue_Und = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSup_CanVisSup_Und = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtSup_TraOfiOpe_Hor = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSup_CanVisIngOpe_Und = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSup_DurEst_Mes = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDis_DurEst_Mes = new System.Windows.Forms.TextBox();
            this.txtDis_TraDia_Hor = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDis_TraPla_Hor = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDis_TraOfi_Hor = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtDis_CanVis_Und = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAlcPro = new System.Windows.Forms.TextBox();
            this.lblRQ = new System.Windows.Forms.Label();
            this.btnPaq = new System.Windows.Forms.Button();
            this.btnLimPaq = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnlRegVis = new System.Windows.Forms.Panel();
            this.dgvRegVis = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pnlIntPro = new System.Windows.Forms.Panel();
            this.fgIntPro = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnCanInt = new System.Windows.Forms.Button();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.txtCel1 = new System.Windows.Forms.TextBox();
            this.btnAgrInt = new System.Windows.Forms.Button();
            this.txtNomInt = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.txtCel2 = new System.Windows.Forms.TextBox();
            this.txtCodCar = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.pnlRegOti = new System.Windows.Forms.Panel();
            this.dgvRegOTI = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.pnlRegRut = new System.Windows.Forms.Panel();
            this.dgvRegRuta = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.pnEnc = new System.Windows.Forms.Panel();
            this.gbFecAprIns = new System.Windows.Forms.GroupBox();
            this.fgFecAprIns = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.mtxtFecFin = new System.Windows.Forms.MaskedTextBox();
            this.txtCodEstObr = new System.Windows.Forms.TextBox();
            this.mtxtFecCab = new System.Windows.Forms.MaskedTextBox();
            this.mtxtFecIni = new System.Windows.Forms.MaskedTextBox();
            this.lblFecfin = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNumMov = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtDir = new System.Windows.Forms.TextBox();
            this.txtDis = new System.Windows.Forms.TextBox();
            this.txtFecIng = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEstObr = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRQ)).BeginInit();
            this.tlsBot.SuspendLayout();
            this.tbcPro.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnlAcuCom.SuspendLayout();
            this.gbDetCosSer.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gbDetConSer.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlRegVis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegVis)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.pnlIntPro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgIntPro)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.pnlRegOti.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegOTI)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.pnlRegRut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegRuta)).BeginInit();
            this.pnEnc.SuspendLayout();
            this.gbFecAprIns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgFecAprIns)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvRQ
            // 
            this.dgvRQ.AllowUserToAddRows = false;
            this.dgvRQ.AllowUserToDeleteRows = false;
            this.dgvRQ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRQ.Location = new System.Drawing.Point(21, 169);
            this.dgvRQ.Name = "dgvRQ";
            this.dgvRQ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRQ.Size = new System.Drawing.Size(1250, 137);
            this.dgvRQ.TabIndex = 25;
            this.dgvRQ.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvRQ_CellBeginEdit);
            this.dgvRQ.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRQ_CellClick);
            this.dgvRQ.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRQ_CellContentClick);
            this.dgvRQ.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvRQ_EditingControlShowing);
            // 
            // tlsBot
            // 
            this.tlsBot.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlsBot.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.btnAbrir,
            this.btnGuardar,
            this.btnModificar,
            this.toolStripSeparator,
            this.btnTer,
            this.btnPar,
            this.btnArc});
            this.tlsBot.Location = new System.Drawing.Point(0, 0);
            this.tlsBot.Name = "tlsBot";
            this.tlsBot.Size = new System.Drawing.Size(1283, 36);
            this.tlsBot.TabIndex = 41;
            this.tlsBot.Text = "toolStrip1";
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("btnNuevo.Image")));
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(42, 33);
            this.btnNuevo.Text = "&Nuevo";
            this.btnNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnAbrir
            // 
            this.btnAbrir.Image = ((System.Drawing.Image)(resources.GetObject("btnAbrir.Image")));
            this.btnAbrir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(34, 33);
            this.btnAbrir.Text = "&Abrir";
            this.btnAbrir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAbrir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbrir.Click += new System.EventHandler(this.btnAbrir_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(50, 33);
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(54, 33);
            this.btnModificar.Text = "Modificar";
            this.btnModificar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnModificar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 36);
            // 
            // btnTer
            // 
            this.btnTer.Image = ((System.Drawing.Image)(resources.GetObject("btnTer.Image")));
            this.btnTer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTer.Name = "btnTer";
            this.btnTer.Size = new System.Drawing.Size(61, 33);
            this.btnTer.Tag = "2";
            this.btnTer.Text = "Terminado";
            this.btnTer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnTer.Click += new System.EventHandler(this.btnTer_Click);
            // 
            // btnPar
            // 
            this.btnPar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsrMAct});
            this.btnPar.Image = ((System.Drawing.Image)(resources.GetObject("btnPar.Image")));
            this.btnPar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(72, 33);
            this.btnPar.Tag = "3";
            this.btnPar.Text = "Paralizado";
            this.btnPar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPar.ButtonClick += new System.EventHandler(this.btnPar_ButtonClick);
            // 
            // tsrMAct
            // 
            this.tsrMAct.Image = ((System.Drawing.Image)(resources.GetObject("tsrMAct.Image")));
            this.tsrMAct.Name = "tsrMAct";
            this.tsrMAct.Size = new System.Drawing.Size(108, 22);
            this.tsrMAct.Text = "Activar";
            this.tsrMAct.Click += new System.EventHandler(this.tsrMAct_Click);
            // 
            // btnArc
            // 
            this.btnArc.Image = ((System.Drawing.Image)(resources.GetObject("btnArc.Image")));
            this.btnArc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnArc.Name = "btnArc";
            this.btnArc.Size = new System.Drawing.Size(59, 33);
            this.btnArc.Tag = "4";
            this.btnArc.Text = "Archivado";
            this.btnArc.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // tbcPro
            // 
            this.tbcPro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tbcPro.Controls.Add(this.tabPage1);
            this.tbcPro.Controls.Add(this.tabPage2);
            this.tbcPro.Controls.Add(this.tabPage3);
            this.tbcPro.Controls.Add(this.tabPage4);
            this.tbcPro.Controls.Add(this.tabPage5);
            this.tbcPro.Controls.Add(this.tabPage6);
            this.tbcPro.Controls.Add(this.tabPage7);
            this.tbcPro.Location = new System.Drawing.Point(21, 315);
            this.tbcPro.Name = "tbcPro";
            this.tbcPro.SelectedIndex = 0;
            this.tbcPro.Size = new System.Drawing.Size(1091, 445);
            this.tbcPro.TabIndex = 36;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pnlAcuCom);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1083, 419);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "a. Acuerdos Comerciales";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pnlAcuCom
            // 
            this.pnlAcuCom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlAcuCom.AutoScroll = true;
            this.pnlAcuCom.Controls.Add(this.gbDetCosSer);
            this.pnlAcuCom.Controls.Add(this.label58);
            this.pnlAcuCom.Controls.Add(this.gbDetConSer);
            this.pnlAcuCom.Controls.Add(this.txtAlcPro);
            this.pnlAcuCom.Controls.Add(this.lblRQ);
            this.pnlAcuCom.Controls.Add(this.btnPaq);
            this.pnlAcuCom.Controls.Add(this.btnLimPaq);
            this.pnlAcuCom.Location = new System.Drawing.Point(3, 3);
            this.pnlAcuCom.Name = "pnlAcuCom";
            this.pnlAcuCom.Size = new System.Drawing.Size(1080, 396);
            this.pnlAcuCom.TabIndex = 46;
            // 
            // gbDetCosSer
            // 
            this.gbDetCosSer.Controls.Add(this.groupBox8);
            this.gbDetCosSer.Controls.Add(this.groupBox7);
            this.gbDetCosSer.Controls.Add(this.groupBox6);
            this.gbDetCosSer.Controls.Add(this.groupBox5);
            this.gbDetCosSer.Location = new System.Drawing.Point(16, 465);
            this.gbDetCosSer.Name = "gbDetCosSer";
            this.gbDetCosSer.Size = new System.Drawing.Size(993, 266);
            this.gbDetCosSer.TabIndex = 4;
            this.gbDetCosSer.TabStop = false;
            this.gbDetCosSer.Text = "Detalle de Costos de Servicios (USD)";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtPro_TotConUti);
            this.groupBox8.Controls.Add(this.label52);
            this.groupBox8.Controls.Add(this.txtPro_TotSinUti);
            this.groupBox8.Controls.Add(this.label53);
            this.groupBox8.Controls.Add(this.txtPro_Uti);
            this.groupBox8.Controls.Add(this.label54);
            this.groupBox8.Controls.Add(this.txtPro_GasGen);
            this.groupBox8.Controls.Add(this.label55);
            this.groupBox8.Controls.Add(this.txtPro_CosInd);
            this.groupBox8.Controls.Add(this.label56);
            this.groupBox8.Controls.Add(this.txtPro_CosDir);
            this.groupBox8.Controls.Add(this.label57);
            this.groupBox8.Location = new System.Drawing.Point(735, 30);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(220, 216);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Programación";
            // 
            // txtPro_TotConUti
            // 
            this.txtPro_TotConUti.Location = new System.Drawing.Point(157, 175);
            this.txtPro_TotConUti.Name = "txtPro_TotConUti";
            this.txtPro_TotConUti.Size = new System.Drawing.Size(54, 21);
            this.txtPro_TotConUti.TabIndex = 19;
            this.txtPro_TotConUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(16, 175);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(134, 31);
            this.label52.TabIndex = 18;
            this.label52.Text = "Total (Con Utilidad)";
            // 
            // txtPro_TotSinUti
            // 
            this.txtPro_TotSinUti.Location = new System.Drawing.Point(157, 147);
            this.txtPro_TotSinUti.Name = "txtPro_TotSinUti";
            this.txtPro_TotSinUti.Size = new System.Drawing.Size(54, 21);
            this.txtPro_TotSinUti.TabIndex = 17;
            this.txtPro_TotSinUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(16, 147);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(134, 31);
            this.label53.TabIndex = 16;
            this.label53.Text = "Total (Sin Utilidad)";
            // 
            // txtPro_Uti
            // 
            this.txtPro_Uti.Location = new System.Drawing.Point(157, 106);
            this.txtPro_Uti.Name = "txtPro_Uti";
            this.txtPro_Uti.Size = new System.Drawing.Size(54, 21);
            this.txtPro_Uti.TabIndex = 15;
            this.txtPro_Uti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_Uti.TextChanged += new System.EventHandler(this.txtPro_Uti_TextChanged);
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(16, 106);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(134, 31);
            this.label54.TabIndex = 14;
            this.label54.Text = "Utilidad";
            // 
            // txtPro_GasGen
            // 
            this.txtPro_GasGen.Location = new System.Drawing.Point(157, 77);
            this.txtPro_GasGen.Name = "txtPro_GasGen";
            this.txtPro_GasGen.Size = new System.Drawing.Size(54, 21);
            this.txtPro_GasGen.TabIndex = 13;
            this.txtPro_GasGen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_GasGen.TextChanged += new System.EventHandler(this.txtPro_GasGen_TextChanged);
            // 
            // label55
            // 
            this.label55.Location = new System.Drawing.Point(16, 77);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(134, 31);
            this.label55.TabIndex = 12;
            this.label55.Text = "Gastos Generales";
            // 
            // txtPro_CosInd
            // 
            this.txtPro_CosInd.Location = new System.Drawing.Point(157, 49);
            this.txtPro_CosInd.Name = "txtPro_CosInd";
            this.txtPro_CosInd.Size = new System.Drawing.Size(54, 21);
            this.txtPro_CosInd.TabIndex = 11;
            this.txtPro_CosInd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_CosInd.TextChanged += new System.EventHandler(this.txtPro_CosInd_TextChanged);
            // 
            // label56
            // 
            this.label56.Location = new System.Drawing.Point(16, 49);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(134, 31);
            this.label56.TabIndex = 10;
            this.label56.Text = "Costos Indirectos";
            // 
            // txtPro_CosDir
            // 
            this.txtPro_CosDir.Location = new System.Drawing.Point(157, 22);
            this.txtPro_CosDir.Name = "txtPro_CosDir";
            this.txtPro_CosDir.Size = new System.Drawing.Size(54, 21);
            this.txtPro_CosDir.TabIndex = 9;
            this.txtPro_CosDir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_CosDir.TextChanged += new System.EventHandler(this.txtPro_CosDir_TextChanged);
            // 
            // label57
            // 
            this.label57.Location = new System.Drawing.Point(16, 22);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(134, 31);
            this.label57.TabIndex = 8;
            this.label57.Text = "Costo Directo";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtIns_TotConUti);
            this.groupBox7.Controls.Add(this.label46);
            this.groupBox7.Controls.Add(this.txtIns_TotSinUti);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Controls.Add(this.txtIns_Uti);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.txtIns_GasGen);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.txtIns_CosInd);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Controls.Add(this.txtIns_CosDir);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Location = new System.Drawing.Point(496, 30);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(220, 216);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Instalacion";
            // 
            // txtIns_TotConUti
            // 
            this.txtIns_TotConUti.Location = new System.Drawing.Point(157, 175);
            this.txtIns_TotConUti.Name = "txtIns_TotConUti";
            this.txtIns_TotConUti.Size = new System.Drawing.Size(54, 21);
            this.txtIns_TotConUti.TabIndex = 19;
            this.txtIns_TotConUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(16, 175);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(134, 31);
            this.label46.TabIndex = 18;
            this.label46.Text = "Total (Con Utilidad)";
            // 
            // txtIns_TotSinUti
            // 
            this.txtIns_TotSinUti.Location = new System.Drawing.Point(157, 147);
            this.txtIns_TotSinUti.Name = "txtIns_TotSinUti";
            this.txtIns_TotSinUti.Size = new System.Drawing.Size(54, 21);
            this.txtIns_TotSinUti.TabIndex = 17;
            this.txtIns_TotSinUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label47
            // 
            this.label47.Location = new System.Drawing.Point(16, 147);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(134, 31);
            this.label47.TabIndex = 16;
            this.label47.Text = "Total (Sin Utilidad)";
            // 
            // txtIns_Uti
            // 
            this.txtIns_Uti.Location = new System.Drawing.Point(157, 106);
            this.txtIns_Uti.Name = "txtIns_Uti";
            this.txtIns_Uti.Size = new System.Drawing.Size(54, 21);
            this.txtIns_Uti.TabIndex = 15;
            this.txtIns_Uti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_Uti.TextChanged += new System.EventHandler(this.txtIns_Uti_TextChanged);
            // 
            // label48
            // 
            this.label48.Location = new System.Drawing.Point(16, 106);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(134, 31);
            this.label48.TabIndex = 14;
            this.label48.Text = "Utilidad";
            // 
            // txtIns_GasGen
            // 
            this.txtIns_GasGen.Location = new System.Drawing.Point(157, 77);
            this.txtIns_GasGen.Name = "txtIns_GasGen";
            this.txtIns_GasGen.Size = new System.Drawing.Size(54, 21);
            this.txtIns_GasGen.TabIndex = 13;
            this.txtIns_GasGen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_GasGen.TextChanged += new System.EventHandler(this.txtIns_GasGen_TextChanged);
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(16, 77);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(134, 31);
            this.label49.TabIndex = 12;
            this.label49.Text = "Gastos Generales";
            // 
            // txtIns_CosInd
            // 
            this.txtIns_CosInd.Location = new System.Drawing.Point(157, 49);
            this.txtIns_CosInd.Name = "txtIns_CosInd";
            this.txtIns_CosInd.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CosInd.TabIndex = 11;
            this.txtIns_CosInd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CosInd.TextChanged += new System.EventHandler(this.txtIns_CosInd_TextChanged);
            // 
            // label50
            // 
            this.label50.Location = new System.Drawing.Point(16, 49);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(134, 31);
            this.label50.TabIndex = 10;
            this.label50.Text = "Costos Indirectos";
            // 
            // txtIns_CosDir
            // 
            this.txtIns_CosDir.Location = new System.Drawing.Point(157, 22);
            this.txtIns_CosDir.Name = "txtIns_CosDir";
            this.txtIns_CosDir.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CosDir.TabIndex = 9;
            this.txtIns_CosDir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CosDir.TextChanged += new System.EventHandler(this.txtIns_CosDir_TextChanged);
            // 
            // label51
            // 
            this.label51.Location = new System.Drawing.Point(16, 22);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(134, 31);
            this.label51.TabIndex = 8;
            this.label51.Text = "Costo Directo";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtSup_TotConUti);
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.txtSup_TotSinUti);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Controls.Add(this.txtSup_Uti);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.txtSup_GasGen);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.txtSup_CosInd);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Controls.Add(this.txtSup_CosDir);
            this.groupBox6.Controls.Add(this.label45);
            this.groupBox6.Location = new System.Drawing.Point(259, 30);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(220, 216);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Supervision";
            // 
            // txtSup_TotConUti
            // 
            this.txtSup_TotConUti.Location = new System.Drawing.Point(157, 175);
            this.txtSup_TotConUti.Name = "txtSup_TotConUti";
            this.txtSup_TotConUti.Size = new System.Drawing.Size(54, 21);
            this.txtSup_TotConUti.TabIndex = 19;
            this.txtSup_TotConUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label40
            // 
            this.label40.Location = new System.Drawing.Point(16, 175);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(134, 31);
            this.label40.TabIndex = 18;
            this.label40.Text = "Total (Con Utilidad)";
            // 
            // txtSup_TotSinUti
            // 
            this.txtSup_TotSinUti.Location = new System.Drawing.Point(157, 147);
            this.txtSup_TotSinUti.Name = "txtSup_TotSinUti";
            this.txtSup_TotSinUti.Size = new System.Drawing.Size(54, 21);
            this.txtSup_TotSinUti.TabIndex = 17;
            this.txtSup_TotSinUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label41
            // 
            this.label41.Location = new System.Drawing.Point(16, 147);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(134, 31);
            this.label41.TabIndex = 16;
            this.label41.Text = "Total (Sin Utilidad)";
            // 
            // txtSup_Uti
            // 
            this.txtSup_Uti.Location = new System.Drawing.Point(157, 106);
            this.txtSup_Uti.Name = "txtSup_Uti";
            this.txtSup_Uti.Size = new System.Drawing.Size(54, 21);
            this.txtSup_Uti.TabIndex = 15;
            this.txtSup_Uti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_Uti.TextChanged += new System.EventHandler(this.txtSup_Uti_TextChanged);
            // 
            // label42
            // 
            this.label42.Location = new System.Drawing.Point(16, 106);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(134, 31);
            this.label42.TabIndex = 14;
            this.label42.Text = "Utilidad";
            // 
            // txtSup_GasGen
            // 
            this.txtSup_GasGen.Location = new System.Drawing.Point(157, 77);
            this.txtSup_GasGen.Name = "txtSup_GasGen";
            this.txtSup_GasGen.Size = new System.Drawing.Size(54, 21);
            this.txtSup_GasGen.TabIndex = 13;
            this.txtSup_GasGen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_GasGen.TextChanged += new System.EventHandler(this.txtSup_GasGen_TextChanged);
            // 
            // label43
            // 
            this.label43.Location = new System.Drawing.Point(16, 77);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(134, 31);
            this.label43.TabIndex = 12;
            this.label43.Text = "Gastos Generales";
            // 
            // txtSup_CosInd
            // 
            this.txtSup_CosInd.Location = new System.Drawing.Point(157, 49);
            this.txtSup_CosInd.Name = "txtSup_CosInd";
            this.txtSup_CosInd.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CosInd.TabIndex = 11;
            this.txtSup_CosInd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CosInd.TextChanged += new System.EventHandler(this.txtSup_CosInd_TextChanged);
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(16, 49);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(134, 31);
            this.label44.TabIndex = 10;
            this.label44.Text = "Costos Indirectos";
            // 
            // txtSup_CosDir
            // 
            this.txtSup_CosDir.Location = new System.Drawing.Point(157, 22);
            this.txtSup_CosDir.Name = "txtSup_CosDir";
            this.txtSup_CosDir.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CosDir.TabIndex = 9;
            this.txtSup_CosDir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CosDir.TextChanged += new System.EventHandler(this.txtSup_CosDir_TextChanged);
            // 
            // label45
            // 
            this.label45.Location = new System.Drawing.Point(16, 22);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(134, 31);
            this.label45.TabIndex = 8;
            this.label45.Text = "Costo Directo";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtDis_TotConUti);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Controls.Add(this.txtDis_TotSinUti);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.txtDis_Uti);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.txtDis_GasGen);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.txtDis_CosInd);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.txtDis_CosDir);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Location = new System.Drawing.Point(16, 30);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(220, 216);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Diseño";
            // 
            // txtDis_TotConUti
            // 
            this.txtDis_TotConUti.Location = new System.Drawing.Point(157, 175);
            this.txtDis_TotConUti.Name = "txtDis_TotConUti";
            this.txtDis_TotConUti.Size = new System.Drawing.Size(54, 21);
            this.txtDis_TotConUti.TabIndex = 19;
            this.txtDis_TotConUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label39
            // 
            this.label39.Location = new System.Drawing.Point(16, 175);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(134, 31);
            this.label39.TabIndex = 18;
            this.label39.Text = "Total (Con Utilidad)";
            // 
            // txtDis_TotSinUti
            // 
            this.txtDis_TotSinUti.Location = new System.Drawing.Point(157, 147);
            this.txtDis_TotSinUti.Name = "txtDis_TotSinUti";
            this.txtDis_TotSinUti.Size = new System.Drawing.Size(54, 21);
            this.txtDis_TotSinUti.TabIndex = 17;
            this.txtDis_TotSinUti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(16, 147);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(134, 31);
            this.label34.TabIndex = 16;
            this.label34.Text = "Total (Sin Utilidad)";
            // 
            // txtDis_Uti
            // 
            this.txtDis_Uti.Location = new System.Drawing.Point(157, 106);
            this.txtDis_Uti.Name = "txtDis_Uti";
            this.txtDis_Uti.Size = new System.Drawing.Size(54, 21);
            this.txtDis_Uti.TabIndex = 15;
            this.txtDis_Uti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_Uti.TextChanged += new System.EventHandler(this.txtDis_Uti_TextChanged);
            // 
            // label35
            // 
            this.label35.Location = new System.Drawing.Point(16, 106);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(134, 31);
            this.label35.TabIndex = 14;
            this.label35.Text = "Utilidad";
            // 
            // txtDis_GasGen
            // 
            this.txtDis_GasGen.Location = new System.Drawing.Point(157, 77);
            this.txtDis_GasGen.Name = "txtDis_GasGen";
            this.txtDis_GasGen.Size = new System.Drawing.Size(54, 21);
            this.txtDis_GasGen.TabIndex = 13;
            this.txtDis_GasGen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_GasGen.TextChanged += new System.EventHandler(this.txtDis_GasGen_TextChanged);
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(16, 77);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(134, 31);
            this.label36.TabIndex = 12;
            this.label36.Text = "Gastos Generales";
            // 
            // txtDis_CosInd
            // 
            this.txtDis_CosInd.Location = new System.Drawing.Point(157, 49);
            this.txtDis_CosInd.Name = "txtDis_CosInd";
            this.txtDis_CosInd.Size = new System.Drawing.Size(54, 21);
            this.txtDis_CosInd.TabIndex = 11;
            this.txtDis_CosInd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_CosInd.TextChanged += new System.EventHandler(this.txtDis_CosInd_TextChanged);
            // 
            // label37
            // 
            this.label37.Location = new System.Drawing.Point(16, 49);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(134, 31);
            this.label37.TabIndex = 10;
            this.label37.Text = "Costos Indirectos";
            // 
            // txtDis_CosDir
            // 
            this.txtDis_CosDir.Location = new System.Drawing.Point(157, 22);
            this.txtDis_CosDir.Name = "txtDis_CosDir";
            this.txtDis_CosDir.Size = new System.Drawing.Size(54, 21);
            this.txtDis_CosDir.TabIndex = 9;
            this.txtDis_CosDir.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_CosDir.TextChanged += new System.EventHandler(this.txtDis_CosDir_TextChanged);
            // 
            // label38
            // 
            this.label38.Location = new System.Drawing.Point(16, 22);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(134, 31);
            this.label38.TabIndex = 8;
            this.label38.Text = "Costo Directo";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(22, 11);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(150, 13);
            this.label58.TabIndex = 6;
            this.label58.Text = "ALCANCES DEL PROYECTO:";
            // 
            // gbDetConSer
            // 
            this.gbDetConSer.Controls.Add(this.groupBox4);
            this.gbDetConSer.Controls.Add(this.groupBox3);
            this.gbDetConSer.Controls.Add(this.groupBox2);
            this.gbDetConSer.Controls.Add(this.groupBox1);
            this.gbDetConSer.Location = new System.Drawing.Point(15, 140);
            this.gbDetConSer.Name = "gbDetConSer";
            this.gbDetConSer.Size = new System.Drawing.Size(994, 319);
            this.gbDetConSer.TabIndex = 0;
            this.gbDetConSer.TabStop = false;
            this.gbDetConSer.Text = "Detalle de condiciones de servicios";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtPro_CosPro_Sol);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.txtPro_CanPanConLic_Und);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.txtPro_CanModRepAmp_Und);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.txtPro_CanBotSenDri_Und);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.txtPro_DurEst_Dia);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Location = new System.Drawing.Point(736, 22);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(252, 212);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Programación";
            // 
            // txtPro_CosPro_Sol
            // 
            this.txtPro_CosPro_Sol.Location = new System.Drawing.Point(185, 173);
            this.txtPro_CosPro_Sol.Name = "txtPro_CosPro_Sol";
            this.txtPro_CosPro_Sol.Size = new System.Drawing.Size(54, 21);
            this.txtPro_CosPro_Sol.TabIndex = 17;
            this.txtPro_CosPro_Sol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_CosPro_Sol.TextChanged += new System.EventHandler(this.txtPro_CosPro_Sol_TextChanged);
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(16, 173);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(149, 31);
            this.label25.TabIndex = 16;
            this.label25.Text = "Costo de Programación (SOLES)";
            // 
            // txtPro_CanPanConLic_Und
            // 
            this.txtPro_CanPanConLic_Und.Location = new System.Drawing.Point(185, 139);
            this.txtPro_CanPanConLic_Und.Name = "txtPro_CanPanConLic_Und";
            this.txtPro_CanPanConLic_Und.Size = new System.Drawing.Size(54, 21);
            this.txtPro_CanPanConLic_Und.TabIndex = 15;
            this.txtPro_CanPanConLic_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_CanPanConLic_Und.TextChanged += new System.EventHandler(this.txtPro_CanPanConLic_Und_TextChanged);
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(16, 139);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(149, 31);
            this.label26.TabIndex = 14;
            this.label26.Text = "Cantidad de pantallas y/o control y/o Licencia (uni.)";
            // 
            // txtPro_CanModRepAmp_Und
            // 
            this.txtPro_CanModRepAmp_Und.Location = new System.Drawing.Point(185, 92);
            this.txtPro_CanModRepAmp_Und.Name = "txtPro_CanModRepAmp_Und";
            this.txtPro_CanModRepAmp_Und.Size = new System.Drawing.Size(54, 21);
            this.txtPro_CanModRepAmp_Und.TabIndex = 13;
            this.txtPro_CanModRepAmp_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_CanModRepAmp_Und.TextChanged += new System.EventHandler(this.txtPro_CanModRepAmp_Und_TextChanged);
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(16, 92);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(149, 44);
            this.label27.TabIndex = 12;
            this.label27.Text = "Cantidad de módulos y/o repetidor y/o amplif. y/o fuente y/o cortina (uni.)";
            // 
            // txtPro_CanBotSenDri_Und
            // 
            this.txtPro_CanBotSenDri_Und.Location = new System.Drawing.Point(185, 56);
            this.txtPro_CanBotSenDri_Und.Name = "txtPro_CanBotSenDri_Und";
            this.txtPro_CanBotSenDri_Und.Size = new System.Drawing.Size(54, 21);
            this.txtPro_CanBotSenDri_Und.TabIndex = 11;
            this.txtPro_CanBotSenDri_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_CanBotSenDri_Und.TextChanged += new System.EventHandler(this.txtPro_CanBotSenDri_Und_TextChanged);
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(16, 56);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(149, 31);
            this.label28.TabIndex = 10;
            this.label28.Text = "Cantidad de botoneras y/o sensores y/o drivers (uni.)";
            // 
            // txtPro_DurEst_Dia
            // 
            this.txtPro_DurEst_Dia.Location = new System.Drawing.Point(185, 22);
            this.txtPro_DurEst_Dia.Name = "txtPro_DurEst_Dia";
            this.txtPro_DurEst_Dia.Size = new System.Drawing.Size(54, 21);
            this.txtPro_DurEst_Dia.TabIndex = 9;
            this.txtPro_DurEst_Dia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPro_DurEst_Dia.TextChanged += new System.EventHandler(this.txtPro_DurEst_Dia_TextChanged);
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(16, 22);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(149, 31);
            this.label29.TabIndex = 8;
            this.label29.Text = "Duración estimada de programación (dias)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtIns_CosMat_Sol);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.txtIns_CosTraNoc_Sol);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.txtIns_CanPruLuc_Und);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.txtIns_CanViaMov_Und);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txtIns_CanVisCoo_Und);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.txtIns_CanTecDia_Und);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.txtIns_DurEst_Dia);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Location = new System.Drawing.Point(497, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(220, 283);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Instalación";
            // 
            // txtIns_CosMat_Sol
            // 
            this.txtIns_CosMat_Sol.Location = new System.Drawing.Point(157, 224);
            this.txtIns_CosMat_Sol.Name = "txtIns_CosMat_Sol";
            this.txtIns_CosMat_Sol.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CosMat_Sol.TabIndex = 21;
            this.txtIns_CosMat_Sol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CosMat_Sol.TextChanged += new System.EventHandler(this.txtIns_CosMat_Sol_TextChanged);
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(16, 224);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(134, 31);
            this.label32.TabIndex = 20;
            this.label32.Text = "Costo de Materiales (SOLES)";
            // 
            // txtIns_CosTraNoc_Sol
            // 
            this.txtIns_CosTraNoc_Sol.Location = new System.Drawing.Point(157, 191);
            this.txtIns_CosTraNoc_Sol.Name = "txtIns_CosTraNoc_Sol";
            this.txtIns_CosTraNoc_Sol.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CosTraNoc_Sol.TabIndex = 19;
            this.txtIns_CosTraNoc_Sol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CosTraNoc_Sol.TextChanged += new System.EventHandler(this.txtIns_CosTraNoc_Sol_TextChanged);
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(16, 191);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(134, 31);
            this.label33.TabIndex = 18;
            this.label33.Text = "Costo de Trabajo Nocturno (SOLES)";
            // 
            // txtIns_CanPruLuc_Und
            // 
            this.txtIns_CanPruLuc_Und.Location = new System.Drawing.Point(157, 158);
            this.txtIns_CanPruLuc_Und.Name = "txtIns_CanPruLuc_Und";
            this.txtIns_CanPruLuc_Und.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CanPruLuc_Und.TabIndex = 17;
            this.txtIns_CanPruLuc_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CanPruLuc_Und.TextChanged += new System.EventHandler(this.txtIns_CanPruLuc_Und_TextChanged);
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(16, 158);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(134, 31);
            this.label20.TabIndex = 16;
            this.label20.Text = "Cantidad de PRUEBAS DE LUCES (uni.)";
            // 
            // txtIns_CanViaMov_Und
            // 
            this.txtIns_CanViaMov_Und.Location = new System.Drawing.Point(157, 125);
            this.txtIns_CanViaMov_Und.Name = "txtIns_CanViaMov_Und";
            this.txtIns_CanViaMov_Und.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CanViaMov_Und.TabIndex = 15;
            this.txtIns_CanViaMov_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CanViaMov_Und.TextChanged += new System.EventHandler(this.txtIns_CanViaMov_Und_TextChanged);
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(16, 125);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(134, 31);
            this.label21.TabIndex = 14;
            this.label21.Text = "Cantidad de Viajes de movilidad (viajes)";
            // 
            // txtIns_CanVisCoo_Und
            // 
            this.txtIns_CanVisCoo_Und.Location = new System.Drawing.Point(157, 91);
            this.txtIns_CanVisCoo_Und.Name = "txtIns_CanVisCoo_Und";
            this.txtIns_CanVisCoo_Und.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CanVisCoo_Und.TabIndex = 13;
            this.txtIns_CanVisCoo_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CanVisCoo_Und.TextChanged += new System.EventHandler(this.txtIns_CanVisCoo_Und_TextChanged);
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(16, 91);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(134, 31);
            this.label22.TabIndex = 12;
            this.label22.Text = "Cantidad de Visitas de Coordinador (visitas)";
            // 
            // txtIns_CanTecDia_Und
            // 
            this.txtIns_CanTecDia_Und.Location = new System.Drawing.Point(157, 56);
            this.txtIns_CanTecDia_Und.Name = "txtIns_CanTecDia_Und";
            this.txtIns_CanTecDia_Und.Size = new System.Drawing.Size(54, 21);
            this.txtIns_CanTecDia_Und.TabIndex = 11;
            this.txtIns_CanTecDia_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_CanTecDia_Und.TextChanged += new System.EventHandler(this.txtIns_CanTecDia_Und_TextChanged);
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(16, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(134, 31);
            this.label23.TabIndex = 10;
            this.label23.Text = "Cantidad de Tecnicos por Dia (uni.)";
            // 
            // txtIns_DurEst_Dia
            // 
            this.txtIns_DurEst_Dia.Location = new System.Drawing.Point(157, 22);
            this.txtIns_DurEst_Dia.Name = "txtIns_DurEst_Dia";
            this.txtIns_DurEst_Dia.Size = new System.Drawing.Size(54, 21);
            this.txtIns_DurEst_Dia.TabIndex = 9;
            this.txtIns_DurEst_Dia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIns_DurEst_Dia.TextChanged += new System.EventHandler(this.txtIns_DurEst_Dia_TextChanged);
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(16, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(134, 31);
            this.label24.TabIndex = 8;
            this.label24.Text = "Duración estimada de instalación (dias)";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSup_CanPrueMeg_Und);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txtSup_CanPruMueDobAlt_Und);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.txtSup_CanPruMue_Und);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtSup_CanVisSup_Und);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtSup_TraOfiOpe_Hor);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtSup_CanVisIngOpe_Und);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtSup_DurEst_Mes);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Location = new System.Drawing.Point(260, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(220, 283);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Supervisión";
            // 
            // txtSup_CanPrueMeg_Und
            // 
            this.txtSup_CanPrueMeg_Und.Location = new System.Drawing.Point(157, 236);
            this.txtSup_CanPrueMeg_Und.Name = "txtSup_CanPrueMeg_Und";
            this.txtSup_CanPrueMeg_Und.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CanPrueMeg_Und.TabIndex = 21;
            this.txtSup_CanPrueMeg_Und.Text = " ";
            this.txtSup_CanPrueMeg_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CanPrueMeg_Und.TextChanged += new System.EventHandler(this.txtSup_CanPrueMeg_Und_TextChanged);
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(16, 236);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(134, 31);
            this.label30.TabIndex = 20;
            this.label30.Text = "Cantidad de PRUEBAS DE MEGADO (uni.)";
            // 
            // txtSup_CanPruMueDobAlt_Und
            // 
            this.txtSup_CanPruMueDobAlt_Und.Location = new System.Drawing.Point(157, 191);
            this.txtSup_CanPruMueDobAlt_Und.Name = "txtSup_CanPruMueDobAlt_Und";
            this.txtSup_CanPruMueDobAlt_Und.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CanPruMueDobAlt_Und.TabIndex = 19;
            this.txtSup_CanPruMueDobAlt_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CanPruMueDobAlt_Und.TextChanged += new System.EventHandler(this.txtSup_CanPruMueDobAlt_Und_TextChanged);
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(16, 191);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(133, 41);
            this.label31.TabIndex = 18;
            this.label31.Text = "Cantidad de PRUEBAS DE MUESTRAS - Doble altura (uni.)";
            // 
            // txtSup_CanPruMue_Und
            // 
            this.txtSup_CanPruMue_Und.Location = new System.Drawing.Point(157, 158);
            this.txtSup_CanPruMue_Und.Name = "txtSup_CanPruMue_Und";
            this.txtSup_CanPruMue_Und.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CanPruMue_Und.TabIndex = 17;
            this.txtSup_CanPruMue_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CanPruMue_Und.TextChanged += new System.EventHandler(this.txtSup_CanPruMue_Und_TextChanged);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(16, 158);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(134, 31);
            this.label15.TabIndex = 16;
            this.label15.Text = "Cantidad de PRUEBAS DE MUESTRAS (uni.)";
            // 
            // txtSup_CanVisSup_Und
            // 
            this.txtSup_CanVisSup_Und.Location = new System.Drawing.Point(157, 125);
            this.txtSup_CanVisSup_Und.Name = "txtSup_CanVisSup_Und";
            this.txtSup_CanVisSup_Und.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CanVisSup_Und.TabIndex = 15;
            this.txtSup_CanVisSup_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CanVisSup_Und.TextChanged += new System.EventHandler(this.txtSup_CanVisSup_Und_TextChanged);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(16, 125);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(134, 31);
            this.label16.TabIndex = 14;
            this.label16.Text = "Cantidad de Visitas del SUPERVISOR (visitas)";
            // 
            // txtSup_TraOfiOpe_Hor
            // 
            this.txtSup_TraOfiOpe_Hor.Location = new System.Drawing.Point(157, 91);
            this.txtSup_TraOfiOpe_Hor.Name = "txtSup_TraOfiOpe_Hor";
            this.txtSup_TraOfiOpe_Hor.Size = new System.Drawing.Size(54, 21);
            this.txtSup_TraOfiOpe_Hor.TabIndex = 13;
            this.txtSup_TraOfiOpe_Hor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_TraOfiOpe_Hor.TextChanged += new System.EventHandler(this.txtSup_TraOfiOpe_Hor_TextChanged);
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(16, 91);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(134, 31);
            this.label17.TabIndex = 12;
            this.label17.Text = "Trabajo en Oficina para OPERACIONES (horas)";
            // 
            // txtSup_CanVisIngOpe_Und
            // 
            this.txtSup_CanVisIngOpe_Und.Location = new System.Drawing.Point(157, 56);
            this.txtSup_CanVisIngOpe_Und.Name = "txtSup_CanVisIngOpe_Und";
            this.txtSup_CanVisIngOpe_Und.Size = new System.Drawing.Size(54, 21);
            this.txtSup_CanVisIngOpe_Und.TabIndex = 11;
            this.txtSup_CanVisIngOpe_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_CanVisIngOpe_Und.TextChanged += new System.EventHandler(this.txtSup_CanVisIngOpe_Und_TextChanged);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(16, 56);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(139, 31);
            this.label18.TabIndex = 10;
            this.label18.Text = "Cantidad de Visitas de ING. OPERACIONES (visitas)";
            // 
            // txtSup_DurEst_Mes
            // 
            this.txtSup_DurEst_Mes.Location = new System.Drawing.Point(157, 22);
            this.txtSup_DurEst_Mes.Name = "txtSup_DurEst_Mes";
            this.txtSup_DurEst_Mes.Size = new System.Drawing.Size(54, 21);
            this.txtSup_DurEst_Mes.TabIndex = 9;
            this.txtSup_DurEst_Mes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSup_DurEst_Mes.TextChanged += new System.EventHandler(this.txtSup_DurEst_Mes_TextChanged);
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(16, 22);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(134, 31);
            this.label19.TabIndex = 8;
            this.label19.Text = "Duración estimada del proyecto (meses)";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDis_DurEst_Mes);
            this.groupBox1.Controls.Add(this.txtDis_TraDia_Hor);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtDis_TraPla_Hor);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtDis_TraOfi_Hor);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtDis_CanVis_Und);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(17, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(220, 209);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Diseño";
            // 
            // txtDis_DurEst_Mes
            // 
            this.txtDis_DurEst_Mes.BackColor = System.Drawing.SystemColors.Window;
            this.txtDis_DurEst_Mes.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDis_DurEst_Mes.Location = new System.Drawing.Point(157, 22);
            this.txtDis_DurEst_Mes.Name = "txtDis_DurEst_Mes";
            this.txtDis_DurEst_Mes.Size = new System.Drawing.Size(54, 21);
            this.txtDis_DurEst_Mes.TabIndex = 47;
            this.txtDis_DurEst_Mes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_DurEst_Mes.TextChanged += new System.EventHandler(this.txtDis_DurEst_Mes_TextChanged);
            // 
            // txtDis_TraDia_Hor
            // 
            this.txtDis_TraDia_Hor.Location = new System.Drawing.Point(157, 158);
            this.txtDis_TraDia_Hor.Name = "txtDis_TraDia_Hor";
            this.txtDis_TraDia_Hor.Size = new System.Drawing.Size(54, 21);
            this.txtDis_TraDia_Hor.TabIndex = 17;
            this.txtDis_TraDia_Hor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_TraDia_Hor.TextChanged += new System.EventHandler(this.txtDis_TraDia_Hor_TextChanged);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(16, 158);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 31);
            this.label14.TabIndex = 16;
            this.label14.Text = "Trabajo en DIALUX (horas)";
            // 
            // txtDis_TraPla_Hor
            // 
            this.txtDis_TraPla_Hor.Location = new System.Drawing.Point(157, 125);
            this.txtDis_TraPla_Hor.Name = "txtDis_TraPla_Hor";
            this.txtDis_TraPla_Hor.Size = new System.Drawing.Size(54, 21);
            this.txtDis_TraPla_Hor.TabIndex = 15;
            this.txtDis_TraPla_Hor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_TraPla_Hor.TextChanged += new System.EventHandler(this.txtDis_TraPla_Hor_TextChanged);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(16, 125);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(134, 31);
            this.label13.TabIndex = 14;
            this.label13.Text = "Trabajo en Planos de obra y detalles (horas)";
            // 
            // txtDis_TraOfi_Hor
            // 
            this.txtDis_TraOfi_Hor.Location = new System.Drawing.Point(157, 91);
            this.txtDis_TraOfi_Hor.Name = "txtDis_TraOfi_Hor";
            this.txtDis_TraOfi_Hor.Size = new System.Drawing.Size(54, 21);
            this.txtDis_TraOfi_Hor.TabIndex = 13;
            this.txtDis_TraOfi_Hor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_TraOfi_Hor.TextChanged += new System.EventHandler(this.txtDis_TraOfi_Hor_TextChanged);
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(16, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(134, 31);
            this.label12.TabIndex = 12;
            this.label12.Text = "Trabajo en Oficina para DISEÑO (horas)";
            // 
            // txtDis_CanVis_Und
            // 
            this.txtDis_CanVis_Und.Location = new System.Drawing.Point(157, 56);
            this.txtDis_CanVis_Und.Name = "txtDis_CanVis_Und";
            this.txtDis_CanVis_Und.Size = new System.Drawing.Size(54, 21);
            this.txtDis_CanVis_Und.TabIndex = 11;
            this.txtDis_CanVis_Und.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDis_CanVis_Und.TextChanged += new System.EventHandler(this.txtDis_CanVis_Und_TextChanged);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(16, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 31);
            this.label11.TabIndex = 10;
            this.label11.Text = "Cantidad de Visitas de DISEÑO (visitas)";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(16, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 31);
            this.label10.TabIndex = 8;
            this.label10.Text = "Duración estimada del proyecto (meses)";
            // 
            // txtAlcPro
            // 
            this.txtAlcPro.Location = new System.Drawing.Point(16, 33);
            this.txtAlcPro.Multiline = true;
            this.txtAlcPro.Name = "txtAlcPro";
            this.txtAlcPro.Size = new System.Drawing.Size(993, 60);
            this.txtAlcPro.TabIndex = 5;
            // 
            // lblRQ
            // 
            this.lblRQ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRQ.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRQ.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblRQ.Location = new System.Drawing.Point(19, 110);
            this.lblRQ.Name = "lblRQ";
            this.lblRQ.Size = new System.Drawing.Size(147, 24);
            this.lblRQ.TabIndex = 1;
            this.lblRQ.Text = "RQ PAQUETE";
            // 
            // btnPaq
            // 
            this.btnPaq.Location = new System.Drawing.Point(190, 112);
            this.btnPaq.Name = "btnPaq";
            this.btnPaq.Size = new System.Drawing.Size(112, 22);
            this.btnPaq.TabIndex = 2;
            this.btnPaq.Text = "Retornar Paquete";
            this.btnPaq.UseVisualStyleBackColor = true;
            this.btnPaq.Click += new System.EventHandler(this.btnPaq_Click);
            // 
            // btnLimPaq
            // 
            this.btnLimPaq.Location = new System.Drawing.Point(308, 112);
            this.btnLimPaq.Name = "btnLimPaq";
            this.btnLimPaq.Size = new System.Drawing.Size(112, 22);
            this.btnLimPaq.TabIndex = 3;
            this.btnLimPaq.Text = "Limpiar Paquete";
            this.btnLimPaq.UseVisualStyleBackColor = true;
            this.btnLimPaq.Click += new System.EventHandler(this.btnLimPaq_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pnlRegVis);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1083, 419);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "b. Registro de Visitas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlRegVis
            // 
            this.pnlRegVis.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRegVis.AutoScroll = true;
            this.pnlRegVis.Controls.Add(this.dgvRegVis);
            this.pnlRegVis.Location = new System.Drawing.Point(9, 6);
            this.pnlRegVis.Name = "pnlRegVis";
            this.pnlRegVis.Size = new System.Drawing.Size(1074, 400);
            this.pnlRegVis.TabIndex = 47;
            // 
            // dgvRegVis
            // 
            this.dgvRegVis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRegVis.Location = new System.Drawing.Point(7, 8);
            this.dgvRegVis.Name = "dgvRegVis";
            this.dgvRegVis.RowHeadersVisible = false;
            this.dgvRegVis.Size = new System.Drawing.Size(1017, 629);
            this.dgvRegVis.TabIndex = 0;
            this.dgvRegVis.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvRegVis_EditingControlShowing);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1083, 419);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "c. Informes de Supervisión";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.pnlIntPro);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1083, 419);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "d. Interesados del Proyecto";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // pnlIntPro
            // 
            this.pnlIntPro.AllowDrop = true;
            this.pnlIntPro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlIntPro.AutoScroll = true;
            this.pnlIntPro.Controls.Add(this.fgIntPro);
            this.pnlIntPro.Controls.Add(this.btnCanInt);
            this.pnlIntPro.Controls.Add(this.txtCargo);
            this.pnlIntPro.Controls.Add(this.label63);
            this.pnlIntPro.Controls.Add(this.label59);
            this.pnlIntPro.Controls.Add(this.txtCel1);
            this.pnlIntPro.Controls.Add(this.btnAgrInt);
            this.pnlIntPro.Controls.Add(this.txtNomInt);
            this.pnlIntPro.Controls.Add(this.label62);
            this.pnlIntPro.Controls.Add(this.label60);
            this.pnlIntPro.Controls.Add(this.txtCel2);
            this.pnlIntPro.Controls.Add(this.txtCodCar);
            this.pnlIntPro.Controls.Add(this.txtEmail);
            this.pnlIntPro.Controls.Add(this.label61);
            this.pnlIntPro.Location = new System.Drawing.Point(3, 13);
            this.pnlIntPro.Name = "pnlIntPro";
            this.pnlIntPro.Size = new System.Drawing.Size(1080, 390);
            this.pnlIntPro.TabIndex = 48;
            // 
            // fgIntPro
            // 
            this.fgIntPro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgIntPro.ColumnInfo = "9,0,0,0,0,95,Columns:";
            this.fgIntPro.Location = new System.Drawing.Point(41, 78);
            this.fgIntPro.Name = "fgIntPro";
            this.fgIntPro.Rows.Count = 1;
            this.fgIntPro.Rows.DefaultSize = 19;
            this.fgIntPro.Size = new System.Drawing.Size(1014, 291);
            this.fgIntPro.TabIndex = 45;
            this.fgIntPro.BeforeEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgIntPro_BeforeEdit);
            this.fgIntPro.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgIntPro_AfterEdit);
            this.fgIntPro.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgIntPro_KeyDown);
            // 
            // btnCanInt
            // 
            this.btnCanInt.Location = new System.Drawing.Point(143, 48);
            this.btnCanInt.Name = "btnCanInt";
            this.btnCanInt.Size = new System.Drawing.Size(95, 23);
            this.btnCanInt.TabIndex = 44;
            this.btnCanInt.Text = "Cancelar";
            this.btnCanInt.UseVisualStyleBackColor = true;
            this.btnCanInt.Click += new System.EventHandler(this.btnCanInt_Click);
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(126, 15);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(144, 21);
            this.txtCargo.TabIndex = 33;
            this.txtCargo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCargo_KeyPress);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(852, 18);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 13);
            this.label63.TabIndex = 42;
            this.label63.Text = "Email:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(45, 18);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(40, 13);
            this.label59.TabIndex = 34;
            this.label59.Text = "Cargo:";
            // 
            // txtCel1
            // 
            this.txtCel1.Location = new System.Drawing.Point(570, 15);
            this.txtCel1.Name = "txtCel1";
            this.txtCel1.Size = new System.Drawing.Size(99, 21);
            this.txtCel1.TabIndex = 37;
            this.txtCel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCel1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCel1_KeyPress);
            // 
            // btnAgrInt
            // 
            this.btnAgrInt.Location = new System.Drawing.Point(42, 48);
            this.btnAgrInt.Name = "btnAgrInt";
            this.btnAgrInt.Size = new System.Drawing.Size(95, 23);
            this.btnAgrInt.TabIndex = 43;
            this.btnAgrInt.Text = "Agregar";
            this.btnAgrInt.UseVisualStyleBackColor = true;
            this.btnAgrInt.Click += new System.EventHandler(this.btnAgrInt_Click);
            // 
            // txtNomInt
            // 
            this.txtNomInt.Location = new System.Drawing.Point(319, 15);
            this.txtNomInt.Name = "txtNomInt";
            this.txtNomInt.Size = new System.Drawing.Size(190, 21);
            this.txtNomInt.TabIndex = 35;
            this.txtNomInt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomInt_KeyPress);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(678, 18);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(53, 13);
            this.label62.TabIndex = 40;
            this.label62.Text = "Celular 2:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(271, 18);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(48, 13);
            this.label60.TabIndex = 36;
            this.label60.Text = "Nombre:";
            // 
            // txtCel2
            // 
            this.txtCel2.Location = new System.Drawing.Point(731, 15);
            this.txtCel2.Name = "txtCel2";
            this.txtCel2.Size = new System.Drawing.Size(99, 21);
            this.txtCel2.TabIndex = 39;
            this.txtCel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCel2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCel2_KeyPress);
            // 
            // txtCodCar
            // 
            this.txtCodCar.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodCar.Location = new System.Drawing.Point(90, 15);
            this.txtCodCar.Name = "txtCodCar";
            this.txtCodCar.ReadOnly = true;
            this.txtCodCar.Size = new System.Drawing.Size(37, 21);
            this.txtCodCar.TabIndex = 32;
            this.txtCodCar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(888, 15);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(118, 21);
            this.txtEmail.TabIndex = 41;
            this.txtEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmail_KeyPress);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(516, 18);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(53, 13);
            this.label61.TabIndex = 38;
            this.label61.Text = "Celular 1:";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.pnlRegOti);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1083, 419);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "e. Registro del OTI";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // pnlRegOti
            // 
            this.pnlRegOti.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRegOti.AutoScroll = true;
            this.pnlRegOti.Controls.Add(this.dgvRegOTI);
            this.pnlRegOti.Location = new System.Drawing.Point(5, 12);
            this.pnlRegOti.Name = "pnlRegOti";
            this.pnlRegOti.Size = new System.Drawing.Size(1075, 389);
            this.pnlRegOti.TabIndex = 49;
            // 
            // dgvRegOTI
            // 
            this.dgvRegOTI.AllowUserToAddRows = false;
            this.dgvRegOTI.AllowUserToDeleteRows = false;
            this.dgvRegOTI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRegOTI.Location = new System.Drawing.Point(13, 15);
            this.dgvRegOTI.Name = "dgvRegOTI";
            this.dgvRegOTI.RowHeadersVisible = false;
            this.dgvRegOTI.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRegOTI.Size = new System.Drawing.Size(1020, 567);
            this.dgvRegOTI.TabIndex = 0;
            this.dgvRegOTI.DataSourceChanged += new System.EventHandler(this.dgvRegOTI_DataSourceChanged);
            this.dgvRegOTI.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvRegOTI_EditingControlShowing);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.pnlRegRut);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1083, 419);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "f. Registro de rutas";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // pnlRegRut
            // 
            this.pnlRegRut.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRegRut.AutoScroll = true;
            this.pnlRegRut.Controls.Add(this.dgvRegRuta);
            this.pnlRegRut.Location = new System.Drawing.Point(9, 8);
            this.pnlRegRut.Name = "pnlRegRut";
            this.pnlRegRut.Size = new System.Drawing.Size(1066, 404);
            this.pnlRegRut.TabIndex = 50;
            // 
            // dgvRegRuta
            // 
            this.dgvRegRuta.AllowUserToAddRows = false;
            this.dgvRegRuta.AllowUserToDeleteRows = false;
            this.dgvRegRuta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRegRuta.Location = new System.Drawing.Point(7, 12);
            this.dgvRegRuta.Name = "dgvRegRuta";
            this.dgvRegRuta.RowHeadersVisible = false;
            this.dgvRegRuta.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRegRuta.Size = new System.Drawing.Size(1019, 481);
            this.dgvRegRuta.TabIndex = 1;
            // 
            // tabPage7
            // 
            this.tabPage7.AutoScroll = true;
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(1083, 419);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "g. Indicadores del Proyecto";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // pnEnc
            // 
            this.pnEnc.Controls.Add(this.gbFecAprIns);
            this.pnEnc.Controls.Add(this.mtxtFecFin);
            this.pnEnc.Controls.Add(this.txtCodEstObr);
            this.pnEnc.Controls.Add(this.mtxtFecCab);
            this.pnEnc.Controls.Add(this.mtxtFecIni);
            this.pnEnc.Controls.Add(this.lblFecfin);
            this.pnEnc.Controls.Add(this.label7);
            this.pnEnc.Controls.Add(this.label8);
            this.pnEnc.Controls.Add(this.label9);
            this.pnEnc.Controls.Add(this.txtNumMov);
            this.pnEnc.Controls.Add(this.txtNom);
            this.pnEnc.Controls.Add(this.txtDir);
            this.pnEnc.Controls.Add(this.txtDis);
            this.pnEnc.Controls.Add(this.txtFecIng);
            this.pnEnc.Controls.Add(this.label5);
            this.pnEnc.Controls.Add(this.label4);
            this.pnEnc.Controls.Add(this.label3);
            this.pnEnc.Controls.Add(this.label2);
            this.pnEnc.Controls.Add(this.label1);
            this.pnEnc.Controls.Add(this.txtEstObr);
            this.pnEnc.Location = new System.Drawing.Point(21, 54);
            this.pnEnc.Name = "pnEnc";
            this.pnEnc.Size = new System.Drawing.Size(1248, 109);
            this.pnEnc.TabIndex = 45;
            // 
            // gbFecAprIns
            // 
            this.gbFecAprIns.Controls.Add(this.fgFecAprIns);
            this.gbFecAprIns.Location = new System.Drawing.Point(869, 0);
            this.gbFecAprIns.Name = "gbFecAprIns";
            this.gbFecAprIns.Size = new System.Drawing.Size(347, 102);
            this.gbFecAprIns.TabIndex = 60;
            this.gbFecAprIns.TabStop = false;
            this.gbFecAprIns.Text = "Fechas Aprox. de Instalación";
            // 
            // fgFecAprIns
            // 
            this.fgFecAprIns.ColumnInfo = "1,0,0,0,0,95,Columns:";
            this.fgFecAprIns.Location = new System.Drawing.Point(8, 17);
            this.fgFecAprIns.Name = "fgFecAprIns";
            this.fgFecAprIns.Rows.Count = 1;
            this.fgFecAprIns.Rows.DefaultSize = 19;
            this.fgFecAprIns.Size = new System.Drawing.Size(332, 80);
            this.fgFecAprIns.TabIndex = 0;
            this.fgFecAprIns.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgFecAprIns_StartEdit);
            this.fgFecAprIns.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgFecAprIns_AfterEdit);
            this.fgFecAprIns.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgFecAprIns_AfterDataRefresh);
            // 
            // mtxtFecFin
            // 
            this.mtxtFecFin.Location = new System.Drawing.Point(698, 32);
            this.mtxtFecFin.Name = "mtxtFecFin";
            this.mtxtFecFin.Size = new System.Drawing.Size(163, 21);
            this.mtxtFecFin.TabIndex = 59;
            this.mtxtFecFin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtxtFecFin.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.mtxtFecFin.Visible = false;
            // 
            // txtCodEstObr
            // 
            this.txtCodEstObr.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodEstObr.Location = new System.Drawing.Point(698, 8);
            this.txtCodEstObr.Name = "txtCodEstObr";
            this.txtCodEstObr.ReadOnly = true;
            this.txtCodEstObr.Size = new System.Drawing.Size(37, 21);
            this.txtCodEstObr.TabIndex = 58;
            this.txtCodEstObr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodEstObr.TextChanged += new System.EventHandler(this.txtCodEstObr_TextChanged);
            // 
            // mtxtFecCab
            // 
            this.mtxtFecCab.Location = new System.Drawing.Point(697, 80);
            this.mtxtFecCab.Name = "mtxtFecCab";
            this.mtxtFecCab.Size = new System.Drawing.Size(163, 21);
            this.mtxtFecCab.TabIndex = 57;
            this.mtxtFecCab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtxtFecCab.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // mtxtFecIni
            // 
            this.mtxtFecIni.Location = new System.Drawing.Point(698, 56);
            this.mtxtFecIni.Name = "mtxtFecIni";
            this.mtxtFecIni.Size = new System.Drawing.Size(163, 21);
            this.mtxtFecIni.TabIndex = 56;
            this.mtxtFecIni.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtxtFecIni.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // lblFecfin
            // 
            this.lblFecfin.AutoSize = true;
            this.lblFecfin.Location = new System.Drawing.Point(603, 35);
            this.lblFecfin.Name = "lblFecfin";
            this.lblFecfin.Size = new System.Drawing.Size(97, 13);
            this.lblFecfin.TabIndex = 54;
            this.lblFecfin.Text = "Fecha Finalización:";
            this.lblFecfin.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(598, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 13);
            this.label7.TabIndex = 53;
            this.label7.Text = "Fecha de cableado:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(510, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(191, 13);
            this.label8.TabIndex = 52;
            this.label8.Text = "Fecha de carcasas/tableros/muestras:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(614, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 13);
            this.label9.TabIndex = 51;
            this.label9.Text = "Estado de Obra:";
            // 
            // txtNumMov
            // 
            this.txtNumMov.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumMov.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtNumMov.Location = new System.Drawing.Point(118, 8);
            this.txtNumMov.Name = "txtNumMov";
            this.txtNumMov.Size = new System.Drawing.Size(100, 21);
            this.txtNumMov.TabIndex = 50;
            this.txtNumMov.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNom
            // 
            this.txtNom.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNom.Location = new System.Drawing.Point(118, 32);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(391, 21);
            this.txtNom.TabIndex = 49;
            // 
            // txtDir
            // 
            this.txtDir.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDir.Location = new System.Drawing.Point(118, 56);
            this.txtDir.Name = "txtDir";
            this.txtDir.Size = new System.Drawing.Size(391, 21);
            this.txtDir.TabIndex = 48;
            // 
            // txtDis
            // 
            this.txtDis.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDis.Location = new System.Drawing.Point(118, 80);
            this.txtDis.Name = "txtDis";
            this.txtDis.Size = new System.Drawing.Size(391, 21);
            this.txtDis.TabIndex = 47;
            // 
            // txtFecIng
            // 
            this.txtFecIng.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtFecIng.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtFecIng.Location = new System.Drawing.Point(409, 8);
            this.txtFecIng.Name = "txtFecIng";
            this.txtFecIng.Size = new System.Drawing.Size(100, 21);
            this.txtFecIng.TabIndex = 46;
            this.txtFecIng.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(314, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 45;
            this.label5.Text = "Fecha de Ingreso:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 44;
            this.label4.Text = "Distrito:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 43;
            this.label3.Text = "Dirección:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Nombre del Proyecto:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 41;
            this.label1.Text = "N° Proyecto:";
            // 
            // txtEstObr
            // 
            this.txtEstObr.BackColor = System.Drawing.SystemColors.Window;
            this.txtEstObr.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtEstObr.Location = new System.Drawing.Point(734, 8);
            this.txtEstObr.Name = "txtEstObr";
            this.txtEstObr.Size = new System.Drawing.Size(126, 21);
            this.txtEstObr.TabIndex = 55;
            this.txtEstObr.TextChanged += new System.EventHandler(this.txtEstObr_TextChanged);
            this.txtEstObr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEstObr_KeyPress);
            // 
            // frmOPE_Pro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1283, 772);
            this.Controls.Add(this.tbcPro);
            this.Controls.Add(this.pnEnc);
            this.Controls.Add(this.tlsBot);
            this.Controls.Add(this.dgvRQ);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmOPE_Pro";
            this.Text = "Proyecto";
            this.Load += new System.EventHandler(this.frmOPE_Pro_Load);
            this.Resize += new System.EventHandler(this.frmOPE_Pro_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRQ)).EndInit();
            this.tlsBot.ResumeLayout(false);
            this.tlsBot.PerformLayout();
            this.tbcPro.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.pnlAcuCom.ResumeLayout(false);
            this.pnlAcuCom.PerformLayout();
            this.gbDetCosSer.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.gbDetConSer.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.pnlRegVis.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegVis)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.pnlIntPro.ResumeLayout(false);
            this.pnlIntPro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgIntPro)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.pnlRegOti.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegOTI)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.pnlRegRut.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegRuta)).EndInit();
            this.pnEnc.ResumeLayout(false);
            this.pnEnc.PerformLayout();
            this.gbFecAprIns.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgFecAprIns)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvRQ;
        private System.Windows.Forms.ToolStrip tlsBot;
        private System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.ToolStripButton btnAbrir;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton btnModificar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.TabControl tbcPro;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtAlcPro;
        private System.Windows.Forms.GroupBox gbDetCosSer;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtPro_TotConUti;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtPro_TotSinUti;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtPro_Uti;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtPro_GasGen;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtPro_CosInd;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtPro_CosDir;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtIns_TotConUti;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtIns_TotSinUti;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtIns_Uti;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtIns_GasGen;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtIns_CosInd;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtIns_CosDir;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtSup_TotConUti;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtSup_TotSinUti;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtSup_Uti;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtSup_GasGen;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtSup_CosInd;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtSup_CosDir;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtDis_TotConUti;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtDis_TotSinUti;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtDis_Uti;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtDis_GasGen;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtDis_CosInd;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtDis_CosDir;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button btnLimPaq;
        private System.Windows.Forms.Button btnPaq;
        private System.Windows.Forms.Label lblRQ;
        private System.Windows.Forms.GroupBox gbDetConSer;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtPro_CosPro_Sol;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtPro_CanPanConLic_Und;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtPro_CanModRepAmp_Und;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtPro_CanBotSenDri_Und;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtPro_DurEst_Dia;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtIns_CosMat_Sol;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtIns_CosTraNoc_Sol;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtIns_CanPruLuc_Und;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtIns_CanViaMov_Und;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtIns_CanVisCoo_Und;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtIns_CanTecDia_Und;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtIns_DurEst_Dia;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSup_CanPrueMeg_Und;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtSup_CanPruMueDobAlt_Und;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtSup_CanPruMue_Und;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSup_CanVisSup_Und;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSup_TraOfiOpe_Hor;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtSup_CanVisIngOpe_Und;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtSup_DurEst_Mes;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDis_TraDia_Hor;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDis_TraPla_Hor;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtDis_TraOfi_Hor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDis_CanVis_Und;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvRegVis;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnCanInt;
        private System.Windows.Forms.Button btnAgrInt;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtCel2;
        private System.Windows.Forms.TextBox txtCel1;
        private System.Windows.Forms.TextBox txtNomInt;
        private System.Windows.Forms.TextBox txtCodCar;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel pnEnc;
        private System.Windows.Forms.MaskedTextBox mtxtFecFin;
        private System.Windows.Forms.TextBox txtCodEstObr;
        private System.Windows.Forms.MaskedTextBox mtxtFecCab;
        private System.Windows.Forms.MaskedTextBox mtxtFecIni;
        private System.Windows.Forms.Label lblFecfin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox txtNumMov;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtDir;
        private System.Windows.Forms.TextBox txtDis;
        private System.Windows.Forms.TextBox txtFecIng;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEstObr;
        private System.Windows.Forms.DataGridView dgvRegOTI;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dgvRegRuta;
        private System.Windows.Forms.TextBox txtDis_DurEst_Mes;
        private System.Windows.Forms.Panel pnlAcuCom;
        private System.Windows.Forms.Panel pnlRegVis;
        private System.Windows.Forms.Panel pnlIntPro;
        private System.Windows.Forms.Panel pnlRegOti;
        private System.Windows.Forms.Panel pnlRegRut;
        private System.Windows.Forms.GroupBox gbFecAprIns;
        private C1.Win.C1FlexGrid.C1FlexGrid fgFecAprIns;
        private System.Windows.Forms.ToolStripButton btnTer;
        private System.Windows.Forms.ToolStripButton btnArc;
        private System.Windows.Forms.ToolStripSplitButton btnPar;
        private System.Windows.Forms.ToolStripMenuItem tsrMAct;
        private C1.Win.C1FlexGrid.C1FlexGrid fgIntPro;
    }
}