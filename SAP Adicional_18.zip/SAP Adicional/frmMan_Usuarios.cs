﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.Man_Menus;
using Interfaces;
using SAP_Adicional;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmMan_Usuarios : Form, frm_Man_Usuarios
    {
        private NMan_UsuMae nmUsu = new NMan_UsuMae();
        private NConsultas nc = new NConsultas();
        private VarGlo varglo = VarGlo.Instance();
        private NSolFac sf = new NSolFac();
        private Int16 indice=0; //estado de los botones
        private Int16 estado=0; //modifica o actuliza
        public frmMan_Usuarios()
        {
            InitializeComponent();  
        }

        private void Man_Usuarios_RecUsu()
        {
            try
            {
                DataTable dtRecUsu = new DataTable(); //valida si hay datos
                dtRecUsu = nmUsu.RecUsuMae();

                if (dtRecUsu.Rows.Count > 0)
                {
                    fgMae.DataSource = nmUsu.RecUsuMae(); //llena los datos
                }
                else
                {
                    MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }           
        }
        private void Man_Usuarios_ForCol()
        {
            //formato de columnas
            fgMae.Cols["Codigo"].Width = 50;
            fgMae.Cols["Empleado"].Width = 250;
            fgMae.Cols["Usuario"].Width = 50;
            fgMae.Cols["Password"].Width =70 ;
            fgMae.Cols["UsuarioActivo"].Width = 90;
            fgMae.Cols["UsuarioActivo"].DataType= typeof(bool);
        }
        private void Man_Usuarios_ForGen()
        {
            //formato general
            fgMae.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fgMae.Styles.Alternate.BackColor = Color.LightBlue;
            fgMae.Styles.Highlight.BackColor = Color.Blue;
            fgMae.Styles.Highlight.ForeColor = Color.White;
            fgMae.AllowFreezing = AllowFreezingEnum.Both;
            fgMae.Cols.Frozen = 3;

            //solo lectura
            Man_Usuarios_DeshaTex();
        }
        private void ConsultaDatos(string vista, string procedimiento, string param1, string param2="")
        {
            DataTable dt = new DataTable();
            dt = nc.OPE_Pro_Filtros(vista, procedimiento, param1, param2);

            if (dt.Rows.Count > 1) ///validamos si hay datos
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 36;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.frm_Man_Usuarios_Rec = this;
                frm.dg.Columns[0].Width = 50;
                frm.dg.Columns[1].Width = 230;
                frm.dg.Columns[2].Width = 50;
                frm.dg.Columns[3].Width = 100;
                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (dt.Rows.Count == 1) //se muestra lo datos si coincide con lo escrito en el textbox
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "NombreEmpleado":
                        txtCodEmp.Text = row["Codigo"].ToString();
                        txtNomEmp.Text = row["Empleado"].ToString();
                        txtNomEmp.Focus();
                        break;

                    default:
                        break;
                }
            }
        }
        private void frmMan_Usuarios_Load(object sender, EventArgs e)
        {
            Man_Usuarios_RecUsu(); 
            Man_Usuarios_ForCol(); 
            Man_Usuarios_ForGen();
            VEN_SolNotCre_EstBot("cargar"); //estado de los botones
            indice = 0;
            Man_Usuarios_RecDatUsu(txtCodEmp.Text);
        }
     
        private void Man_Usuarios_RecDatUsu( string cod)
        {
            
            DataTable dtRecUsu = new DataTable();

            if (string.IsNullOrEmpty(cod)) //validatos si esta vacio
            {
                cod = 0.ToString();
            }

            dtRecUsu = nmUsu.RecManUsu(indice,Convert.ToInt32(cod));

            if (dtRecUsu.Rows.Count == 0) //validamos si no hay datos
            {
                return;
            }

            //asignamos los datos a las cajas de texto
            txtCodEmp.Text= string.Format("00{0}" , dtRecUsu.Rows[0]["Codigo"].ToString());
            txtNomEmp.Text = dtRecUsu.Rows[0]["Empleado"].ToString();
            txtUsu.Text = dtRecUsu.Rows[0]["Usuario"].ToString();
            txtPas.Text = dtRecUsu.Rows[0]["Password"].ToString();
            txtPasAga.Text = dtRecUsu.Rows[0]["Password"].ToString();
            dtRecUsu.Rows[0]["UsuarioActivo"] = true ? chkUsuAct.Checked = true : chkUsuAct.Checked = false;
            fgMae.Row = fgMae.FindRow(txtCodEmp.Text,0,2,false,false,false);
        }

        private void txtNomUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("NombreEmpleado", "Filtro_Empleado_SoloUsu", txtNomEmp.Text);
                txtUsu.Focus();
            }         
        }

        private void fgMae_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col != 2 && e.Col != 3)
            {
                if (e.KeyChar != 3 && e.KeyChar != 27) //no permite escribir en el fg
                {
                    e.Handled = true;
                }
            }
        }

        private void btnExp_Click_1(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fgMae.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch { }
        }

        private void fgMae_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                tabManUsuMae.SelectedTab = tabManUsuMae.TabPages[0]; //muestra la primera pagina del tabControl
                indice = 4;
                Man_Usuarios_RecDatUsu(fgMae.Rows[fgMae.RowSel][0].ToString());
            }
            catch { return; }         
        }

        public void recdat_frmMan_Usuarios(string CodEm, string NomEmp)
        {
            txtCodEmp.Text = CodEm;
            txtNomEmp.Text = NomEmp;
        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            estado = 1;
            Man_Usuarios_ValUsuSapAdi(3);
            Man_Usuarios_HabiText();
        }

        private void btnCer_Click(object sender, EventArgs e)
        {
            //valida el mensaje
           DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea Salir?","Mensaje del sistema",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (mensaje == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                return;
            }
        }
        private void Mensaje()
        {
            MessageBox.Show("No cuenta con acceso para realizar esta operación", "Mensaje del Sistema",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void Man_Usuarios_ValUsuSapAdi(int campo)
        {
            switch (campo)
            {
                case 1:
                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 1, 0) == 1) //valida si tiene acceso 
                    {
                        VEN_SolNotCre_EstBot("cargar"); //estado de los botones
                        Man_Usuarios_LimBot();
                        Man_Usuarios_HabiText();
                    }
                    else
                    {
                        Mensaje(); //aviso
                        return;
                    }
                    break;

                case 2:
                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 2, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("nuevo");
                    }
                    else
                    {
                        Mensaje();
                        return;
                    }
                    break;
                case 3:

                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 3, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("modificar");
                    }
                    else
                    {
                        Mensaje();
                        return;
                    }
                    break;
                case 4:

                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 3, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("guardar");
                    }
                    else
                    {
                        Mensaje();
                        return;
                    }
                    break;
                case 5:

                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 3, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("borrar");
                    }
                    else
                    {
                        Mensaje();
                        return;
                    }
                    break;
                default:
                    break;
            }
        }
        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }
        public void VEN_SolNotCre_EstBot(string BotonEstado)
        {
            bool[] EstadoM = { true };

            //cargar, nuevo, modificar, guardar, borrar, cancelar

            switch (BotonEstado)
            {
                case "cargar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;

                case "nuevo": //
                    EstadoM = matriz(false, false, true, false, true, false);
                    break;

                case "modificar": //
                    EstadoM = matriz(false, false, true, false, true, false);
                    break;

                case "guardar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;

                case "borrar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;

                case "cancelar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;

            }
            //botones que habilita o deshabilita
            this.btnNue.Enabled = EstadoM[0];
            this.btnMod.Enabled = EstadoM[1];
            this.btnGua.Enabled = EstadoM[2];
            this.btnBor.Enabled = EstadoM[3];
            this.btnCan.Enabled = EstadoM[4];
            this.btnCer.Enabled = EstadoM[5];
        }

        private void btnNue_Click(object sender, EventArgs e)
        {
            estado = 0;
            Man_Usuarios_ValUsuSapAdi(2);
           
            gpbBot.Enabled = false;
        }
        private void Man_Usuarios_HabiText()
        {
            txtNomEmp.ReadOnly = false;
            txtUsu.ReadOnly = false;
            txtPas.ReadOnly = false;
            txtPasAga.ReadOnly = false;
            chkUsuAct.Enabled = true;
            txtNomEmp.Focus();           
        }
        private void Man_Usuarios_LimBot()
        {
            txtCodEmp.Clear();
            txtNomEmp.Clear();
            txtUsu.Clear();
            txtPas.Clear();
            txtPasAga.Clear();
            chkUsuAct.Checked = false;
        }
        private void btnGua_Click(object sender, EventArgs e)
        {   
            //valida las cajas de texto         
            if (string.IsNullOrEmpty(txtCodEmp.Text) || string.IsNullOrEmpty(txtNomEmp.Text) || string.IsNullOrEmpty(txtUsu.Text) ||
                   string.IsNullOrEmpty(txtPas.Text) || string.IsNullOrEmpty(txtPasAga.Text))
            {
                MessageBox.Show("Todos los datos son obligatorios", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                //valida la concidencia de contraseñ
                if (txtPas.Text == txtPasAga.Text)
                {
                    DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea Guardar?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (mensaje == DialogResult.Yes)
                    {

                        Int16 registro;
                        if (estado == 0) //valida si guarda o actuliza
                        {

                            registro = 0;
                        }
                        else
                        {
                            registro = 1;
                        }
                        //asiganmos a la entidad guadamos o actualizamos
                        Man_UsuMae UsuInsAct = new Man_UsuMae();

                        UsuInsAct.Acc = Convert.ToInt16(registro);
                        UsuInsAct.CodUsu = Convert.ToInt32(txtCodEmp.Text);
                        UsuInsAct.Usu = txtUsu.Text;
                        UsuInsAct.Cla = txtPas.Text;
                        UsuInsAct.UsuAct = Convert.ToInt16(chkUsuAct.Checked);
                        Man_Usuarios_ValUsuSapAdi(4); //validamos el acceso
                        nmUsu.ActGuaUsu(UsuInsAct); //ejecutamos el metodo                      
                        Man_Usuarios_DeshaTex(); //desahabilitamos botones

                        if (estado == 0)
                        {
                            MessageBox.Show("Se guardo correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Se actualizo correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        Man_Usuarios_RecUsu(); //volver a llenar los daos en el fg
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Las contraseñas no coindicen", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPas.Focus();
                    return;
                }
                
            }
        }

        private void btnBor_Click(object sender, EventArgs e)
        {
            //valida la caja de texto
            if (string.IsNullOrEmpty(txtCodEmp.Text))
            {
                MessageBox.Show("No se puede eliminar ,falta datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                //valida la respuesta
                DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea Eliminar?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (mensaje == DialogResult.Yes)
                {
                    nmUsu.EliUsu(Convert.ToInt16(txtCodEmp.Text));
                    Man_Usuarios_ValUsuSapAdi(4);
                    btnPri.PerformClick();
                    Man_Usuarios_DeshaTex();
                }
                else
                {
                    return;
                }
            }                  
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            VEN_SolNotCre_EstBot("cancelar");          
            Man_Usuarios_DeshaTex();
            btnPri.PerformClick();
        }
        private void Man_Usuarios_DeshaTex()
        {
            txtCodEmp.ReadOnly = true;
            txtNomEmp.ReadOnly = true;
            txtUsu.ReadOnly = true;
            txtPas.ReadOnly = true;
            txtPasAga.ReadOnly = true;
            chkUsuAct.Enabled = false;
            gpbBot.Enabled = true;
            txtNomEmp.Focus();
        }
        
        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPas.Focus();
            }
        }

        private void txtPasAga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnGua.Focus();
            }
        }

        private void chkMosPas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnPri.Focus();
            }
        }

        private void txtPas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPasAga.Focus();
            }
        }

        private void btnPri_Click(object sender, EventArgs e)
        {
            indice = 0;
            Man_Usuarios_RecDatUsu(txtCodEmp.Text);
        }

        private void btnRet_Click(object sender, EventArgs e)
        {
            indice = 1;
            Man_Usuarios_RecDatUsu(txtCodEmp.Text);
        }

        private void btnAva_Click(object sender, EventArgs e)
        {
            indice = 2;
            Man_Usuarios_RecDatUsu(txtCodEmp.Text);
        }

        private void btnUlt_Click(object sender, EventArgs e)
        {
            indice = 3;
            Man_Usuarios_RecDatUsu(txtCodEmp.Text);
        }

        private void chkMosPas_CheckedChanged(object sender, EventArgs e)
        {
            
            if (chkMosPas.Checked == true)
            {
                if (txtPas.PasswordChar == '*')
                {
                    txtPas.PasswordChar = '\0'; //codigo para habilitar el passwordchar
                    txtPasAga.PasswordChar = '\0';
                }
            }
            else
            {
                txtPas.PasswordChar = '*'; //oculta el password
                txtPasAga.PasswordChar = '*';
            }
        }
        private void fgMae_AfterEdit(object sender, RowColEventArgs e)
        {
            Int16 numCol;
            if (e.Col == 2) //Actuliza el usuario
            {
                numCol = 0;
                nmUsu.ActUsuMae(fgMae.Rows[fgMae.RowSel][e.Col].ToString(),
                Convert.ToInt16(fgMae.Rows[fgMae.RowSel][0]), numCol);
            }
            else if (e.Col == 3) //Actuliza la clave
            {
                numCol = 1;
                nmUsu.ActUsuMae(fgMae.Rows[fgMae.RowSel][e.Col].ToString(), 
                Convert.ToInt16(fgMae.Rows[fgMae.RowSel][0]), numCol);
            }
            else                 //Actuliza el estado
            {
                if (e.Col == 4)
                {
                    numCol = 2;
                    nmUsu.ActUsuMae(fgMae.Rows[fgMae.RowSel][e.Col].ToString(),
                    Convert.ToInt16(fgMae.Rows[fgMae.RowSel][0]), numCol);
                }
            }
        }

        private void tabManUsuMae_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!btnMod.Enabled) //si el boton modificar esta en false
            {
                if (tabManUsuMae.SelectedTab == tabManUsuMae.TabPages[1]) //valida si hace click en la otra pestaña cuando se edita
                {
                    tabManUsuMae.SelectedTab = tabManUsuMae.TabPages[0];
                }
            }
        }

        public void recdat_frm_Man_Usuario(string CodEmp, string NomEmp)
        {
            txtCodEmp.Text = CodEmp;
            txtNomEmp.Text =  NomEmp;
        }
    }
}
