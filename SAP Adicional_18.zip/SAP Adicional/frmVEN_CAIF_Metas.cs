﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace SAP_Adicional
{
    public partial class frmVEN_CAIF_Metas : Form
    {

        NVEN_CAIF nc = new NVEN_CAIF();
        VarGlo varglo = VarGlo.Instance();

        public frmVEN_CAIF_Metas()
        {
            InitializeComponent();
        }

        private void frmVEN_CAIF_Metas_Load(object sender, EventArgs e)
        {            
            cbAño.ValueMember = "Año";
            cbAño.DisplayMember = "Año";

            cbAño.DataSource = nc.VEN_CAIF_Años();

            cbTipMet.ValueMember = "CodTipMet";
            cbTipMet.DisplayMember = "Des";

            cbTipMet.DataSource = nc.VEN_CAIF_MetTip();

            btnMos.PerformClick();

        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            this.fg.AutoGenerateColumns = true;

            this.fg.DataSource = nc.VEN_CAIF_Metas(Convert.ToInt32(cbAño.Text), Convert.ToInt16(cbTipMet.SelectedValue));
            //this.fg.Refresh();

        }

        private void FormatoGrid()
        {
            fg.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.Solid;

            this.fg.Cols[0].Visible = false;
            this.fg.Cols[2].Visible = false;

            this.fg.Cols[1].Width = 200;
            this.fg.Cols[3].Width = 100;

            //Recorro columnas
            for (int i = 4; i < fg.Cols.Count; i++)
            {
                this.fg.Cols[i].Width = 70;
                fg.Cols[i].Format = "#,###,###";
            }

            //Recorro filas
            for (int i = 0; i < fg.Rows.Count; i++)
            {

                if (fg.Cols[0][i].ToString() == "" && fg.Cols[2][i].ToString() != "")
                {

                    this.fg.GetCellRange(i, 0, i, fg.Cols.Count - 1).StyleNew.BackColor = Color.GreenYellow;
                }

                if (fg.Cols[0][i].ToString() == "" && fg.Cols[2][i].ToString() == "")
                {

                    this.fg.GetCellRange(i, 0, i, fg.Cols.Count - 1).StyleNew.BackColor = Color.Orange;
                }
                
            }

        }

        private void fg_Click(object sender, EventArgs e)
        {

        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGrid();
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.Col > 3 && fg.Cols[0][e.Row].ToString() != "")
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = false;
                }
            }
            else
            {
                    e.Handled = true;
            }
        }
      
        private void fg_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col > 3 && fg.Cols[0][e.Row].ToString() != "")
            {
                nc.VEN_CAIF_Metas_ingact(Convert.ToInt32(fg.Cols[0][e.Row]), 
                                        fg.Cols[2][e.Row].ToString(), 
                                        e.Col == 4 ? Convert.ToInt16(0) : Convert.ToInt16(fg.Cols[e.Col][0].ToString().Substring(0, 2)), 
                                        Convert.ToInt32(cbAño.Text),
                                        Convert.ToInt16(cbTipMet.SelectedValue),
                                        Convert.ToDecimal(string.IsNullOrEmpty(fg.Cols[e.Col][e.Row].ToString()) ? 0 : fg.Cols[e.Col][e.Row]),
                                        varglo.CodUsuAct);

                int ColUlt; int RowUlt;

                ColUlt = e.Col; RowUlt = e.Row;

                btnMos.PerformClick(); 

                fg.Select(fg.GetCellRange(RowUlt, ColUlt));

            }            
            
        }

        private void cbAño_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnMos.PerformClick();
        }

        private void cbTipMet_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnMos.PerformClick();
        }

        private void fg_LeaveEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            
        }
    }
}
