﻿namespace SAP_Adicional
{
    partial class frmMenus_Acceso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodUsu = new System.Windows.Forms.TextBox();
            this.txtNomUsu = new System.Windows.Forms.TextBox();
            this.chkSelPer = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtFor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRel = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKeyNod = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNomMen = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCodMen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.treeVieMenAcc = new System.Windows.Forms.TreeView();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCodUsuCop = new System.Windows.Forms.TextBox();
            this.txtNomUsuCop = new System.Windows.Forms.TextBox();
            this.btnAcc = new System.Windows.Forms.Button();
            this.btnCan = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usuario:";
            // 
            // txtCodUsu
            // 
            this.txtCodUsu.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodUsu.Location = new System.Drawing.Point(54, 34);
            this.txtCodUsu.Name = "txtCodUsu";
            this.txtCodUsu.Size = new System.Drawing.Size(62, 21);
            this.txtCodUsu.TabIndex = 1;
            // 
            // txtNomUsu
            // 
            this.txtNomUsu.Location = new System.Drawing.Point(119, 34);
            this.txtNomUsu.Name = "txtNomUsu";
            this.txtNomUsu.Size = new System.Drawing.Size(274, 21);
            this.txtNomUsu.TabIndex = 2;
            this.txtNomUsu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomUsu_KeyPress);
            // 
            // chkSelPer
            // 
            this.chkSelPer.AutoSize = true;
            this.chkSelPer.Location = new System.Drawing.Point(54, 11);
            this.chkSelPer.Name = "chkSelPer";
            this.chkSelPer.Size = new System.Drawing.Size(107, 17);
            this.chkSelPer.TabIndex = 0;
            this.chkSelPer.Text = "Seleccionar perfil";
            this.chkSelPer.UseVisualStyleBackColor = true;
            this.chkSelPer.CheckedChanged += new System.EventHandler(this.chkSelPer_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtFor);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtRel);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtKeyNod);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtNomMen);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCodMen);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(405, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(231, 302);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Información del Menú";
            // 
            // txtFor
            // 
            this.txtFor.Location = new System.Drawing.Point(10, 239);
            this.txtFor.Name = "txtFor";
            this.txtFor.Size = new System.Drawing.Size(205, 21);
            this.txtFor.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Formulario";
            // 
            // txtRel
            // 
            this.txtRel.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtRel.Location = new System.Drawing.Point(10, 189);
            this.txtRel.Name = "txtRel";
            this.txtRel.Size = new System.Drawing.Size(205, 21);
            this.txtRel.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Key (Relation)";
            // 
            // txtKeyNod
            // 
            this.txtKeyNod.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtKeyNod.Location = new System.Drawing.Point(10, 136);
            this.txtKeyNod.Name = "txtKeyNod";
            this.txtKeyNod.Size = new System.Drawing.Size(205, 21);
            this.txtKeyNod.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "key (Nodo)";
            // 
            // txtNomMen
            // 
            this.txtNomMen.Location = new System.Drawing.Point(10, 87);
            this.txtNomMen.Name = "txtNomMen";
            this.txtNomMen.Size = new System.Drawing.Size(205, 21);
            this.txtNomMen.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Nombre Menu:";
            // 
            // txtCodMen
            // 
            this.txtCodMen.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodMen.Location = new System.Drawing.Point(10, 38);
            this.txtCodMen.Name = "txtCodMen";
            this.txtCodMen.Size = new System.Drawing.Size(100, 21);
            this.txtCodMen.TabIndex = 8;
            this.txtCodMen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Codigo Menu:";
            // 
            // treeVieMenAcc
            // 
            this.treeVieMenAcc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.treeVieMenAcc.CheckBoxes = true;
            this.treeVieMenAcc.Location = new System.Drawing.Point(3, 76);
            this.treeVieMenAcc.Name = "treeVieMenAcc";
            this.treeVieMenAcc.Size = new System.Drawing.Size(388, 358);
            this.treeVieMenAcc.TabIndex = 9;
            this.treeVieMenAcc.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.treeVieMenAcc_AfterCheck);
            this.treeVieMenAcc.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeVieMenAcc_AfterSelect);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Usuario a copiar:";
            // 
            // txtCodUsuCop
            // 
            this.txtCodUsuCop.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodUsuCop.Enabled = false;
            this.txtCodUsuCop.Location = new System.Drawing.Point(105, 22);
            this.txtCodUsuCop.Name = "txtCodUsuCop";
            this.txtCodUsuCop.Size = new System.Drawing.Size(62, 21);
            this.txtCodUsuCop.TabIndex = 5;
            // 
            // txtNomUsuCop
            // 
            this.txtNomUsuCop.Enabled = false;
            this.txtNomUsuCop.Location = new System.Drawing.Point(171, 22);
            this.txtNomUsuCop.Name = "txtNomUsuCop";
            this.txtNomUsuCop.Size = new System.Drawing.Size(274, 21);
            this.txtNomUsuCop.TabIndex = 6;
            this.txtNomUsuCop.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomUsuCop_KeyPress);
            // 
            // btnAcc
            // 
            this.btnAcc.AutoSize = true;
            this.btnAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAcc.Location = new System.Drawing.Point(397, 32);
            this.btnAcc.Name = "btnAcc";
            this.btnAcc.Size = new System.Drawing.Size(116, 23);
            this.btnAcc.TabIndex = 3;
            this.btnAcc.Text = "Accesos >>";
            this.btnAcc.UseVisualStyleBackColor = true;
            this.btnAcc.Click += new System.EventHandler(this.btnAcc_Click);
            // 
            // btnCan
            // 
            this.btnCan.AutoSize = true;
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Location = new System.Drawing.Point(470, 20);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(75, 23);
            this.btnCan.TabIndex = 7;
            this.btnCan.Text = "Cancelar";
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.btnCan);
            this.groupBox2.Controls.Add(this.txtCodUsuCop);
            this.groupBox2.Controls.Add(this.txtNomUsuCop);
            this.groupBox2.Location = new System.Drawing.Point(516, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(569, 51);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Copia de accesos";
            // 
            // frmMenus_Acceso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1114, 446);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnAcc);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.treeVieMenAcc);
            this.Controls.Add(this.chkSelPer);
            this.Controls.Add(this.txtNomUsu);
            this.Controls.Add(this.txtCodUsu);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMenus_Acceso";
            this.Text = "Menus Acceso";
            this.Load += new System.EventHandler(this.frmMenus_Acceso_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodUsu;
        private System.Windows.Forms.TextBox txtNomUsu;
        private System.Windows.Forms.CheckBox chkSelPer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCodMen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtRel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKeyNod;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNomMen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TreeView treeVieMenAcc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCodUsuCop;
        private System.Windows.Forms.TextBox txtNomUsuCop;
        private System.Windows.Forms.Button btnAcc;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}