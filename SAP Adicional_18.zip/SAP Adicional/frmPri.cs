﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using CapaNegocio;
using System.Runtime.InteropServices;

namespace SAP_Adicional
{

    public partial class frmPri : Form
    {
        private VarGlo varglo = VarGlo.Instance();
        private ToolStripMenuItem _m;
        private frmLogin _frmLogin;
        private bool _existe = false;
        private frmCambioSesion _frmCambioSesion;
        private ToolStripMenuItem _itemclic;

        [DllImport("user32")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
        LASTINPUTINFO INPUT = new LASTINPUTINFO();//PARA USAR LA ESTRUCTURA EN LA FUNCION GetLastInputInfo

        private struct LASTINPUTINFO
        {
            public int cbSize; //TAMAÑO DE LA ESTRUCTURA EN BYTES ¿?
            public int dwTime; //MOMENTO (MILISEGUNDOS DESDE QUE SE INICIO LA SESION) EN QUE SE PULSA UNA TECLA O SE ACTIVA EL MOUSE
        }

        public frmPri()
        {
            InitializeComponent();
           
        }
        public frmPri(frmLogin f)
        {
            InitializeComponent();
            _frmLogin = f;
        }

        public frmPri(frmCambioSesion frmCambioSesion)
        {
            this._frmCambioSesion = frmCambioSesion;
        }

        private void frmPri_Load(object sender, EventArgs e)
        {
            CargaMenu(0,null, menuStrip1, varglo.CodUsuAct);
            this.HorizontalScroll.Enabled = false;
           
            if (varglo.Empresa.Contains("HOME"))
            {
                this.Icon = SAP_Adicional.Properties.Resources.IconoTrazzoHome;
            }
            else
            {
                this.Icon = SAP_Adicional.Properties.Resources.TRAZZOICONO;
            }

            if (_existe)
            {
                frmFavoritos frmFav = new frmFavoritos();
                frmFav.Location = new Point(0, 0);
                frmFav.MdiParent = this;
                frmFav.Show();
            }

            //¿? PERO ES NECESARIO
            INPUT.cbSize = Marshal.SizeOf(INPUT);

            //MONITORIZAREMOS GetLastInputInfo CADA SEGUNDO
            this.tmrIna.Interval = 9000;
            this.tmrIna.Start();

            frmInfSapAdi f = new frmInfSapAdi();
            f.MdiParent = this;
            f.Show();
            f.Location = new Point(600, 415);
        }

        private void frmPri_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (varglo.ValFormClose == false)
            {
                DialogResult dialogo = MessageBox.Show("¿Desea cerrar el programa?", "SAP Adicional", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dialogo == DialogResult.No)
                {
                    e.Cancel = true;
                }
                else
                {
                    this.Dispose();
                    e.Cancel = false;
                }
            } 
        }

        public void CargaMenu(Int32 IdMenu, ToolStripMenuItem mP, MenuStrip Menu, int CodUsuAct)
        {
            Cursor.Current = Cursors.WaitCursor;

            DataTable menu = new DataTable();

            menu = NPri.CargaMenu(IdMenu, mP, Menu, CodUsuAct);

            DataView Menus = new DataView(menu);
            //El campo nivel superior es el campo que indica el codigo del Menu Padre
            Menus.RowFilter = menu.Columns["NivelSuperior"].ColumnName + "=" + IdMenu;

            foreach (DataRowView fila in Menus)
            {
                _m = new ToolStripMenuItem();

                _m.Text = fila["Menu"].ToString();
                _m.Name = fila["Codigo"].ToString();
                _m.Tag = fila["Formulario"].ToString();
                _m.ToString();
                _m.ForeColor = Color.Blue;

               
                if (_m.Tag.ToString() == "frmFavoritos")
                {
                    _existe = true;
                }
               
                if (_m.Text == "Salir")
                {
                    _m.Click += new EventHandler(mnuSalir);
                }
                else if (_m.Text == "Actualizar menús")
                {
                    _m.Click += new EventHandler(mnuActualizarMenus);
                }
                else
                {
                    _m.Click += new EventHandler(EventoMenu);
                }                                    

                if (int.Parse(fila["NivelSuperior"].ToString()) == 0)
                {
                    Menu.Items.Add(_m);
                }
                else
                {
                    mP.DropDownItems.Add(_m);
                }                

                if (_m.Tag.ToString() != "" && _m.Tag.ToString().Contains("frm"))
                {
                    try
                    {
                        Assembly asm = Assembly.GetExecutingAssembly();
                        Type formtype = asm.GetType("SAP_Adicional." + _m.Tag.ToString());
                        Form f = (Form)Activator.CreateInstance(formtype);
                    }
                    catch (Exception)
                    {

                        _m.ForeColor = Color.Red;
                    }
                }

                CargaMenu(int.Parse(fila["Codigo"].ToString()), _m, Menu, CodUsuAct);
            }

            Cursor.Current = Cursors.Default;
        }

        public void EventoMenu(object sender, EventArgs e)
        {
            _itemclic = (ToolStripMenuItem)sender;

            try
            {
                if (_itemclic.Tag.ToString() != "")
                {
                    //se abre el form 
                    Assembly asm = Assembly.GetExecutingAssembly();
                    Type formtype = asm.GetType("SAP_Adicional." + _itemclic.Tag.ToString());
                    Form f = (Form)Activator.CreateInstance(formtype);
                    f.MdiParent = this;

                    if (varglo.Empresa.Contains("HOME"))
                    {
                        f.Icon = SAP_Adicional.Properties.Resources.IconoTrazzoHome;
                    }
                    else
                    {
                        f.Icon = SAP_Adicional.Properties.Resources.TRAZZOICONO;
                    }

                    //Formulario de tamaño pequeño
                    if (_itemclic.Tag.ToString() == "frmFavoritos")
                    {
                        f.Show();
                        f.Location = new System.Drawing.Point(0, 0);
                        f.WindowState = FormWindowState.Normal;
                        return;
                    }

                    //Formulario de tamaño pequeño
                    if (_itemclic.Tag.ToString() == "frmAgrMenu")
                    {
                        f.Show();
                        f.WindowState = FormWindowState.Normal;
                        return;

                    }

                    //Formulario de tamaño pequeño
                    if (_itemclic.Tag.ToString() == "frmCambioSesion")
                    {
                        f.Show();
                        f.WindowState = FormWindowState.Normal;

                        //desahbilitamos los menus
                        foreach (Control menu in this.Controls)
                        {
                            if (menu is MenuStrip)
                            {
                                menu.Enabled = false;
                            }
                        }

                        //desahbilitamos los formulario hijos 
                        foreach (var menu in this.MdiChildren)
                        {
                            if (menu.Name != "frmCambioSesion")
                            {
                                menu.Enabled = false;
                            }
                        }
                        return;
                    }

                    f.Show();
                    f.WindowState = FormWindowState.Minimized;
                    f.WindowState = FormWindowState.Maximized;
                }
            }
            catch (Exception)
            {
                System.Windows.MessageBox.Show("En proceso");
                return;
            }
        }

        public void mnuSalir(object sender, EventArgs e)
        {           
           this.Close();
        }

        public void mnuActualizarMenus(object sender, EventArgs e)
        {
            menuStrip1.Items.Clear();
            CargaMenu(0, null, menuStrip1, varglo.CodUsuAct);
        }

        private void frmPri_KeyUp(object sender, KeyEventArgs e)
        {
            //Al presionar Ctrl + F aparece el formulario favoritos
            Form frm = new Form();
            if (Convert.ToInt32(e.KeyData) == Convert.ToInt32(Keys.Control) + Convert.ToInt32(Keys.F))
            {
                frmFavoritos frmFav= new frmFavoritos();
                frmFav.MdiParent = this;
                frmFav.Show();
                frmFav.Location = new System.Drawing.Point(0, 0);
            }

            //Al presionar Ctrl + M aparece el formulario Agregar Menu
            if (Convert.ToInt32(e.KeyData) == Convert.ToInt32(Keys.Control) + Convert.ToInt32(Keys.M))
            {
                frmAgrMenu frmAgrMen = new frmAgrMenu();
                frmAgrMen.MdiParent = this;
                frmAgrMen.Show();
                frmAgrMen.WindowState = FormWindowState.Normal;
            }
        }

        private void tmrMsg_Tick(object sender, EventArgs e)
        {
            //Valida el tiempo de la inactividad
            if (tmrMsg.Interval == 6000)
            {
                stpPri.BackColor = Color.White;
                tlsLblMen.Text = "";
            }
           
            tmrMsg.Enabled = false;
        }

        private void tmrIna_Tick(object sender, EventArgs e)
        {
            //Metodo que detecta la inactividad del usuario
            GetLastInputInfo(ref this.INPUT);

            int TOTAL = Environment.TickCount;
            int ULTIMO = INPUT.dwTime;
            int INTERVALO = Convert.ToInt32((double)(TOTAL - ULTIMO) / (double)9000);

            if (INTERVALO == 60)
            {
                this.tmrIna.Stop();

                //Muestra el form 
                frmSeguridad f = new frmSeguridad();
                f.MdiParent = this;
                f.Show();

                //Deshabilita el menuStrip
                foreach (Control menu in this.Controls)
                {
                    if (menu is MenuStrip)
                    {
                        menu.Enabled = false;
                    }
                }

                //Deshabilita los formularios
                foreach (var menu in this.MdiChildren)
                {
                    if (menu.Name != "frmSeguridad")
                    {
                        menu.Enabled = false;
                    }
                }
            }
        }
    }
}
