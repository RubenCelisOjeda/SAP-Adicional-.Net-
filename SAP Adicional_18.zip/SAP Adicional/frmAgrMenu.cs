﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.Men_Fav;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmAgrMenu : Form
    {
        private int posX;
        private int posY;
        NMenFav menFav = new NMenFav();
        string valorCelda = "";
       
        public frmAgrMenu()
        {
            InitializeComponent();
        }

        private void pnlBarra_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender,e);
        }
        private void MenuFavoritos_MoverForm(object sender, MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }
           
        }

       
        private void btnAgr_Click(object sender, EventArgs e)
        {
          /******************************************
           * Nombre: "boton agregar"
           * Proposito: <agregar los formularios abiertos al menu añadir favoritos validando que no se repitan los nombres>
           * Ouptut : <"mostrar los formularios en el menú favoritos">
           * Creado por: Ruben C.
           *****************************************/

            if (cmbNomMen.Text == "")
            {
                MessageBox.Show("Error no puede ingresar datos vacios","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }

            string valorCbx = "";
            valorCbx = cmbNomMen.SelectedValue.ToString(); 

            if (fgMen.Rows.Count > 1)
            {
                for (int i= 0; i < fgMen.Rows.Count;i++)
                {
                    string valorFg = fgMen.Rows[i][1].ToString();
                  
                    if (valorFg == valorCbx)
                    {
                        MessageBox.Show("El Formulario seleccionado ya esta en el menú de favoritos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
            }
           
            if (cmbNomMen.Text != "")
            {
                fgMen.Rows.Add();
                fgMen.Rows[fgMen.Rows.Count - 1][0] = valorCbx;
                fgMen.Rows[fgMen.Rows.Count - 1][1] = cmbNomMen.Text;
            }

            AgrMenu_Enc Enc = new AgrMenu_Enc();
            Enc.CodMen = fgMen.Rows[fgMen.Row][0].ToString();
            Enc.NomMen = fgMen.Rows[fgMen.Row][1].ToString();
            Enc.CodUsu = Convert.ToInt16(VarGlo.Instance().CodUsuAct);

            menFav.MenFav_InsAct(1,Enc);
            AgrMenu_Rec();
            AgrMenu_FormatoColumnas();
            btnAct.PerformClick();
            btnActMenFav.PerformClick();
        }
       

        private void lblMini_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Minimized;
            }
        }

        private void lblCer_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender, e);
        }

        private void frmAgrMenu_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender, e);
        }

        private void frmAgrMenu_Load(object sender, EventArgs e)
        {
            AgrMenu_Rec();
            AgrMenu_FormatoColumnas();
            AgrtMen_RecCmb();
        }
        void AgrtMen_RecCmb()
        {
            /******************************************
            * Nombre: "AgrtMen_RecCmb"
            * Proposito: <buscar los formularios abiertos y guardarlos en un datatable el texto y valor>
            * Ouptut : <"mostrar los formularios en el combobox">
            * Creado por: <Ruben C.>
            *****************************************/

            DataTable dtMenus = new DataTable();
            dtMenus.Columns.Add("NombreOrigen");
            dtMenus.Columns.Add("NombreFormulario");
            string nomOriFrm = "";
            string nomOriFg = "";
            bool valor = false;

            foreach (var menu in VarGlo.Instance().frmNuevo.MdiChildren)
            {
                if (menu.Name != "frmFavoritos" & menu.Name != "frmAgrMenu")
                {
                    valor = true;

                    nomOriFrm = menu.Name;

                    bool estado = false;

                    foreach (Row row in fgMen.Rows)
                    {
                        if (row.Index > 0)
                        {
                            nomOriFg = row[1].ToString();

                            if (nomOriFrm == nomOriFg)
                            {
                                estado = true;
                                break;
                            }
                        }
                    }

                    string nomFrm = "";
                    bool frmAbierto = false;

                    if (!estado)
                    {
                        DataRow dr = dtMenus.NewRow();

                        dr[0] = menu.Name;
                        dr[1] = menu.Text;

                        foreach (DataRow row in dtMenus.Rows)
                        {

                            nomFrm = row[0].ToString();

                            if (menu.Name == nomFrm)
                            {
                                frmAbierto = true;
                                break;
                            }
                        }

                        if (!frmAbierto)
                        {
                            dtMenus.Rows.Add(dr);
                        }
                    }
                }
            }

            if (dtMenus.Rows.Count > 0)
            {
                cmbNomMen.ValueMember = "NombreOrigen";
                cmbNomMen.DisplayMember = "NombreFormulario";
                cmbNomMen.DataSource = dtMenus;
                cmbNomMen.SelectedIndex = 0;
                return;
            }
            if (valor == true && cmbNomMen.Text == "")
            {
                cmbNomMen.ValueMember = "NombreOrigen";
                cmbNomMen.DisplayMember = "NombreFormulario";
                cmbNomMen.DataSource = dtMenus;
            }
        }

        void AgrMenu_Rec()
        {
            /******************************************
           * Nombre: "AgrMenu_Rec"
           * Proposito: <consultar los datos de la tabla Men_Agr>
           * Ouptut : <"mostrar los datos en el flexgrid">
           * Creado por: <Ruben C.>
           *****************************************/
            DataTable dtRecMen = menFav.MenFav_Rec(Convert.ToInt16(VarGlo.Instance().CodUsuAct));
            fgMen.DataSource = dtRecMen;
        }
        void AgrMenu_FormatoColumnas()
        {
            fgMen.Cols[2].Visible = false; 

            fgMen.Cols[0].Width = 190; 
            fgMen.Cols[1].Width = 190;

            fgMen.Cols[1].Move(0);
            fgMen.Cols[0].Move(1);
           

            CellStyle style = fgMen.Styles.Add("Nombre formulario de usuario");
            style.BackColor = Color.Gray;
            style.ForeColor = Color.Gold;
            fgMen.Rows[0].Style = style;

            fgMen.BackColor = Color.Gainsboro;
        }

        private void cmbNomMen_MouseHover(object sender, EventArgs e)
        {
            tolTip.Show(cmbNomMen.Text,cmbNomMen);
        }
        
        private void btnAct_Click(object sender, EventArgs e)
        {
         /******************************************
         * Nombre: "boton actulizar"
         * Proposito: <mostrar y validar los formularios abiertos que no esten agregados ya en el grid y en el combo>
         * Ouptut : <"mostrar el menu que no este agregado en el combobox">
         * Creado por: <Ruben C.>
         *****************************************/

            DataTable dtMenus = new DataTable();
            dtMenus.Columns.Add("NombreOrigen");
            dtMenus.Columns.Add("NombreFormulario");
            string nomOriFrm = "";
            string nomOriFg = "";
            bool valor = false;

            foreach (var menu in VarGlo.Instance().frmNuevo.MdiChildren)
            {
                if (menu.Name != "frmFavoritos" & menu.Name != "frmAgrMenu")
                {
                    valor = true;

                    nomOriFrm = menu.Name;

                    bool estado = false;

                    foreach (Row row in fgMen.Rows)
                    {
                        if (row.Index > 0)
                        {
                            nomOriFg = row[1].ToString();

                            if (nomOriFrm == nomOriFg)
                            {
                                estado = true;
                                break;
                            }
                        }
                    }

                    string nomFrm = "";
                    bool frmAbierto = false;

                    if (!estado)
                    {
                        DataRow dr = dtMenus.NewRow();

                        dr[0] = menu.Name;
                        dr[1] = menu.Text;
                     
                        foreach (DataRow row in dtMenus.Rows)
                        {
                           
                            nomFrm = row[0].ToString();

                            if (menu.Name == nomFrm)
                            {
                                frmAbierto = true;
                                break;
                            }
                        }

                        if (!frmAbierto)
                        {
                            dtMenus.Rows.Add(dr);
                        }
                    }
                }
            }

            if (!valor)
            {
                cmbNomMen.ValueMember = "NombreOrigen";
                cmbNomMen.DisplayMember = "NombreFormulario";
                cmbNomMen.DataSource = dtMenus;
                MessageBox.Show("Abra un(a) ventana o módulo para poder añadir al menu favoritos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (dtMenus.Rows.Count > 0)
            {
                cmbNomMen.ValueMember = "NombreOrigen";
                cmbNomMen.DisplayMember = "NombreFormulario";
                cmbNomMen.DataSource = dtMenus;
                cmbNomMen.SelectedIndex = 0;
                return;
            }
            if (valor == true && cmbNomMen.Text == "")
            {
                MessageBox.Show("Los módulos abiertos ya estan en el menú de favoritos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                cmbNomMen.ValueMember = "NombreOrigen";
                cmbNomMen.DisplayMember = "NombreFormulario";
                cmbNomMen.DataSource = dtMenus;
                return;
            }
        }

        private void btnEli_Click(object sender, EventArgs e)
        {
            /******************************************
            * Nombre: "boton eliminar"
            * Proposito: <eliminar los menus seleccionados y los valida que los haya>
            * Ouptut : <"mostrar los menus actualizados">
            * Creado por: <Ruben C.>
            *****************************************/
            if (fgMen.Rows.Count == 1)
            {
                MessageBox.Show("No se encontraron datos para eliminar", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                if (fgMen.IsCellSelected(fgMen.Row, fgMen.Col))
                {
                    string codMen = fgMen.Rows[fgMen.Row][1].ToString();
                    Int16 codUsu = Convert.ToInt16(VarGlo.Instance().CodUsuAct);
                    menFav.MenFav_Eli(codMen, codUsu);
                    fgMen.Rows.Remove(fgMen.Row);
                    AgrMenu_Rec();
                    AgrMenu_FormatoColumnas();
                    btnActMenFav.PerformClick();
                }
            }
        }
        private void fgMen_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col == 0)
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void fgMen_AfterEdit(object sender, RowColEventArgs e)
        {
           /******************************************
            * Nombre: "evento del grid despues de editar"
            * Proposito: <actulizar la celda editada>
            * Ouptut : <"mostrar el nuevo dato actualizado">
            * Creado por: <Ruben C.>
            *****************************************/
            if (e.Col == 0)
            {
                if (string.IsNullOrEmpty(fgMen[e.Row,e.Col].ToString()))
                {
                    MessageBox.Show("Ingrese un nombre","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    fgMen[e.Row, e.Col] = valorCelda;
                    return;
                }

                if (fgMen.IsCellSelected(fgMen.Row,fgMen.Col))
                {
                    AgrMenu_Enc Enc = new AgrMenu_Enc();
                    Enc.CodMen = fgMen.Rows[fgMen.Row][1].ToString();
                    Enc.NomMen = fgMen.Rows[fgMen.Row][0].ToString();
                    Enc.CodUsu = Convert.ToInt16(VarGlo.Instance().CodUsuAct);
                    menFav.MenFav_InsAct(2, Enc);
                    btnActMenFav.PerformClick();
                }
            }
        }

        private void btnAct_MouseHover(object sender, EventArgs e)
        {
            ToolTip mensaje = new ToolTip();
            mensaje.AutoPopDelay = 10000;
            mensaje.ToolTipIcon = ToolTipIcon.Info;
            mensaje.ToolTipTitle = "Mensaje";
            mensaje.UseFading = true;
            mensaje.UseAnimation = true;
            mensaje.IsBalloon = true;
            mensaje.SetToolTip(btnAct, "Muestra todos los formularios abiertos");
        }

        private void btnActMenFav_Click(object sender, EventArgs e)
        {
            /******************************************
            * Nombre: "boton  actulziar menus favoritos"
            * Proposito: <cerrar el formulario  frmPri y volver abrirlo>
            * Ouptut : <"mostrar el formulario frmPri con los menus actualizados o recien agregados">
            * Creado por: <Ruben C.>
            *****************************************/
            foreach (var menu in VarGlo.Instance().frmNuevo.MdiChildren)
            {
                if (menu.Name == "frmFavoritos")
                {
                    menu.Dispose();
                }
            }

            frmFavoritos f = new frmFavoritos();
            f.WindowState = FormWindowState.Normal;
            f.MdiParent = this.MdiParent;
            f.Show();
            f.Location = new System.Drawing.Point(0, 0);
        }

        private void fgMen_StartEdit(object sender, RowColEventArgs e)
        {
            valorCelda = fgMen[e.Row, e.Col].ToString();
        }
    }
}
