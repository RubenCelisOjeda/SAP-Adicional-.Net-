﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;

namespace SAP_Adicional
{
    public partial class frmOPE_Pro_VisGen : Form
    {
        VarGlo varglo = VarGlo.Instance();
        NOPE_Pro nop = new NOPE_Pro();
        int TipoColumna;

        public frmOPE_Pro_VisGen()
        {
            InitializeComponent();
        }

        private void frmOPE_Pro_VisGen_Load(object sender, EventArgs e)
        {
            dgv.Columns.Clear();
            this.dgv.DataSource = nop.OPE_Pro_VisGen(chkVisDet.Checked);
            //dgv_formato(0);
        }

        private void dgv_formato(byte tipo)
        {            
            dgv.RowHeadersVisible = false;
            dgv.Font = new Font("Tahoma", 7);

            if (tipo == 0)
            {
                dgv.Columns[0].Width = 90; //N° Proyecto
                dgv.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv.Columns[1].Width = 500; //Nombre
                dgv.Columns[2].Width = 100; //Estado
                dgv.Columns[3].Width = 100; //Distrito
                dgv.Columns[4].Width = 300; //Direccion
            }
            else
            {                
                dgv.Columns[0].Width = 70; //N° Proyecto
                dgv.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv.Columns[1].Width = 300; //Nombre del proyecto                
                dgv.Columns[2].Width = 50; //RQ
                dgv.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv.Columns[3].Width = 200; //Socio de Negocio
                dgv.Columns[4].Width = 70; //Tipo
                dgv.Columns[5].Width = 100; //Complejidad
                dgv.Columns[6].Width = 60; //Tipo predio.
                dgv.Columns[7].Width = 100; //distrito
                dgv.Columns[8].Width = 100; //estado
                dgv.Columns[9].Width = 70; //inicio de obra
                dgv.Columns[10].Width = 80; //cableado
                dgv.Columns[11].Width = 100; //fecha aprox 
                dgv.Columns[12].Width = 150; //diseño
                dgv.Columns[13].Width = 150; //ing
                dgv.Columns[14].Width = 150; //sup
                dgv.Columns[15].Width = 100; //adm. ped. 
                dgv.Columns[16].Width = 120; //vend
                dgv.Columns[17].Width = 200; //direcion
                dgv.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv.Columns[18].Width = 70; //fecha ingreso
                dgv.Columns[19].Width = 100; //status del proyecto

                dgv.Columns[4].Frozen = true;

            }

        }

        private void btnNuePro_Click(object sender, EventArgs e)
        {
            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 4, "nue", 0) == 1)
            {
                frmOPE_Pro_ingact frm = new frmOPE_Pro_ingact();
                //
                frm.MdiParent = this.MdiParent;

                frm.LimpiarControles();
                frm.Show();
            }
            else
            {
                MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void dgv_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(dgv.Columns[e.ColumnIndex].ValueType == typeof(decimal) ||
                dgv.Columns[e.ColumnIndex].ValueType == typeof(Int16) ||
                dgv.Columns[e.ColumnIndex].ValueType == typeof(Int32) ||
                dgv.Columns[e.ColumnIndex].ValueType == typeof(Int64))
            {//Si es numerico es 1
                TipoColumna = 1;
            }

            if (dgv.Columns[e.ColumnIndex].ValueType == typeof(string))
            {//Si es texto es 2
                TipoColumna = 2;
            }

            if (dgv.Columns[e.ColumnIndex].ValueType == typeof(DateTime))
            {//Si es fecha es 3
                TipoColumna = 3;
            }

            this.lblFiltro.Text = dgv.Columns[e.ColumnIndex].Name;
            this.txtFiltro.Focus();
            
        }

        private void txtFiltro_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (this.lblFiltro.Text == "") return;

            string Filtro;

            Filtro = "";            

            if (e.KeyChar == 13)
            {
                if (TipoColumna == 1)
                {
                    Filtro = "WHERE [" + this.lblFiltro.Text + "] = " + this.txtFiltro.Text;
                }

                if (TipoColumna == 2)
                {
                    Filtro = "WHERE [" + this.lblFiltro.Text + "] LIKE '%" + this.txtFiltro.Text + "%'";
                }

                if (TipoColumna == 3)
                {
                    Filtro = "WHERE [" + this.lblFiltro.Text + "] = '" + this.txtFiltro.Text + "'";
                }

                try
                {
 
                    dgv.DataSource = nop.OPE_Pro_VisGen_Filtro(Filtro, chkVisDet.Checked);
                                       
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message.ToString(),"SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                
            }
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_DoubleClick(object sender, EventArgs e)
        {

            frmOPE_Pro frm = new frmOPE_Pro();
            //
            frm.MdiParent = this.MdiParent;
            frm.txtNumMov.Text = dgv.CurrentRow.Cells[0].Value.ToString();  
            frm.Show();            

        }

        private void btnEdiPro_Click(object sender, EventArgs e)
        {
            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 4, "mod", 0) == 1)
            {
                frmOPE_Pro_ingact frm = new frmOPE_Pro_ingact();

                frm.MdiParent = this.MdiParent;
                frm.txtNumMov.Text = dgv.CurrentRow.Cells[0].Value.ToString();

                frm.Show();
            }        
            else
            {
                MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
}

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkVisDet_CheckedChanged(object sender, EventArgs e)
        {
            dgv.Columns.Clear();
            this.dgv.DataSource = nop.OPE_Pro_VisGen(chkVisDet.Checked);
        }

        private void dgv_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgv_formato(Convert.ToByte(chkVisDet.Checked == true ? 1 : 0));
        }

        private void dgv_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //Referenciamos el control TextBox subyacente en la celda actual.

            TextBox cellTextBox = (DataGridViewTextBoxEditingControl)e.Control;

            cellTextBox.ReadOnly = true;
        }
    }
}
