﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.ALM_Ubi_ConStock;
using Interfaces;
using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;


namespace SAP_Adicional
{
    public partial class frmALM_Ubi_ConStock : Form, IALM_Ubi_ConStock
    {
        private Microsoft.Office.Interop.Excel.Application _excel = new Microsoft.Office.Interop.Excel.Application();
        private NALM_Ubi_ConStock nUs = new NALM_Ubi_ConStock();
        private VarGlo varglo = VarGlo.Instance();
        private byte _tipo = 0;
        private char _tipMov = '0';
        private string _msg = "";
        public static int _est ;
        private int _rowConta = 0;
        private int _contador = 0;
        private int _colConta = 0;

       
        public frmALM_Ubi_ConStock()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.BackColorBtn(this.pnlPri);
            MetGlo.SeleccionTexto(this);
        }
		
        private void ALM_Ubi_ConStock_ConsultaDatos(string vista, string procedimiento, string param,Int16 param2=0)
        {
            /******************************************
            * Nombre: "Consultar datos"
            * Proposito: <Filtrar datos al presionar enter dependiendo de sus parametros y vistas>
            * Ouptut : <Mostrar los datos y asignarlos a los textbox>
            * Creado por: Ruben C.
            *****************************************/

            string stock = "";
            string stockSapAdi = "";
            decimal stockRdn = 0;
            decimal stkRdnSap = 0;
            DataRow row = null;
            DataTable dtFiltro = new DataTable();

            Cursor.Current = Cursors.WaitCursor;

            dtFiltro = nUs.ALM_Ubi_ConStock_Filtros(vista, procedimiento, param, param2);

            if (dtFiltro.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();

                frm.Formulario = 7;
                frm.dg.DataSource = dtFiltro;
                frm.ALM_Ubi_ConStock_Rec = this;
                frm.Text = vista;     
                frm.Vista = vista;
                frm.ShowDialog();

                //Pasar el foco al seleccionar una fila
                if (vista == "Almacen" & this.pnlCon.Visible == true) this.txtCodArtPar.Focus();
                if (vista == "Almacen" & this.pnlCreUbi.Visible == true) this.txtNumDocCon.Focus();
                if (vista == "Almacen" & this.pnlMosTod.Visible == true) this.txtCodArtP2.Focus();
                if (vista == "Articulo" & this.pnlMosTod.Visible == true) this.txtDesArtP2.Focus();
                if (vista == "Articulo2" & this.pnlMosTod.Visible == true) this.txtDesArtP2.Focus();
                if (vista == "Articulo") this.txtCan.Focus();
                if (vista == "Articulo2") this.btnAceCon.Focus();
               

                //Valida la vista 
                if (vista == "Articulo")
                {
                    if (this._tipMov == 'I')
                    {
                        //redondea a entero
                        stock = nUs.ALM_Ubi_ConStock_StoAlm(this.txtCodAlm.Text,this.txtCodArtSap.Text);
                        stockRdn = Math.Floor(Convert.ToDecimal(stock));

                        // valida si hay datos ,si no por defecto 0
                        this.txtSto.Text = stockRdn.ToString() == "" ? "0" : stockRdn.ToString(); 
                    }
                    else
                    {   
                        stockSapAdi = nUs.ALM_Ubi_ConStock_StoUniSapAdi(this.txtCodArtSap.Text,
                                                                           this.txtZon.Text,
                                                                           this.txtRac.Text,
                                                                           this.txtCol.Text, txtFil.Text,
                                                                           this.txtCodAlm.Text);

                        //redondea a entero
                        stkRdnSap = Math.Floor(Convert.ToDecimal(stockSapAdi == "" ? 0 : 
                                               Convert.ToDecimal(stockSapAdi)));

                        this.txtSto.Text = stkRdnSap.ToString();
                        return;
                    }
                }               
            }
            else if (dtFiltro.Rows.Count == 1)
            {
                row = dtFiltro.Rows[0];

                //Obtiene los focos al ingrsar el dato 
                if (vista == "Almacen" && this.pnlCreUbi.Visible == true)
                {
                    this.txtNumDocCon.Focus(); return;
                }
                if (vista == "Almacen" & this.pnlCon.Visible == true)
                {
                    this.txtCodArtPar.Focus(); return;
                }
                if (vista == "Articulo2" & this.pnlCon.Visible == true)
                {
                    this.txtDesArtPar.Focus(); return;
                }
                if (vista == "Articulo2" & this.pnlMosTod.Visible == true)
                {
                    this.txtDesArtP2.Focus(); return;
                }
                if (vista == "Almacen" & this.pnlMosTod.Visible == true)
                {
                    this.txtCodArtP2.Focus(); return;
                }

                switch (vista)
                {
                    case "Almacen":
                        this.txtDesAlm.Text = row["Almacen"].ToString();
                        this.txtNumDocCon.Focus();
                        break;

                    case "Corte":
                        this.txtCodAlm.Text = row["Codigo"].ToString();
                        this.txtDesAlm.Text = row["Descripcion"].ToString();

                        break;
                    case "Articulo":
                        this.txtCodArtSap.Text = row["Codigo"].ToString();
                        this.txtCodXtr.Text = row["CodXtrazzo"].ToString();
                        this.txtDesArt.Text = row["Descripcion"].ToString();
                        this.txtCan.Focus();
                        break;

                    case "Articulo2":
                        this.txtCodArtPar.Text = row["Codigo"].ToString();
                        this.txtDesArtPar.Text = row["Descripcion"].ToString();
                        this.btnAceCon.Focus();

                        break;
                    case "Instalador":
                        this.txtCodArtPar.Text = row["Codigo"].ToString();
                        this.txtDesArtPar.Text = row["Instalador"].ToString();

                        break;

                    default:
                        break;
                }
            }
            else if (dtFiltro.Rows.Count == 0)
            {
                this.ALM_UbiConStock_MosMsgStrip("No se encontraron registros.", Color.Red);
                this.txtDesAlm.Focus();
            }

            Cursor.Current = Cursors.Default;
        }

        private void ALM_UbiConStock_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }

        private void frmALM_Ubi_ConStock_Load(object sender, EventArgs e)
        {
            this.txtFec.Text = DateTime.Now.Date.ToShortDateString();
            this.ALM_Ubi_ConStock_SoloLectura();
            this._tipMov = 'I';
        }

        private void ALM_Ubi_ConStock_SoloLectura()
        {
            //Muestra el panel principal en todo el formulario
            this.pnlPri.Visible = true;
            this.pnlPri.Dock = DockStyle.Fill;

            //solo lectura articulo                 
            this.txtCodAlm.ReadOnly = true;         
            this.txtFec.ReadOnly = true;            
            this.txtCan.ReadOnly = true;           
            this.txtSto.ReadOnly = true;            
            this.txtObs.ReadOnly = true;
            this.txtCodRes.ReadOnly = true;

            //deshabilitas los textbox
            this.txtCodArtSap.Enabled = false;
            this.txtCodXtr.Enabled = false;
            this.btnLeeUbi.Enabled = false;
            this.txtDesArt.Enabled = false;

            //solo lectura ubicacion
            this.txtZon.ReadOnly = true;
            this.txtRac.ReadOnly = true;
            this.txtCol.ReadOnly = true;
            this.txtFil.ReadOnly = true;

            //parametro
            this.txtCodAlmP.ReadOnly = true;
            this.txtCodAlmP2.ReadOnly = true;
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            //oculta el panel de parametro consulta
            this.gpbParCon.Visible = false;
            this.pnlCreUbi.Enabled = true;
            this.fgUbi.Enabled = true;
        }

        public void recdat_ALM_Ubi_ConStock_Alm(string CodAlm, string DesAlm)
        {
            //datos de la interface

            if (this.pnlCreUbi.Visible == true)
            {
                this.txtCodAlm.Text = CodAlm;
                this.txtDesAlm.Text = DesAlm;
                this.txtDesAlm.ForeColor = Color.Black;
            }
            
            //Valida para obtener el foco
            if (this.pnlCon.Visible == true)
            {
                this.txtCodAlmP.Text = CodAlm;
                this.txtDesAlmP.Text = DesAlm;
            }

            //Valida para obtener el foco
            if (this.pnlMosTod.Visible == true)
            {
                this.txtCodAlmP2.Text = CodAlm;
                this.txtDesAlmP2.Text = DesAlm;
            }
        }

        public void recdat_ALM_Ubi_ConStock_Art2(string CodArt, string DesArt)
        {
            //datos de la interface
            this.txtCodArtPar.Text = CodArt;
            this.txtDesArtPar.Text = DesArt;
            this.txtDesArtPar.ForeColor = Color.Black;

            //Valida para obtener el foco
            if (this.pnlMosTod.Visible == true)
            {
                this.txtCodArtP2.Text = CodArt;
                this.txtDesArtP2.Text = DesArt;
                this.txtDesArtP2.ForeColor = Color.Black;
            }
        }

        public void recdat_ALM_Ubi_ConStock_Res(string CodRes, string DesRes)
        {
            //datos de la interface
            this.txtCodRes.Text = CodRes;
            this.txtDesRes.Text = DesRes;
            this.txtDesRes.ForeColor = Color.Black;
        }

        public void recdat_ALM_Ubi_ConStock_Art(string CodSap, string CodXtr,string DestArt)
        {
            //datos de la interface
            this.txtCodArtSap.Text = CodSap;
            this.txtCodXtr.Text = CodXtr;
            this.txtDesArt.Text = DestArt;

            //cambia el color al formato normal cuando hay dato 
            if (this.txtCodArtSap.Text != "" || this.txtCodXtr.Text != "" || this.txtDesArt.Text != "")
            {
                this.txtCodArtSap.ForeColor = Color.Black;
                this.txtCodXtr.ForeColor = Color.Black;
                this.txtDesArt.ForeColor = Color.Black;
                this.txtCan.Focus();
            }
            else
            {
                this.txtCodArtSap.ForeColor = Color.DimGray;
                this.txtCodXtr.ForeColor = Color.DimGray;
                this.txtDesArt.ForeColor = Color.DimGray;
            }
        }

        private void ALM_Ubi_ConStock_ForCol(C1FlexGrid fg)
        {
            //formato de las columnas del grid ubicacion

            //tamaño columnas
            if (fg.Rows.Count > 1)
            {
                fg.Cols["N° Mov"].Width = 50;
                fg.Cols["Tipo"].Width = 60;
                fg.Cols["Zona"].Width = 30;
                fg.Cols["Rack"].Width = 30;
                fg.Cols["Columna"].Width = 50;
                fg.Cols["Fila"].Width = 30;
                fg.Cols["Articulo"].Width = 500;
                fg.Cols["Cant"].Width = 50;
                fg.Cols["obs"].Width = 250;
                fg.Cols["Serie"].Width = 30;
                fg.Cols["Encargado Serie"].Width = 150;
                fg.Cols["RQ"].Width = 40;
                fg.Cols["Creado"].Width = 120;
                fg.Cols["Modificado"].Width = 120;

                //nombre
                fg.Cols["obs"].Caption = "Obs";

                //formato de columna
                fg.Cols["Cant"].Format = "0.0";
                fg.Cols["Creado"].Format = "dd-MM-yyyy HH:mm:ss";
                fg.Cols["Modificado"].Format = "dd-MM-yyyy HH:mm:ss";

                //visible 
                fg.Cols["CodEst"].Visible = false;

                //Tipo de dato
                //fg.Cols["Comprometido"].Style.DataType = typeof(decimal);
            }
        }
        private void btnExp_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(this.fgUbi, this.Text);
        }
        private void btnMosCru_Click(object sender, EventArgs e)
        {
            //muestra el panel del cruze 
            this.pnlCru.Visible = true;
            this.pnlCru.Dock = DockStyle.Fill;
        }

        private void btnExpCru_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(this.fgCru, this.Text);
        }

        private void ALM_Ubi_ConStock_FormaFgCruce()
        {
            //formato de las columnas del grid cruze
            if (fgCru.Rows.Count > 1)
            {
                //tamaño de columnas
                this.fgCru.Cols["Column1"].Width = 500;
                this.fgCru.Cols["Almacen"].Width = 50;
                this.fgCru.Cols["zona"].Width = 30;
                this.fgCru.Cols["rack"].Width = 30;
                this.fgCru.Cols["Columna"].Width = 50;
                this.fgCru.Cols["Fila"].Width = 40;
                this.fgCru.Cols["Stock Ubi"].Width = 60;
                this.fgCru.Cols["Stock Ubi Tot"].Width = 75;
                this.fgCru.Cols["Stock SAP"].Width = 70;

                //nombre de columna
                this.fgCru.Cols["codart"].Caption = "Codigo";
                this.fgCru.Cols["Column1"].Caption = "Descripción";

                //formato de columna
                this.fgCru.Cols["Stock Ubi"].Format = "0.##";
                this.fgCru.Cols["Stock Ubi Tot"].Format = "0.##";
                this.fgCru.Cols["Stock SAP"].Format = "0.##";
            }
        }

        private void fgCru_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.ALM_Ubi_ConStock_FormaFgCruce();
            this.ALM_Ubi_ConStock_FormatoGeneralFg(this.fgCru);
        }

        private void ALM_Ubi_ConStock_FormatoGeneralFg(C1FlexGrid fg)
        {
            //formato general del frid cruze
            if (fg.Rows.Count > 1)
            {
                fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                fg.VisualStyle = VisualStyle.Office2010Silver;
                fg.Styles.Alternate.BackColor = Color.LightBlue;
                fg.Styles.Highlight.BackColor = Color.Blue;
                fg.Styles.Highlight.ForeColor = Color.White;
                fg.AllowFreezing = AllowFreezingEnum.Both;
            }
        }

        private void btnCer_Click(object sender, EventArgs e)
        {
            this.pnlCru.Visible = false;
        }

        private void ALM_Ubi_ConStock_HabArt(bool Est)
        {
            //habilita  o deshabilita los controles
            this.txtCodArtSap.Enabled = Est;
            this.txtCodXtr.Enabled = Est;
            this.txtDesArt.Enabled = Est;
            this.txtCan.ReadOnly = !Est;
            this.txtObs.ReadOnly = !Est;
        }
        private void ALM_Ubi_ConStock_LimTextArt()
        {
            //limpia los controls del grupo de articulos
            foreach (Control c in this.gpbArt.Controls)
            {
                if (c is TextBox)
                {
                    c.Text = "";
                }
            }

            //Limpia otros texto y muestras los textos predeterminados
            this.cboSer.Text = "";
            this.txtCodAlm.Text = "";
            this.txtDesAlm.Text = "";
            this.ALM_Ubi_ConStock_TexPre();
        }

        private void ALM_Ubi_ConStock_TexPre()
        {
            //texto predeterminado y formato
            this.txtCodArtSap.Text = "(Código SAP)";
            this.txtCodXtr.Text = "(Código Xtrazzo)";
            this.txtDesAlm.Text = "Presione enter o ingrese un almacén";
            this.txtDesRes.Text = "Presione enter o ingrese un responsable";
            this.txtFec.Text = DateTime.Now.ToShortDateString();
            this.mskFecLle.Text = "";
            this.txtCodArtSap.ForeColor = Color.DimGray;
            this.txtCodXtr.ForeColor = Color.DimGray;
            this.txtDesAlm.ForeColor = Color.DimGray;
            this.txtDesRes.ForeColor = Color.DimGray;
        }
        private void btnAceCon_Click(object sender, EventArgs e)
        {
            /******************************************
           * Nombre: "Aceptar consulta"
           * Proposito: <Consultar los articulos con las fechas seleccionadas o los filtros por codigo y
           * descripcion> 
           * Ouptut : <>
           * Creado por: Ruben C.
           *****************************************/

            _tipo = 0;
            DataTable dtRecMovDia = null;

            //valida la fecha que no sea mayor a la final
            if (this.dtpFecIni.Value.Date > this.dtpFecFin.Value.Date)
            {
                _msg = "La fecha inicial no debe ser mayor a la final.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.DodgerBlue);

            }
            //valida la fecha final no sea mayor a la actual
            else if (this.dtpFecFin.Value.Date > DateTime.Now.Date)
            {
                _msg = "La fecha final no debe ser mayor a la actual.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.DodgerBlue);
            }
            else
            {
                //obtiene el tipo de acuerdo a lo seleccionado
                if (this.chkIncEli.Checked == false)
                {
                    if (this.chkSolArt.Checked == false)
                    {
                        if (this.txtCodArtPar.Text == "") _tipo = 0;
                        else _tipo = 1;
                    }
                    else
                    {
                        _tipo = 6;
                    }
                }
                else
                {
                    if (this.chkSolArt.Checked == false)
                    {
                        if (this.txtCodArtPar.Text == "") _tipo = 3;
                        else _tipo = 2;
                    }
                    else
                    {
                        _tipo = 7;
                    }
                }

                //ejecuta la consulta para obtener los articulos 
                dtRecMovDia = nUs.ALM_Ubi_ConStock_RecMovDia(this.dtpFecIni.Value.Date,
                                                                this.dtpFecFin.Value.Date,
                                                                this.txtCodAlmP.Text,
                                                                _tipo,
                                                                this.txtCodArtPar.Text);

                //valia si hay articulos de acuerdo a al fecha
                if (dtRecMovDia.Rows.Count > 0)
                {
                    this.fgUbi.DataSource = dtRecMovDia;
                    this.gpbParCon.Visible = false;
                    this.pnlCreUbi.Enabled = true;
                    this.fgUbi.Enabled = true;
                }
                else
                {
                    //limpia el grid
                    DataTable dtClear = new DataTable();
                    dtClear.Clear();
                    this.fgUbi.DataSource = dtClear;

                    _msg = "No se encontraron datos.";
                    this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
                }
            }
        }

        private void fgUbi_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //No permite ingresar datos al grid
            if (e.Col != 18)
            {
                if (e.KeyChar != 3 | e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void chkSolArt_CheckedChanged(object sender, EventArgs e)
        {
            //ocula el panel de fechas  si se selecciono por  solo articulo
            if (this.chkSolArt.Checked)
            {
                this.pnlFec.Visible = false;
            }
            else
            {
                this.pnlFec.Visible = true;
            }
        }

        private void fgCru_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //no permite ingresar datos en el grid
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void ALM_Ubi_ConStock_EveKeyPre(Control Ctr, KeyPressEventArgs e)
        {
            //evento key press para los textbox que permite pasar al otro control
            if (e.KeyChar == (char)13)
            {
                Ctr.Focus();
            }
        }

        private void rdbIng_CheckedChanged(object sender, EventArgs e)
        {
            //valida si ha sido seleccionado el tipo de movimiento
            if (this.rdbIng.Checked)
            {
                this._tipMov = 'S';
            }
        }

        private void rdbSal_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdbIng.Checked)
            {
                this._tipMov = 'I';
            }
        }

        private void fgUbi_KeyDown(object sender, KeyEventArgs e)
        {
            /******************************************
            * Nombre: "borrar articulo"
            * Proposito: <Valida la fila seleccionada para poder borrar con el numero de movimiento>
            * Ouptut : <>
            * Creado por: Ruben C.
            *****************************************/

            int numMov = 0;
            DialogResult msg = 0;

            //valida que sea seleccionado uan fila y se haya presionado suprimir para poder borrar la fila
            if (this.fgUbi.IsCellSelected(this.fgUbi.Row, this.fgUbi.Col) & e.KeyCode == Keys.Delete)
            {
               
                msg = MessageBox.Show("¿Esta seguro de eliminar este item?", "Mensaje del sistema",
                                                 MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                //valida la respuesta
                if (msg == DialogResult.Yes)
                {
                    numMov = (int)this.fgUbi.Rows[this.fgUbi.Row][0];
                    this.nUs.ALM_Ubi_ConStock_EliArt(varglo.CodUsuAct,DateTime.Now,numMov);
                    this.fgUbi.Rows.Remove(this.fgUbi.RowSel);
                    this.ALM_UbiConStock_MosMsgStrip("Se elimino correctamente.",Color.Green);
                }
            }
        }

        private void btnMosCom_Click(object sender, EventArgs e)
        {
            /******************************************
            * Nombre: "Mostrar comparacion de saldos"
            * Proposito: <Validar y recuperar  la comparaciuon de los datos dependiente del tipo seleccionado>
            * Ouptut : <>
            * Creado por: Ruben C.
            *****************************************/

            Cursor.Current = Cursors.WaitCursor;

            DataTable dtArt = null;

            //se ejecuta la consulta cuando se selecciono algun tipo de comparacion
            if (this.cboCom.SelectedIndex >= 0)
            {
                dtArt = nUs.ALM_Ubi_ConStock_RecTipArt(Convert.ToInt16(this.cboCom.SelectedIndex));
            }

            //valida si no selecciono ningun tipo de comparacion
            if (this.cboCom.SelectedIndex == -1)
            {
                this._msg = "Seleccione un tipo.";
                this.ALM_UbiConStock_MosMsgStrip(this._msg,Color.Red);
                this.cboCom.Focus();
            }
            //valida si no se encontraron datos del tipo de comparacion y limpia el grid
            else if(dtArt.Rows.Count == 0)
            {
                this._msg = "No se encontraron datos.";
                this.ALM_UbiConStock_MosMsgStrip(this._msg, Color.Red);

                DataTable dtClear = null;
                dtClear.Clear();

                this.fgCru.DataSource = dtClear;
                this.btnMosCom.Focus();
            }
            else
            {
                /*pone el style para poder agregar margenes grupal  a la columna 0-8-9 y recupera 
                  los datos en el grid del tipo seleccionado*/

                this.fgCru.Styles.Normal.WordWrap = true;
                this.fgCru.AllowMerging = AllowMergingEnum.Free;

                this.fgCru.DataSource = dtArt;

                this.fgCru.Cols[0].AllowMerging = true;
                this.fgCru.Cols[8].AllowMerging = true;
                this.fgCru.Cols[9].AllowMerging = true;
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnExpCom_Click(object sender, EventArgs e)
        {
            //Valia que solo exporta sin grafico la ultima opcion
            if (this.cboCom.SelectedIndex == 2)
            {
                this.ALM_Ubi_ConStock_ExpExcel(this.fgCru);
            }
            else
            {
                MetGlo.ExportarExcel(this.fgCru,this.Text);
            }
        }

        public  void ALM_Ubi_ConStock_ExpExcel(C1FlexGrid fg)
        {
            int rowMax = fg.Rows.Count;
            int colMax = fg.Cols.Count;
            decimal porcentajeInc = 0;

            frmPri f = (frmPri)this.MdiParent;
           
            //Solo hara al inicio
            if (_rowConta == 0)
            {
                this.tslPgbUbi.Visible = true;
                this.tslPgbUbi.Maximum = this.fgCru.Rows.Count;
                this.tslPgbUbi.Visible = true;
                this.btnPauExp.Visible = true;
                this.btnCanExp.Visible = true;
                this.tslPgbUbi.Value = 0;
                _excel.Application.Workbooks.Add(true);
            }

            //Recorre las filas
            for (int row = _rowConta; row < rowMax; row++)
            {
                _colConta = 0;

                //Recorre las columnas
                for (int col = 0; col < colMax; col++)
                {
                    _contador++;
                      
                    //Incrementa la barra de progreso
                    this.tslPgbUbi.Value = _rowConta;

                    //Va contando el progreso en porcentaje
                    porcentajeInc = (decimal)_contador / (rowMax * colMax);
                    this.lblPor.Text = ((int)(porcentajeInc * 100)).ToString() + "%";

                    //Añade las filas a al hoja de excel
                    _excel.Cells[_rowConta + 1, _colConta + 1] = fg.Rows[row][col].ToString();

                    _colConta++;
                }

                _rowConta++;
                Application.DoEvents();

                //pausa la exportacion
                if (_est == 2)
                {
                    break;
                }
                if (_est == 1)
                {
                    return;
                }
            }

            //Cuando llegue al valor maximo se deshabilita
            if (this.tslPgbUbi.Maximum == _rowConta)
            {
                _excel.Visible = true;

                _est = 1;
                _rowConta = 0;
                _colConta = 0;
                _contador = 0;

                this.tslPgbUbi.Value = 0;
                this.lblPor.Text = "";
                this.btnPauExp.Text = "Pausar";
                this.tslPgbUbi.Visible = false;
                this.btnPauExp.Visible = false;
                this.btnCanExp.Visible = false;
            }
        }

        private void txtCodArtPar_KeyPress(object sender, KeyPressEventArgs e)
        {
            //filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo2", "[Filtro_3Articulo]", this.txtCodArtPar.Text.Trim(), 1);
                this.txtDesArtPar.Focus();
            }
        }

        private void txtDesArtPar_KeyPress(object sender, KeyPressEventArgs e)
        {
            //filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo2", "[Filtro_3Articulo]", this.txtDesArtPar.Text.Trim(), 2);
                this.btnAceCon.Focus();
            }
        }

        private void btnPauExp_Click(object sender, EventArgs e)
        {
            //Cambia el nombre del texto y estado para pausar o renaudar
            if (this.btnPauExp.Text == "Pausar")
            {
                this.btnPauExp.Text = "Renaudar";
                _est = 2;
                return;
            }
            if (this.btnPauExp.Text == "Renaudar")
            {
                _est = 0;
                this.btnPauExp.Text = "Pausar";
                this.btnExpCom.PerformClick();
            }
        }

        private void btnCanExp_Click(object sender, EventArgs e)
        {
            //Cancela la el recorrdigo del grid y la barra de progreso
            if (this.btnCanExp.Text == "Cancelar")
            {
                _est = 1;
                _rowConta = 0;
                _colConta = 0;
                _contador = 0;

                this.tslPgbUbi.Value = 0;
                this.lblPor.Text = "";
                
                this.btnPauExp.Text = "Pausar";
                this.tslPgbUbi.Visible = false;
                this.btnPauExp.Visible = false;
                this.btnCanExp.Visible = false;
            }
        }

        private void btnCreUbiP_Click(object sender, EventArgs e)
        {
            this.pnlOpcTipMov.Visible = true;
            this.rdbIngP.Checked = false;
            this.rdbSalP.Checked = false;
            this.lblPre.Visible = false;
        }

        private void btnMosCruP_Click(object sender, EventArgs e)
        {
            this.pnlPri.Visible = false;
            this.pnlCru.Visible = true;
            this.pnlCru.Dock = DockStyle.Fill;
        }

        private void btnCanMov_Click(object sender, EventArgs e)
        {
            this.pnlOpcTipMov.Visible = false;

            //Habilitar botones
            this.ALM_UbiConStock_HabBtnsPri(true);
            this.lblPre.Visible = true;
        }

        private void ALM_UbiConStock_HabBtnsPri(bool isHab)
        {
            //Habilita o deshabilita los botones
            foreach (Control c in this.pnlPri.Controls)
            {
                if(c is Button) c.Enabled = isHab;
            }
        }

        private void btnAceMov_Click(object sender, EventArgs e)
        {
            //valida que seleccione un tipo de movimiento
            if (this.rdbIngP.Checked)
            {
                this.rdbIng.Checked = true;
                this.rdbSal.Visible = false;
                this.pnlCreUbi.Visible = true;
                this.pnlCreUbi.Dock = DockStyle.Fill;
            }
            else if (this.rdbSalP.Checked)
            {
                this.rdbSal.Checked = true;
                this.rdbIng.Visible = false;
                this.rdbSal.Visible = true;
                this.pnlCreUbi.Visible = true;
                this.pnlCreUbi.Dock = DockStyle.Fill;
            }
            else
            {
                this.ALM_UbiConStock_MosMsgStrip("Seleccione un tipo de movimiento.", Color.DodgerBlue);
                return;
            }

            this.pnlPri.Visible = false;
        }

        private void btnMosTodP_Click(object sender, EventArgs e)
        {
            this.pnlPri.Visible = false;
            this.pnlMosTod.Visible = true;
            this.pnlMosTod.Dock = DockStyle.Fill;
        }

        private void btnAgrUbi_Click(object sender, EventArgs e)
        {
            /******************************************
           * Nombre: "Agregar item"
           * Proposito: <Validar el codigo de almacen ,la cantidad que no sea mayor al stock y 
           * seleccionar un serie si el codigo de almacen es DT>
           * Ouptut : <"Mostrar el articulo agregado en el grid">
           * Creado por: Ruben C.
           *****************************************/

            string can = ""; string stock = ""; DataTable dtRecUbi = null;

            //valida que ingrese un codigo de almacen

            if (this.txtCodAlm.Text == "")
            {
                this._msg = "Ingrese un almacén.";
                this.ALM_UbiConStock_MosMsgStrip(this._msg, Color.Red);
                this.txtDesAlm.Focus();
                return;
            }
            if (this.txtCodArtSap.Text == "(Código SAP)")
            {
                this._msg = "Ingrese un articulo.";
                this.ALM_UbiConStock_MosMsgStrip(this._msg, Color.Red);
                this.txtCodArtSap.Focus();
                return;
            }
            if (txtZon.Text == "" | txtRac.Text == "" | txtCol.Text == "" | txtFil.Text == "")
            {
                this._msg = "Ingrese la ubicacion completa.";
                this.ALM_UbiConStock_MosMsgStrip(this._msg, Color.Red);
                this.txtZon.Focus();
                return;
            }
            //valida el codigo del almacen si se ingreso difente al DT - DIF- AHI
            if (this.txtCodAlm.Text != "DT" | this.txtCodAlm.Text != "DIF" | this.txtCodAlm.Text != "AHI")
            {
                //valida el campo de texto si esta vacio
                can = this.txtCan.Text == "" ? "0" : this.txtCan.Text;
                stock = this.txtSto.Text == "" ? "0" : this.txtSto.Text;

                //valida que el stock no sea menor a la cantidad ingresada
                if (Convert.ToDecimal(stock) < Convert.ToDecimal(can))
                {
                    this._msg = "No puede ingresar una cantidad mayor a la que indica el campo stock.";
                    this.ALM_UbiConStock_MosMsgStrip(this._msg, Color.DodgerBlue);

                    this.txtCan.Focus();
                    return;
                }
            }

            //valida si se encuentra el articulo en SAP
            if (MetGlo.ValCodArtGen_Sap(this.txtCodArtSap.Text, varglo.BaseSAP) == false)
            {
                this._msg = "No se encontro el artículo seleccionado,verifique que el codigo este correcto.";
                this.ALM_UbiConStock_MosMsgStrip(this._msg, Color.DodgerBlue);
                this.txtCodArtSap.Focus();
                return;
            }
            //valida que ingrese una cantidad
            if (this.txtCan.Text == "")
            {
                _msg = "Ingrese una cantidad.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
                this.txtCan.Focus();
                return;
            }
            //valida que cuando el stock sea 0 pueda ingresar la cantidad 0
            if (this.txtCan.Text == "0" & Convert.ToInt32(stock) > 0)
            {
                _msg = "La cantidad no es válida.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
                this.txtCan.Focus();
                return;
            }
            //valida cuande se ingreso el codigo de almacen DT se ingrese una serie y un correlativo
            if (this.txtCodAlm.Text == "DT" & this.cboSer.Text == "" || this.txtNumCor.Text == "0")
            {
                _msg = "Debe agregar una serie para los movimientos del almacen DT.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
                this.cboSer.Focus();
                return;
            }
            //valida el rq ingresado del SAP
            if (this.txtRq.Text != "")
            {
                if (MetGlo.ValRqGenSap(this.txtRq.Text, varglo.BaseSAP) == false)
                {
                    _msg = "El rq ingresado es inválido.";
                    this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
                    this.txtRq.Focus();
                    return;
                }
            }

            //asignamos los valores a la entidad 
            ALM_Ubi_ConStock_Enc Ubi = new ALM_Ubi_ConStock_Enc
            {
                CodArtSap = this.txtCodArtSap.Text,
                Can = this.txtCan.Text,
                TipMov = this._tipMov,
                Zon = this.txtZon.Text,
                Rac = this.txtRac.Text,
                Col = this.txtCol.Text,
                Row = this.txtFil.Text,
                CodAlm = this.txtCodAlm.Text,
            };

            //ejecutamos la consulta de busqueda
            nUs.ALM_Ubi_ConStock_ValMovStkFin(Ubi);

            //asignamos los valores a la entidad 
            ALM_Ubi_ConStock_Enc InsUbi = new ALM_Ubi_ConStock_Enc
            {
                CodAlm = this.txtCodAlm.Text,
                Zon = this.txtZon.Text,
                Rac = this.txtRac.Text,
                Col = this.txtCol.Text,
                Row = this.txtFil.Text,
                CodArtSap = this.txtCodArtSap.Text,
                TipMov = this._tipMov,
                Can = this.txtCan.Text,
                Obs = this.txtObs.Text,
                CodUsu = Convert.ToInt16(varglo.CodUsuAct),

                NumDocCon = Convert.ToInt32(string.IsNullOrEmpty(this.txtNumDocCon.Text) ? null :
                                                                 this.txtNumDocCon.Text),

                NumSer = this.cboSer.Text,
                NumCorr = this.txtNumCor.Text == "" ? "0" : this.txtNumCor.Text,
                Rq = this.txtRq.Text,
                FecLle = this.mskFecLle.Text,
                CodRes = this.txtCodRes.Text == "" ? "0" : this.txtCodRes.Text,
            };

            //Guardamos la ubicacion
            nUs.ALM_Ubi_ConStock_InsMov(InsUbi);

            //ejecuta la consulta para obtener los articulos  ingresado recientemente
            dtRecUbi = nUs.ALM_Ubi_ConStock_MosMovDia(this.dtpFecIni.Value.Date,
                                                      this.dtpFecFin.Value.Date,
                                                      this.txtCodAlm.Text,
                                                      0,
                                                      this.txtCodArtPar.Text);

            this.ALM_UbiConStock_MosMsgStrip("Se agrego correctamente.", Color.Green);
            this.ALM_Ubi_ConStock_LimTextArt();
        }

        private void txtDesAlm_KeyPress(object sender, KeyPressEventArgs e)
        {
            //filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Almacen", "[Filtro_Almacenes]", this.txtDesAlm.Text.Trim());

                //habilita los textox si hay un CodAlm
                if (this.txtDesAlm.Text != "")
                {
                    this.txtZon.ReadOnly = false;
                    this.txtRac.ReadOnly = false;
                    this.txtCol.ReadOnly = false;
                    this.txtFil.ReadOnly = false;
                    this.btnLeeUbi.Enabled = true;
                }
            }
        }

        private void txtZon_KeyPress(object sender, KeyPressEventArgs e)
        {
            //pasa el foco al siguiente campo al presionar enter
            this.ALM_Ubi_ConStock_EveKeyPre(this.txtRac, e);

            //detecta la tecla control
            if (char.IsControl(e.KeyChar))
            {
                return;
            }
        }

        private void txtZon_TextChanged(object sender, EventArgs e)
        {
            //obtiene el foco del sigueinte textbox depues de ingresar un dato
            string zon = "";
            zon = this.txtZon.Text;

            if (zon.Length == 2)
            {
                this.txtRac.Focus();
            }
        }

        private void txtRac_KeyPress(object sender, KeyPressEventArgs e)
        {
            //pasa al otro control presionando enter
            if (e.KeyChar == (char)13)
            {
                this.txtCol.Focus();
                return;
            }

            //pasa al anterior textox al borrar el dato
            if (char.IsControl(e.KeyChar) & this.txtFil.Text == "")
            {
                this.txtZon.Focus();
            }

            //retorna si no hay datos
            if (char.IsControl(e.KeyChar))
            {
                return;
            }
        }

        private void txtRac_TextChanged(object sender, EventArgs e)
        {
            //obtiene el foco del sigueinte textbox depues de ingresar un dato
            string rac = "";
            rac = this.txtRac.Text;

            if (rac.Length == 1)
            {
                this.txtCol.Focus();
            }
        }

        private void txtCol_KeyPress(object sender, KeyPressEventArgs e)
        {
            //pasa al otro control presionando enter
            if (e.KeyChar == (char)13)
            {
                this.txtFil.Focus();
                return;
            }

            //pasa al anterior textox al borrar el dato
            if (char.IsControl(e.KeyChar) & this.txtFil.Text == "")
            {
                this.txtRac.Focus();
            }

            //retorna si no hay datos
            if (char.IsControl(e.KeyChar))
            {
                return;
            }
        }

        private void txtCol_TextChanged(object sender, EventArgs e)
        {
            //obtiene el foco del sigueinte textbox depues de ingresar un dato
            string col = "";
            col = this.txtCol.Text;
            if (col.Length == 1)
            {
                this.txtFil.Focus();
            }
        }

        private void txtFil_KeyPress(object sender, KeyPressEventArgs e)
        {
            //pasa al otro control presionando enter
            if (e.KeyChar == (char)13)
            {
                this.btnLeeUbi.Focus();
                return;
            }

            //retorna si no hay datos
            if (char.IsControl(e.KeyChar))
            {
                this.txtCol.Focus();
                return;
            }
        }

        private void txtFil_TextChanged(object sender, EventArgs e)
        {
            string fil = "";
            fil = this.txtFil.Text;

            if (fil.Length == 1)
            {
                this.btnLeeUbi.Focus();
            }
        }

        private void btnLeeUbi_Click(object sender, EventArgs e)
        {
            /******************************************
           * Nombre: "Leer ubicación"
           * Proposito: <Validar la ubicación si existe ZONA-RACK-COL-ROW>
           * Ouptut : <>
           * Creado por: Ruben C.
           *****************************************/
            bool valTxt = false;
            DataTable dtRecUbi = null;

            //ejecuta la consulta de ubicacion del articulo de SAP
            dtRecUbi = nUs.ALM_Ubi_ConStock_ValUbi(0,
                                                   this.txtCodAlm.Text,
                                                   this.txtZon.Text,
                                                   this.txtRac.Text,
                                                   this.txtCol.Text,
                                                   this.txtFil.Text,
                                                   'F');

            //Valida si no ingreso un codigo de almacen
            if (this.txtCodAlm.Text == "")
            {
                this._msg = "Seleccione un almacén para obtener ubicaciones.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
                this.txtDesAlm.Focus();
                return;
            }

            //Valida si no completo la ubicacion del articulo de SAP
            if (this.txtZon.Text == "")
            {
                this.txtZon.Focus();
                valTxt = true;
            }
            else if (this.txtRac.Text == "")
            {
                this.txtRac.Focus();
                valTxt = true;
            }
            else if (this.txtCol.Text == "")
            {
                this.txtCol.Focus();
                valTxt = true;
            }
            else if (this.txtFil.Text == "")
            {
                this.txtFil.Focus();
                valTxt = true;
            }

            //Valida y Muestra el mensaje de error
            if (valTxt)
            {
                this.ALM_UbiConStock_MosMsgStrip("Debe completa la ubicación.", Color.Red);
                return;
            }

            //Valida si no encontro la ubicacion del articulo de SAP
            if (dtRecUbi.Rows.Count == 0)
            {
                _msg = "La ubicación ingresada es inválida.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);

                this.ALM_Ubi_ConStock_LimTextArt();
                this.ALM_Ubi_ConStock_HabArt(false);
                this.btnLeeUbi.Focus();
            }
            else
            {
                //Habilita los campos del articulo
                this.ALM_Ubi_ConStock_HabArt(true);
                this.txtCodArtSap.Focus();
            }
        }

        private void txtCodArtSap_KeyPress(object sender, KeyPressEventArgs e)
        {
            //filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo", "[Filtro_3Articulo]", this.txtCodArtSap.Text.Trim(), 1);
            }
        }

        private void txtCodXtr_KeyPress(object sender, KeyPressEventArgs e)
        {
            //filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo", "[Filtro_3Articulo]", this.txtCodXtr.Text.Trim(), 4);
            }
        }

        private void txtDesArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            //filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo", "[Filtro_3Articulo]", this.txtDesArt.Text.Trim(), 2);
            }
        }

        private void txtDesRes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Instalador", "[Filtro_Operaciones]", this.txtDesRes.Text.Trim());
                this.mskFecLle.Focus();
            }
        }

        private void txtNumDocCon_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite ingresar solo numeros enteros
            if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            this.ALM_Ubi_ConStock_EveKeyPre(this.txtZon, e);
        }

        private void txtCan_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite ingresar numero y decimal con un punto
            if (Char.IsDigit(e.KeyChar) || Char.IsControl(e.KeyChar) || Char.IsSeparator(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (e.KeyChar == '.' && !this.txtCan.Text.Contains(".")) //verifica si hay un punto decimal
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            this.ALM_Ubi_ConStock_EveKeyPre(this.txtObs, e);
        }

        private void txtObs_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.cboSer, e);
        }

        private void cboSer_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.txtNumCor, e);
        }

        private void txtNumCor_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite ingresar solo numeros enteros
            if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            this.ALM_Ubi_ConStock_EveKeyPre(this.txtRq, e);
        }

        private void txtRq_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.txtDesRes, e);
        }

        private void mskFecLle_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.btnAgrUbi, e);
        }

        private void txtCodArtSap_Enter(object sender, EventArgs e)
        {
            //cambia el texto del textbox al ingresar un dato
            this.ALM_Ubi_ConStock_EveEnter(this.txtCodArtSap,"(Código SAP)","",Color.Black);
        }

        private void txtCodArtSap_Leave(object sender, EventArgs e)
        {
            //cambia el texto predeterminado cuando no se ingreso ningun data
            this.ALM_Ubi_ConStock_EveLeave(this.txtCodArtSap,"", "(Código SAP)", Color.DimGray);
        }

        private void txtCodXtr_Enter(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtCodXtr,"(Código Xtrazzo)","",Color.Black);
        }

        private void txtCodXtr_Leave(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtCodXtr,"", "(Código Xtrazzo)", Color.DimGray);
        }

        private void btnVolMenCru_Click(object sender, EventArgs e)
        {
            if (_rowConta != 0)
            {
                this.btnPauExp.PerformClick();

                DialogResult msg =  MessageBox.Show("¿Desea cancelar la exportación?","Mensaje del sistema",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

                if (msg == DialogResult.Yes)
                {
                    this.btnCanExp.PerformClick();
                }
                else
                {
                    this.btnPauExp.PerformClick();
                    return;
                }
            }

            //Ocultar panel agregar ubicacion
            this.pnlCru.Visible = false;

            //Limpiaamos el grid y el combobox
            this.cboCom.SelectedIndex = -1;

            DataTable dtClear = new DataTable();
            dtClear.Clear();
            this.fgCru.DataSource = dtClear;

            //Ocultar panel de movimiento
            this.pnlOpcTipMov.Visible = false;

            //Mostrar panel principal
            this.pnlPri.Visible = true;
            this.pnlPri.Dock = DockStyle.Fill;

            //Habilita los botones
            this.ALM_UbiConStock_HabBtnsPri(true);
        }

        private void btnConP_Click(object sender, EventArgs e)
        {
            this.pnlPri.Visible = false;
            this.pnlCon.Visible = true;
            this.pnlCon.Dock = DockStyle.Fill;
        }

        private void btnConPar_Click(object sender, EventArgs e)
        {
            this.gpbParCon.Visible = true;
        }

        private void btnVolMenCon_Click(object sender, EventArgs e)
        {
            //Ocultar panel de consulta
            this.pnlCon.Visible = false;

            //Valores predeterminado
            this.dtpFecIni.Value = DateTime.Now.Date;
            this.dtpFecFin.Value = DateTime.Now.Date;
            this.chkSolArt.Checked = false;

            //Limpiamos los textos
            foreach (Control c in this.gpbParCon.Controls)
            {
                if (c is TextBox) c.Text = "";
            }
            this.chkIncEli.Checked = false;

            //Limpiamos el grid
            DataTable dtClear = new DataTable();
            dtClear.Clear();
            this.fgUbi.DataSource = dtClear;

            //Ocultar groupOx
            this.gpbParCon.Visible = false;

            //Ocultar panel de movimiento
            this.pnlOpcTipMov.Visible = false;

            //Mostrar panel principal
            this.pnlPri.Visible = true;
            this.pnlPri.Dock = DockStyle.Fill;

            //Habilita los botones
            this.ALM_UbiConStock_HabBtnsPri(true);

            //Texto predeterminado
            this.txtDesAlmP.Text = "Presione enter o ingrese un almacén";
            this.txtDesArtPar.Text = "Presione enter o ingrese un artìculo";
            this.txtDesAlmP.ForeColor = Color.DimGray;
            this.txtDesArtPar.ForeColor = Color.DimGray;
        }

        private void txtDesAlm_Enter(object sender, EventArgs e)
        {
            //cambia el texto del textbox al ingresar un dato
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesAlm, "Presione enter o ingrese un almacén", "", Color.Black);
        }

        private void txtDesAlm_Leave(object sender, EventArgs e)
        {
            //cambia el texto del textbox al ingresar un dato
            this.ALM_Ubi_ConStock_EveLeave(this.txtDesAlm,"", "Presione enter o ingrese un almacén", Color.DimGray);
        }

        private void ALM_Ubi_ConStock_EveEnter(TextBox txtBox, string text,string msg,Color color)
        {
            //Metod evento enter
            if (txtBox.Text == text)
            {
                txtBox.Text = msg;
                txtBox.ForeColor = color;
            }
        }

        private void ALM_Ubi_ConStock_EveLeave(TextBox txtBox,string text, string msg, Color color)
        {
            //Metod evento leave
            if (txtBox.Text == text)
            {
                txtBox.Text = msg;
                txtBox.ForeColor = color;
            }
        }

        private void txtDesRes_Enter(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesRes,"Presione enter o ingrese un responsable","",Color.Black);
        }

        private void txtDesRes_Leave(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesRes,"", "Presione enter o ingrese un responsable", Color.DimGray);
        }

        private void txtDesAlmP_Enter(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesAlmP, "Presione enter o ingrese un almacén", "", Color.Black);
        }

        private void txtDesAlmP_Leave(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesAlmP, "", "Presione enter o ingrese un almacén", Color.DimGray);
        }

        private void txtDesAlmP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Almacen", "[Filtro_Almacenes]", this.txtDesAlmP.Text.Trim());
            }
        }

        private void btnVolMenUbi_Click(object sender, EventArgs e)
        {
            //Ocultar panel agregar ubicacion
            this.pnlCreUbi.Visible = false;

            //Recorre los controles del panel para poder limpiarlos
            foreach (Control pnl in this.pnlCreUbi.Controls)
            {
                if (pnl is TextBox) pnl.Text = "";

                foreach (Control gpb in this.gpbAgrUbi.Controls)
                {
                    if (gpb is TextBox) gpb.Text = "";

                    foreach (Control gpb2 in this.gpbArt.Controls)
                    {
                        if (gpb2 is TextBox) gpb2.Text = "";
                    }
                }
            }

            this.cboSer.Text = "";
            this.ALM_Ubi_ConStock_TexPre();
            this.ALM_Ubi_ConStock_SoloLectura();

            //Ocultar panel de movimiento
            this.pnlOpcTipMov.Visible = false;

            //Mostrar panel principal
            this.pnlPri.Visible = true;
            this.pnlPri.Dock = DockStyle.Fill;

            //Habilita los botones
            this.ALM_UbiConStock_HabBtnsPri(true);
        }

        private void txtDesArtPar_Enter(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesArtPar, "Presione enter o ingrese un artìculo", "", Color.Black);
        }

        private void txtDesArtPar_Leave(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesArtPar, "", "Presione enter o ingrese un artìculo", Color.DimGray);
        }

        private void txtDesArtP2_Enter(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesArtP2, "Presione enter o ingrese un artìculo", "", Color.Black);
        }

        private void txtDesArtP2_Leave(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesArtP2, "", "Presione enter o ingrese un artìculo", Color.DimGray);
        }

        private void txtDesAlmP2_Enter(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesAlmP2, "Presione enter o ingrese un almacén", "", Color.Black);
        }

        private void txtDesAlmP2_Leave(object sender, EventArgs e)
        {
            this.ALM_Ubi_ConStock_EveEnter(this.txtDesAlmP2, "", "Presione enter o ingrese un almacén", Color.DimGray);
        }

        private void btnExpMosTod_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(this.fgMosTod,this.Text);
        }

        private void btnVolMenMosTod_Click(object sender, EventArgs e)
        {
            //Muestra el panel actual y oculta el principal
            this.pnlMosTod.Visible = false;
            this.pnlPri.Visible = true;
            this.pnlPri.Dock = DockStyle.Fill;

            //Valores 
            this.dtpFecIniMosTod.Value = DateTime.Now.Date;
            this.dtpFecFinMosTod.Value = DateTime.Now.Date;

            //Limpiamos el grid
            foreach (Control c in this.pnlMosTod.Controls)
            {
                if (c is TextBox) c.Text = "";
            }

            this.chkIncEliP2.Checked = false;
            DataTable dtClear = new DataTable();
            this.fgMosTod.DataSource = dtClear;

            //Valores predeterminados
            this.txtDesAlmP2.Text = "Presione enter o ingrese un almacén";
            this.txtDesArtP2.Text = "Presione enter o ingrese un artìculo";
            this.txtDesAlmP2.ForeColor = Color.DimGray;
            this.txtDesArtP2.ForeColor = Color.DimGray;
        }

        private void btnBus_Click(object sender, EventArgs e)
        {
            //Recupera los datos en el gri con los parametros requeridos,validando el tipo

            Cursor.Current = Cursors.WaitCursor;

            if (this.chkIncEliP2.Checked)
            {
                _tipo = 4;
            }
            else
            {
                _tipo = 5;
            }

            DataTable dtRecMov = null;

            dtRecMov = nUs.ALM_Ubi_ConStock_RecMovDia(this.dtpFecIniMosTod.Value.Date,
                                                      this.dtpFecFinMosTod.Value.Date,
                                                      this.txtCodAlmP2.Text,
                                                      _tipo,
                                                      this.txtCodArtP2.Text);

            //valia si hay articulos de acuerdo a al fecha
            if (dtRecMov.Rows.Count > 0)
            {
                this.fgMosTod.DataSource = dtRecMov;
            }
            else
            {
                //limpia el grid
                DataTable dtClear = new DataTable();

                dtClear.Clear();
                this.fgMosTod.DataSource = dtClear;

                _msg = "No se encontraron datos.";
                this.ALM_UbiConStock_MosMsgStrip(_msg, Color.Red);
            }

            Cursor.Current = Cursors.Default;
        }

        private void txtCodArtP2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo2", "[Filtro_3Articulo]", this.txtCodArtP2.Text.Trim(), 1);
            }
        }

        private void txtDesArtP2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Articulo2", "[Filtro_3Articulo]", this.txtDesArtP2.Text.Trim(), 2);
            }
        }

        private void txtDesAlmP2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ALM_Ubi_ConStock_ConsultaDatos("Almacen", "[Filtro_Almacenes]", this.txtDesAlmP2.Text.Trim());
            }
        }

        private void fgMosTod_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.ALM_Ubi_ConStock_FormatoGeneralFg(this.fgMosTod);
            this.ALM_Ubi_ConStock_ForCol(this.fgMosTod);
        }

        private void fgUbi_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.ALM_Ubi_ConStock_ForCol(this.fgUbi);
            this.ALM_Ubi_ConStock_FormatoGeneralFg(this.fgUbi);
        }

        private void fgMosTod_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnVerUbi_Click(object sender, EventArgs e)
        {
            //Recupera las ubicaciones
            DataTable dtUbi = null;
            dtUbi = nUs.ALM_Ubi_ConStock_RecUbi();

            if (dtUbi.Rows.Count > 0)
            {
                this.fgUbis.DataSource = dtUbi;
                this.pnlUbi.Visible = true;
            }
            else
            {
                this.ALM_UbiConStock_MosMsgStrip("No se encontraron datos",Color.Red);
            }
        }

        private void fgUbis_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.ALM_Ubi_ConStock_FormatoGeneralFg(this.fgUbis);
            this.ALM_Ubi_ConStock_ForColUbis();
        }
        private void ALM_Ubi_ConStock_ForColUbis()
        {
            //Centra los datos
            for (int col = 0; col < this.fgUbis.Cols.Count;col++)
            {
                this.fgUbis.Cols[col].TextAlign = TextAlignEnum.CenterCenter;
            }

            this.fgUbis.Cols["Zona"].Width = 50;
            this.fgUbis.Cols["Rack"].Width = 50;
            this.fgUbis.Cols["Columna"].Width = 50;
            this.fgUbis.Cols["Fila"].Width = 50; 
        }

        private void fgUbis_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //No permite editar en el grid
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnCanUbi_Click(object sender, EventArgs e)
        {
            if (this.pnlUbi.Visible == true)
            {
                this.pnlUbi.Visible = false;
            }
        }

        private void dtpFecIni_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.dtpFecFin,e);
        }

        private void dtpFecFin_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.chkSolArt, e);
        }

        private void txtCodAlmP_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.txtDesAlmP, e);
        }

        private void chkSolArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.ALM_Ubi_ConStock_EveKeyPre(this.txtCodAlmP, e);
        }

        private void frmALM_Ubi_ConStock_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Valida si la exportacion esta en ejecucion
            if (_rowConta != 0)
            {
                //Valida que haya hecho click en el boton cerrar del formulario
                if (e.CloseReason == CloseReason.UserClosing)
                {
                    this.btnPauExp.PerformClick();

                    DialogResult msg = MessageBox.Show("¿Desea cancelar la exportación", "Mensaje del sistema",
                                                         MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (msg == DialogResult.No)
                    {
                        //Renauda la exportacion
                        e.Cancel = true;
                        this.btnPauExp.PerformClick();
                    }
                    else
                    {
                        //Cancelar la exportacion
                        this.btnCanExp.PerformClick();
                        e.Cancel = false;
                    }
                }
            }
        }

        private void fgUbi_AfterEdit(object sender, RowColEventArgs e)
        {
            decimal? valor = 0;
            int? numMov = 0;

            //Valida si hay dato en el grid 
            if (string.IsNullOrEmpty(this.fgUbi.Rows[e.Row][18].ToString()))
            {
                valor = null;
            }
            else
            {
                valor = (decimal)this.fgUbi.Rows[e.Row][18];
            }

            if (e.Col == 18)
            {
                //Obtiene el numero de movimiento
                numMov = (int)this.fgUbi.Rows[this.fgUbi.RowSel][0];

                //Actuliza la cantidad comprometida
                nUs.ALM_Ubi_ConStock_ActCantCom(numMov,valor);
            }
        }
    }
}
