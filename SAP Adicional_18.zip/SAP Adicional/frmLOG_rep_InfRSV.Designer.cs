﻿namespace SAP_Adicional
{
    partial class frmLOG_rep_InfRSV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLOG_rep_InfRSV));
            this.fgInfRes = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnMosAct = new System.Windows.Forms.Button();
            this.btnExpInfRes = new System.Windows.Forms.Button();
            this.chkEliDes = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.fgInfRes)).BeginInit();
            this.SuspendLayout();
            // 
            // fgInfRes
            // 
            this.fgInfRes.AllowFiltering = true;
            this.fgInfRes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgInfRes.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgInfRes.Location = new System.Drawing.Point(1, 57);
            this.fgInfRes.Name = "fgInfRes";
            this.fgInfRes.Rows.DefaultSize = 19;
            this.fgInfRes.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgInfRes.Size = new System.Drawing.Size(886, 453);
            this.fgInfRes.TabIndex = 3;
            this.fgInfRes.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgInfRes_KeyPressEdit);
            this.fgInfRes.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgInfRes_AfterDataRefresh);
            // 
            // btnMosAct
            // 
            this.btnMosAct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosAct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMosAct.Image = ((System.Drawing.Image)(resources.GetObject("btnMosAct.Image")));
            this.btnMosAct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMosAct.Location = new System.Drawing.Point(1, 12);
            this.btnMosAct.Name = "btnMosAct";
            this.btnMosAct.Size = new System.Drawing.Size(116, 26);
            this.btnMosAct.TabIndex = 0;
            this.btnMosAct.Text = "&Mostrar/Actulizar";
            this.btnMosAct.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMosAct.UseVisualStyleBackColor = true;
            this.btnMosAct.Click += new System.EventHandler(this.btnMosAct_Click);
            // 
            // btnExpInfRes
            // 
            this.btnExpInfRes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpInfRes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExpInfRes.Image = ((System.Drawing.Image)(resources.GetObject("btnExpInfRes.Image")));
            this.btnExpInfRes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExpInfRes.Location = new System.Drawing.Point(123, 12);
            this.btnExpInfRes.Name = "btnExpInfRes";
            this.btnExpInfRes.Size = new System.Drawing.Size(118, 26);
            this.btnExpInfRes.TabIndex = 1;
            this.btnExpInfRes.Text = "E&xportar Excel";
            this.btnExpInfRes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExpInfRes.UseVisualStyleBackColor = true;
            this.btnExpInfRes.Click += new System.EventHandler(this.btnExpInfRes_Click);
            // 
            // chkEliDes
            // 
            this.chkEliDes.AutoSize = true;
            this.chkEliDes.Location = new System.Drawing.Point(258, 18);
            this.chkEliDes.Name = "chkEliDes";
            this.chkEliDes.Size = new System.Drawing.Size(116, 17);
            this.chkEliDes.TabIndex = 2;
            this.chkEliDes.Text = "Eliminar despachos";
            this.chkEliDes.UseVisualStyleBackColor = true;
            // 
            // frmLOG_rep_InfRSV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 522);
            this.Controls.Add(this.chkEliDes);
            this.Controls.Add(this.btnExpInfRes);
            this.Controls.Add(this.btnMosAct);
            this.Controls.Add(this.fgInfRes);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmLOG_rep_InfRSV";
            this.Text = "Información para reserva (reporte)";
            ((System.ComponentModel.ISupportInitialize)(this.fgInfRes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private C1.Win.C1FlexGrid.C1FlexGrid fgInfRes;
        private System.Windows.Forms.Button btnMosAct;
        private System.Windows.Forms.Button btnExpInfRes;
        private System.Windows.Forms.CheckBox chkEliDes;
    }
}