﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using Entidades.OPE_Pro;
using C1.Win.C1FlexGrid;

namespace SAP_Adicional
{
    public partial class frmOPE_Pro : Form , OPE_Pro_Filtros_Act
    {
        NOPE_Pro nop = new NOPE_Pro();

        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        DataTable Det1 = new DataTable();
        DataTable Det4 = new DataTable();

        Int64 RQ = 0;
        byte EstDoc = 0;
        bool PesAcuCome;
        bool PesIntPro;

        public frmOPE_Pro()
        {
            InitializeComponent();

            OPE_Pro_HabilitarDeshabilitar(false);
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        public void OPE_Pro_Buscar()
        {
            DataSet dsOPE_Pro = new DataSet();

            dsOPE_Pro = nop.OPE_Pro_rec2(Convert.ToInt32(this.txtNumMov.Text), varglo.CodUsuAct);

            //Tabla OPE_Pro_Enc del DataSet
            DataTable OPE_Pro_Enc = dsOPE_Pro.Tables["OPE_Pro_Enc"];

            this.txtNom.Text = OPE_Pro_Enc.Rows[0]["NomPro"].ToString();
            this.txtDir.Text = OPE_Pro_Enc.Rows[0]["DirPro"].ToString();
            this.txtDis.Text = OPE_Pro_Enc.Rows[0]["DisPro"].ToString();
            this.txtCodEstObr.Text = OPE_Pro_Enc.Rows[0]["CodEstObr"].ToString();
            this.txtEstObr.Text = OPE_Pro_Enc.Rows[0]["EstObr"].ToString();
            this.EstDoc = Convert.ToByte(OPE_Pro_Enc.Rows[0]["CodEst"].ToString());

            DateTime fecha = Convert.ToDateTime(OPE_Pro_Enc.Rows[0]["FecEmi"].ToString());
            this.txtFecIng.Text = fecha.ToShortDateString();

            this.mtxtFecIni.Text = OPE_Pro_Enc.Rows[0]["FecIni"].ToString();
            this.mtxtFecCab.Text = OPE_Pro_Enc.Rows[0]["FecCab"].ToString();
            this.mtxtFecFin.Text = OPE_Pro_Enc.Rows[0]["FecFin"].ToString();
            this.txtAlcPro.Text = OPE_Pro_Enc.Rows[0]["AlcPro"].ToString();

            this.Text = "";
            this.Text = "Proyectos - " + OPE_Pro_Enc.Rows[0]["EstPro"].ToString();

            PesAcuCome = Convert.ToBoolean(OPE_Pro_Enc.Rows[0]["PesAcuCom"]);
            PesIntPro = Convert.ToBoolean(OPE_Pro_Enc.Rows[0]["PesIntPro"]);

            //Tabla OPE_Pro_Det del DataSet
            DataTable OPE_Pro_Det0 = dsOPE_Pro.Tables["OPE_Pro_Det0"];

            foreach (DataRow row in OPE_Pro_Det0.Rows)
            {
                string[] rowDet = new string[]
                                   {row["Tipico"].ToString(),
                                    row["Pendiente"].ToString(),
                                    row["SERSUP"].ToString(),
                                    row["CodTip"].ToString(),
                                    row["Tipo"].ToString(),
                                    row["RQ"].ToString(),
                                    row["SocNeg"].ToString(),
                                    row["CodCom"].ToString(),
                                    row["Complejidad"].ToString(),
                                    row["CodTipPre"].ToString(),
                                    row["TipoPredio"].ToString(),
                                    row["Ven"].ToString(),
                                    row["CodDis"].ToString(),
                                    row["Diseño"].ToString(),
                                    row["CodIngOpe"].ToString(),
                                    row["IngOpe"].ToString(),
                                    row["CodSup"].ToString(),
                                    row["Sup"].ToString(),
                                    row["CodAdmPed"].ToString(),
                                    row["AdmPed"].ToString(),
                                    row["AdmRQ"].ToString()};

                dgvRQ.Rows.Add(rowDet);

            }

            //Tabla OPE_Pro_Det1 del DataSet
            Det1 = dsOPE_Pro.Tables["OPE_Pro_Det1"];

            foreach (DataRow dr in Det1.Rows)
            {
                if (dr["RQ"].ToString() != "0")
                {
                    RQ = Convert.ToInt64(dr["RQ"]);

                    lblRQ.Text = "RQ " + RQ.ToString();

                    AcuCom_RecDat();                                   
                }
            }                      

            //Consulta de registro de visitas se recupera al grid dgRegVis
            dgvRegVis.DataSource = dsOPE_Pro.Tables["OPE_Pro_Det2"];

            //foreach (DataGridViewRow fila in dgvRQ.Rows)
            //{
            //    fila.ReadOnly = true;
            //}

            //Tabla OPE_Pro_ del DataSet
            DataTable OPE_Pro_Det4 = dsOPE_Pro.Tables["OPE_Pro_Det4"];

            foreach (DataRow row in OPE_Pro_Det4.Rows)
            {
                //Interesados del proyecto
                string[] rowDet = new string[]
                                   {row["Item"].ToString(),
                                    row["CodIntPro"].ToString(),
                                    row["Cargo"].ToString(),
                                    row["Nom"].ToString(),
                                    row["Cel1"].ToString(),
                                    row["Cel2"].ToString(),
                                    row["Email"].ToString(),
                                    row["ResFirGui"].ToString(),
                                    row["ResActVis"].ToString()};

                fgIntPro.AddItem(rowDet);
            }

            //Consulta de las OTIS relacionadas con los RQ's agregados al proyecto
            dgvRegOTI.DataSource = dsOPE_Pro.Tables["OPE_Pro_Det5"];
            dgvRegOTI.AutoSize = true;
            dgvRegOTI.AutoResizeColumns();

            //Consulta de las Rutas relacionadas con los RQ's agregados al proyecto
            dgvRegRuta.DataSource = dsOPE_Pro.Tables["OPE_Pro_Det6"];
            dgvRegRuta.AutoSize = true;
            dgvRegRuta.AutoResizeColumns();

            //Consulta las fechas Aprox. Instalacion
            fgFecAprIns.DataSource = dsOPE_Pro.Tables["OPE_Pro_Det7"];

            dgvRegRuta_formato();
        }

        private void frmOPE_Pro_Load(object sender, EventArgs e)
        {

            //
            this.mtxtFecIni.Mask = "00/00/0000";
            this.mtxtFecCab.Mask = "00/00/0000";
            this.mtxtFecFin.Mask = "00/00/0000";

            //Formato de los Grid
            dgvRQ_Formato();
            //dgvIntPro_Formato();
            OPE_Pro_formatofg();

            //Recuperar informacion de encabezado y detalles
            OPE_Pro_Buscar();            

            //Primero revisamos si se ha agregado una linea con RQ = 0 la cual hace referencia a paquete
            foreach (DataRow dr in Det1.Rows)
            {
                if (Convert.ToInt32(dr["RQ"].ToString()) == 0)
                {//Si existe lo cargamos
                    btnPaq.PerformClick();
                }
            }

            OPE_Pro_EstBot("abrir");

            

        }

        private void dgvRQ_Formato()
        {
            dgvRQ.ColumnCount = 18;

            //Detalle (Articulos Compuestos)
            DataGridViewCheckBoxColumn Col1 = new DataGridViewCheckBoxColumn();
            Col1.Name = "Tipico";
            Col1.HeaderText = "Tipico";
            dgvRQ.Columns.Insert(0, Col1);
            //dgvRQ.Columns.Add(Col1);
            //dgvRQ.Columns[0].Name = "Tipico";

            DataGridViewCheckBoxColumn Col2 = new DataGridViewCheckBoxColumn();
            Col2.Name = "Pendiente";
            Col2.HeaderText = "Pendiente";
            dgvRQ.Columns.Insert(1, Col2);

            DataGridViewCheckBoxColumn Col3 = new DataGridViewCheckBoxColumn();
            Col3.Name = "SUP";
            Col3.HeaderText = "SUP";
            dgvRQ.Columns.Insert(2, Col3);

            dgvRQ.Columns[3].Name = "CodTip";
            dgvRQ.Columns[4].Name = "Tipo";
            dgvRQ.Columns[5].Name = "RQ";
            dgvRQ.Columns[6].Name = "Socio Negocio";
            dgvRQ.Columns[7].Name = "CodCom";
            dgvRQ.Columns[8].Name = "Complejidad";
            dgvRQ.Columns[9].Name = "CodTipPre";
            dgvRQ.Columns[10].Name = "Tipo Predio";
            dgvRQ.Columns[11].Name = "Vendedor";
            dgvRQ.Columns[12].Name = "CodDis";
            dgvRQ.Columns[13].Name = "Diseño";
            dgvRQ.Columns[14].Name = "CodIngOpe";
            dgvRQ.Columns[15].Name = "Ing. Operaciones";
            dgvRQ.Columns[16].Name = "CodSup";
            dgvRQ.Columns[17].Name = "Supervisor";
            dgvRQ.Columns[18].Name = "CodAdmPed";
            dgvRQ.Columns[19].Name = "Adm. Pedidos";
            dgvRQ.Columns[20].Name = "Adm. RQ";

            dgvRQ.Font = new Font("Tahoma", 7);

            dgvRQ.Columns[3].Frozen = true;
            dgvRQ.RowHeadersVisible = false;

            dgvRQ.Columns[0].Width = 50; //Tipico
            dgvRQ.Columns[1].Width = 60;//Pendiente
            dgvRQ.Columns[2].Width = 50;//SUP
            dgvRQ.Columns[3].Visible = false; //CodTip
            dgvRQ.Columns[4].Width = 90;//Tipo
            dgvRQ.Columns[5].Width = 40; //RQ
            dgvRQ.Columns[6].Width = 300;//Socio negocio
            dgvRQ.Columns[7].Visible = false;//CodCom
            dgvRQ.Columns[8].Width = 110;//Complejidad
            dgvRQ.Columns[9].Visible = false;//CodTipPre
            dgvRQ.Columns[10].Width = 110;//Tipo Predio
            dgvRQ.Columns[11].Width = 150; //Vendedor
            dgvRQ.Columns[12].Visible = false;//CodDis
            dgvRQ.Columns[13].Width = 150;//Diseño
            dgvRQ.Columns[14].Visible = false;//CodIngOpe
            dgvRQ.Columns[15].Width = 150;//Ing. Operaciones
            dgvRQ.Columns[16].Visible = false; //CodSup
            dgvRQ.Columns[17].Width = 150; //Supervisor
            dgvRQ.Columns[18].Visible = false;//CodAdmPed
            dgvRQ.Columns[19].Width = 150;//Adm.Pedido
            dgvRQ.Columns[20].Width = 150;//Adm RQ.

            //dgvRQ.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

        }

        private void AcuCom_RecDat()
        {
            bool Existe = false;

            foreach (DataRow dr in Det1.Rows)
            {
                if (dr["RQ"].ToString() == RQ.ToString())
                //Si la busqueda en el datatable devuelve algun codigo, recupera los valores
                {
                    this.txtDis_DurEst_Mes.Text = dr["Dis_DurEst_Mes"].ToString();
                    this.txtDis_CanVis_Und.Text = dr["Dis_CanVis_Und"].ToString();
                    this.txtDis_TraOfi_Hor.Text = dr["Dis_TraOfi_Hor"].ToString();
                    this.txtDis_TraPla_Hor.Text = dr["Dis_TraPla_Hor"].ToString();
                    this.txtDis_TraDia_Hor.Text = dr["Dis_TraDia_Hor"].ToString();
                    this.txtDis_CosDir.Text = dr["Dis_CosDir"].ToString();
                    this.txtDis_CosInd.Text = dr["Dis_CosInd"].ToString();
                    this.txtDis_GasGen.Text = dr["Dis_GasGen"].ToString();
                    this.txtDis_Uti.Text = dr["Dis_Uti"].ToString();
                    this.txtSup_DurEst_Mes.Text = dr["Sup_DurEst_Mes"].ToString();
                    this.txtSup_CanVisIngOpe_Und.Text = dr["Sup_CanVisIngOpe_Und"].ToString();
                    this.txtSup_TraOfiOpe_Hor.Text = dr["Sup_TraOfiOpe_Hor"].ToString();
                    this.txtSup_CanVisSup_Und.Text = dr["Sup_CanVisSup_Und"].ToString();
                    this.txtSup_CanPruMue_Und.Text = dr["Sup_CanPruMue_Und"].ToString();
                    this.txtSup_CanPruMueDobAlt_Und.Text = dr["Sup_CanPruMueDobAlt_Und"].ToString();
                    this.txtSup_CanPrueMeg_Und.Text = dr["Sup_CanPrueMeg_Und"].ToString();
                    this.txtSup_CosDir.Text = dr["Sup_CosDir"].ToString();
                    this.txtSup_CosInd.Text = dr["Sup_CosInd"].ToString();
                    this.txtSup_GasGen.Text = dr["Sup_GasGen"].ToString();
                    this.txtSup_Uti.Text = dr["Sup_Uti"].ToString();
                    this.txtIns_DurEst_Dia.Text = dr["Ins_DurEst_Dia"].ToString();
                    this.txtIns_CanTecDia_Und.Text = dr["Ins_CanTecDia_Und"].ToString();
                    this.txtIns_CanVisCoo_Und.Text = dr["Ins_CanVisCoo_Und"].ToString();
                    this.txtIns_CanViaMov_Und.Text = dr["Ins_CanViaMov_Und"].ToString();
                    this.txtIns_CanPruLuc_Und.Text = dr["Ins_CanPruLuc_Und"].ToString();
                    this.txtIns_CosTraNoc_Sol.Text = dr["Ins_CosTraNoc_Sol"].ToString();
                    this.txtIns_CosMat_Sol.Text = dr["Ins_CosMat_Sol"].ToString();
                    this.txtIns_CosDir.Text = dr["Ins_CosDir"].ToString();
                    this.txtIns_CosInd.Text = dr["Ins_CosInd"].ToString();
                    this.txtIns_GasGen.Text = dr["Ins_GasGen"].ToString();
                    this.txtIns_Uti.Text = dr["Ins_Uti"].ToString();
                    this.txtPro_DurEst_Dia.Text = dr["Pro_DurEst_Dia"].ToString();
                    this.txtPro_CanBotSenDri_Und.Text = dr["Pro_CanBotSenDri_Und"].ToString();
                    this.txtPro_CanModRepAmp_Und.Text = dr["Pro_CanModRepAmp_Und"].ToString();
                    this.txtPro_CanPanConLic_Und.Text = dr["Pro_CanPanConLic_Und"].ToString();
                    this.txtPro_CosPro_Sol.Text = dr["Pro_CosPro_Sol"].ToString();
                    this.txtPro_CosDir.Text = dr["Pro_CosDir"].ToString();
                    this.txtPro_CosInd.Text = dr["Pro_CosInd"].ToString();
                    this.txtPro_GasGen.Text = dr["Pro_GasGen"].ToString();
                    this.txtPro_Uti.Text = dr["Pro_Uti"].ToString();

                    Existe = true;
                }
            }

            if (Existe == false)
            {
                LimpiaAcuerdoComercial();
            }
        }

        private void dgvRQ_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Primero revisamos si se ha agregado una linea con RQ = 0 la cual hace referencia a paquete
            foreach (DataRow dr in Det1.Rows)
            {
                if (Convert.ToInt32(dr["RQ"].ToString()) == 0)
                {//Si existe salimos y no recuperamos nada con RQ
                    return;
                }
            }

            RQ = Convert.ToInt32(this.dgvRQ.CurrentRow.Cells[5].Value);

            lblRQ.Text = "RQ " + RQ.ToString();

            //Acuerdo Comercial _ Recupera Datos
            AcuCom_RecDat();

        }

        private void txtDis_DurEst_Mes_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_DurEst_Mes, "Dis_DurEst_Mes");
        }

        private void OPE_Pro_Det1_NuevaLinea()
        {
            DataRow dr = Det1.NewRow();

            //Creamos una linea vacia en el datatable
            dr["NumMov"] = txtNumMov.Text;
            dr["RQ"] = RQ;
            dr["Dis_DurEst_Mes"] = 0;
            dr["Dis_CanVis_Und"] = 0;
            dr["Dis_TraOfi_Hor"] = 0;
            dr["Dis_TraPla_Hor"] = 0;
            dr["Dis_TraDia_Hor"] = 0;
            dr["Dis_CosDir"] = 0;
            dr["Dis_CosInd"] = 0;
            dr["Dis_GasGen"] = 0;
            dr["Dis_Uti"] = 0;
            dr["Sup_DurEst_Mes"] = 0;
            dr["Sup_CanVisIngOpe_Und"] = 0;
            dr["Sup_TraOfiOpe_Hor"] = 0;
            dr["Sup_CanVisSup_Und"] = 0;
            dr["Sup_CanPruMue_Und"] = 0;
            dr["Sup_CanPruMueDobAlt_Und"] = 0;
            dr["Sup_CanPrueMeg_Und"] = 0;
            dr["Sup_CosDir"] = 0;
            dr["Sup_CosInd"] = 0;
            dr["Sup_GasGen"] = 0;
            dr["Sup_Uti"] = 0;
            dr["Ins_DurEst_Dia"] = 0;
            dr["Ins_CanTecDia_Und"] = 0;
            dr["Ins_CanVisCoo_Und"] = 0;
            dr["Ins_CanViaMov_Und"] = 0;
            dr["Ins_CanPruLuc_Und"] = 0;
            dr["Ins_CosTraNoc_Sol"] = 0;
            dr["Ins_CosMat_Sol"] = 0;
            dr["Ins_CosDir"] = 0;
            dr["Ins_CosInd"] = 0;
            dr["Ins_GasGen"] = 0;
            dr["Ins_Uti"] = 0;
            dr["Pro_DurEst_Dia"] = 0;
            dr["Pro_CanBotSenDri_Und"] = 0;
            dr["Pro_CanModRepAmp_Und"] = 0;
            dr["Pro_CanPanConLic_Und"] = 0;
            dr["Pro_CosPro_Sol"] = 0;
            dr["Pro_CosDir"] = 0;
            dr["Pro_CosInd"] = 0;
            dr["Pro_GasGen"] = 0;
            dr["Pro_Uti"] = 0;

            Det1.Rows.Add(dr);
        }

        private void dgvRQ_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LimpiaAcuerdoComercial()
        {
            this.txtDis_DurEst_Mes.Text = "";
            this.txtDis_CanVis_Und.Text = "";
            this.txtDis_TraOfi_Hor.Text = "";
            this.txtDis_TraPla_Hor.Text = "";
            this.txtDis_TraDia_Hor.Text = "";
            this.txtDis_CosDir.Text = "";
            this.txtDis_CosInd.Text = "";
            this.txtDis_GasGen.Text = "";
            this.txtDis_Uti.Text = "";

            this.txtSup_DurEst_Mes.Text = "";
            this.txtSup_CanVisIngOpe_Und.Text = "";
            this.txtSup_TraOfiOpe_Hor.Text = "";
            this.txtSup_CanVisSup_Und.Text = "";
            this.txtSup_CanPruMue_Und.Text = "";
            this.txtSup_CanPruMueDobAlt_Und.Text = "";
            this.txtSup_CanPrueMeg_Und.Text = "";
            this.txtSup_CosDir.Text = "";
            this.txtSup_CosInd.Text = "";
            this.txtSup_GasGen.Text = "";
            this.txtSup_Uti.Text = "";

            this.txtIns_DurEst_Dia.Text = "";
            this.txtIns_CanTecDia_Und.Text = "";
            this.txtIns_CanVisCoo_Und.Text = "";
            this.txtIns_CanViaMov_Und.Text = "";
            this.txtIns_CanPruLuc_Und.Text = "";
            this.txtIns_CosTraNoc_Sol.Text = "";
            this.txtIns_CosMat_Sol.Text = "";
            this.txtIns_CosDir.Text = "";
            this.txtIns_CosInd.Text = "";
            this.txtIns_GasGen.Text = "";
            this.txtIns_Uti.Text = "";

            this.txtPro_DurEst_Dia.Text = "";
            this.txtPro_CanBotSenDri_Und.Text = "";
            this.txtPro_CanModRepAmp_Und.Text = "";
            this.txtPro_CanPanConLic_Und.Text = "";
            this.txtPro_CosPro_Sol.Text = "";
            this.txtPro_CosDir.Text = "";
            this.txtPro_CosInd.Text = "";
            this.txtPro_GasGen.Text = "";
            this.txtPro_Uti.Text = "";

        }

        private void btnPaq_Click(object sender, EventArgs e)
        {
            RQ = 0;
            this.lblRQ.Text = "RQ PAQUETE";

            //Acuerdo Comercial _ Recupera Datos
            AcuCom_RecDat();

        }

        private void txtDis_CanVis_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_CanVis_Und, "Dis_CanVis_Und");
        }

        private void txtDis_TraOfi_Hor_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_TraOfi_Hor, "Dis_TraOfi_Hor");

        }

        private void txtDis_TraPla_Hor_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_TraPla_Hor, "Dis_TraPla_Hor");

        }

        private void txtDis_TraDia_Hor_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_TraDia_Hor, "Dis_TraDia_Hor");
        }

        private void txtDis_CosDir_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_CosDir, "Dis_CosDir");

            CosServTot_SinUti();
        }

        private void txtDis_CosInd_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_CosInd, "Dis_CosInd");

            CosServTot_SinUti();

        }

        private void txtDis_GasGen_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_GasGen, "Dis_GasGen");

            CosServTot_SinUti();
        }

        private void txtDis_Uti_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtDis_Uti, "Dis_Uti");

            CosServTot_ConUti();
        }

        private void txtSup_DurEst_Mes_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_DurEst_Mes, "Sup_DurEst_Mes");
        }


        private void IngVal_AcuCom(TextBox CuaTex, string NomCam)
        {
            //Ingresa valores de acuerdos comerciales

            Int16 val;

            if (Int16.TryParse(CuaTex.Text, out val))
            {
                bool Existe = false;

                foreach (DataRow dr in Det1.Rows)
                {
                    if (dr["RQ"].ToString() == RQ.ToString())
                    {

                        dr[NomCam] = CuaTex.Text;
                        Existe = true;
                    }
                }

                if (Existe == false)
                {
                    OPE_Pro_Det1_NuevaLinea();

                    foreach (DataRow dr in Det1.Rows)
                    {
                        if (dr["RQ"].ToString() == RQ.ToString())
                        {

                            dr[NomCam] = CuaTex.Text;
                            Existe = true;
                        }
                    }
                }

            }
        }

        private void txtSup_CanVisIngOpe_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CanVisIngOpe_Und, "Sup_CanVisIngOpe_Und");
        }

        private void txtSup_TraOfiOpe_Hor_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_TraOfiOpe_Hor, "Sup_TraOfiOpe_Hor");
        }

        private void txtSup_CanVisSup_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CanVisSup_Und, "Sup_CanVisSup_Und");
        }

        private void txtSup_CanPruMue_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CanPruMue_Und, "Sup_CanPruMue_Und");
        }

        private void txtSup_CanPruMueDobAlt_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CanPruMueDobAlt_Und, "Sup_CanPruMueDobAlt_Und");
        }

        private void txtSup_CanPrueMeg_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CanPrueMeg_Und, "Sup_CanPrueMeg_Und");
        }

        private void txtSup_CosDir_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CosDir, "Sup_CosDir");

            CosServTot_SinUti();
        }

        private void txtSup_CosInd_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_CosInd, "Sup_CosInd");

            CosServTot_SinUti();
        }

        private void txtSup_GasGen_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_GasGen, "Sup_GasGen");

            CosServTot_SinUti();
        }

        private void txtSup_Uti_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtSup_Uti, "Sup_Uti");

            CosServTot_ConUti();
        }

        private void txtIns_DurEst_Dia_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_DurEst_Dia, "Ins_DurEst_Dia");
        }

        private void txtIns_CanTecDia_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CanTecDia_Und, "Ins_CanTecDia_Und");
        }

        private void txtIns_CanVisCoo_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CanVisCoo_Und, "Ins_CanVisCoo_Und");
        }

        private void txtIns_CanViaMov_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CanViaMov_Und, "Ins_CanViaMov_Und");
        }

        private void txtIns_CanPruLuc_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CanPruLuc_Und, "Ins_CanPruLuc_Und");
        }

        private void txtIns_CosTraNoc_Sol_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CosTraNoc_Sol, "Ins_CosTraNoc_Sol");
        }

        private void txtIns_CosMat_Sol_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CosMat_Sol, "Ins_CosMat_Sol");
        }

        private void txtIns_CosDir_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CosDir, "Ins_CosDir");

            CosServTot_SinUti();
        }

        private void txtIns_CosInd_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_CosInd, "Ins_CosInd");

            CosServTot_SinUti();
        }

        private void txtIns_GasGen_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_GasGen, "Ins_GasGen");

            CosServTot_SinUti();
        }

        private void txtIns_Uti_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtIns_Uti, "Ins_Uti");

            CosServTot_ConUti();
        }

        private void txtPro_DurEst_Dia_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_DurEst_Dia, "Pro_DurEst_Dia");
        }

        private void txtPro_CanBotSenDri_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_CanBotSenDri_Und, "Pro_CanBotSenDri_Und");
        }

        private void txtPro_CanModRepAmp_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_CanModRepAmp_Und, "Pro_CanModRepAmp_Und");
        }

        private void txtPro_CanPanConLic_Und_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_CanPanConLic_Und, "Pro_CanPanConLic_Und");
        }

        private void txtPro_CosPro_Sol_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_CosPro_Sol, "Pro_CosPro_Sol");
        }

        private void txtPro_CosDir_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_CosDir, "Pro_CosDir");

            CosServTot_SinUti();
        }

        private void txtPro_CosInd_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_CosInd, "Pro_CosInd");

            CosServTot_SinUti();
        }

        private void txtPro_GasGen_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_GasGen, "Pro_GasGen");

            CosServTot_SinUti();
        }

        private void txtPro_Uti_TextChanged(object sender, EventArgs e)
        {
            IngVal_AcuCom(txtPro_Uti, "Pro_Uti");

            CosServTot_ConUti();
        }

        private void CosServTot_SinUti()
        {
            double Dis_CosDir = 0;
            double Dis_CosInd = 0;
            double Dis_GasGen = 0;

            double.TryParse(this.txtDis_CosDir.Text, out Dis_CosDir);
            double.TryParse(this.txtDis_CosInd.Text, out Dis_CosInd);
            double.TryParse(this.txtDis_GasGen.Text, out Dis_GasGen);

            this.txtDis_TotSinUti.Text = (Dis_CosDir + Dis_CosInd + Dis_GasGen).ToString();

            double Sup_CosDir = 0;
            double Sup_CosInd = 0;
            double Sup_GasGen = 0;

            double.TryParse(this.txtSup_CosDir.Text, out Sup_CosDir);
            double.TryParse(this.txtSup_CosInd.Text, out Sup_CosInd);
            double.TryParse(this.txtSup_GasGen.Text, out Sup_GasGen);

            this.txtSup_TotSinUti.Text = (Sup_CosDir + Sup_CosInd + Sup_GasGen).ToString();

            double Ins_CosDir = 0;
            double Ins_CosInd = 0;
            double Ins_GasGen = 0;

            double.TryParse(this.txtIns_CosDir.Text, out Ins_CosDir);
            double.TryParse(this.txtIns_CosInd.Text, out Ins_CosInd);
            double.TryParse(this.txtIns_GasGen.Text, out Ins_GasGen);

            this.txtIns_TotSinUti.Text = (Ins_CosDir + Ins_CosInd + Ins_GasGen).ToString();

            double Pro_CosDir = 0;
            double Pro_CosInd = 0;
            double Pro_GasGen = 0;

            double.TryParse(this.txtPro_CosDir.Text, out Pro_CosDir);
            double.TryParse(this.txtPro_CosInd.Text, out Pro_CosInd);
            double.TryParse(this.txtPro_GasGen.Text, out Pro_GasGen);

            this.txtPro_TotSinUti.Text = (Pro_CosDir + Pro_CosInd + Pro_GasGen).ToString();
        }

        private void CosServTot_ConUti()
        {
            double Dis_Uti = 0;
            double Dis_TotSinUti = 0;
          
            double.TryParse(this.txtDis_Uti.Text, out Dis_Uti);
            double.TryParse(this.txtDis_TotSinUti.Text, out Dis_TotSinUti);

            this.txtDis_TotConUti.Text = (Dis_Uti + Dis_TotSinUti).ToString();


            double Sup_Uti = 0;
            double Sup_TotSinUti = 0;

            double.TryParse(this.txtSup_Uti.Text, out Sup_Uti);
            double.TryParse(this.txtSup_TotSinUti.Text, out Sup_TotSinUti);

            this.txtSup_TotConUti.Text = (Sup_Uti + Sup_TotSinUti).ToString();

            double Ins_Uti = 0;
            double Ins_TotSinUti = 0;

            double.TryParse(this.txtIns_Uti.Text, out Ins_Uti);
            double.TryParse(this.txtIns_TotSinUti.Text, out Ins_TotSinUti);

            this.txtIns_TotConUti.Text = (Ins_Uti + Ins_TotSinUti).ToString();

            double Pro_Uti = 0;
            double Pro_TotSinUti = 0;

            double.TryParse(this.txtPro_Uti.Text, out Pro_Uti);
            double.TryParse(this.txtPro_TotSinUti.Text, out Pro_TotSinUti);

            this.txtPro_TotConUti.Text = (Pro_Uti + Pro_TotSinUti).ToString();

        }

        private void btnLimPaq_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Esto limpiara los valores de RQ Paquete, esta seguro", "SAP Adicional", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                foreach (DataRow dr in Det1.Rows)
                {//Buscamos la linea con RQ = 0 
                    if (Convert.ToInt32(dr["RQ"].ToString()) == 0)
                    {//Si existe lo eliminamos y salimos
                        //dr.Delete(); //primero eliminamos la linea                                       
                        Det1.Rows.Remove(dr);
                        Det1.AcceptChanges(); //aceptamos los cambios en el datatable
                        this.txtDis_DurEst_Mes.Focus();
                        break;
                    }
                }

                LimpiaAcuerdoComercial();
            }
        }

        private void mtxtFecIni_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mtxtFecIni_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtCargo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Cargo", "Filtro_OPE_Pro_IntPro", this.txtCargo.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    txtNomInt.Focus();
                }
            }
        }

        public void ConsultaDatos(string vista, string procedimiento, string param1, string param2)
        {
            DataTable dt = new DataTable();

            dt = nc.OPE_Pro_Filtros(vista, procedimiento, param1, param2);

            if (dt.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 40;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.OPE_Pro_Act = this;
                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Cargo":
                        txtCodCar.Text = row["Codigo"].ToString();
                        txtCargo.Text = row["Cargo"].ToString();
                        txtNomInt.Focus();
                        break;
                    case "Estado Obra":
                        txtCodEstObr.Text = row["Codigo"].ToString();
                        txtEstObr.Text = row["Estado Obra"].ToString();
                        mtxtFecIni.Focus();
                        break;
                    default:
                        break;
                }
            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional");
            }
        }

        public void recdat_OPE_Pro_Cargo(string CodCar, string Cargo)
        {
            txtCodCar.Text = CodCar;
            txtCargo.Text = Cargo;
        }
        

        //private void dgvIntPro_Formato()
        //{

        //    dgvIntPro.ColumnCount = 7;

        //    dgvIntPro.Columns[0].Name = "Item";
        //    dgvIntPro.Columns[1].Name = "CodIntPro";
        //    dgvIntPro.Columns[2].Name = "Cargo";
        //    dgvIntPro.Columns[3].Name = "Nombre";
        //    dgvIntPro.Columns[4].Name = "Celular1";
        //    dgvIntPro.Columns[5].Name = "Celular2";
        //    dgvIntPro.Columns[6].Name = "Email";

        //    dgvIntPro.Font = new Font("Tahoma", 8);

        //    dgvIntPro.Columns[1].Visible = false;
        //    dgvIntPro.RowHeadersVisible = false;

        //    dgvIntPro.Columns[0].Width = 40; //Item
        //    dgvIntPro.Columns[2].Width = 150;//Cargo
        //    dgvIntPro.Columns[3].Width = 300;//Nombre
        //    dgvIntPro.Columns[4].Width = 100; //Celular1
        //    dgvIntPro.Columns[5].Width = 100;//Celular2
        //    dgvIntPro.Columns[6].Width = 200;//Email

        //}

        private void OPE_Pro_formatofg()
        {
            fgIntPro.Cols[0].Caption = "Item";
            fgIntPro.Cols[1].Caption = "CodIntPro";
            fgIntPro.Cols[2].Caption = "Cargo";
            fgIntPro.Cols[3].Caption = "Nombre";
            fgIntPro.Cols[4].Caption = "Celular1";
            fgIntPro.Cols[5].Caption = "Celular2";
            fgIntPro.Cols[6].Caption = "Email";
            fgIntPro.Cols[7].Caption = "Para OT";
            fgIntPro.Cols[8].Caption = "Para Actas";

            fgIntPro.Cols[1].Visible = false;
            fgIntPro.Cols[7].DataType = typeof(bool);
            fgIntPro.Cols[8].DataType = typeof(bool);

            fgIntPro.Cols[0].Width = 40; //Item
            fgIntPro.Cols[2].Width = 150; //Cargo
            fgIntPro.Cols[3].Width = 300; //Nombre
            fgIntPro.Cols[4].Width = 100; //Celular1
            fgIntPro.Cols[5].Width = 100; //Celular2
            fgIntPro.Cols[6].Width = 200; //Email
            fgIntPro.Cols[7].Width = 100; //Para OT
            fgIntPro.Cols[8].Width = 100; //Para Actas

        }

        private void txtNomInt_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNomInt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtCel1.Focus();
            }
        }

        private void txtCel1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) {txtCel2.Focus();}
        }

        private void txtCel2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { txtEmail.Focus(); }
        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { btnAgrInt.Focus(); }
        }

        private void btnAgrInt_Click(object sender, EventArgs e)
        {
            //Validaciones

            if (string.IsNullOrEmpty(this.txtCodCar.Text))
            { MessageBox.Show("Debe elegir un Cargo", "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information); this.txtCargo.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtNomInt.Text))
            { MessageBox.Show("Debe ingresar un Nombre", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); this.txtNomInt.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtCel1.Text))
            { MessageBox.Show("Debe ingresar un numero de Celular", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); this.txtCel1.Focus(); return; }

            if (string.IsNullOrEmpty(this.txtEmail.Text))
            { MessageBox.Show("Debe ingresar un Email", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); this.txtEmail.Focus(); return; }

            //Agregamos la fila al dgvIntPro
            string[] rowDet = new string[]
                            {(fgIntPro.Rows.Count).ToString(), txtCodCar.Text, txtCargo.Text, txtNomInt.Text, txtCel1.Text,
                            txtCel2.Text, txtEmail.Text};

            fgIntPro.AddItem(rowDet);

            this.btnCanInt.PerformClick();
        }

        private void btnCanInt_Click(object sender, EventArgs e)
        {
            txtCodCar.Text = ""; txtCargo.Text = "";
            txtNomInt.Text = ""; txtCel1.Text = "";
            txtCel2.Text = ""; txtEmail.Text = "";
        }

        private void dgvIntPro_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void txtEstObr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Estado Obra", "Filtro_OPE_Pro_EstObr", this.txtEstObr.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    mtxtFecIni.Focus();
                }
            }
        }

        public void recdat_OPE_Pro_EstadoObra(string CodEstObr, string EstObr)
        {
            txtCodEstObr.Text = CodEstObr;
            txtEstObr.Text = EstObr;
        }

        private void frmOPE_Pro_Resize(object sender, EventArgs e)
        {
            //pnTabs.Height = this.Height - 400;
            dgvRegOTI.Height = tbcPro.Height - 100;
            //tbcPro.Height = pnTabs.Height-20;
        }

        private void dgvRQ_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvRQ.CurrentCell.ColumnIndex == 0 || dgvRQ.CurrentCell.ColumnIndex == 1 || dgvRQ.CurrentCell.ColumnIndex == 2)
            {
                e.Cancel = true;
            }
        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }

        private void OPE_Pro_EstBot(string BotonEstado)
        {
            bool[] EstadoM = { true };

            switch (BotonEstado)
            {
                case "modificar":
                    EstadoM = matriz(false, false, true, false, false, false, false);
                    break;
                case "abrir":
                case "guardar":
                    switch (EstDoc)
                    {
                        case 1:
                            EstadoM = matriz(true, true, false, true, true, true, true);
                            break;
                        case 2: //Terminado
                        case 4: //Paralizado
                            EstadoM = matriz(true, true, false, false, false, false, false);
                            break;
                        case 3: //Archivado                        
                            EstadoM = matriz(true, true, false, true, false, true, false );
                            break;
                    }
                    break;
                //case "guardar":
                //    EstadoM = matriz(true, true, false, true, );
                //    break;
            }

            this.btnNuevo.Enabled = EstadoM[0];
            this.btnAbrir.Enabled = EstadoM[1];
            this.btnGuardar.Enabled = EstadoM[2];
            this.btnModificar.Enabled = EstadoM[3];

            this.btnTer.Enabled = EstadoM[4];
            this.btnPar.Enabled = EstadoM[5];
            this.btnArc.Enabled = EstadoM[6];

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            OPE_Pro_Botones(btnGuardar);
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            OPE_Pro_Botones(btnNuevo);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            OPE_Pro_Botones(btnModificar);
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            OPE_Pro_Botones(btnAbrir);
        }

        private void dgvRQ_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //Referenciamos el control TextBox subyacente en la celda actual.

            TextBox cellTextBox = (DataGridViewTextBoxEditingControl)e.Control;

            cellTextBox.ReadOnly = true;
        }

        private void OPE_Pro_HabilitarDeshabilitar(Boolean estado)
        {
            pnEnc.Enabled = estado;

            //Deshabilitamos los controles dentro del Tab
            foreach (Control item in tbcPro.Controls)
            {
                if (!(item is DataGridView))
                {
                    item.Enabled = estado;
                }

                pnlAcuCom.Enabled = PesAcuCome;

                pnlIntPro.Enabled = PesIntPro;
            }

        }

        private void dgvRegVis_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //Referenciamos el control TextBox subyacente en la celda actual.

            TextBox cellTextBox = (DataGridViewTextBoxEditingControl)e.Control;

            cellTextBox.ReadOnly = true;
        }

        private void dgvRegOTI_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //Referenciamos el control TextBox subyacente en la celda actual.

            TextBox cellTextBox = (DataGridViewTextBoxEditingControl)e.Control;

            cellTextBox.ReadOnly = true;
        }

        private void dgvRegOTI_formato()
        {
            dgvRegOTI.Font = new Font("Tahoma", 7);

            dgvRegOTI.Columns[0].Width = 80; //N° OTI
            dgvRegOTI.Columns[1].Width = 250;//Tipo de trabajo
            dgvRegOTI.Columns[2].Width = 150;//Clasificacion de trabajo
            dgvRegOTI.Columns[3].Width = 60; //RQ
            dgvRegOTI.Columns[4].Width = 80;//Fecha de inicio
            dgvRegOTI.Columns[5].Width = 80; //Fecha de fin
            dgvRegOTI.Columns[6].Width = 50;//moneda
            dgvRegOTI.Columns[7].Width = 70;//monto oti
        }

        private void dgvRegRuta_formato()
        {
            try
            {
                dgvRegRuta.Columns[0].Width = 80; //[N° Mov]
                dgvRegRuta.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvRegRuta.Columns[1].Width = 100;//[Fecha Despacho]
                dgvRegRuta.Columns[2].Width = 150;//[Medio Transporte]
                dgvRegRuta.Columns[3].Width = 60; //RQ
                dgvRegRuta.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvRegRuta.Columns[4].Width = 80;//[N° Ruta]
                dgvRegRuta.Columns[5].Width = 100; //[Tipo de trabajo]
            }catch { }
            
    }

        private void dgvRegOTI_DataSourceChanged(object sender, EventArgs e)
        {
            dgvRegOTI_formato();
        }

        private void txtEstObr_TextChanged(object sender, EventArgs e)
        {

        }

        private void fgFormato()
        {
            this.fgFecAprIns.Cols[0].Width = 100;
            this.fgFecAprIns.Cols[1].Width = 100;
            this.fgFecAprIns.Cols[2].Width = 100;
            this.fgFecAprIns.Cols[2].EditMask = "##/####";

            this.fgFecAprIns.Cols[2].TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
        }

        private void fgFecAprIns_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            fgFormato();
        }

        private void btnTer_Click(object sender, EventArgs e)
        {
            OPE_Pro_Botones(btnTer);
        }

        private void OPE_Pro_Botones(ToolStripButton boton)
        {
            switch (boton.Text)
            {
                case "&Nuevo":
                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 1, "nue", 0) == 1)
                    {
                        frmOPE_Pro_ingact f = new frmOPE_Pro_ingact();

                        f.MdiParent = this.MdiParent;

                        f.LimpiarControles();
                        f.Show();
                        //
                        this.Dispose();
                    }
                    else
                    {
                        MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    break;

                case "&Abrir":

                    bool Existe;

                    Existe = false;

                    Form frm = this.MdiParent.MdiChildren.FirstOrDefault(x => x is frmOPE_Pro_VisGen);

                    if (frm != null)
                    {
                        frm.BringToFront();
                        frm.Show();

                        Existe = true;
                    }

                    if (Existe == false)
                    {
                        frmOPE_Pro_VisGen f = new frmOPE_Pro_VisGen();

                        f.WindowState = FormWindowState.Maximized;
                        f.MdiParent = this.MdiParent;                        
                        f.Show();
                    }

                    this.Dispose();

                    break;

                case "&Guardar":

                    //validamos agregar estado obra
                    if (string.IsNullOrEmpty(txtCodEstObr.Text) == true)
                    {
                        MessageBox.Show("Debe seleccionar un estado de obra", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtEstObr.Focus();
                        return;
                    }

                    //Validamos fecha
                    DateTime fecha;

                    mtxtFecIni.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;

                    if (!String.IsNullOrEmpty(mtxtFecIni.Text) & mtxtFecIni.MaskFull == true)
                    {
                        mtxtFecIni.TextMaskFormat = MaskFormat.IncludeLiterals;

                        if (!DateTime.TryParse(mtxtFecIni.Text, out fecha))
                        {

                            MessageBox.Show("Fecha de carcasas/tabler... incorrecta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            mtxtFecIni.Focus();
                            return;
                        }
                    }
                    else if (!String.IsNullOrEmpty(mtxtFecIni.Text) & mtxtFecIni.MaskFull == false)
                    {
                        MessageBox.Show("Debe llenar todos los valores en la Fecha de carcasas/tabler...", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        mtxtFecIni.Focus();
                        return;
                    }

                    mtxtFecCab.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;

                    if (!String.IsNullOrEmpty(mtxtFecCab.Text) & mtxtFecCab.MaskFull == true)
                    {
                        mtxtFecCab.TextMaskFormat = MaskFormat.IncludeLiterals;

                        if (!DateTime.TryParse(mtxtFecCab.Text, out fecha))
                        {
                            MessageBox.Show("Fecha de cableado incorrecta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            mtxtFecCab.Focus();
                            return;
                        }
                    }
                    else if (!String.IsNullOrEmpty(mtxtFecCab.Text) & mtxtFecCab.MaskFull == false)
                    {
                        MessageBox.Show("Debe llenar todos los valores en la fecha de cableado", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        mtxtFecCab.Focus();
                        return;
                    }


                    mtxtFecFin.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;

                    if (!String.IsNullOrEmpty(mtxtFecFin.Text) & mtxtFecFin.MaskFull == true)
                    {
                        mtxtFecFin.TextMaskFormat = MaskFormat.IncludeLiterals;

                        if (!DateTime.TryParse(mtxtFecFin.Text, out fecha))
                        {
                            MessageBox.Show("Fecha de finalización incorrecta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            mtxtFecFin.Focus();
                            return;
                        }
                    }
                    else if (!String.IsNullOrEmpty(mtxtFecFin.Text) & mtxtFecFin.MaskFull == false)
                    {
                        MessageBox.Show("Debe llenar todos los valores en la fecha aprox. de instalacion", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        mtxtFecFin.Focus();
                        return;
                    }

                    if (txtCodEstObr.Text == "15")
                    {
                        if (String.IsNullOrEmpty(mtxtFecFin.Text))
                        {
                            MessageBox.Show("Si el estado de Obra o estado del proyecto es Terminado debe agregar una fecha de finalización valida.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            mtxtFecFin.Focus();
                            return;
                        }

                    }

                    //Entidad encabezado de OPE_Pro donde tambien se llama a los detalles
                    OPE_Pro Enc = new OPE_Pro();

                    Enc.NumMov = Convert.ToInt64(txtNumMov.Text);
                    Enc.CodEstObr = Convert.ToInt16(txtCodEstObr.Text);

                    //Si el valor del campo es vacio se envia un null
                    if (!String.IsNullOrEmpty(mtxtFecIni.Text))
                    {
                        Enc.FecIni = Convert.ToDateTime(this.mtxtFecIni.Text);
                    }
                    else
                    {
                        Enc.FecIni = null;
                    }

                    //Si el valor del campo es vacio se envia un null
                    if (!String.IsNullOrEmpty(mtxtFecCab.Text))
                    {
                        Enc.FecCab = Convert.ToDateTime(this.mtxtFecCab.Text);
                    }
                    else
                    {
                        Enc.FecCab = null;
                    }

                    //Si el valor del campo es vacio se envia un null
                    if (!String.IsNullOrEmpty(mtxtFecFin.Text))
                    {
                        Enc.FecFin = Convert.ToDateTime(this.mtxtFecFin.Text);
                    }
                    else
                    {
                        Enc.FecFin = null;
                    }

                    Enc.AlcPro = this.txtAlcPro.Text;                                        

                    //Recorremos el DataSet para agregar las lineas de detalle cero
                    foreach (DataRow dr in Det1.Rows)
                    {
                        OPE_Pro_Det1 Det1 = new OPE_Pro_Det1();

                        //Det0.NumMov = Convert.ToInt64(this.txtNumMov.Text);
                        Det1.NumMov = Convert.ToInt64(txtNumMov.Text);
                        Det1.RQ = Convert.ToInt32(dr["RQ"].ToString());
                        Det1.Dis_DurEst_Mes = Convert.ToInt32(dr["Dis_DurEst_Mes"].ToString());
                        Det1.Dis_CanVis_Und = Convert.ToInt32(dr["Dis_CanVis_Und"].ToString());
                        Det1.Dis_TraOfi_Hor = Convert.ToInt32(dr["Dis_TraOfi_Hor"].ToString());
                        Det1.Dis_TraPla_Hor = Convert.ToInt32(dr["Dis_TraPla_Hor"].ToString());
                        Det1.Dis_TraDia_Hor = Convert.ToInt32(dr["Dis_TraDia_Hor"].ToString());
                        Det1.Dis_CosDir = Convert.ToDecimal(dr["Dis_CosDir"].ToString());
                        Det1.Dis_CosInd = Convert.ToDecimal(dr["Dis_CosInd"].ToString());
                        Det1.Dis_GasGen = Convert.ToDecimal(dr["Dis_GasGen"].ToString());
                        Det1.Dis_Uti = Convert.ToDecimal(dr["Dis_Uti"].ToString());

                        Det1.Sup_DurEst_Mes = Convert.ToInt32(dr["Sup_DurEst_Mes"].ToString());
                        Det1.Sup_CanVisIngOpe_Und = Convert.ToInt32(dr["Sup_CanVisIngOpe_Und"].ToString());
                        Det1.Sup_TraOfiOpe_Hor = Convert.ToInt32(dr["Sup_TraOfiOpe_Hor"].ToString());
                        Det1.Sup_CanVisSup_Und = Convert.ToInt32(dr["Sup_CanVisSup_Und"].ToString());
                        Det1.Sup_CanPruMue_Und = Convert.ToInt32(dr["Sup_CanPruMue_Und"].ToString());
                        Det1.Sup_CanPruMueDobAlt_Und = Convert.ToInt32(dr["Sup_CanPruMueDobAlt_Und"].ToString());
                        Det1.Sup_CanPrueMeg_Und = Convert.ToInt32(dr["Sup_CanPrueMeg_Und"].ToString());
                        Det1.Sup_CosDir = Convert.ToDecimal(dr["Sup_CosDir"].ToString());
                        Det1.Sup_CosInd = Convert.ToDecimal(dr["Sup_CosInd"].ToString());
                        Det1.Sup_GasGen = Convert.ToDecimal(dr["Sup_GasGen"].ToString());
                        Det1.Sup_Uti = Convert.ToDecimal(dr["Sup_Uti"].ToString());

                        Det1.Ins_DurEst_Dia = Convert.ToInt32(dr["Ins_DurEst_Dia"].ToString());
                        Det1.Ins_CanTecDia_Und = Convert.ToInt32(dr["Ins_CanTecDia_Und"].ToString());
                        Det1.Ins_CanVisCoo_Und = Convert.ToInt32(dr["Ins_CanVisCoo_Und"].ToString());
                        Det1.Ins_CanViaMov_Und = Convert.ToInt32(dr["Ins_CanViaMov_Und"].ToString());
                        Det1.Ins_CanPruLuc_Und = Convert.ToInt32(dr["Ins_CanPruLuc_Und"].ToString());
                        Det1.Ins_CosTraNoc_Sol = Convert.ToDecimal(dr["Ins_CosTraNoc_Sol"].ToString());
                        Det1.Ins_CosMat_Sol = Convert.ToDecimal(dr["Ins_CosMat_Sol"].ToString());
                        Det1.Ins_CosDir = Convert.ToDecimal(dr["Ins_CosDir"].ToString());
                        Det1.Ins_CosInd = Convert.ToDecimal(dr["Ins_CosInd"].ToString());
                        Det1.Ins_GasGen = Convert.ToDecimal(dr["Ins_GasGen"].ToString());
                        Det1.Ins_Uti = Convert.ToDecimal(dr["Ins_Uti"].ToString());

                        Det1.Pro_DurEst_Dia = Convert.ToInt32(dr["Pro_DurEst_Dia"].ToString());
                        Det1.Pro_CanBotSenDri_Und = Convert.ToInt32(dr["Pro_CanBotSenDri_Und"].ToString());
                        Det1.Pro_CanModRepAmp_Und = Convert.ToInt32(dr["Pro_CanModRepAmp_Und"].ToString());
                        Det1.Pro_CanPanConLic_Und = Convert.ToInt32(dr["Pro_CanPanConLic_Und"].ToString());
                        Det1.Pro_CosPro_Sol = Convert.ToDecimal(dr["Pro_CosPro_Sol"].ToString());
                        Det1.Pro_CosDir = Convert.ToDecimal(dr["Pro_CosDir"].ToString());
                        Det1.Pro_CosInd = Convert.ToDecimal(dr["Pro_CosInd"].ToString());
                        Det1.Pro_GasGen = Convert.ToDecimal(dr["Pro_GasGen"].ToString());
                        Det1.Pro_Uti = Convert.ToDecimal(dr["Pro_Uti"].ToString());

                        Enc.Det1.Add(Det1);
                    }


                    //Recorremos el flexgrid 
                    for (int i = 0; i < fgIntPro.Rows.Count; i++)
                    {

                    }

                    foreach (Row row in fgIntPro.Rows)
                    {
                        if (row.Index > 0)
                        {
                            OPE_Pro_Det4 Det4 = new OPE_Pro_Det4();

                            //Det0.NumMov = Convert.ToInt64(this.txtNumMov.Text);
                            Det4.NumMov = Convert.ToInt64(txtNumMov.Text);
                            Det4.Item = Convert.ToInt32(row[0]);
                            Det4.CodIntPro = Convert.ToInt32(row[1]);
                            Det4.Nom = (row[3]).ToString();
                            Det4.Cel1 = (row[4]).ToString();
                            Det4.Cel2 = (row[5]).ToString();
                            Det4.Email = (row[6]).ToString();
                            Det4.ResFirGui = Convert.ToBoolean(row[7]);
                            Det4.ResActVis = Convert.ToBoolean(row[8]);

                            Enc.Det4.Add(Det4);
                        }

                    }

                    nop.OPE_Pro_Det1(Enc);

                    OPE_Pro_EstBot("guardar");

                    OPE_Pro_HabilitarDeshabilitar(false);

                    break;

                case "Modificar":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 4, "mod", 0) == 1)
                    {
                        OPE_Pro_EstBot("modificar");

                        OPE_Pro_HabilitarDeshabilitar(true);
                    }
                    else
                    {
                        MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }

                    break;

                case "Terminado":

                    if (txtCodEstObr.Text != "15")
                    { MessageBox.Show("El estado de la obra debe estar en (15 - TERMINADO).", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

                    mtxtFecFin.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;

                    if (!String.IsNullOrEmpty(mtxtFecFin.Text) & mtxtFecFin.MaskFull == true)
                    {
                        mtxtFecFin.TextMaskFormat = MaskFormat.IncludeLiterals;

                        if (!DateTime.TryParse(mtxtFecFin.Text, out fecha))
                        {
                            MessageBox.Show("Fecha de finalización incorrecta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            mtxtFecFin.Focus();
                            return;
                        }
                    }
                    else if (!String.IsNullOrEmpty(mtxtFecFin.Text) & mtxtFecFin.MaskFull == false)
                    {
                        MessageBox.Show("Debe llenar todos los valores en la fecha aprox. de instalacion", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        mtxtFecFin.Focus();
                        return;
                    }

                    if (String.IsNullOrEmpty(mtxtFecFin.Text))
                    {
                        MessageBox.Show(@"Si el Estado de Obra es 'TERMINADO' o quieres actualizar el Estado " + 
                                         "del proyecto a 'TERMINADO', debe agregar una fecha de " +
                                        "finalización valida.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        mtxtFecFin.Focus();
                        return;
                    }
                    else
                    {
                        OPE_Pro_ConEst("ter", Convert.ToByte(boton.Tag)); 
                    }

                    break;

                case "Archivado":

                    OPE_Pro_ConEst("arc", Convert.ToByte(boton.Tag)); break;

                default:

                    break;
            }

        }

        private void OPE_Pro_ConEst(string cadbot, byte codest)
        {
            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 4, cadbot, 0) == 1)
            {
                DialogResult res = MessageBox.Show("¿Esta seguro de realizar esta acción?", "SAP Adicional", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (res == DialogResult.Yes)
                {
                    nop.OPE_Pro_Est(Convert.ToInt64(txtNumMov.Text), varglo.CodUsuAct, codest);

                    EstDoc = codest;

                    switch (codest)
                    {
                        case 2:
                            this.Text = "Proyecto - TERMINADO"; break;
                        case 3:
                            this.Text = "Proyecto - PARALIZADO"; break;
                        case 4:
                            this.Text = "Proyecto - ARCHIVADO"; break;

                    }

                    OPE_Pro_EstBot("abrir");
                }
            }
            else
            {
                MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtCodEstObr_TextChanged(object sender, EventArgs e)
        {
             if (txtCodEstObr.Text == "15")
            {
                lblFecfin.Visible = true; mtxtFecFin.Visible = true;
                mtxtFecFin.Focus();
            }
            else
            {
                lblFecfin.Visible = false; mtxtFecFin.Visible = false;
                mtxtFecFin.Text = "";
            }

        }

        private void tsrMAct_Click(object sender, EventArgs e)
        {
            if (EstDoc == 3)
            {
                OPE_Pro_ConEst("act", 1);
            }
            else
            {
                MessageBox.Show("El estado del proyecto ya es Activo","SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnPar_ButtonClick(object sender, EventArgs e)
        {
            if (EstDoc == 1)
            {
                OPE_Pro_ConEst("par", 3);
            }
            else
            {
                MessageBox.Show("El estado del proyecto ya es Paralizado", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        string fecaprins;

        private void fgFecAprIns_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 2)
            {
                try
                {
                    Convert.ToDateTime(fgFecAprIns.Rows[e.Row][2]);

                    nop.OPE_Pro_ActFecAprIns(Convert.ToInt64(txtNumMov.Text),
                                            varglo.CodUsuAct,
                                            Convert.ToDateTime(fgFecAprIns.Rows[e.Row][2]),
                                            Convert.ToInt64(fgFecAprIns.Rows[e.Row][1]));
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message,"SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information);
                    fgFecAprIns.Rows[e.Row][2] = fecaprins;

                }


            }
        }

        private void fgIntPro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 46)
            {
                DialogResult result = MessageBox.Show("¿Esta seguro de eliminar esta linea?", "SAP Adicional", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    fgIntPro.Rows.Remove(fgIntPro.Row);

                    foreach (Row row in fgIntPro.Rows)
                    {
                        if (row.Index > 0)
                        {
                            row[0] = row.Index + 1;
                        }
                        
                    }
                }
            }
        }

        private void fgIntPro_BeforeEdit(object sender, RowColEventArgs e)
        {

        }

        private void fgIntPro_AfterEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 7)
            {
                foreach (Row row in fgIntPro.Rows)
                {
                    if (row.Index > 0)
                    {
                        if (row.Index != e.Row && Convert.ToBoolean(row[7]) == true)
                        {
                            MessageBox.Show("Ya existe otro predeterminado OTI","SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information);
                            fgIntPro.Rows[e.Row][7] = false;
                            return;
                        }                        
                    }
                }
            }

            if (e.Col == 8)
            {
                foreach (Row row in fgIntPro.Rows)
                {
                    if (row.Index > 0)
                    {
                        if (row.Index != e.Row && Convert.ToBoolean(row[8]) == true)
                        {
                            MessageBox.Show("Ya existe otro predeterminado actas", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            fgIntPro.Rows[e.Row][8] = false;
                            return;
                        }
                    }
                }
            }
        }

        private void fgFecAprIns_StartEdit(object sender, RowColEventArgs e)
        {
            fecaprins = fgFecAprIns.Rows[e.Row][2].ToString();
        }
    }
}
