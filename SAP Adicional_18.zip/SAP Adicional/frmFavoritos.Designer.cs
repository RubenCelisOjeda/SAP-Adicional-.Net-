﻿namespace SAP_Adicional
{
    partial class frmFavoritos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFavoritos));
            this.pnlControles = new System.Windows.Forms.Panel();
            this.cbxOcuMen = new System.Windows.Forms.CheckBox();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlBarra = new System.Windows.Forms.Panel();
            this.lblMini = new System.Windows.Forms.Label();
            this.lblCer = new System.Windows.Forms.Label();
            this.imgLis = new System.Windows.Forms.ImageList(this.components);
            this.pnlControles.SuspendLayout();
            this.pnlBarra.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlControles
            // 
            this.pnlControles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlControles.BackColor = System.Drawing.Color.White;
            this.pnlControles.Controls.Add(this.cbxOcuMen);
            this.pnlControles.Controls.Add(this.pnlForm);
            this.pnlControles.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlControles.ForeColor = System.Drawing.Color.Black;
            this.pnlControles.Location = new System.Drawing.Point(5, 32);
            this.pnlControles.Name = "pnlControles";
            this.pnlControles.Size = new System.Drawing.Size(311, 625);
            this.pnlControles.TabIndex = 14;
            this.pnlControles.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlControles_MouseMove);
            // 
            // cbxOcuMen
            // 
            this.cbxOcuMen.AutoSize = true;
            this.cbxOcuMen.Location = new System.Drawing.Point(10, 599);
            this.cbxOcuMen.Name = "cbxOcuMen";
            this.cbxOcuMen.Size = new System.Drawing.Size(132, 17);
            this.cbxOcuMen.TabIndex = 12;
            this.cbxOcuMen.Text = "Ocultar menú principal";
            this.cbxOcuMen.UseVisualStyleBackColor = true;
            this.cbxOcuMen.Visible = false;
            this.cbxOcuMen.CheckedChanged += new System.EventHandler(this.cbxOcuMen_CheckedChanged);
            // 
            // pnlForm
            // 
            this.pnlForm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlForm.AutoScroll = true;
            this.pnlForm.BackColor = System.Drawing.Color.White;
            this.pnlForm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlForm.Location = new System.Drawing.Point(10, 10);
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Size = new System.Drawing.Size(293, 586);
            this.pnlForm.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(98, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Menú Favoritos";
            this.label1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label1_MouseMove);
            // 
            // pnlBarra
            // 
            this.pnlBarra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBarra.BackColor = System.Drawing.Color.Gray;
            this.pnlBarra.Controls.Add(this.lblMini);
            this.pnlBarra.Controls.Add(this.label1);
            this.pnlBarra.Controls.Add(this.lblCer);
            this.pnlBarra.Location = new System.Drawing.Point(5, 3);
            this.pnlBarra.Name = "pnlBarra";
            this.pnlBarra.Size = new System.Drawing.Size(311, 26);
            this.pnlBarra.TabIndex = 15;
            this.pnlBarra.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBarra_MouseMove);
            // 
            // lblMini
            // 
            this.lblMini.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblMini.BackColor = System.Drawing.Color.White;
            this.lblMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMini.Image = ((System.Drawing.Image)(resources.GetObject("lblMini.Image")));
            this.lblMini.Location = new System.Drawing.Point(260, 3);
            this.lblMini.Name = "lblMini";
            this.lblMini.Size = new System.Drawing.Size(18, 17);
            this.lblMini.TabIndex = 11;
            this.lblMini.Click += new System.EventHandler(this.lblMini_Click);
            // 
            // lblCer
            // 
            this.lblCer.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblCer.BackColor = System.Drawing.Color.White;
            this.lblCer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCer.Image = ((System.Drawing.Image)(resources.GetObject("lblCer.Image")));
            this.lblCer.Location = new System.Drawing.Point(285, 3);
            this.lblCer.Name = "lblCer";
            this.lblCer.Size = new System.Drawing.Size(20, 17);
            this.lblCer.TabIndex = 0;
            this.lblCer.Click += new System.EventHandler(this.lblCer_Click);
            // 
            // imgLis
            // 
            this.imgLis.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLis.ImageStream")));
            this.imgLis.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLis.Images.SetKeyName(0, "btnImagen.png");
            // 
            // frmFavoritos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(321, 660);
            this.ControlBox = false;
            this.Controls.Add(this.pnlBarra);
            this.Controls.Add(this.pnlControles);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximizeBox = false;
            this.Name = "frmFavoritos";
            this.Load += new System.EventHandler(this.frmFavoritos_Load);
            this.pnlControles.ResumeLayout(false);
            this.pnlControles.PerformLayout();
            this.pnlBarra.ResumeLayout(false);
            this.pnlBarra.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlControles;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlBarra;
        private System.Windows.Forms.Label lblMini;
        private System.Windows.Forms.Label lblCer;
        private System.Windows.Forms.ImageList imgLis;
        public System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.CheckBox cbxOcuMen;
    }
}