﻿using CapaNegocio;
using SAP_Adicional.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmFavoritos : Form
    {
        VarGlo varglo = VarGlo.Instance();
        NMenFav menFav = new NMenFav();
        int posY = 0;
        int posX = 0;
        string nombreMenu = "";
        string nombreOrigen = "";
        int ubiNue = 0;
        int espacio = 3;
        public frmFavoritos()
        {
            InitializeComponent();
           
        }

        private void lblMini_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Minimized;
            }
        }

        private void lblCer_Click(object sender, EventArgs e)
        {
            if (cbxOcuMen.Checked)
            {
                MessageBox.Show("Desmarque el check de menu principal para poder cerrar el menú favoritos","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            else
            {
                this.Dispose();
            }            
        }

        private void pnlControles_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender, e);
        }

        private void pnlBarra_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender,e);
        }
        void MenuFavoritos_MoverForm(object sender, MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }
        }


        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender, e);
        }

        private void frmMenuFavoritos_MouseMove(object sender, MouseEventArgs e)
        {
            MenuFavoritos_MoverForm(sender, e);
        }

        private void frmFavoritos_Load(object sender, EventArgs e)
        {
            Favoritos_RecMenus();
        }
        public void Favoritos_RecMenus()
        {
            DataTable dtRecMenFav = new DataTable();
            dtRecMenFav = menFav.MenFav_RecMenFav(Convert.ToInt16(VarGlo.Instance().CodUsuAct));

            if (dtRecMenFav.Rows.Count > 0)
            {
                for (int i = 0; i < dtRecMenFav.Rows.Count; i++)
                {
                    nombreMenu = dtRecMenFav.Rows[i][1].ToString();
                    nombreOrigen = dtRecMenFav.Rows[i][0].ToString();

                    Button btn = new Button();
                    btn.BackColor = Color.Silver;
                    btn.Cursor = Cursors.Hand;
                    btn.FlatStyle = FlatStyle.Popup;
                    btn.Font = new Font("Tahoma", 6.75F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(0)));
                    btn.ForeColor = Color.Gold;
                    btn.TextAlign = ContentAlignment.MiddleCenter;
                    btn.ImageAlign = ContentAlignment.MiddleLeft;
                    btn.ImageIndex = 0;
                    btn.ImageList = imgLis;
                    btn.Tag = nombreOrigen;
                    btn.Size = new Size(281, 23);
                   
                    if (i == 0) //primer boton en aparecer
                    {
                        btn.Location = new Point(4, espacio);
                    }
                    else
                    {
                        btn.Location = new Point(4, ubiNue + espacio);
                    }

                    btn.Name = "button" + i;
                    btn.TabIndex = i;
                    btn.Text = nombreMenu;
                    btn.UseVisualStyleBackColor = false;
                    pnlForm.Controls.Add(btn); //cada boton agregado sumar mas 2 a la variable
                    ubiNue = ubiNue + btn.Height;
                    espacio = espacio + 2;

                    btn.Click += new EventHandler(this.button_Click);
                    
                }
            }
            else
            {
                return;
            }
        }
        private void button_Click(object sender, EventArgs e)
        {
            string btnEven = "";
            btnEven = ((Button)sender).Tag.ToString();

            Form f = new Form();

            var t = Type.GetType("SAP_Adicional." + btnEven);
            Form frm = Activator.CreateInstance(t) as Form;
            f = frm;

            if (varglo.Empresa.Contains("HOME"))
            {
                f.Icon = SAP_Adicional.Properties.Resources.IconoTrazzoHome;
            }
            else
            {
                
                f.Icon = SAP_Adicional.Properties.Resources.TRAZZOICONO;
            }

            //evento a la hora de hacer click
           
            f.Size = new Size(1019, 676);
            f.MdiParent = this.MdiParent;
            f.Show();
            f.Location = frm.Location = new Point(337, 0);
        }

        private void cbxOcuMen_CheckedChanged(object sender, EventArgs e)
        {
            frmPri frmFav = new frmPri();

            if (cbxOcuMen.Checked)
            {
                foreach (Control c in VarGlo.Instance().frmNuevo.Controls)
                {
                    if (c is MenuStrip)
                    {
                        c.Visible = false;
                    }
                }
            }
            else
            {
                foreach (Control c in VarGlo.Instance().frmNuevo.Controls)
                {
                    if (c is MenuStrip)
                    {
                        c.Visible = true;
                    }
                }
            }
        }
    }
}
