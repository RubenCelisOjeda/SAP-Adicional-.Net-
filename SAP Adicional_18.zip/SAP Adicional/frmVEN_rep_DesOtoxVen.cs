﻿
using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmVEN_rep_DesOtoxVen : Form
    {
        NConsultas nc = new NConsultas();
        DataTable dt;

        public frmVEN_rep_DesOtoxVen()
        {
            InitializeComponent();
        }

        private void frmVEN_rep_Fac_Load(object sender, EventArgs e)
        {
            //DisenoColumnas();
            //dgv.Rows.Count = 5;
            //ColumnasTamano();

            dgv.Styles.Normal.WordWrap = true;
            dgv.Rows.Count = 1;
            dgv.Cols.Count = 1;
            dgv.Rows[0].Height = 50;
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtpInicio.Checked == false && dtpFinal.Checked == false)
                {
                    return;
                }
                else
                {
                    this.dt = nc.VEN_rep_DesOtoxVen(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text));
                    this.dgv.DataSource = dt;

                    FormatoGeneral();
                    //ColumnasTamano();
                }
            }
            catch
            {

            }
        }
        public void DisenoColumnas()
        {
            //DISEÑO DE COLUMNAS
            dgv.Styles.Normal.WordWrap = true;
            dgv.Cols.Count = 35;
            dgv.Rows.Fixed = 5;
            dgv.Rows.Frozen = 1;
            dgv.Cols.Frozen = 6;
            dgv.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
            dgv.Styles.Fixed.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
            C1.Win.C1FlexGrid.CellRange rng;
            dgv.Rows[0].AllowMerging = true;
            dgv.Rows[1].AllowMerging = true;

            for (int i = 0; i < dgv.Cols.Count; i++)
            {
                dgv.Cols[i].AllowMerging = true;
            }

            rng = dgv.GetCellRange(0, 0, 4, 0);
            rng.Data = "RQ";

            rng = dgv.GetCellRange(0, 1, 4, 1);
            rng.Data = "             Nombre de Cliente " + "           ";

            rng = dgv.GetCellRange(0, 2, 4, 2);
            rng.Data = "             Nombre de la Venta " + "           ";

            rng = dgv.GetCellRange(0, 3, 4, 3);
            rng.Data = "     Empleado de Ventas " + "   ";

            rng = dgv.GetCellRange(0, 4, 4, 4);
            rng.Data = "Motivo";

            rng = dgv.GetCellRange(0, 5, 4, 5);
            rng.Data = "Centro Venta";

            rng = dgv.GetCellRange(0, 6, 4, 6);
            rng.Data = "Tipo de Venta";

            rng = dgv.GetCellRange(0, 7, 4, 7);
            rng.Data = "Tipo de Venta Relativo";

            rng = dgv.GetCellRange(0, 8, 4, 8);
            rng.Data = "Rubro";

            rng = dgv.GetCellRange(0, 9, 4, 9);
            rng.Data = "Tipo de Obra";

            rng = dgv.GetCellRange(0, 10, 4, 10);
            rng.Data = "Dimension";

            rng = dgv.GetCellRange(0, 11, 4, 11);
            rng.Data = "Moneda";

            rng = dgv.GetCellRange(0, 12, 0, 14);
            rng.Data = "V. VTA USD";

            rng = dgv.GetCellRange(1, 12, 4, 12);
            rng.Data = "Mercaderia";

            rng = dgv.GetCellRange(1, 13, 4, 13);
            rng.Data = "Servicio";

            rng = dgv.GetCellRange(1, 14, 4, 14);
            rng.Data = "Gran Total SIN IGV";

            //FILA PRINCUPAL
            rng = dgv.GetCellRange(0, 15, 0, 34); rng.Data = "V. Venta USD -Servicios";

            rng = dgv.GetCellRange(1, 15, 1, 18);
            rng.Data = "Supervisión y Diseño";
            ;
            rng = dgv.GetCellRange(2, 15, 4, 15);
            rng.Data = "     Diseño   ";

            rng = dgv.GetCellRange(2, 16, 4, 16);
            rng.Data = "Supervision Tecnica";

            rng = dgv.GetCellRange(2, 17, 4, 17);
            rng.Data = "Supervision y Replanteo por Arquitectura";

            rng = dgv.GetCellRange(2, 18, 4, 18);
            rng.Data = "Total Supervision y Diseño";

            rng = dgv.GetCellRange(1, 19, 1, 24);
            rng.Data = "Instalacion";

            rng = dgv.GetCellRange(2, 19, 4, 19);
            rng.Data = "Instalacion de Equipos CLN    (Cortinas)";

            rng = dgv.GetCellRange(2, 20, 4, 20);
            rng.Data = "Instalacion de Equipos de Audio";

            rng = dgv.GetCellRange(2, 21, 4, 21);
            rng.Data = "Instalacion de Equipos de Control";

            rng = dgv.GetCellRange(2, 22, 4, 22);
            rng.Data = "Instalacion de Luminarias";

            rng = dgv.GetCellRange(2, 23, 4, 23);
            rng.Data = "Instalacion de Luminarias   (Jardines)";

            rng = dgv.GetCellRange(2, 24, 4, 24);
            rng.Data = "Total Instalacion";

            rng = dgv.GetCellRange(1, 25, 1, 30);
            rng.Data = "Otros Servicios";

            rng = dgv.GetCellRange(2, 25, 4, 25);
            rng.Data = "Servicio de Albañileria";

            rng = dgv.GetCellRange(2, 26, 4, 26);
            rng.Data = "Servicio de Modificacion de Producto";

            rng = dgv.GetCellRange(2, 27, 4, 27);
            rng.Data = "Servicio de Movilidad";

            rng = dgv.GetCellRange(2, 28, 4, 28);
            rng.Data = "Trabajo de Cableado";

            rng = dgv.GetCellRange(2, 29, 4, 29);
            rng.Data = "Trabajos de Pintura";

            rng = dgv.GetCellRange(2, 30, 4, 30);
            rng.Data = "Total Otros Servicios";

            rng = dgv.GetCellRange(1, 31, 1, 34);
            rng.Data = "Programacion de Equipos Audio/Video";

            rng = dgv.GetCellRange(2, 31, 4, 31);
            rng.Data = "Programación de Equipos de Audio/Video";

            rng = dgv.GetCellRange(2, 32, 4, 32);
            rng.Data = "Programación de Equipos de Control";

            rng = dgv.GetCellRange(2, 33, 4, 33);
            rng.Data = "Programación de Pantallas Tactiles";

            rng = dgv.GetCellRange(2, 34, 4, 34);
            rng.Data = "Total Programación";

            // Alinea y autosize las celdas.
            dgv.Styles.Fixed.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
        }
        public void FormatoGeneral()
        {

            //dgv.Styles.Alternate.BackColor = Color.LightBlue;
            //dgv.Styles.Highlight.BackColor = Color.Blue;
            //dgv.Styles.Highlight.ForeColor = Color.White;
            dgv.AllowFreezing = AllowFreezingEnum.Both;
            dgv.Cols.Frozen = 4;
            dgv.Rows.Frozen = 1;
            CellStyle s = dgv.Styles[CellStyleEnum.Subtotal0];
            s.BackColor = Color.Yellow;
            s.ForeColor = Color.Blue;

            ColumnasTamano();
            //DisenoColumnas();        
        }
        public void ColumnasTamano()
        {            
            dgv.Cols[0].Width = 60;
            dgv.Cols[1].Width = 70;
            dgv.Cols[2].Width = 70;
            dgv.Cols[3].Width = 300; //Cliente
            dgv.Cols[4].Width = 250;//Nombre
            dgv.Cols[5].Width = 150;//Vendedor
            dgv.Cols[6].Width = 100;
            dgv.Cols[7].Width = 110;
            dgv.Cols[8].Width = 110;
            dgv.Cols[9].Width = 70;//Rubro
            dgv.Cols[10].Width = 80;
            dgv.Cols[11].Width = 70;//
            dgv.Cols[12].Width = 80;//
            dgv.Cols[13].Width = 80;//

            dgv.Cols[10].Format = "#,###.00";
            dgv.Cols[11].Format = "#,###.00";
            dgv.Cols[12].Format = "#,###.00";
        }
        private void dgv_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {          
            Suma();
        }

        public void Suma()
        {

            decimal a = 0;
            decimal c = 0;

            try
            {
                 
                dgv.Subtotal(AggregateEnum.Sum, 0, -1, 10, "TOTALES");
                dgv.Subtotal(AggregateEnum.Sum, 0, -1, 11, "TOTALES");
                dgv.Subtotal(AggregateEnum.Sum, 0, -1, 12, "TOTALES");

                a = Convert.ToDecimal(dgv.Cols[10][1]);
                c = Convert.ToDecimal(dgv.Cols[12][1]);

                dgv.Cols[0][1] = "TOTALES";
                dgv.Cols[13][1] =  decimal.Round(1 - (c / a),2);

            }
            catch
            {

            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void dgv_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        public void ExportExcel()
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            dgv.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }    
          
        private void btnExp_Click(object sender, EventArgs e)
        {
            ExportExcel();
        }

        private void dgv_AfterFilter(object sender, EventArgs e)
        {
            Suma();
        }
    }

}
