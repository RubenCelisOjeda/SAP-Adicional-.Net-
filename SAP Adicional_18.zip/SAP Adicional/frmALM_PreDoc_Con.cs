﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using CrystalDecisions.CrystalReports.Engine;
using Interfaces;
using SAP_Adicional.Reportes;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_PreDoc_Con : Form, ALM_PreDoc_Con
    {
        private NALM_PreDoc_Con nDc = new NALM_PreDoc_Con();
        private VarGlo varglo = VarGlo.Instance();
        private string _msg = "";

        public frmALM_PreDoc_Con()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private void frmALM_PreDoc_Con_Load(object sender, EventArgs e)
        {
            this.txtCodRut.ReadOnly = true;
            this.txtCodAlm.ReadOnly = true;
            this.chkAgr.Checked = true;
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            //Valida que la fecha de inicio no sea mayor a la final
            if (dtpDes.Value.Date > dtpHas.Value.Date)
            {
                _msg = "La fecha de inicio no puede ser mayor a la fecha final.";
                this.ALM_PreDoc_Con_MosMsgStrip(_msg,Color.DodgerBlue);
                this.dtpDes.Focus();
                return;
            }

            //Valida que la fecha final no sea mayor a la actual
            if (dtpHas.Value.Date > DateTime.Now)
            {
                _msg = "La fecha final no puede ser mayor a la fecha actual.";
                this.ALM_PreDoc_Con_MosMsgStrip(_msg, Color.DodgerBlue);
                this.dtpHas.Focus();
                return;
            }

            DataTable dtRecDocCon = new DataTable();
            DataTable dtCle = new DataTable();
            dtCle.Clear();

            Int16 CodRut = 0;
            Int16.TryParse(this.txtCodRut.Text, out CodRut);

            //Valida si es falso
            if (!chkInfTra.Checked)
            {

                dtRecDocCon = nDc.PreDoc_Con_Rec(0,
                                                    Convert.ToInt16(this.chkAgr.Checked),
                                                    this.dtpDes.Value.Date,
                                                    this.dtpHas.Value.Date, CodRut,
                                                    this.txtCodAlm.Text,
                                                    this.chkSolSto.Checked);


                //Valida si hay datos
                if (dtRecDocCon.Rows.Count > 0)
                {
                    this.fgDocCon.DataSource = dtCle;
                    this.fgDocCon.DataSource = dtRecDocCon;
                    this.ALM_PreDoc_Con_DesignColumnas();
                }
                else
                {
                    this.fgDocCon.DataSource = dtCle;

                    _msg = "No se encontraron datos.";
                    this.ALM_PreDoc_Con_MosMsgStrip(_msg, Color.Red);
                    this.btnMos.Focus();
                }
            }
            else
            {
                dtRecDocCon = nDc.PreDoc_Con_Rec(1, 
                                                    Convert.ToByte(this.chkAgr.Checked),
                                                    this.dtpDes.Value.Date,
                                                    this.dtpHas.Value.Date, 
                                                    CodRut,
                                                    this.txtCodAlm.Text,
                                                    this.chkSolSto.Checked);

                if (dtRecDocCon.Rows.Count > 0)
                {
                    this.fgDocCon.DataSource = dtCle;
                    this.fgDocCon.DataSource = dtRecDocCon;
                    this.ALM_PreDoc_Con_DesignColumnas();
                }
                else
                {
                    this.fgDocCon.DataSource = dtCle;
                    _msg = "No se encontraron datos.";
                    this.ALM_PreDoc_Con_MosMsgStrip(_msg, Color.Red);
                    this.btnMos.Focus();
                }
            }

            Cursor.Current = Cursors.Default;
        }
        private void ALM_PreDoc_Con_FormatoGeneral()
        {
            //Formato del grid

            if (this.fgDocCon.Rows.Count > 1)
            {
                this.fgDocCon.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                this.fgDocCon.VisualStyle = VisualStyle.Office2010Silver;
                this.fgDocCon.Styles.Alternate.BackColor = Color.LightBlue;
                this.fgDocCon.Styles.Highlight.BackColor = Color.Blue;
                this.fgDocCon.Styles.Highlight.ForeColor = Color.White;
                this.fgDocCon.AllowFreezing = AllowFreezingEnum.Both;
            }
        }
        private void ALM_PreDoc_Con_DesignColumnas()
        {
            //Formato del margen de columnas

            if (this.fgDocCon.Rows.Count > 1)
            {
                this.fgDocCon.AllowMerging = AllowMergingEnum.Free;
                this.fgDocCon.Cols[0].AllowMerging = true;
                this.fgDocCon.Cols[1].AllowMerging = true;
                this.fgDocCon.Cols[2].AllowMerging = true;
                this.fgDocCon.Cols[3].AllowMerging = true;
            }
        }

        private void fgDocCon_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            this.ALM_PreDoc_Con_FormatoColumnas();
            this.ALM_PreDoc_Con_FormatoGeneral();
        }

        private void ALM_PreDoc_Con_FormatoColumnas()
        {
            try
            {
                //tamaño columnas para los 4 filtros
                this.fgDocCon.Cols["Articulo"].Width = 450;
                this.fgDocCon.Cols["Cantidad"].Width = 70;
                this.fgDocCon.Cols["Ubicacion"].Width = 150;
                this.fgDocCon.Cols["Almacen"].Width = 130;
                this.fgDocCon.Cols["EnStock"].Width = 50;

                if (this.chkAgr.Checked) //valida el check  para mostrar las columnas modificadas
                {
                    this.fgDocCon.Cols["SQO"].Width = 50;
                    this.fgDocCon.Cols["AC"].Width = 50;
                    this.fgDocCon.Cols["AC"].Style.Format = "0";
                    this.fgDocCon.Cols["SQO"].Style.Format = "#####.#";
                }
                if (this.chkAgr.Checked & this.chkSolSto.Checked)
                {
                    this.fgDocCon.Cols["SQO"].Width = 50;
                    this.fgDocCon.Cols["AC"].Width = 50;
                    this.fgDocCon.Cols["AC"].Style.Format = "0";
                    this.fgDocCon.Cols["SQO"].Style.Format = "#####.#";
                }

                this.fgDocCon.Cols["Cantidad"].Style.Format = "#####.##";
                this.fgDocCon.Cols["EnStock"].Style.Format = "#####.#";
            }
            catch (Exception)
            {
                return;
            }
        }

        private void fgDocCon_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //No permite editar
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {       
            //exportar excel
            MetGlo.ExportarExcel(this.fgDocCon,this.Text);
        }
        private void ALM_PreDoc_Con_ConsultaDatos(string vista, string procedimiento, string param)
        {
            Cursor.Current = Cursors.WaitCursor; //cursor cargando

            DataTable dtFiltro = new DataTable();
            dtFiltro = nDc.PreDoc_Con_Filtros(vista, procedimiento, param);

            if (dtFiltro.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 3;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFiltro;
                frm.ALM_PreDoc_Con_Rec = this;
                frm.ShowDialog();
            }
            else if (dtFiltro.Rows.Count == 1)
            {
                DataRow row = dtFiltro.Rows[0];

                switch (vista)
                {
                    case "Rutas":
                        this.txtCodRut.Text = row["Codigo"].ToString();
                        this.txtDesRut.Text = row["Descripcion"].ToString();
                        break;

                    case "Almacen":
                        this.txtCodAlm.Text = row["Codigo"].ToString();
                        this.txtDesAlm.Text = row["Almacen"].ToString();
                        break;

                    default:
                        break;
                }
            }
            else if (dtFiltro.Rows.Count == 0)
            {
                varglo.Elegi = false;
                _msg = "No se encontraron registros.";
                this.ALM_PreDoc_Con_MosMsgStrip(_msg, Color.Red);
            }

            Cursor.Current = Cursors.Default; //cursor default
        }

        public void recdat_ALM_PreDoc_Con_Rut(string CodRut, string DesRut)
        {
            //Obtiene los datos del grid desde la interfaz
            this.txtCodRut.Text = CodRut;
            this.txtDesRut.Text = DesRut;
        }

        public void recdat_ALM_PreDoc_Con_Alm(string CodAlm, string DesAlm)
        {
            //Obtiene los datos del grid desde la interfaz
            this.txtCodAlm.Text = CodAlm;
            this.txtDesAlm.Text = DesAlm;
        }

        private void txtDesRut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar ==(char)13)
            {
                this.ALM_PreDoc_Con_ConsultaDatos("Rutas","Filtro_Rutas", this.txtDesRut.Text);
                this.txtDesAlm.Focus();
            }
        }

        private void txtDesAlm_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.ALM_PreDoc_Con_ConsultaDatos("Almacen", "Filtro_Almacenes", this.txtDesAlm.Text);
                this.btnExp.Focus();
            }
        }

        private void btnLim_Click(object sender, EventArgs e)
        {
            //Texto predeterminado al limpiar
            this.txtCodRut.Text = "";
            this.txtDesRut.Text = "Presione enter o ingrese una ruta";
            this.txtCodAlm.Text = "";
            this.txtDesAlm.Text = "Presione enter o ingrese un almacén";
            this.txtDesRut.ForeColor = Color.DimGray;
            this.txtDesAlm.ForeColor = Color.DimGray;
        }

        private void btnImp_Click(object sender, EventArgs e)
        {
            ReportDocument rpt = new ReportDocument();
            frmVisor f = new frmVisor();
           
            string msgAlm = "";
            string msgRut = "";

            //Valida el reporte a mostrar
            if (this.chkInfTra.Checked)
            {
                rpt = new rptALM_PickingPacking_Con_Tra();
            }
            else
            {
                rpt = new rptALM_PickingPacking_con();
            }

            if (chkAgr.Checked)
            {
                TextObject txtRpt = (TextObject)rpt.ReportDefinition.ReportObjects["txtTitulo"];
                txtRpt.Text = "REPORTE CONSOLIDADO - AGRUPADO";
            }
            else
            {
                TextObject txtRpt = (TextObject)rpt.ReportDefinition.ReportObjects["txtTitulo"];
                txtRpt.Text = "REPORTE CONSOLIDADO - DESAGRUPADO";
            }


            TextObject txtRut = (TextObject)rpt.ReportDefinition.ReportObjects["txtRuta"];

            msgRut = this.txtDesRut.Text;
            if (msgRut.Equals("Presione enter o ingrese una ruta"))
            {
                msgRut = "";
            }


            if (this.fgDocCon.Rows.Count > 1)
            {
                txtRut.Text = msgRut;
            }

            TextObject txtAlm = (TextObject)rpt.ReportDefinition.ReportObjects["txtAlmacen"];

            msgAlm = this.txtDesAlm.Text;
            if (msgAlm.Equals("Presione enter o ingrese un almacén"))
            {
                msgAlm = "";
            }

            if (this.fgDocCon.Rows.Count > 1)
            {
                txtAlm.Text = msgAlm;
            }
           

            //parametros siempre se ejecutan 
            rpt.SetParameterValue("@TipCon", this.chkAgr.Checked ? 1 : 0);
            rpt.SetParameterValue("@FInicial", this.dtpDes.Value.Date);
            rpt.SetParameterValue("@FFinal", this.dtpHas.Value.Date);
            rpt.SetParameterValue("@Ruta", this.txtCodRut.Text == "" ? 0 : Convert.ToInt32(this.txtCodRut.Text));
            rpt.SetParameterValue("@Almacen", this.txtCodAlm.Text);

            //if(chkInfTra.Checked)rpt.SetParameterValue("@RutaDes", txtDesRut.Text);

            rpt.SetParameterValue("@ConStock", chkSolSto.Checked ?1:0);

            MetGlo.CRVisPre(rpt);
        }

        private void dtpDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.dtpHas.Focus();
            }
        }

        private void dtpHas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.btnMos.Focus();
            }
        }

        private void txtDesRut_Enter(object sender, EventArgs e)
        {
            if (this.txtDesRut.Text == "Presione enter o ingrese una ruta")
            {
                this.txtDesRut.Text = "";
                this.txtDesRut.ForeColor = Color.Black;
            }
        }

        private void txtDesRut_Leave(object sender, EventArgs e)
        {
            if (this.txtDesRut.Text == "")
            {
                this.txtDesRut.Text = "Presione enter o ingrese una ruta";
                this.txtDesRut.ForeColor = Color.DimGray;
            }
        }

        private void txtDesAlm_Enter(object sender, EventArgs e)
        {
            if (this.txtDesAlm.Text == "Presione enter o ingrese un almacén")
            {
                this.txtDesAlm.Text = "";
                this.txtDesAlm.ForeColor = Color.Black;
            }
        }

        private void txtDesAlm_Leave(object sender, EventArgs e)
        {
            if (this.txtDesAlm.Text == "")
            {
                this.txtDesAlm.Text = "Presione enter o ingrese un almacén";
                this.txtDesAlm.ForeColor = Color.DimGray;
            }
        }

        private void ALM_PreDoc_Con_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }
    }
}
