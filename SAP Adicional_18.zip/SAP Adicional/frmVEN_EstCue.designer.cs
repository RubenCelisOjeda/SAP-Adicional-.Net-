﻿namespace SAP_Adicional
{
    partial class frmVEN_EstCue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdbOrigen_3 = new System.Windows.Forms.RadioButton();
            this.rdbOrigen_2 = new System.Windows.Forms.RadioButton();
            this.rdbOrigen_1 = new System.Windows.Forms.RadioButton();
            this.rdbOrigen_0 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRq_ = new System.Windows.Forms.TextBox();
            this.btnMost_ = new System.Windows.Forms.Button();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnMosRep = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdbOrigen_3);
            this.groupBox2.Controls.Add(this.rdbOrigen_2);
            this.groupBox2.Controls.Add(this.rdbOrigen_1);
            this.groupBox2.Controls.Add(this.rdbOrigen_0);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(418, 65);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "RQ Origenes(Presupuesto FInal)";
            // 
            // rdbOrigen_3
            // 
            this.rdbOrigen_3.Location = new System.Drawing.Point(324, 22);
            this.rdbOrigen_3.Name = "rdbOrigen_3";
            this.rdbOrigen_3.Size = new System.Drawing.Size(89, 30);
            this.rdbOrigen_3.TabIndex = 3;
            this.rdbOrigen_3.Text = "Cotizaciones Actuales";
            this.rdbOrigen_3.UseVisualStyleBackColor = true;
            this.rdbOrigen_3.CheckedChanged += new System.EventHandler(this.rdbOrigen_3_CheckedChanged);
            this.rdbOrigen_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rdbOrigen_3_KeyPress);
            // 
            // rdbOrigen_2
            // 
            this.rdbOrigen_2.Location = new System.Drawing.Point(211, 22);
            this.rdbOrigen_2.Name = "rdbOrigen_2";
            this.rdbOrigen_2.Size = new System.Drawing.Size(87, 30);
            this.rdbOrigen_2.TabIndex = 2;
            this.rdbOrigen_2.Text = "Cotizaciones probadas";
            this.rdbOrigen_2.UseVisualStyleBackColor = true;
            this.rdbOrigen_2.CheckedChanged += new System.EventHandler(this.rdbOrigen_2_CheckedChanged);
            this.rdbOrigen_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rdbOrigen_2_KeyPress);
            // 
            // rdbOrigen_1
            // 
            this.rdbOrigen_1.AutoSize = true;
            this.rdbOrigen_1.Location = new System.Drawing.Point(107, 29);
            this.rdbOrigen_1.Name = "rdbOrigen_1";
            this.rdbOrigen_1.Size = new System.Drawing.Size(88, 17);
            this.rdbOrigen_1.TabIndex = 1;
            this.rdbOrigen_1.Text = "Ordenes SAP";
            this.rdbOrigen_1.UseVisualStyleBackColor = true;
            this.rdbOrigen_1.CheckedChanged += new System.EventHandler(this.rdbOrigen_1_CheckedChanged);
            this.rdbOrigen_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rdbOrigen_1_KeyPress);
            // 
            // rdbOrigen_0
            // 
            this.rdbOrigen_0.AutoSize = true;
            this.rdbOrigen_0.Checked = true;
            this.rdbOrigen_0.Location = new System.Drawing.Point(7, 29);
            this.rdbOrigen_0.Name = "rdbOrigen_0";
            this.rdbOrigen_0.Size = new System.Drawing.Size(84, 17);
            this.rdbOrigen_0.TabIndex = 0;
            this.rdbOrigen_0.TabStop = true;
            this.rdbOrigen_0.Text = "Ofertas SAP";
            this.rdbOrigen_0.UseVisualStyleBackColor = true;
            this.rdbOrigen_0.CheckedChanged += new System.EventHandler(this.rdbOrigen_0_CheckedChanged);
            this.rdbOrigen_0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rdbOrigen_0_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "RQ:";
            // 
            // txtRq_
            // 
            this.txtRq_.Location = new System.Drawing.Point(65, 91);
            this.txtRq_.Name = "txtRq_";
            this.txtRq_.Size = new System.Drawing.Size(100, 21);
            this.txtRq_.TabIndex = 4;
            this.txtRq_.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRq_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRq__KeyPress);
            // 
            // btnMost_
            // 
            this.btnMost_.Location = new System.Drawing.Point(171, 91);
            this.btnMost_.Name = "btnMost_";
            this.btnMost_.Size = new System.Drawing.Size(113, 21);
            this.btnMost_.TabIndex = 5;
            this.btnMost_.Text = "Mostrar";
            this.btnMost_.UseVisualStyleBackColor = true;
            this.btnMost_.Click += new System.EventHandler(this.btnMost__Click);
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(12, 122);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fg.Size = new System.Drawing.Size(709, 236);
            this.fg.TabIndex = 4;
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            // 
            // btnMosRep
            // 
            this.btnMosRep.Location = new System.Drawing.Point(11, 363);
            this.btnMosRep.Name = "btnMosRep";
            this.btnMosRep.Size = new System.Drawing.Size(195, 23);
            this.btnMosRep.TabIndex = 6;
            this.btnMosRep.Text = "Mostrar Estado de Cuenta";
            this.btnMosRep.UseVisualStyleBackColor = true;
            this.btnMosRep.Click += new System.EventHandler(this.btnMosRep_Click);
            // 
            // frmVEN_EstCue
            // 
            this.ClientSize = new System.Drawing.Size(791, 398);
            this.Controls.Add(this.btnMosRep);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.btnMost_);
            this.Controls.Add(this.txtRq_);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_EstCue";
            this.Load += new System.EventHandler(this.frmVEN_EstCue_Load_1);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        //private System.Windows.Forms.GroupBox groupBox1;
        //private System.Windows.Forms.RadioButton rdbOrigen1;
        //private System.Windows.Forms.RadioButton rdbOrigen2;
        //private System.Windows.Forms.RadioButton rdbOrigen0;
        //private System.Windows.Forms.RadioButton rdbOrigen3;
        //private System.Windows.Forms.TextBox txtRq;
        //private System.Windows.Forms.Label label5;
        //private System.Windows.Forms.Button btnMos;
        //private C1.Win.C1FlexGrid.C1FlexGrid dgv;
        //private System.Windows.Forms.Button btnMosCue;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdbOrigen_3;
        private System.Windows.Forms.RadioButton rdbOrigen_2;
        private System.Windows.Forms.RadioButton rdbOrigen_1;
        private System.Windows.Forms.RadioButton rdbOrigen_0;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRq_;
        private System.Windows.Forms.Button btnMost_;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
        private System.Windows.Forms.Button btnMosRep;
        //private C1CheckBox c1CheckBox1;
    }
}