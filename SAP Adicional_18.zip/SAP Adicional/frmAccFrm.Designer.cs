﻿namespace SAP_Adicional
{
    partial class frmAccFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAccFrm));
            this.pnlCen = new System.Windows.Forms.Panel();
            this.pnlUsuCop = new System.Windows.Forms.Panel();
            this.pnlUsu = new System.Windows.Forms.Panel();
            this.fgCopUsu = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnCan = new System.Windows.Forms.Button();
            this.btnAceCop = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.fgAccUsu = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnCopAcc = new System.Windows.Forms.Button();
            this.btnAgr = new System.Windows.Forms.Button();
            this.txtDesDoc = new System.Windows.Forms.TextBox();
            this.txtCodDoc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDesUsu = new System.Windows.Forms.TextBox();
            this.txtCodUsu = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlBarra = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMaxMin = new System.Windows.Forms.Label();
            this.lblMini = new System.Windows.Forms.Label();
            this.lblTit = new System.Windows.Forms.Label();
            this.lblCer = new System.Windows.Forms.Label();
            this.pnlCen.SuspendLayout();
            this.pnlUsuCop.SuspendLayout();
            this.pnlUsu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCopUsu)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAccUsu)).BeginInit();
            this.pnlBarra.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCen
            // 
            this.pnlCen.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCen.AutoScroll = true;
            this.pnlCen.BackColor = System.Drawing.Color.White;
            this.pnlCen.Controls.Add(this.pnlUsuCop);
            this.pnlCen.Controls.Add(this.fgAccUsu);
            this.pnlCen.Controls.Add(this.btnCopAcc);
            this.pnlCen.Controls.Add(this.btnAgr);
            this.pnlCen.Controls.Add(this.txtDesDoc);
            this.pnlCen.Controls.Add(this.txtCodDoc);
            this.pnlCen.Controls.Add(this.label3);
            this.pnlCen.Controls.Add(this.txtDesUsu);
            this.pnlCen.Controls.Add(this.txtCodUsu);
            this.pnlCen.Controls.Add(this.label2);
            this.pnlCen.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlCen.Location = new System.Drawing.Point(3, 40);
            this.pnlCen.Name = "pnlCen";
            this.pnlCen.Size = new System.Drawing.Size(1012, 487);
            this.pnlCen.TabIndex = 25;
            // 
            // pnlUsuCop
            // 
            this.pnlUsuCop.BackColor = System.Drawing.Color.DarkGray;
            this.pnlUsuCop.Controls.Add(this.pnlUsu);
            this.pnlUsuCop.Controls.Add(this.panel1);
            this.pnlUsuCop.Location = new System.Drawing.Point(359, 14);
            this.pnlUsuCop.Name = "pnlUsuCop";
            this.pnlUsuCop.Size = new System.Drawing.Size(384, 466);
            this.pnlUsuCop.TabIndex = 9;
            this.pnlUsuCop.Visible = false;
            // 
            // pnlUsu
            // 
            this.pnlUsu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlUsu.BackColor = System.Drawing.Color.White;
            this.pnlUsu.Controls.Add(this.fgCopUsu);
            this.pnlUsu.Controls.Add(this.btnCan);
            this.pnlUsu.Controls.Add(this.btnAceCop);
            this.pnlUsu.Location = new System.Drawing.Point(5, 44);
            this.pnlUsu.Name = "pnlUsu";
            this.pnlUsu.Size = new System.Drawing.Size(374, 418);
            this.pnlUsu.TabIndex = 29;
            // 
            // fgCopUsu
            // 
            this.fgCopUsu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgCopUsu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.fgCopUsu.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgCopUsu.Location = new System.Drawing.Point(11, 19);
            this.fgCopUsu.Name = "fgCopUsu";
            this.fgCopUsu.Rows.DefaultSize = 19;
            this.fgCopUsu.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgCopUsu.Size = new System.Drawing.Size(357, 361);
            this.fgCopUsu.StyleInfo = resources.GetString("fgCopUsu.StyleInfo");
            this.fgCopUsu.TabIndex = 0;
            this.fgCopUsu.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgCopUsu_AfterEdit);
            this.fgCopUsu.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgCopUsu_KeyPressEdit);
            // 
            // btnCan
            // 
            this.btnCan.BackColor = System.Drawing.Color.Gold;
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCan.Location = new System.Drawing.Point(87, 386);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(70, 23);
            this.btnCan.TabIndex = 11;
            this.btnCan.Text = "Cancelar";
            this.btnCan.UseVisualStyleBackColor = false;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // btnAceCop
            // 
            this.btnAceCop.BackColor = System.Drawing.Color.Gold;
            this.btnAceCop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAceCop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAceCop.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceCop.Location = new System.Drawing.Point(11, 386);
            this.btnAceCop.Name = "btnAceCop";
            this.btnAceCop.Size = new System.Drawing.Size(70, 23);
            this.btnAceCop.TabIndex = 10;
            this.btnAceCop.Text = "Aceptar";
            this.btnAceCop.UseVisualStyleBackColor = false;
            this.btnAceCop.Click += new System.EventHandler(this.btnAce_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(374, 34);
            this.panel1.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(54, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(273, 19);
            this.label4.TabIndex = 13;
            this.label4.Text = "Copiar parametrización de formulario";
            // 
            // fgAccUsu
            // 
            this.fgAccUsu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgAccUsu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.fgAccUsu.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgAccUsu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fgAccUsu.Location = new System.Drawing.Point(14, 80);
            this.fgAccUsu.Name = "fgAccUsu";
            this.fgAccUsu.Rows.DefaultSize = 19;
            this.fgAccUsu.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgAccUsu.Size = new System.Drawing.Size(979, 391);
            this.fgAccUsu.StyleInfo = resources.GetString("fgAccUsu.StyleInfo");
            this.fgAccUsu.TabIndex = 8;
            this.fgAccUsu.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgAccUsu_AfterEdit);
            this.fgAccUsu.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgAccUsu_KeyPressEdit);
            // 
            // btnCopAcc
            // 
            this.btnCopAcc.BackColor = System.Drawing.Color.Gold;
            this.btnCopAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCopAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCopAcc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopAcc.Location = new System.Drawing.Point(871, 30);
            this.btnCopAcc.Name = "btnCopAcc";
            this.btnCopAcc.Size = new System.Drawing.Size(130, 23);
            this.btnCopAcc.TabIndex = 7;
            this.btnCopAcc.Text = "Copiar accesos a >>";
            this.btnCopAcc.UseVisualStyleBackColor = false;
            this.btnCopAcc.Click += new System.EventHandler(this.btnCopAcc_Click);
            // 
            // btnAgr
            // 
            this.btnAgr.BackColor = System.Drawing.Color.Gold;
            this.btnAgr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAgr.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgr.Location = new System.Drawing.Point(766, 30);
            this.btnAgr.Name = "btnAgr";
            this.btnAgr.Size = new System.Drawing.Size(103, 23);
            this.btnAgr.TabIndex = 6;
            this.btnAgr.Text = "Agregar";
            this.btnAgr.UseVisualStyleBackColor = false;
            this.btnAgr.Click += new System.EventHandler(this.btnAgr_Click);
            // 
            // txtDesDoc
            // 
            this.txtDesDoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesDoc.ForeColor = System.Drawing.Color.Blue;
            this.txtDesDoc.Location = new System.Drawing.Point(490, 32);
            this.txtDesDoc.Name = "txtDesDoc";
            this.txtDesDoc.Size = new System.Drawing.Size(271, 21);
            this.txtDesDoc.TabIndex = 5;
            this.txtDesDoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesDoc_KeyPress);
            // 
            // txtCodDoc
            // 
            this.txtCodDoc.BackColor = System.Drawing.Color.Silver;
            this.txtCodDoc.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodDoc.ForeColor = System.Drawing.Color.Blue;
            this.txtCodDoc.Location = new System.Drawing.Point(454, 32);
            this.txtCodDoc.Name = "txtCodDoc";
            this.txtCodDoc.Size = new System.Drawing.Size(35, 21);
            this.txtCodDoc.TabIndex = 4;
            this.txtCodDoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodDoc_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(378, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Documento:";
            // 
            // txtDesUsu
            // 
            this.txtDesUsu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesUsu.ForeColor = System.Drawing.Color.Blue;
            this.txtDesUsu.Location = new System.Drawing.Point(101, 33);
            this.txtDesUsu.Name = "txtDesUsu";
            this.txtDesUsu.Size = new System.Drawing.Size(271, 21);
            this.txtDesUsu.TabIndex = 1;
            this.txtDesUsu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsu_KeyPress);
            // 
            // txtCodUsu
            // 
            this.txtCodUsu.BackColor = System.Drawing.Color.Silver;
            this.txtCodUsu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodUsu.ForeColor = System.Drawing.Color.Blue;
            this.txtCodUsu.Location = new System.Drawing.Point(66, 33);
            this.txtCodUsu.Name = "txtCodUsu";
            this.txtCodUsu.Size = new System.Drawing.Size(35, 21);
            this.txtCodUsu.TabIndex = 8;
            this.txtCodUsu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodUsu_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Usuario:";
            // 
            // pnlBarra
            // 
            this.pnlBarra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBarra.BackColor = System.Drawing.Color.Gray;
            this.pnlBarra.Controls.Add(this.label1);
            this.pnlBarra.Controls.Add(this.lblMaxMin);
            this.pnlBarra.Controls.Add(this.lblMini);
            this.pnlBarra.Controls.Add(this.lblTit);
            this.pnlBarra.Controls.Add(this.lblCer);
            this.pnlBarra.Location = new System.Drawing.Point(3, 3);
            this.pnlBarra.Name = "pnlBarra";
            this.pnlBarra.Size = new System.Drawing.Size(1012, 31);
            this.pnlBarra.TabIndex = 27;
            this.pnlBarra.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlBarra_MouseMove);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(438, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 19);
            this.label1.TabIndex = 13;
            this.label1.Text = "Acceso formulario";
            // 
            // lblMaxMin
            // 
            this.lblMaxMin.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblMaxMin.BackColor = System.Drawing.Color.White;
            this.lblMaxMin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMaxMin.Image = ((System.Drawing.Image)(resources.GetObject("lblMaxMin.Image")));
            this.lblMaxMin.Location = new System.Drawing.Point(963, 4);
            this.lblMaxMin.Name = "lblMaxMin";
            this.lblMaxMin.Size = new System.Drawing.Size(20, 19);
            this.lblMaxMin.TabIndex = 12;
            this.lblMaxMin.Click += new System.EventHandler(this.lblMaxMin_Click);
            // 
            // lblMini
            // 
            this.lblMini.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblMini.BackColor = System.Drawing.Color.White;
            this.lblMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMini.Image = ((System.Drawing.Image)(resources.GetObject("lblMini.Image")));
            this.lblMini.Location = new System.Drawing.Point(940, 4);
            this.lblMini.Name = "lblMini";
            this.lblMini.Size = new System.Drawing.Size(20, 19);
            this.lblMini.TabIndex = 11;
            this.lblMini.Click += new System.EventHandler(this.lblMini_Click);
            // 
            // lblTit
            // 
            this.lblTit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTit.AutoSize = true;
            this.lblTit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTit.ForeColor = System.Drawing.Color.Gold;
            this.lblTit.Location = new System.Drawing.Point(435, 5);
            this.lblTit.Name = "lblTit";
            this.lblTit.Size = new System.Drawing.Size(137, 19);
            this.lblTit.TabIndex = 0;
            this.lblTit.Text = "Acceso formulario";
            this.lblTit.MouseMove += new System.Windows.Forms.MouseEventHandler(this.lblTit_MouseMove);
            // 
            // lblCer
            // 
            this.lblCer.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblCer.BackColor = System.Drawing.Color.White;
            this.lblCer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCer.Image = ((System.Drawing.Image)(resources.GetObject("lblCer.Image")));
            this.lblCer.Location = new System.Drawing.Point(986, 4);
            this.lblCer.Name = "lblCer";
            this.lblCer.Size = new System.Drawing.Size(20, 19);
            this.lblCer.TabIndex = 0;
            this.lblCer.Click += new System.EventHandler(this.lblCer_Click);
            // 
            // frmAccFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1018, 532);
            this.ControlBox = false;
            this.Controls.Add(this.pnlBarra);
            this.Controls.Add(this.pnlCen);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.Name = "frmAccFrm";
            this.Load += new System.EventHandler(this.frmAccFrm_Load);
            this.pnlCen.ResumeLayout(false);
            this.pnlCen.PerformLayout();
            this.pnlUsuCop.ResumeLayout(false);
            this.pnlUsu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgCopUsu)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAccUsu)).EndInit();
            this.pnlBarra.ResumeLayout(false);
            this.pnlBarra.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlCen;
        private System.Windows.Forms.Panel pnlBarra;
        private System.Windows.Forms.Label lblMini;
        private System.Windows.Forms.Label lblTit;
        private System.Windows.Forms.Label lblCer;
        private System.Windows.Forms.Label lblMaxMin;
        private System.Windows.Forms.TextBox txtDesDoc;
        private System.Windows.Forms.TextBox txtCodDoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDesUsu;
        private System.Windows.Forms.TextBox txtCodUsu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCopAcc;
        private System.Windows.Forms.Button btnAgr;
        private C1.Win.C1FlexGrid.C1FlexGrid fgAccUsu;
        private System.Windows.Forms.Panel pnlUsuCop;
        private C1.Win.C1FlexGrid.C1FlexGrid fgCopUsu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Button btnAceCop;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnlUsu;
    }
}