﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.DMan_ArticuloCompuesto;
using Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
 
    public partial class frmMan_ArticuloCompuesto : Form, frmMan_Articulo_Compuesto
    {
        NMan_ArticuloCompuesto ArtCom = new NMan_ArticuloCompuesto();
        ArtComMae_Enc ArtComEnc = new ArtComMae_Enc();
        NSolFac sf = new NSolFac();
        VarGlo varglo = VarGlo.Instance();
        string Filtro = string.Empty; Int16 codigo = 0; string rutaArchivo=""; string nombreArchivo=""; string rutaAplicacion = "";string codigoBorrado="";
        string key; string value;byte EstadoRegistro; string desRec; string descuRec;//verifica si modifica o actualiza
        bool modGua;
        public frmMan_ArticuloCompuesto()
        {
            InitializeComponent();
        }
              
        private void frmMan_ArticuloCompuesto_Load(object sender, EventArgs e)
        {
            ArtCom_Rec();
            int boton = Convert.ToInt16(btnPri.Tag); //booton = 0
            btnMovimientos(Convert.ToInt16(boton),Convert.ToInt16(txtCod.Text="0"));  //asigna 0 al cargar para no generar error
            Man_Usuarios_ValUsuSapAdi(1);
            Man_ArtCom_DeshaTex(false);
            FormatoColumnComponentes();
            txtCod.ReadOnly = true;
            txtCodTipArt.ReadOnly = true;
        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }
        public void VEN_SolNotCre_EstBot(string BotonEstado)
        {
            bool[] EstadoM = { true };

            //cargar, nuevo, modificar, guardar, borrar, cancelar

            switch (BotonEstado)
            {
                case "cargar": //
                    EstadoM = matriz(true, true, false, true, false, true);
                    break;

                case "nuevo": //
                    EstadoM = matriz(false, false, true, false, true, false);
                    break;

                case "modificar": //
                    EstadoM = matriz(false, false, true, false, true, false);
                    break;

                case "guardar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;
                case "borrar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;

                case "deshacer": //
                    EstadoM = matriz(true, true, false, true, false, true);
                    break;
            }

            //botones que habilita o deshabilita
            this.btnNue.Enabled = EstadoM[0];
            this.btnMod.Enabled = EstadoM[1];
            this.btnGua.Enabled = EstadoM[2];
            this.btnBor.Enabled = EstadoM[3];
            this.btnDeshacer.Enabled = EstadoM[4];
            this.btnCer.Enabled = EstadoM[5];
        }
        void Man_ArtCom_DeshaTex(bool estado)
        {
            //textbox solo lectura
            txtDes.ReadOnly = !estado;
            txtObs.ReadOnly = !estado;
            txtTipoArt.ReadOnly = !estado;
        }
        void Mensaje()
        {
            MessageBox.Show("No cuenta con acceso para realizar esta operación", "Mensaje del sistema",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        void Man_Usuarios_ValUsuSapAdi(int campo)
        {
            //valida el acceso del usuario y habilita segun el boton
            switch (campo)
            {
                case 1:
                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 1, 0) == 1) //valida si tiene acceso 
                    {
                        VEN_SolNotCre_EstBot("cargar"); //estado de los botones
                    }
                    else
                    {
                        Mensaje(); //aviso
                    }
                    break;

                case 2:
                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 2, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("nuevo");
                    }
                    else
                    {
                        Mensaje();
                    }
                    break;
                case 3:

                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 3, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("modificar");
                    }
                    else
                    {
                        Mensaje();
                    }
                    break;
                case 4:

                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 3, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("guardar");
                    }
                    else
                    {
                        Mensaje();
                    }
                    break;
                case 5:
                    if (sf.VEN_SolFac_ConAcc(varglo.CodUsuAct, 3, 0) == 1)
                    {
                        VEN_SolNotCre_EstBot("borrar");
                    }
                    else
                    {
                        Mensaje();
                    }
                    break;
                default:
                    break;
            }
        }

        void ArtCom_Rec()
        {
            //llena los datos en grid maestros
            DataTable dtArCom = new DataTable();
            dtArCom = ArtCom.Man_ArticuloCompuesto_Rec();

            if (dtArCom.Rows.Count  > 0) //valida si hay filas
            {
                fgMae.DataSource = dtArCom;
            }
            else
            {
                MessageBox.Show("No se encontraron datos","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
        }
   
        void btnMovimientos(int indice,Int16  cod)
        {
            if (string.IsNullOrEmpty(txtCod.Text)) //validatos si esta vacio la caja de texto
            {
                cod = 0;
            }

            DataSet ArtCom_MovGeneral_Rec = new DataSet();
            ArtCom_MovGeneral_Rec = ArtCom.ArtCom_MovGeneral_Rec(Convert.ToInt16(indice), cod);

            //asigna las tablasde del dataset
            DataTable dtMovGen_rec = ArtCom_MovGeneral_Rec.Tables["ArticuloGeneral"];
            DataTable dtMovGen_Det ;  dtMovGen_Det = ArtCom_MovGeneral_Rec.Tables["ArticuloDetalle"];
            
            if (dtMovGen_rec.Rows.Count == 0)//validar si hay filas
            {
                return;
            }

            //asignamos los datos a los textbox del procedimiento ArtCom_MovGeneral
            codigoBorrado = txtCod.Text = dtMovGen_rec.Rows[0]["Codigo"].ToString();
            codigo = Convert.ToInt16(txtCod.Text);
            txtDes.Text = dtMovGen_rec.Rows[0]["Descripcion"].ToString();
            txtObs.Text = dtMovGen_rec.Rows[0]["Obs"].ToString();
            txtCodTipArt.Text = dtMovGen_rec.Rows[0]["CodTipArtCom"].ToString();
            txtTipoArt.Text = dtMovGen_rec.Rows[0]["Tipo"].ToString();
            Int16 chek = Convert.ToInt16(dtMovGen_rec.Rows[0]["Inactivo"].ToString());
            chkInac.Checked = Convert.ToBoolean(chek);
            fgMae.Row = fgMae.FindRow(txtCod.Text, 0, 2, false, false, false);

            if (dtMovGen_Det.Rows.Count > 0)  //validamos si hay filas
            {
                fgCom.DataSource = dtMovGen_Det;
            }
            else
            {
                fgCom.DataSource = dtMovGen_Det; //llena vacio el grid
            }
            FormatoColumnComponentes();
        }

        private void btnPri_Click(object sender, EventArgs e)
        {
            int cod = 0;
            if (!string.IsNullOrEmpty(txtCod.Text)) //Valida que halla dato
            {
                cod = Convert.ToInt32(txtCod.Text);
            }
            btnMovimientos(Convert.ToInt16(btnPri.Tag),Convert.ToInt16(cod));  //se posiciona en la primera fila
        }

        private void fgMae_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoColumnMaestro();
            FormatoGeneral();
            DatosCategoria();
        }
        void FormatoColumnMaestro()
        {
            try
            {
                //tamaño de columnas
                fgMae.Cols["Codigo"].Width = 50;
                fgMae.Cols["Descripcion"].Width = 350;
                fgMae.Cols["Observacion"].Width = 500;
                fgMae.Cols["Tipo"].Width = 80;
                fgMae.Cols["Inactivo"].Width = 80;
                fgMae.Cols["Descuento"].Width = 80;
                fgMae.Cols["RutaImagen"].Width = 250;
                fgMae.Cols["NombreArchivo"].Width = 250;
                fgMae.Cols["RutaAplicacion"].Width = 250;
                fgMae.Cols["Creado por:"].Width = 250;
                fgMae.Cols["Modificado por:"].Width = 220;
                fgMae.Cols["Modificado EL:"].Width = 100;

                //formato columna
                fgMae.Cols["Inactivo"].DataType = typeof(bool);
                fgMae.Cols["Creado el:"].DataType = typeof(string);
                fgMae.Cols["Modificado EL:"].DataType = typeof(string);

                //visible
                fgMae.Cols["NombreArchivo"].Visible = false;
            }
            catch { }
        }

        void FormatoColumnComponentes()
        {
            try
            {
                //tamaño columnas
                fgCom.Cols["Descripcion"].Width = 300;
                fgCom.Cols["can"].Width = 30;
                fgCom.Cols["Principal"].Width = 20;
                fgCom.Cols["precio"].Width = 80;
                fgCom.Cols["Moneda"].Width = 50;
                fgCom.Cols["Descontinuado"].Width = 80;

                //cambios del nobmre de  la columna
                fgCom.Cols["can"].Caption = "Cant";
                fgCom.Cols["Principal"].Caption = "P";
                fgCom.Cols["precio"].Caption = "Precio Publico";

                //formato dato
                fgCom.Cols["precio"].Format = "0.00";
                fgCom.Cols["Cant"].Format = "0.00";
            }
            catch { }
        }

        void FormatoGeneral()
        {
            //formato para gri maestros
            fgMae.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fgMae.Styles.Alternate.BackColor = Color.LightBlue;
            fgMae.Styles.Highlight.BackColor = Color.Blue;
            fgMae.Styles.Highlight.ForeColor = Color.White;
            fgMae.AllowFreezing = AllowFreezingEnum.Both;
            fgMae.Cols.Frozen = 2;

            //formato para grid componentes
            fgCom.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fgCom.Styles.Alternate.BackColor = Color.LightBlue;
            fgCom.Styles.Highlight.BackColor = Color.Blue;
            fgCom.Styles.Highlight.ForeColor = Color.White;
            fgCom.AllowFreezing = AllowFreezingEnum.Both;
        }

        private void fgMae_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col == 0 || e.Col > 8) //no permite ingresar datos a las columnas > 8
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = false;
                }
            }
            if (e.Col == 10) //no permite ingresar datos
            {
                e.Handled = true;
            }      
        }

        private void btnRet_Click(object sender, EventArgs e)
        {
            int cod = 0;
            if (!string.IsNullOrEmpty(txtCod.Text))//valida que halla dato
            {
                cod = Convert.ToInt32(txtCod.Text);
            }
         
            btnMovimientos(Convert.ToInt16(btnRet.Tag),Convert.ToInt16(cod));    //retrocede una fila
        }

        private void btnAva_Click(object sender, EventArgs e)
        {
            int cod = 0;
            if (!string.IsNullOrEmpty(txtCod.Text)) //valida que halla dato
            {
                cod = Convert.ToInt32(txtCod.Text);
            }

            btnMovimientos(Convert.ToInt16(btnAva.Tag),Convert.ToInt16(cod));  //avanza una fila
        }

        private void btnUlt_Click(object sender, EventArgs e)
        {
            int cod = 0;
            if (!string.IsNullOrEmpty(txtCod.Text))
            {
                cod = Convert.ToInt32(txtCod.Text);
            }

            btnMovimientos(Convert.ToInt16(btnUlt.Tag),Convert.ToInt16(cod));  //se posiciona en la ultima fila
        }

        private void fgMae_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                if (fgMae.Rows.Count > 0)
                {
                    Int16 cod = Convert.ToInt16(fgMae.Rows[fgMae.RowSel][0]); //toma el valor de la primera columna del grid maestros

                    tabMae.SelectedTab = tabMae.TabPages[0]; //muestra la primera pagina del tabControl
                    btnMovimientos(4, cod);
                }
            }
            catch { return; }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fgMae.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch { }
        }

        private void fgCom_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //no permite ingresar datos
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnRutImgCot_Click(object sender, EventArgs e)
        {
            if (fgMae.IsCellSelected(fgMae.Row,fgMae.Col)) //valida si ha seleccionado la fila
            {
                OpenFileDialog open = new OpenFileDialog(); //clase de tipo de dialogo de archivo          
                FolderBrowserDialog ruta = new FolderBrowserDialog(); //clase para obtener la ruta

                try
                {
                    open.Title = "Seleccione una imagen para capturar la ruta";  //establece el titulo de la ventana
                    open.Filter = "Imagenes JPEG | *.JPG;*.JPEG;*.JPE;*.JFIF"; //establece los tipo de archivo a mostrar     
                    open.ShowDialog();      //abre el dialogo
                    ruta.SelectedPath = open.FileName;  //asigna el de dialogos de archivo a la ruta
                    rutaArchivo = ruta.SelectedPath;    //nombre de la ruta del archivo
                    nombreArchivo = open.SafeFileName;  //nombre del archivo
                    fgMae[fgMae.Row,6] = rutaArchivo;
                    fgMae[fgMae.Row, 7] = nombreArchivo;
                    ArtCom.ArtCom_Act(rutaArchivo, nombreArchivo, Convert.ToInt32(fgMae.Rows[fgMae.RowSel][0])); //ejecutamos el procedimiento
                }
                catch { return; }
            }
            else
            {
                MessageBox.Show("Seleccione un fila", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void btnLimRut_Click(object sender, EventArgs e)
        {
            if (fgMae.IsCellSelected(fgMae.Row, fgMae.Col)) //valida si ha seleccionado la fila
            {
                if (!string.IsNullOrEmpty(fgMae[fgMae.Row, 6].ToString()) ||  //valida si hay datos
                    !string.IsNullOrEmpty(fgMae[fgMae.Row, 7].ToString())) 
                {
                    fgMae[fgMae.Row, 6] = ""; //limpia las celdas
                    fgMae[fgMae.Row, 7] = "";

                    ArtCom.ArtCom_Act(rutaArchivo,nombreArchivo,Convert.ToInt32(fgMae.Rows[fgMae.RowSel][0])); //ejecutamos el procedimiento
                    return;
                }
            }
            else
            {
                MessageBox.Show("Seleccione un fila para limpiar la ruta", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnRutImgApl_Click(object sender, EventArgs e)
        {
            if (fgMae.IsCellSelected(fgMae.Row, fgMae.Col)) //valida si ha seleccionado la fila
            {
                OpenFileDialog open = new OpenFileDialog(); //clase de tipo de dialogo de archivo          
                FolderBrowserDialog ruta = new FolderBrowserDialog(); //clase para obtener la ruta

                try
                {
                    open.Title = "Seleccione una imagen para capturar la ruta";  //establece el titulo de la ventana
                    open.Filter = "Imagenes JPEG | *.JPG;*.JPEG;*.JPE;*.JFIF"; //establece los tipo de archivo a mostrar     
                    open.ShowDialog();      //abre el dialogo
                    ruta.SelectedPath = open.FileName;  //asigna el de dialogos de archivo a la ruta
                    rutaAplicacion = ruta.SelectedPath;    //nombre de la ruta del archivo
                    fgMae[fgMae.Row, 8] = rutaAplicacion;
                    ArtCom.ArtCom_ActApl(rutaAplicacion, Convert.ToInt32(fgMae.Rows[fgMae.RowSel][0])); //ejecutamos el procedimiento
                    return;
                }
                catch { return; }
            }
            else
            {
                MessageBox.Show("Seleccione un fila", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }

        private void btnNue_Click(object sender, EventArgs e)
        {
            modGua = false;
            EstadoRegistro = 0;
            Man_Usuarios_ValUsuSapAdi(2); //valida acceso

            DialogResult mensaje = MessageBox.Show("Crear basado en el articulo seleccionado", "Mensaje del sistema", 
                                                    MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (mensaje == DialogResult.Yes)
            {
                txtCod.Clear();
                Man_ArtCom_DeshaTex(true); //habilita los textos
                gpbCom.Enabled = true; //habilita grupo de textos
                chkInac.Enabled = true;
                gpbBot.Enabled = false;
                LimpiarTextos(true);
                txtCodArt.Focus();
                VEN_SolNotCre_EstBot("modificar");
              
            }
            else 
            {
                LimpiarTextos(false);

                DataSet ArtCom_MovGeneral_Rec = new DataSet();
                ArtCom_MovGeneral_Rec = ArtCom.ArtCom_MovGeneral_Rec(Convert.ToInt16(btnPri.Tag), 0);
                DataTable dtMovGen_Det = ArtCom_MovGeneral_Rec.Tables["ArticuloDetalle"];
                dtMovGen_Det.Clear();

                fgCom.DataSource = dtMovGen_Det;
                Man_ArtCom_DeshaTex(true);
                gpbBot.Enabled = false;
                gpbCom.Enabled = true;
                chkInac.Enabled = true;
                txtDes.Focus();
                FormatoColumnComponentes();
            }
        }

        void LimpiarTextos(bool limBtn)
        {
            switch (limBtn)
            {
                case false:
                    txtCod.Clear(); txtDes.Clear(); txtObs.Clear(); txtCodTipArt.Clear(); txtTipoArt.Clear();
                    txtCodArt.Clear(); txtCat.Clear(); txtDesArt.Clear(); txtCat.Clear(); 
                    chkInac.Checked = false;
                    chkPri.Checked = false;
                    break;
                case true:
                    txtCodArt.Clear(); txtCat.Clear();
                    txtDesArt.Clear(); txtCan.Clear();
                    chkPri.Checked = false;
                    break;
                default:
                    break;
            }
        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            EstadoRegistro = 1; //si agrega  o actualiza
            Man_Usuarios_ValUsuSapAdi(3);
            Man_ArtCom_DeshaTex(true); //habilita los textos
            gpbBot.Enabled = false;
            gpbCom.Enabled = true;
            chkInac.Enabled = true;
        }

        private void btnGua_Click(object sender, EventArgs e)
        {
            Man_Usuarios_ValUsuSapAdi(4);

            if (string.IsNullOrEmpty(txtDes.Text)) //valida que haya dato
            {
                MessageBox.Show("Decripción no aceptada", "Mensaje del sistema",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                VEN_SolNotCre_EstBot("modificar");
                txtDes.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtCodTipArt.Text))//valida que haya dato
            {
                MessageBox.Show("Debe asignar un tipo de artículo compuesto", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                VEN_SolNotCre_EstBot("modificar");
                txtTipoArt.Focus();
                return;
            }               
            if(fgCom.Rows.Count <= 1)    //valida que haya mas de un registro
            {
                MessageBox.Show("No se encontro ningun componente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                VEN_SolNotCre_EstBot("modificar");
                gpbCom.Enabled = true;
                txtCodArt.Focus();
                return;
            }

            //valida que haya un articulo principal
            try
            {
                bool seleccionar = false;
                for (int i = 1; i < fgCom.Rows.Count; i++)
                {
                    if (Convert.ToInt32(fgCom.Rows[i][4].ToString()) != 0) { seleccionar = true; }
                }
                if (seleccionar == false)
                {
                    MessageBox.Show("Debe haber un articulo compuesto principal", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    VEN_SolNotCre_EstBot("modificar");
                    return;
                }
            }
            catch { }

            DialogResult valida = MessageBox.Show("¿Esta seguro que desea guardar?", "Mensaje del sistema", 
                                                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (valida == DialogResult.Yes)
            {
                //insertando encabezado articulo compuestos
                ArtCom_Enc Enc = new ArtCom_Enc();
                Enc.EstReg = EstadoRegistro;

                int codigo = 0;
                int.TryParse(txtCod.Text, out codigo);
                Enc.Cod = Convert.ToInt32(codigo);
                Enc.Des = txtDes.Text;
                Enc.Obs = txtObs.Text;
                Enc.CodTipArt = Convert.ToInt32(txtCodTipArt.Text);
                Enc.Inactivo = Convert.ToInt32(chkInac.Checked);

                //insertando detalle articulo compuestos
               
                try
                {
                    foreach (Row row in fgCom.Rows)
                    {
                        if (row.Index > 0)
                        {
                            ArtCom_Det Det = new ArtCom_Det();
                            Det.CodArt = Convert.ToString(row[0]);
                            Det.Can = Convert.ToInt16(row[3]);
                            Det.Pri = Convert.ToByte(row[4]);
                            Enc.ArtComDet.Add(Det); //Agregamos los datos a la entidad
                        }
                    }
                }
                catch { }

                ArtCom.ArtCom_ActGua(Enc); //guarda encabezado y detalle
                VEN_SolNotCre_EstBot("cargar");
                Man_ArtCom_DeshaTex(false); //deshabilitamos los textos
                gpbCom.Enabled = false;
                gpbBot.Enabled = true;
                chkInac.Enabled = false;
                txtCod.Text = Enc.Cod.ToString();
             }
             else
             {
                VEN_SolNotCre_EstBot("modificar");
             }
        }

        private void btnBor_Click(object sender, EventArgs e)
        {
            Man_Usuarios_ValUsuSapAdi(5);
            DialogResult mensaje = MessageBox.Show("¿Esta seguro de eliminar este artículo?", "Mensaje del sistema",
                                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (mensaje == DialogResult.Yes) //Valiada la respuesta
            {
                ArtCom.ArtCom_Eli(Convert.ToInt32( txtCod.Text)); //elimnina el registro              
                btnMovimientos(Convert.ToInt16(btnPri.Tag), Convert.ToInt16(txtCod.Text)); //se posiciona en la perimera fila
            }
            else
            {
                return;
            }
            VEN_SolNotCre_EstBot("cargar");
        }

        private void btnDeshacer_Click(object sender, EventArgs e)
        {
            VEN_SolNotCre_EstBot("deshacer");
            Man_ArtCom_DeshaTex(false); //deshabilitad los textos
            gpbBot.Enabled = true; //habilita los botones
            gpbCom.Enabled = false; //deshabilita el grupo de texto
            chkInac.Enabled = false;

            if (btnDeshacer.Enabled) //valida el boton si esta en true
            {
                txtCod.Text = codigoBorrado; //retorna el codigo borrado
            }

            int cod = 0;
            if (!string.IsNullOrEmpty(txtCod.Text)) //valida que el texto este lleno
            {
                cod = Convert.ToInt32(txtCod.Text);
            }

            LimpiarTextos(false);
            LimpiarTextos(true);
            btnMovimientos(Convert.ToInt16(btnPri.Tag), Convert.ToInt16(cod)); //retorna al primer
        }

        private void btnCer_Click(object sender, EventArgs e)
        {
            //valida el mensaje
            DialogResult mensaje = MessageBox.Show("¿Esta seguro que desea Salir?", "Mensaje del sistema", 
                                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (mensaje == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                return;
            }
        }

        private void tabMae_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!btnMod.Enabled) //si el boton modficar es false
            {
                if (tabMae.SelectedTab == tabMae.TabPages[1]) //valida cuando hace click en la pestaña
                {
                    tabMae.SelectedTab = tabMae.TabPages[0]; //se posicion en el primer tabpages
                }
            }
        }

        private void DatosCategoria()
        {
            //llena de datos la columna de categoria
            CellStyle styArtCom;
            DataTable dtRecArtCom = new DataTable();
            dtRecArtCom = ArtCom.ArtCom_Tip_Rec();

            ListDictionary lisCat = new ListDictionary();

            for (int i = 0; i <= dtRecArtCom.Rows.Count - 1; i++)
            {
               key = dtRecArtCom.Rows[i][0].ToString();
               value = dtRecArtCom.Rows[i][1].ToString();
                lisCat.Add(key, value);
            }

            styArtCom = fgMae.Styles.Add("Tipo");
            styArtCom.DataMap = lisCat;
            fgMae.Cols["Tipo"].Style = styArtCom;
        }

        private void fgMae_AfterEdit(object sender, RowColEventArgs e)
        {
            try
            {   //actualiza los registros segun la columna
                ArtComEnc.CodArtCom = Convert.ToInt32(fgMae[e.Row, 0]); //codigo de articulo
                string DesArt = fgMae[e.Row, 1].ToString();

                if (e.Col == 1)
                {
                    if (string.IsNullOrEmpty(DesArt.Trim()))
                    {
                        MessageBox.Show("Ingrese una descripion", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        fgMae[e.Row, 1] = desRec;
                        return;
                    }
                }

                //guardad los datos segun la columna posicionada
                switch (e.Col)
                {
                    case 1:
                        ArtComEnc.Des = Convert.ToString(fgMae[e.Row, 1]); //guarda la celda a la entidad
                        ArtCom.ArtCom_UpdCol(1, ArtComEnc, varglo.CodUsuAct); // ejecuta la consulta
                        break;
                    case 2:
                        ArtComEnc.Obs = fgMae[e.Row, 2].ToString();
                        ArtCom.ArtCom_UpdCol(2, ArtComEnc, varglo.CodUsuAct);
                        break;
                    case 3:
                        ArtComEnc.CodTipArtCom = Convert.ToInt16(key);
                        ArtCom.ArtCom_UpdCol(3, ArtComEnc, varglo.CodUsuAct);
                        break;
                    case 4:
                        ArtComEnc.Inacivo = Convert.ToBoolean(fgMae[e.Row, 4]); 
                        if (Convert.ToInt16(fgMae[e.Row, 4].ToString()) != 0)   //valida si hay check
                        {
                            ArtCom.ArtCom_UpdCol(4, ArtComEnc, varglo.CodUsuAct);
                        }
                        else
                        {
                            ArtCom.ArtCom_UpdCol(4, ArtComEnc, varglo.CodUsuAct);
                        }
                        break;
                    case 5:
                        ArtComEnc.PorDes = Convert.ToDecimal(fgMae[e.Row, 5]);
                        ArtCom.ArtCom_UpdCol(5, ArtComEnc, varglo.CodUsuAct);
                        break;
                    case 6:
                        ArtComEnc.RutaImagen = Convert.ToString(fgMae[e.Row, 6]);
                        ArtCom.ArtCom_UpdCol(6, ArtComEnc, varglo.CodUsuAct);
                        break;
                    case 8:
                        ArtComEnc.RutAplicacion = Convert.ToString(fgMae[e.Row, 8]);
                        ArtCom.ArtCom_UpdCol(8, ArtComEnc, varglo.CodUsuAct);
                        break;
                    default:
                        break;
                 }

                if (txtCod.Text.ToString() == fgMae[e.Row, 0].ToString())  //recuperamos los datos
                {
                    txtDes.Text = fgMae[e.Row, 1].ToString();
                    txtObs.Text = fgMae[e.Row, 2].ToString();
                    txtCodTipArt.Text = key;
                    txtTipoArt.Text = value;
                }
            }
            catch { return; }
        }

        private void txtDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            //detecta el enter
            if (e.KeyChar == (char)13)
            {
                txtObs.Focus();
            }
        }

        private void txtObs_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtTipoArt.Focus();
            }
        }
        void ConsultaDatos(string vista, string procedimiento, string param1, int param2 = 0) //parametros
        {
            DataTable dt = new DataTable();
            frmConsulta_Varios frm = new frmConsulta_Varios();
            dt = ArtCom.Man_ArticulosCompuesto_Filtros(vista, procedimiento, param1, param2);

            if (dt.Rows.Count > 1 && vista == "Tipo") //valida si hay datos mayores a 1
            {
                frm.Formulario = 18;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.Man_ArtCom = this;

                frm.dg.Columns[0].Width = 50;
                frm.dg.Columns[1].Width = 50;

                frm.ShowDialog();
            }

            else if (dt.Rows.Count > 1 && vista == "Articulo")
            {
                frm.Formulario = 18;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.Man_ArtCom = this;

                frm.dg.Columns[0].Width = 100;
                frm.dg.Columns[2].Width = 600;
                frm.dg.Columns[3].Width = 150;
                frm.dg.Columns[4].Width = 50;

                frm.dg.Columns[6].Width = 50;
                frm.dg.Columns[7].Width = 80;
                frm.dg.Columns[8].Width = 250;
                frm.dg.Columns[9].Width = 500;

                frm.dg.Columns[5].DefaultCellStyle.Format = "0.00";

                frm.ShowDialog();
            }
            else if (dt.Rows.Count == 1) //valida si el dato tiene registros
            {
                DataRow rows = dt.Rows[0];
            }
            else 
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataRow row = null;

            if (dt.Rows.Count == 1) //valida si tiene registro
            {
                row = dt.Rows[0];

                switch (vista)
                {
                    case "Tipo":
                        txtCodTipArt.Text = row["Codigo"].ToString();
                        txtTipoArt.Text = row["Des"].ToString();
                        txtTipoArt.Focus();
                        break;
                    case "Articulo":
                        txtCodArt.Text = row["Codigo"].ToString();
                        txtDesArt.Text = row["Descripcion"].ToString();
                        txtCat.Text = row["Catalogo"].ToString();
                        txtPre.Text = row["Precio Publico"].ToString();
                        txtMon.Text = row["Moneda"].ToString();
                        txtDescon.Text = row["Descontinuado"].ToString();
                        txtCan.Focus();
                        break;
                    default:
                        break;
                }
            }
        }

        private void txtTipoArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar ==(char)13)
            {
                ConsultaDatos("Tipo", "Filtro_TipoArticuloCompuesto", txtTipoArt.Text);
                txtCodArt.Focus();
            }
        }

        private void txtCod_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtDes.Focus();
            }
        }

        //constructor de las interfaces
        public void recdat_TipSer(string CodTipArt, string DesTipArt)
        {
            txtCodTipArt.Text = CodTipArt;
            txtTipoArt.Text = DesTipArt;
        }
        public void recdat_ArtCom(string CodArt, string DesArt, string Cat, string Pre, string Mon, string Descon)
        {
            txtCodArt.Text = CodArt;
            txtDesArt.Text = DesArt;
            txtCat.Text = Cat;
            txtPre.Text = Pre;
            txtMon.Text = Mon;
            txtDescon.Text = Descon;
        }
        //
        private void txtCodArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar ==(char)13)
            {
                ConsultaDatos("Articulo", "Filtro_3Articulo", txtCodArt.Text, 1);
                txtDesArt.Focus();
            }
        }

        private void txtCat_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("Articulo", "Filtro_3Articulo", txtCat.Text, 3);
                txtCan.Focus();
            }
        }

        private void txtDesArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            //valida si hay datos
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("Articulo", "Filtro_3Articulo", txtDesArt.Text, 2);
                txtCan.Focus();
            }
        }

        private void txtCan_KeyPress(object sender, KeyPressEventArgs e)
        {
            //permite solo numeros y decimal
            if ( char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar)) //verifica si hay un punto decimal - permite ingresar la tecla backspace
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                btnAgr.Focus();
            }
        }

        int fila = 0;
        private void btnAgr_Click(object sender, EventArgs e)
        {
            int valor = 0;

            if (string.IsNullOrEmpty(txtCodArt.Text))//valida si no hay codigo de articulo
            {
                MessageBox.Show("Ingrese una codigo de articulo", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCodArt.Focus();
                return;
            }
            if (ArtCom.Man_ArtCom_ValCodArt(txtCodArt.Text) == 0) //valida  si el codigo de articulo existe
            {
                MessageBox.Show("El codigo de artículo no existe", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCodArt.Focus();
                return;
            }
            if (string.IsNullOrEmpty(txtCan.Text)) //valida si no a ingresado datos
            {
                MessageBox.Show("Ingrese una cantidad", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCan.Focus();
                return;
            }

            if (txtCan.Text.Substring(0,1) == "0")
            {
                MessageBox.Show("Cantidad ingresada incorrecta", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCan.Focus();
                return;
            }

            int.TryParse(txtCan.Text.ToString(), out valor);

            if (valor == 0)//valida si no hay cantidad o tiene cero(s)
            {
                MessageBox.Show("Ingrese un cantidad mayor a 0", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCan.Focus();

                return;
            }

            for (int i = 1; i < fgCom.Rows.Count; i++) //verificar que no se repita el codigo de articulo
            {
                if (txtCodArt.Text == fgCom.Rows[i][0].ToString())
                {
                    if (modGua == false)
                    {
                        MessageBox.Show("El codigo de articulo ya esta agregado,seleccione otro", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtCodArt.Focus();
                        return;
                    }
                }
            }

            if (chkPri.Checked)
            {
                for (int i = 1; i < fgCom.Rows.Count; i++) //verificar que no haya mas de un articulo principal
                {
                    if (fgCom.Rows[i][4].ToString() == "1" )
                    {
                        if ((modGua == true & fgCom.Rows[i][0].ToString() != txtCodArt.Text)  || modGua == false )
                        {
                            MessageBox.Show("Ya tiene un articulo principal", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtCodArt.Focus();
                            return;
                        }
               
                    }
                }
            }

            if (modGua == false)
            {
                fgCom.Rows.Add();
                fila = fgCom.Rows.Count - 1;
            }

            //asignando datos al grid
            fgCom.Rows[fila][0] = txtCodArt.Text;
            fgCom.Rows[fila][1] = txtCat.Text;
            fgCom.Rows[fila][2] = txtDesArt.Text;
            fgCom.Rows[fila][3] = txtCan.Text;
            fgCom.Rows[fila][4] = chkPri.Checked;
            fgCom.Rows[fila][5] = txtPre.Text;
            fgCom.Rows[fila][6] = txtMon.Text;
            fgCom.Rows[fila][7] = txtDescon.Text;

            //limpiando cajas de texto componetes
            LimpiarTextos(true);
            btnModCom.Enabled = true;
            fgCom.Enabled = true;
            modGua = false;
        }

        private void btnModCom_Click(object sender, EventArgs e)
        {
            if (fgCom.IsCellSelected(fgCom.Row,fgCom.Col)) //valida que halla seleccionado un fila
            {
                modGua = true;
                //pasando valors a los textos
                txtCodArt.Text = fgCom.Rows[fgCom.Row][0].ToString();
                txtCat.Text = fgCom.Rows[fgCom.Row][1].ToString();
                txtDesArt.Text = fgCom.Rows[fgCom.Row][2].ToString();
                txtCan.Text = fgCom.Rows[fgCom.Row][3].ToString();
                chkPri.Checked = Convert.ToBoolean(fgCom.Rows[fgCom.Row][4]);
                txtPre.Text = fgCom.Rows[fgCom.Row][5].ToString();
                txtMon.Text = fgCom.Rows[fgCom.Row][6].ToString();
                txtDescon.Text = fgCom.Rows[fgCom.Row][7].ToString();
                fila = fgCom.Row;

                btnModCom.Enabled = false; //deshabilita el boton
                fgCom.Enabled = false;
            }
            else
            {
                return;
            }
        }

        private void btnEliCom_Click(object sender, EventArgs e)
        {
            DialogResult mensaje = MessageBox.Show("¿Esta seguro de eliminar este artículo?", "Mensaje del sistema",
                                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (mensaje == DialogResult.Yes)
            {
                if (fgCom.IsCellSelected(fgCom.Row, fgCom.Col)) //valida que halla seleccionado un fila
                {
                    fgCom.Rows.Remove(fgCom.Row); //elimina la fila seleccionada
                    LimpiarTextos(true);
                    btnModCom.Enabled = true;
                    fgCom.Enabled = true;
                    modGua = false;
                }
            }
        }

        private void btnCanCom_Click(object sender, EventArgs e)
        {
            LimpiarTextos(true);
            fgCom.Enabled = true;
            btnModCom.Enabled = true;
        }

        private void fgMae_StartEdit(object sender, RowColEventArgs e)
        {
            desRec = fgMae[e.Row, 1].ToString();
            descuRec = fgMae[e.Row, 5].ToString();
        }
    }
}
