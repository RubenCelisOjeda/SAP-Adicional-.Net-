﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmRuta_OnlineAviso : Form
    {
        public frmRuta_OnlineAviso()
        {
            InitializeComponent();
        }

        private void btnCerAvi_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fgRutOnlAvi_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar !=27)
            {
                e.Handled = true;
            }
        }
    }
}
