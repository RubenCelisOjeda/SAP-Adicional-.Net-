﻿namespace SAP_Adicional
{
    partial class frmRuta_Online
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRuta_Online));
            this.btnAct = new System.Windows.Forms.Button();
            this.gpbInf = new System.Windows.Forms.GroupBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.chkRutCor = new System.Windows.Forms.CheckBox();
            this.lblCorRut = new System.Windows.Forms.Label();
            this.txtCodCorRut = new System.Windows.Forms.TextBox();
            this.txtDesCorRut = new System.Windows.Forms.TextBox();
            this.txtCodTra = new System.Windows.Forms.TextBox();
            this.txtDesTra = new System.Windows.Forms.TextBox();
            this.lblTra = new System.Windows.Forms.Label();
            this.btnImp = new System.Windows.Forms.Button();
            this.gpbOpcImp = new System.Windows.Forms.GroupBox();
            this.dtpFecRutOnl = new System.Windows.Forms.DateTimePicker();
            this.chkTod = new System.Windows.Forms.CheckBox();
            this.txtMin = new System.Windows.Forms.TextBox();
            this.btnAceAte = new System.Windows.Forms.Button();
            this.btnAnu = new System.Windows.Forms.Button();
            this.btnCamFec = new System.Windows.Forms.Button();
            this.pnlCabmFec = new System.Windows.Forms.Panel();
            this.ggpbCamFec = new System.Windows.Forms.GroupBox();
            this.txtFecCF = new System.Windows.Forms.MaskedTextBox();
            this.btnCamAct = new System.Windows.Forms.Button();
            this.txtHorCF = new System.Windows.Forms.TextBox();
            this.txtEncCF = new System.Windows.Forms.TextBox();
            this.txtRutCF = new System.Windows.Forms.TextBox();
            this.txtNumRQCF = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCliCF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCer = new System.Windows.Forms.Label();
            this.btnPen = new System.Windows.Forms.Button();
            this.fgRutOnl = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnExp = new System.Windows.Forms.Button();
            this.pnlPri = new System.Windows.Forms.Panel();
            this.tmrDat = new System.Windows.Forms.Timer(this.components);
            this.ntfRut = new System.Windows.Forms.NotifyIcon(this.components);
            this.gpbInf.SuspendLayout();
            this.gpbOpcImp.SuspendLayout();
            this.pnlCabmFec.SuspendLayout();
            this.ggpbCamFec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgRutOnl)).BeginInit();
            this.pnlPri.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAct
            // 
            this.btnAct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAct.Image = ((System.Drawing.Image)(resources.GetObject("btnAct.Image")));
            this.btnAct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAct.Location = new System.Drawing.Point(3, 7);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(91, 23);
            this.btnAct.TabIndex = 0;
            this.btnAct.Text = "&Actualizar";
            this.btnAct.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAct.UseVisualStyleBackColor = true;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            // 
            // gpbInf
            // 
            this.gpbInf.Controls.Add(this.lblInfo);
            this.gpbInf.Location = new System.Drawing.Point(359, 3);
            this.gpbInf.Name = "gpbInf";
            this.gpbInf.Size = new System.Drawing.Size(318, 38);
            this.gpbInf.TabIndex = 3;
            this.gpbInf.TabStop = false;
            this.gpbInf.Text = "Información";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(62, 17);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(0, 13);
            this.lblInfo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(680, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Actualizar cada";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(800, 16);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(39, 13);
            this.lblMin.TabIndex = 5;
            this.lblMin.Text = "minuto";
            // 
            // chkRutCor
            // 
            this.chkRutCor.AutoSize = true;
            this.chkRutCor.Location = new System.Drawing.Point(14, 21);
            this.chkRutCor.Name = "chkRutCor";
            this.chkRutCor.Size = new System.Drawing.Size(49, 17);
            this.chkRutCor.TabIndex = 7;
            this.chkRutCor.Text = "Ruta";
            this.chkRutCor.UseVisualStyleBackColor = true;
            this.chkRutCor.CheckedChanged += new System.EventHandler(this.chkRutCor_CheckedChanged);
            // 
            // lblCorRut
            // 
            this.lblCorRut.AutoSize = true;
            this.lblCorRut.Location = new System.Drawing.Point(78, 22);
            this.lblCorRut.Name = "lblCorRut";
            this.lblCorRut.Size = new System.Drawing.Size(38, 13);
            this.lblCorRut.TabIndex = 8;
            this.lblCorRut.Text = "Corte:";
            // 
            // txtCodCorRut
            // 
            this.txtCodCorRut.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodCorRut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodCorRut.Location = new System.Drawing.Point(122, 14);
            this.txtCodCorRut.Name = "txtCodCorRut";
            this.txtCodCorRut.Size = new System.Drawing.Size(39, 21);
            this.txtCodCorRut.TabIndex = 9;
            // 
            // txtDesCorRut
            // 
            this.txtDesCorRut.BackColor = System.Drawing.Color.White;
            this.txtDesCorRut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesCorRut.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesCorRut.Location = new System.Drawing.Point(160, 14);
            this.txtDesCorRut.Name = "txtDesCorRut";
            this.txtDesCorRut.Size = new System.Drawing.Size(178, 21);
            this.txtDesCorRut.TabIndex = 10;
            this.txtDesCorRut.Text = "Presione enter o ingrese un corte";
            this.txtDesCorRut.Enter += new System.EventHandler(this.txtDesCorRut_Enter);
            this.txtDesCorRut.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesCor_KeyPress);
            this.txtDesCorRut.Leave += new System.EventHandler(this.txtDesCorRut_Leave);
            // 
            // txtCodTra
            // 
            this.txtCodTra.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodTra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodTra.Location = new System.Drawing.Point(418, 14);
            this.txtCodTra.Name = "txtCodTra";
            this.txtCodTra.Size = new System.Drawing.Size(52, 21);
            this.txtCodTra.TabIndex = 12;
            this.txtCodTra.Visible = false;
            // 
            // txtDesTra
            // 
            this.txtDesTra.BackColor = System.Drawing.Color.White;
            this.txtDesTra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesTra.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesTra.Location = new System.Drawing.Point(469, 14);
            this.txtDesTra.Name = "txtDesTra";
            this.txtDesTra.Size = new System.Drawing.Size(204, 21);
            this.txtDesTra.TabIndex = 13;
            this.txtDesTra.Text = "Presione enter o ingrese un transportista";
            this.txtDesTra.Visible = false;
            this.txtDesTra.Enter += new System.EventHandler(this.txtDesTra_Enter);
            this.txtDesTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesTra_KeyPress);
            this.txtDesTra.Leave += new System.EventHandler(this.txtDesTra_Leave);
            // 
            // lblTra
            // 
            this.lblTra.AutoSize = true;
            this.lblTra.Location = new System.Drawing.Point(345, 22);
            this.lblTra.Name = "lblTra";
            this.lblTra.Size = new System.Drawing.Size(71, 13);
            this.lblTra.TabIndex = 11;
            this.lblTra.Text = "Transportista";
            this.lblTra.Visible = false;
            // 
            // btnImp
            // 
            this.btnImp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnImp.Image = ((System.Drawing.Image)(resources.GetObject("btnImp.Image")));
            this.btnImp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImp.Location = new System.Drawing.Point(679, 12);
            this.btnImp.Name = "btnImp";
            this.btnImp.Size = new System.Drawing.Size(109, 23);
            this.btnImp.TabIndex = 14;
            this.btnImp.Text = "&Imprimir";
            this.btnImp.UseVisualStyleBackColor = true;
            this.btnImp.Click += new System.EventHandler(this.btnImp_Click);
            // 
            // gpbOpcImp
            // 
            this.gpbOpcImp.Controls.Add(this.btnImp);
            this.gpbOpcImp.Controls.Add(this.lblTra);
            this.gpbOpcImp.Controls.Add(this.txtDesTra);
            this.gpbOpcImp.Controls.Add(this.txtCodTra);
            this.gpbOpcImp.Controls.Add(this.txtDesCorRut);
            this.gpbOpcImp.Controls.Add(this.txtCodCorRut);
            this.gpbOpcImp.Controls.Add(this.lblCorRut);
            this.gpbOpcImp.Controls.Add(this.chkRutCor);
            this.gpbOpcImp.Location = new System.Drawing.Point(4, 36);
            this.gpbOpcImp.Name = "gpbOpcImp";
            this.gpbOpcImp.Size = new System.Drawing.Size(797, 45);
            this.gpbOpcImp.TabIndex = 6;
            this.gpbOpcImp.TabStop = false;
            this.gpbOpcImp.Text = "Opciones de Impresión";
            // 
            // dtpFecRutOnl
            // 
            this.dtpFecRutOnl.Location = new System.Drawing.Point(97, 8);
            this.dtpFecRutOnl.Name = "dtpFecRutOnl";
            this.dtpFecRutOnl.Size = new System.Drawing.Size(200, 21);
            this.dtpFecRutOnl.TabIndex = 1;
            this.dtpFecRutOnl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpFec_KeyPress);
            // 
            // chkTod
            // 
            this.chkTod.AutoSize = true;
            this.chkTod.Location = new System.Drawing.Point(302, 12);
            this.chkTod.Name = "chkTod";
            this.chkTod.Size = new System.Drawing.Size(50, 17);
            this.chkTod.TabIndex = 2;
            this.chkTod.Text = "Todo";
            this.chkTod.UseVisualStyleBackColor = true;
            // 
            // txtMin
            // 
            this.txtMin.Location = new System.Drawing.Point(762, 9);
            this.txtMin.Name = "txtMin";
            this.txtMin.Size = new System.Drawing.Size(37, 21);
            this.txtMin.TabIndex = 5;
            this.txtMin.Text = "1";
            this.txtMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtMin.TextChanged += new System.EventHandler(this.txtMin_TextChanged);
            this.txtMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMin_KeyPress);
            // 
            // btnAceAte
            // 
            this.btnAceAte.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAceAte.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAceAte.Image = ((System.Drawing.Image)(resources.GetObject("btnAceAte.Image")));
            this.btnAceAte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceAte.Location = new System.Drawing.Point(3, 85);
            this.btnAceAte.Name = "btnAceAte";
            this.btnAceAte.Size = new System.Drawing.Size(127, 23);
            this.btnAceAte.TabIndex = 17;
            this.btnAceAte.Text = "Aceptar Atendidas";
            this.btnAceAte.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAceAte.UseVisualStyleBackColor = true;
            this.btnAceAte.Click += new System.EventHandler(this.btnAceAte_Click);
            // 
            // btnAnu
            // 
            this.btnAnu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAnu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAnu.Image = ((System.Drawing.Image)(resources.GetObject("btnAnu.Image")));
            this.btnAnu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAnu.Location = new System.Drawing.Point(136, 85);
            this.btnAnu.Name = "btnAnu";
            this.btnAnu.Size = new System.Drawing.Size(116, 23);
            this.btnAnu.TabIndex = 18;
            this.btnAnu.Text = "A&nular";
            this.btnAnu.UseVisualStyleBackColor = true;
            this.btnAnu.Click += new System.EventHandler(this.btnAnu_Click);
            // 
            // btnCamFec
            // 
            this.btnCamFec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCamFec.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCamFec.Image = ((System.Drawing.Image)(resources.GetObject("btnCamFec.Image")));
            this.btnCamFec.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCamFec.Location = new System.Drawing.Point(815, 39);
            this.btnCamFec.Name = "btnCamFec";
            this.btnCamFec.Size = new System.Drawing.Size(101, 38);
            this.btnCamFec.TabIndex = 15;
            this.btnCamFec.Text = "Cambiar Fecha";
            this.btnCamFec.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCamFec.UseVisualStyleBackColor = true;
            this.btnCamFec.Click += new System.EventHandler(this.btnCamFec_Click);
            // 
            // pnlCabmFec
            // 
            this.pnlCabmFec.Controls.Add(this.ggpbCamFec);
            this.pnlCabmFec.Location = new System.Drawing.Point(330, 138);
            this.pnlCabmFec.Name = "pnlCabmFec";
            this.pnlCabmFec.Size = new System.Drawing.Size(410, 245);
            this.pnlCabmFec.TabIndex = 0;
            // 
            // ggpbCamFec
            // 
            this.ggpbCamFec.Controls.Add(this.txtFecCF);
            this.ggpbCamFec.Controls.Add(this.btnCamAct);
            this.ggpbCamFec.Controls.Add(this.txtHorCF);
            this.ggpbCamFec.Controls.Add(this.txtEncCF);
            this.ggpbCamFec.Controls.Add(this.txtRutCF);
            this.ggpbCamFec.Controls.Add(this.txtNumRQCF);
            this.ggpbCamFec.Controls.Add(this.label8);
            this.ggpbCamFec.Controls.Add(this.label6);
            this.ggpbCamFec.Controls.Add(this.label9);
            this.ggpbCamFec.Controls.Add(this.label7);
            this.ggpbCamFec.Controls.Add(this.label5);
            this.ggpbCamFec.Controls.Add(this.txtCliCF);
            this.ggpbCamFec.Controls.Add(this.label3);
            this.ggpbCamFec.Controls.Add(this.lblCer);
            this.ggpbCamFec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ggpbCamFec.Location = new System.Drawing.Point(8, 4);
            this.ggpbCamFec.Name = "ggpbCamFec";
            this.ggpbCamFec.Size = new System.Drawing.Size(391, 238);
            this.ggpbCamFec.TabIndex = 0;
            this.ggpbCamFec.TabStop = false;
            this.ggpbCamFec.Text = "Cambiar fecha";
            // 
            // txtFecCF
            // 
            this.txtFecCF.Location = new System.Drawing.Point(270, 57);
            this.txtFecCF.Mask = "00/00/0000";
            this.txtFecCF.Name = "txtFecCF";
            this.txtFecCF.Size = new System.Drawing.Size(90, 21);
            this.txtFecCF.TabIndex = 3;
            this.txtFecCF.ValidatingType = typeof(System.DateTime);
            // 
            // btnCamAct
            // 
            this.btnCamAct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCamAct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCamAct.Image = ((System.Drawing.Image)(resources.GetObject("btnCamAct.Image")));
            this.btnCamAct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCamAct.Location = new System.Drawing.Point(152, 203);
            this.btnCamAct.Name = "btnCamAct";
            this.btnCamAct.Size = new System.Drawing.Size(126, 29);
            this.btnCamAct.TabIndex = 7;
            this.btnCamAct.Text = "Cambiar/Actualizar";
            this.btnCamAct.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCamAct.UseVisualStyleBackColor = true;
            this.btnCamAct.Click += new System.EventHandler(this.btnCamAct_Click);
            // 
            // txtHorCF
            // 
            this.txtHorCF.Location = new System.Drawing.Point(270, 85);
            this.txtHorCF.Name = "txtHorCF";
            this.txtHorCF.ReadOnly = true;
            this.txtHorCF.Size = new System.Drawing.Size(64, 21);
            this.txtHorCF.TabIndex = 5;
            // 
            // txtEncCF
            // 
            this.txtEncCF.Location = new System.Drawing.Point(57, 117);
            this.txtEncCF.Multiline = true;
            this.txtEncCF.Name = "txtEncCF";
            this.txtEncCF.ReadOnly = true;
            this.txtEncCF.Size = new System.Drawing.Size(303, 79);
            this.txtEncCF.TabIndex = 6;
            // 
            // txtRutCF
            // 
            this.txtRutCF.Location = new System.Drawing.Point(57, 85);
            this.txtRutCF.Name = "txtRutCF";
            this.txtRutCF.ReadOnly = true;
            this.txtRutCF.Size = new System.Drawing.Size(167, 21);
            this.txtRutCF.TabIndex = 4;
            // 
            // txtNumRQCF
            // 
            this.txtNumRQCF.Location = new System.Drawing.Point(57, 58);
            this.txtNumRQCF.Name = "txtNumRQCF";
            this.txtNumRQCF.ReadOnly = true;
            this.txtNumRQCF.Size = new System.Drawing.Size(167, 21);
            this.txtNumRQCF.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(230, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Hora:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(230, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Fecha:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Encargo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Ruta:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "N° RQ:";
            // 
            // txtCliCF
            // 
            this.txtCliCF.Location = new System.Drawing.Point(57, 31);
            this.txtCliCF.Name = "txtCliCF";
            this.txtCliCF.ReadOnly = true;
            this.txtCliCF.Size = new System.Drawing.Size(303, 21);
            this.txtCliCF.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cliente:";
            // 
            // lblCer
            // 
            this.lblCer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCer.Image = ((System.Drawing.Image)(resources.GetObject("lblCer.Image")));
            this.lblCer.Location = new System.Drawing.Point(368, 9);
            this.lblCer.Name = "lblCer";
            this.lblCer.Size = new System.Drawing.Size(21, 18);
            this.lblCer.TabIndex = 1;
            this.lblCer.Click += new System.EventHandler(this.lblCer_Click);
            // 
            // btnPen
            // 
            this.btnPen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPen.Image = ((System.Drawing.Image)(resources.GetObject("btnPen.Image")));
            this.btnPen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPen.Location = new System.Drawing.Point(815, 76);
            this.btnPen.Name = "btnPen";
            this.btnPen.Size = new System.Drawing.Size(101, 36);
            this.btnPen.TabIndex = 16;
            this.btnPen.Text = "Pendientes";
            this.btnPen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPen.UseVisualStyleBackColor = true;
            this.btnPen.Click += new System.EventHandler(this.btnPen_Click);
            // 
            // fgRutOnl
            // 
            this.fgRutOnl.AllowFiltering = true;
            this.fgRutOnl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgRutOnl.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgRutOnl.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.Heavy;
            this.fgRutOnl.Location = new System.Drawing.Point(0, 122);
            this.fgRutOnl.Name = "fgRutOnl";
            this.fgRutOnl.Rows.DefaultSize = 19;
            this.fgRutOnl.Rows.MaxSize = 50;
            this.fgRutOnl.Size = new System.Drawing.Size(1094, 347);
            this.fgRutOnl.TabIndex = 20;
            this.fgRutOnl.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgRutOnl_StartEdit);
            this.fgRutOnl.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgRutOnl_AfterEdit);
            this.fgRutOnl.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgRutOnl_KeyPressEdit);
            this.fgRutOnl.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgRutOnl_AfterDataRefresh);
            // 
            // btnExp
            // 
            this.btnExp.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnExp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExp.Image = ((System.Drawing.Image)(resources.GetObject("btnExp.Image")));
            this.btnExp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExp.Location = new System.Drawing.Point(491, 475);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(116, 32);
            this.btnExp.TabIndex = 21;
            this.btnExp.Text = "Exportar Excel";
            this.btnExp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // pnlPri
            // 
            this.pnlPri.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlPri.Controls.Add(this.btnAct);
            this.pnlPri.Controls.Add(this.dtpFecRutOnl);
            this.pnlPri.Controls.Add(this.chkTod);
            this.pnlPri.Controls.Add(this.gpbInf);
            this.pnlPri.Controls.Add(this.btnPen);
            this.pnlPri.Controls.Add(this.label1);
            this.pnlPri.Controls.Add(this.btnCamFec);
            this.pnlPri.Controls.Add(this.txtMin);
            this.pnlPri.Controls.Add(this.btnAnu);
            this.pnlPri.Controls.Add(this.lblMin);
            this.pnlPri.Controls.Add(this.btnAceAte);
            this.pnlPri.Controls.Add(this.gpbOpcImp);
            this.pnlPri.Location = new System.Drawing.Point(2, 3);
            this.pnlPri.Name = "pnlPri";
            this.pnlPri.Size = new System.Drawing.Size(1092, 117);
            this.pnlPri.TabIndex = 22;
            // 
            // tmrDat
            // 
            this.tmrDat.Interval = 60000;
            this.tmrDat.Tick += new System.EventHandler(this.tmrDat_Tick);
            // 
            // ntfRut
            // 
            this.ntfRut.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.ntfRut.Icon = ((System.Drawing.Icon)(resources.GetObject("ntfRut.Icon")));
            this.ntfRut.Text = "SAP Adiconal .Net";
            this.ntfRut.Visible = true;
            this.ntfRut.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.ntfRut_MouseDoubleClick);
            // 
            // frmRuta_Online
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 511);
            this.Controls.Add(this.pnlPri);
            this.Controls.Add(this.pnlCabmFec);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.fgRutOnl);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmRuta_Online";
            this.Text = "Ruta OnLine";
            this.Load += new System.EventHandler(this.frmRuta_Online_Load);
            this.gpbInf.ResumeLayout(false);
            this.gpbInf.PerformLayout();
            this.gpbOpcImp.ResumeLayout(false);
            this.gpbOpcImp.PerformLayout();
            this.pnlCabmFec.ResumeLayout(false);
            this.ggpbCamFec.ResumeLayout(false);
            this.ggpbCamFec.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgRutOnl)).EndInit();
            this.pnlPri.ResumeLayout(false);
            this.pnlPri.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAct;
        private System.Windows.Forms.GroupBox gpbInf;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.CheckBox chkRutCor;
        private System.Windows.Forms.Label lblCorRut;
        private System.Windows.Forms.TextBox txtCodCorRut;
        private System.Windows.Forms.TextBox txtDesCorRut;
        private System.Windows.Forms.TextBox txtCodTra;
        private System.Windows.Forms.TextBox txtDesTra;
        private System.Windows.Forms.Label lblTra;
        private System.Windows.Forms.Button btnImp;
        private System.Windows.Forms.GroupBox gpbOpcImp;
        private System.Windows.Forms.DateTimePicker dtpFecRutOnl;
        private System.Windows.Forms.CheckBox chkTod;
        private System.Windows.Forms.TextBox txtMin;
        private System.Windows.Forms.Button btnAceAte;
        private System.Windows.Forms.Button btnAnu;
        private System.Windows.Forms.Button btnCamFec;
        private System.Windows.Forms.Panel pnlCabmFec;
        private System.Windows.Forms.GroupBox ggpbCamFec;
        private System.Windows.Forms.Button btnCamAct;
        private System.Windows.Forms.TextBox txtHorCF;
        private System.Windows.Forms.TextBox txtEncCF;
        private System.Windows.Forms.TextBox txtRutCF;
        private System.Windows.Forms.TextBox txtNumRQCF;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCliCF;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCer;
        private System.Windows.Forms.Button btnPen;
        private C1.Win.C1FlexGrid.C1FlexGrid fgRutOnl;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Panel pnlPri;
        private System.Windows.Forms.MaskedTextBox txtFecCF;
        private System.Windows.Forms.NotifyIcon ntfRut;
        protected internal System.Windows.Forms.Timer tmrDat;
    }
}