﻿namespace SAP_Adicional
{
    partial class frmVEN_RQ_info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMost = new System.Windows.Forms.Button();
            this.txtCli = new System.Windows.Forms.TextBox();
            this.txtRQ = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExp = new System.Windows.Forms.Button();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMost
            // 
            this.btnMost.Location = new System.Drawing.Point(637, 61);
            this.btnMost.Name = "btnMost";
            this.btnMost.Size = new System.Drawing.Size(117, 20);
            this.btnMost.TabIndex = 2;
            this.btnMost.Text = "Mostrar/Actualizar";
            this.btnMost.UseVisualStyleBackColor = true;
            this.btnMost.Click += new System.EventHandler(this.btnMost_Click);
            // 
            // txtCli
            // 
            this.txtCli.Location = new System.Drawing.Point(93, 61);
            this.txtCli.Name = "txtCli";
            this.txtCli.Size = new System.Drawing.Size(538, 21);
            this.txtCli.TabIndex = 1;
            this.txtCli.TextChanged += new System.EventHandler(this.txtCli_TextChanged);
            this.txtCli.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCli_KeyPress);
            // 
            // txtRQ
            // 
            this.txtRQ.Location = new System.Drawing.Point(93, 35);
            this.txtRQ.Name = "txtRQ";
            this.txtRQ.Size = new System.Drawing.Size(96, 21);
            this.txtRQ.TabIndex = 0;
            this.txtRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRQ.TextChanged += new System.EventHandler(this.txtRQ_TextChanged);
            this.txtRQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRQ_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "N° RQ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Cliente:";
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(760, 61);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(117, 20);
            this.btnExp.TabIndex = 3;
            this.btnExp.Text = "Exportar Excel";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.FocusRect = C1.Win.C1FlexGrid.FocusRectEnum.Heavy;
            this.fg.Location = new System.Drawing.Point(12, 99);
            this.fg.Name = "fg";
            this.fg.Rows.Count = 1;
            this.fg.Rows.DefaultSize = 19;
            this.fg.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fg.Size = new System.Drawing.Size(1307, 423);
            this.fg.TabIndex = 5;
            this.fg.VisualStyle = C1.Win.C1FlexGrid.VisualStyle.System;
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            // 
            // frmVEN_RQ_info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1331, 534);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRQ);
            this.Controls.Add(this.txtCli);
            this.Controls.Add(this.btnMost);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_RQ_info";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Información de RQ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmVEN_RQ_info_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnMost;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.TextBox txtCli;
        private System.Windows.Forms.TextBox txtRQ;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
    }
}