﻿namespace SAP_Adicional
{
    partial class frmSeguridad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSeguridad));
            this.label7 = new System.Windows.Forms.Label();
            this.txtCon = new System.Windows.Forms.TextBox();
            this.btnAce = new System.Windows.Forms.Button();
            this.btnCan = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblSap = new System.Windows.Forms.Label();
            this.pnlLogin = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(24, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(437, 37);
            this.label7.TabIndex = 15;
            this.label7.Text = "Se está utilizando este Sistema y ha sido bloqueado por tener una  inactividad de" +
    " 10 minutos.Ingrese su Password para reanudar la conexión.Gracias!\r\n";
            // 
            // txtCon
            // 
            this.txtCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCon.ForeColor = System.Drawing.Color.Black;
            this.txtCon.Location = new System.Drawing.Point(252, 106);
            this.txtCon.Name = "txtCon";
            this.txtCon.PasswordChar = '*';
            this.txtCon.Size = new System.Drawing.Size(164, 21);
            this.txtCon.TabIndex = 2;
            // 
            // btnAce
            // 
            this.btnAce.BackColor = System.Drawing.Color.DarkGray;
            this.btnAce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAce.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAce.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAce.ForeColor = System.Drawing.Color.Black;
            this.btnAce.Location = new System.Drawing.Point(198, 144);
            this.btnAce.Name = "btnAce";
            this.btnAce.Size = new System.Drawing.Size(93, 25);
            this.btnAce.TabIndex = 3;
            this.btnAce.Text = "&Aceptar";
            this.btnAce.UseVisualStyleBackColor = false;
            this.btnAce.Click += new System.EventHandler(this.btnAce_Click);
            // 
            // btnCan
            // 
            this.btnCan.BackColor = System.Drawing.Color.DarkGray;
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCan.ForeColor = System.Drawing.Color.Black;
            this.btnCan.Location = new System.Drawing.Point(323, 144);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(93, 25);
            this.btnCan.TabIndex = 4;
            this.btnCan.Text = "&Salir";
            this.btnCan.UseVisualStyleBackColor = false;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(159, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 14);
            this.label2.TabIndex = 5;
            this.label2.Text = "Contraseña:";
            // 
            // lblSap
            // 
            this.lblSap.AutoSize = true;
            this.lblSap.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSap.ForeColor = System.Drawing.Color.Black;
            this.lblSap.Location = new System.Drawing.Point(188, 14);
            this.lblSap.Name = "lblSap";
            this.lblSap.Size = new System.Drawing.Size(125, 18);
            this.lblSap.TabIndex = 9;
            this.lblSap.Text = "SAP Adicional";
            // 
            // pnlLogin
            // 
            this.pnlLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlLogin.BackColor = System.Drawing.Color.White;
            this.pnlLogin.Controls.Add(this.pictureBox1);
            this.pnlLogin.Controls.Add(this.label7);
            this.pnlLogin.Controls.Add(this.txtCon);
            this.pnlLogin.Controls.Add(this.btnAce);
            this.pnlLogin.Controls.Add(this.btnCan);
            this.pnlLogin.Controls.Add(this.label2);
            this.pnlLogin.Controls.Add(this.lblSap);
            this.pnlLogin.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlLogin.Location = new System.Drawing.Point(5, 4);
            this.pnlLogin.Name = "pnlLogin";
            this.pnlLogin.Size = new System.Drawing.Size(464, 212);
            this.pnlLogin.TabIndex = 16;
            this.pnlLogin.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlLogin_MouseMove);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(27, 83);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(126, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // frmSeguridad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(473, 220);
            this.ControlBox = false;
            this.Controls.Add(this.pnlLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmSeguridad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmSeguridad_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmSeguridad_MouseMove);
            this.pnlLogin.ResumeLayout(false);
            this.pnlLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCon;
        private System.Windows.Forms.Button btnAce;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSap;
        private System.Windows.Forms.Panel pnlLogin;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}