﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmVEN_rep_CroPag : Form
    {
        NConsultas nc = new NConsultas();
        DataSet ds = new DataSet();

        public frmVEN_rep_CroPag()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                
                ds = nc.VEN_rep_CroPag(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text));

                fg.DataSource = ds.Tables[0];

                FormatoGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void FormatoGrid()
        {
            fg.Cols.Frozen = 2;
            
            fg.Cols[0].Width = 70;
            fg.Cols[1].Width = 300;
            fg.Cols[2].Width= 200;

            for (int i = 3; i < fg.Cols.Count; i++)
            {
                fg.Cols[i].Width = 60;
                fg.Cols[i].Format = "0.00";
            }

            this.fg.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Columns;

        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if(e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }

        }

        private void btnExp_Click(object sender, EventArgs e)
        {

            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }

        private void frmVEN_rep_CroPag_Load(object sender, EventArgs e)
        {

        }

        private void fg_Click(object sender, EventArgs e)
        {
            fgDet.Visible = false;
        }

        private void fg_DoubleClick(object sender, EventArgs e)
        {
            //DataSet ds = new DataSet();

            //ds = nc.VEN_rep_CroPag(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text));

            DataView dv = new DataView(ds.Tables[1]);
            dv.RowFilter = "[N° RQ] = " + Convert.ToInt32(fg.Rows[fg.Row][0]);

            fgDet.DataSource = dv;
            fgDet.Visible = true;

            fgDet.Top = fg.Top + fg.Rows[fg.Row].Top + fg.Rows[fg.Row].HeightDisplay;
        }

        private void fgDet_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            fgDet.Cols[0].Width = 70;            
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            for (int i = 3; i < fg.Cols.Count; i++)
            {
                fg.Subtotal(AggregateEnum.Sum, 0, -1, i);
            }
        }
    }
}
