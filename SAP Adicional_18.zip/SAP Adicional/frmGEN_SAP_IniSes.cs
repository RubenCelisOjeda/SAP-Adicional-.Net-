﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;

namespace SAP_Adicional
{
    public partial class frmGEN_SAP_IniSes : Form
    {
        NGEN_SAPConexion sap = new NGEN_SAPConexion();
        VarGlo varglo = VarGlo.Instance();

        public SAP_Variables SAP_Var { get; set; }

        public frmGEN_SAP_IniSes()
        {
            InitializeComponent();
        }

        private void btnAce_Click(object sender, EventArgs e)
        {
        
            if (sap.SAP_ValidarUsuario(txtUsu.Text,txtPas.Text) != 0)
            {
                MessageBox.Show("Usuario o password incorrecto", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);

                SAP_Var.rec_SAP_UserBad(true);

                this.txtUsu.Focus();

            }
            else
            {
                varglo.UsuSAP = txtUsu.Text; varglo.PasSAP = txtPas.Text;

                SAP_Var.rec_SAP_Connection(sap.SAP_ConectarCompañia(txtUsu.Text, txtPas.Text));

                SAP_Var.rec_SAP_UserBad(false);

                this.Dispose();

            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            SAP_Var.rec_SAP_UserBad(true);

            this.Dispose();
        }

        private void frmGEN_SAP_IniSes_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Dispose();
            }
        }

        private void txtPas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnAce.Focus();
            }
        }

        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPas.Focus();
            }
        }
    }
}
