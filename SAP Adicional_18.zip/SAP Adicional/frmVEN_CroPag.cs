﻿
using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.VEN_CroPag;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmVEN_CroPag : Form
    {

        NVEN_CroPag dc = new NVEN_CroPag();
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        public Int64 NumMov=0;
        byte EstDoc;
        public Int16 Origen;
        byte OriLla = 0; //Para el agregar cotizaciones             
        
        public frmVEN_CroPag()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }
        //estado de los botones
        public void VEN_CroPag_EstBot(string BotonEstado)
        {
            bool[] EstadoM = { true };

            //nuevo, abrir, guardar, deshacer, modificar, imprimir,

            switch (BotonEstado)
            {
 
                case "nuevo":
                case "modificar":
                    EstadoM = matriz(false, false, true, true, false, false);
                    break;
                case "abrir":

                    switch (EstDoc)
                    {
                        case 1: //Generado
                            EstadoM = matriz(true, true, false, false, true, true);
                            break;

                    }
                    break;

                case "guardar": //
                    EstadoM = matriz(true, true, false, true, true, true);
                    break;

                case "deshacer": //
                    EstadoM = matriz(true, true, false, true, false, false);
                    break;

                //case "seleccionar aceptar": //
                //    EstadoM = matriz(false, false, true, true, false, false);
                //    break;
            }

            this.btnNuevo.Enabled = EstadoM[0];
            this.btnAbrir.Enabled = EstadoM[1];
            this.btnGuardar.Enabled = EstadoM[2];
            this.btnDeshacer.Enabled = EstadoM[3];
            this.btnModificar.Enabled = EstadoM[4];
        }
        public void Mensaje()
        {
            MessageBox.Show("No cuenta con acceso para realizar esta operación", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);return;
        }

        void Botones(ToolStripButton boton)
        {
            switch (boton.Text)
            {
                case "&Nuevo":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 3, "nue", 0) == 0)
                    {                        
                        pnlFon.Visible = true;                       
                        pnlNumRq.Visible = true;
                        txtNumRQP.Focus();
                        Origen = 0;

                        VEN_CroPag_EstBot("nuevo");
                    }
                    else
                    {
                        Mensaje();
                    }

                    break;

                case "&Abrir":

                    frmVEN_CroPag_visgen vista = new frmVEN_CroPag_visgen();
                    vista.MdiParent = this.MdiParent;
                    vista.Show();
                    Close();

                    break;

                case "&Guardar":

                    //agregamos o actulizamos el encabezado  de cotizaciones  
                    VEN_CroPag Enc = new VEN_CroPag();

                    Enc.NumMov = Convert.ToInt64(NumMov);
                    Enc.NumCro = txtNumCro.Text;
                    Enc.Rq = Convert.ToInt32(txtNumRq.Text);
                    Enc.Obs = txtObs.Text;
                    Enc.CodUsu = Convert.ToInt16(varglo.CodUsuAct);


                    //recorremos cotizaciones vinculadas
                    foreach (Row row in fgCotVin.Rows)
                    {
                        VEN_CroPag_Cot EncCot = new VEN_CroPag_Cot();

                        if (row.Index > 0)
                        {
                            EncCot.NumMovCot = Convert.ToInt32(row[0]); //
                            EncCot.NumCot = Convert.ToString(row[1].ToString()); //
                            Enc.CroPagCot.Add(EncCot);
                        }
                    }

                    //recorremos el detalle de la cotizacion

                    foreach (Row row in fg.Rows)
                    {
                        VEN_CroPag_Det Det = new VEN_CroPag_Det();

                        if (row.Index > 0 && row.Index < fg.Rows.Count - 1)
                        {
                            Det.Item = Convert.ToInt32(row[0].ToString());
                            Det.FecCuo = Convert.ToDateTime(row[1].ToString());
                            Det.MonCuo = Convert.ToDecimal(row[2]);
                            Det.Obs = Convert.ToString(row[3]);
                            Det.Sit = Convert.ToBoolean(row[4]);

                            //si es null valida en la capa de datos,de lo contrario guarda la fecha seleccionada
                            try
                            {
                                Det.FecPag = row[5].ToString();

                            }
                            catch { }
                            Det.MonPag = Convert.ToDecimal(row[6]);
                            Enc.CroPagDet.Add(Det);
                        }
                    }
                    //Ejecutamos las sentencias
                    dc.VEN_CroPag_Enc_actgua(Enc);

                    NumMov = Enc.NumMov;
                    txtNumCro.Text = Enc.NumCro;

                    VEN_CroPag_EstBot("guardar");

                    break;
                case "&Deshacer":
                    
                    LimpiarControles();
                    pnlFon.Visible = true;
                    pnlFon.Dock = DockStyle.Fill;
                    pnlfgCotMig.Visible = false;
                    txtFecEmi.Text = Convert.ToString(DateTime.Now.Date.ToShortDateString());

                    VEN_CroPag_EstBot("deshacer");

                    break;

                case "&Modificar":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 3, "mod", 0) == 0)
                    {                        

                        gpbOpc.Enabled = true;
                        btnAgrCot.Enabled = true;
                        fgCotVin.Enabled = true;
                        txtPor.Focus();
                        txtObs.ReadOnly = false;                                                
                        fg.Enabled = true;

                        VEN_CroPag_EstBot("modificar");
                    }
                    else
                    {
                        Mensaje();
                    }

                    break;

            }
        }

        public void RecuperarDatos()
        {
            //recupera informacion
            string NumMovCot = "";
            string NumCot = "";

            DataTable Det = new DataTable();
            DataSet CroPag_Enc_rec = new DataSet();

            CroPag_Enc_rec = dc.VEN_CroPag_Enc_rec(NumMov); //nummov creado al guardar

            DataTable Enc = CroPag_Enc_rec.Tables["Enc"];
            //Cronograma de pagos encabezado
            NumMov = Convert.ToInt32(Enc.Rows[0]["NumMov"].ToString());
            txtNumCro.Text = Enc.Rows[0]["NumCro"].ToString();

            txtFecEmi.Text = Enc.Rows[0]["FecEmi"].ToString();
            DateTime fecha = Convert.ToDateTime(Enc.Rows[0]["FecEmi"].ToString());
            txtFecEmi.Text = fecha.ToShortDateString();

            EstDoc = Convert.ToByte(Enc.Rows[0]["EstDoc"].ToString());
            txtNumRq.Text = Enc.Rows[0]["RQ"].ToString();
            //lblTipMon.Text = Enc.Rows[0]["DocCur"].ToString();
            txtObs.Text = Enc.Rows[0]["Obs"].ToString();

            //Encabezado de cotizaciones vinculadas fg
            DataTable EncCotApr = CroPag_Enc_rec.Tables["EncCotApr"];
            
            if (EncCotApr.Rows.Count >= 0)
            {
                foreach (DataRow row in EncCotApr.Rows)
                {
                    fgCotVin.Rows.Add();
                    NumMovCot = Convert.ToString(row["NumMovCot"].ToString()); // numero movimiento
                    NumCot = row["NumCot"].ToString(); //numero cotizacion
                    fgCotVin.Rows[fgCotVin.Rows.Count - 1][0] = row["NumMovCot"].ToString();
                    fgCotVin.Rows[fgCotVin.Rows.Count - 1][1] = row["NumCot"].ToString();
                }
            }
           

            // recuperar Detalle
            Det = CroPag_Enc_rec.Tables["Det"];
            foreach (DataRow row in Det.Rows)
            {
                fg.Rows.Add();
                DateTime date = Convert.ToDateTime(row["FecCuo"]);
                fg.Rows[fg.Rows.Count - 1][0] = (fg.Rows.Count - 1).ToString();
                fg.Rows[fg.Rows.Count - 1][1] = date.ToShortDateString();
                fg.Rows[fg.Rows.Count - 1][2] = row["MonCuo"].ToString();
                fg.Rows[fg.Rows.Count - 1][3] = row["Obs"].ToString();
                fg.Rows[fg.Rows.Count - 1][4] = row["Sit"].ToString();
                fg.Rows[fg.Rows.Count - 1][5] = row["FecPag"].ToString();
                fg.Rows[fg.Rows.Count - 1][6] = row["MonPag"].ToString();
            }

            VEN_CroPag_RecTot();
            VEN_CroPag_SumaTotal();

        }

        private void frmVEN_CroPag_Load(object sender, EventArgs e)
        {
            fgFormatosGenerales(); 
            SoloLectura(); 
           

            ToolTip toolTip1 = new ToolTip();

            
            toolTip1.ShowAlways = true;

            // Set up the ToolTip text for the Button and Checkbox.
            toolTip1.SetToolTip(this.fgCotVin, "Para eliminar una fila utilice la tecla SUPR");
            toolTip1.SetToolTip(this.fg, "Para eliminar una fila utilice la tecla SUPR");
        }

        private void fgFormatosGenerales()
        {
            //Crogograma de pago cotizacion vinculadas 
            fgCotVin.Cols.Count = 2;
            fgCotVin.Rows.Count = 1;

            fgCotVin.Cols[0].DataType = typeof(int);
            fgCotVin.Cols[1].DataType = typeof(string);

            fgCotVin.Cols[0].Caption = "N° MOV";
            fgCotVin.Cols[1].Caption = "N° COT";

            fgCotVin.Cols[0].Visible = false;

            //Crogograma de pago Detalle
            try
            {
                fg.Cols.Count = 7;
                fg.Rows.Count = 1;
                //fg.Rows[0].Height = 30;
                fg.Styles.Normal.WordWrap = true;

                fg.Cols[0].Caption = "Item";
                fg.Cols[1].Caption = "Fecha Prog. de Pago";
                fg.Cols[2].Caption = "Monto Prg.";
                fg.Cols[3].Caption = "Observación";
                fg.Cols[4].Caption = "Situación";
                fg.Cols[5].Caption = "Fecha de Pago";
                fg.Cols[6].Caption = "Monto pagado";

                fg.Cols[0].DataType = typeof(string);
                fg.Cols[1].DataType = typeof(DateTime);
                fg.Cols[2].DataType = typeof(decimal);
                fg.Cols[3].DataType = typeof(string);

                fg.Cols[4].DataType = typeof(bool);
                fg.Cols[5].DataType = typeof(DateTime);
                fg.Cols[6].DataType = typeof(decimal); //solo permito numeros decimales

                for (int i = 0; i < fg.Rows.Count; i++)
                {
                    fg.Cols[5][i] = DBNull.Value;
                }

                fg.Cols[5].Caption = "Fecha de Pago";

                fg.Cols[0].Width = 50;
                fg.Cols[1].Width = 100;
                fg.Cols[2].Width = 80;
                fg.Cols[3].Width = 300;
                fg.Cols[4].Width = 80;
                fg.Cols[5].Width = 80;
                fg.Cols[6].Width = 100;

                fg.Enabled = false;
                //fg.Rows[fg.Rows.Count - 1][4] = 0;
            }
            catch { }

            //Crogograma de pago Encabezado migrar
            fgCotMig.Cols.Count = 5;
            fgCotMig.Rows.Count = 1;

            fgCotMig.Cols[1].Visible = false;

            fgCotMig.Cols[0].DataType = typeof(Boolean);
            fgCotMig.Cols[2].DataType = typeof(string);
            fgCotMig.Cols[3].DataType = typeof(string);
            fgCotMig.Cols[4].DataType = typeof(string);

            fgCotMig.Cols[0].Caption = "Selección";
            fgCotMig.Cols[1].Caption = "N° MOV";
            fgCotMig.Cols[2].Caption = "N° COT";
            fgCotMig.Cols[3].Caption = "Cliente";
            fgCotMig.Cols[4].Caption = "Vendedor";

            fgCotMig.Cols[0].Width = 50;
            fgCotMig.Cols[1].Width = 50;
            fgCotMig.Cols[2].Width = 70;
            fgCotMig.Cols[3].Width = 394;
            fgCotMig.Cols[4].Width = 150;
        }
        private void SoloLectura()
        {
            //no permite modificar las cajas de texto
            txtNumCro.ReadOnly = true;
            txtFecEmi.ReadOnly = true;
            txtNumRq.ReadOnly = true;
            txtTotDocCA.ReadOnly = true;
            txtTotDocOFV.ReadOnly = true;
            txtObs.ReadOnly = true;
            fgCotVin.Enabled = false;
            btnAgrCot.Enabled = false;
            gpbOpc.Enabled = false;
            txtPor.MaxLength = 5;               
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //valida solo la columna
            if (e.Col == 0 )
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }

            if (e.Col == 2 || e.Col == 6)
            {
                //VEN_CroPag_SumaTotal();
            }
        }

        private void txtPor_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPor.Text) == true)
            {
                txtPor.Clear();
                txtMon.Clear();
            }

            else if (Convert.ToDecimal(txtPor.Text) > 100)
            {
                txtPor.Text = "100";
                return;
            }

            else
            {
                decimal total1 = 0;
                decimal.TryParse(txtTotDocCA.Text, out total1);
                decimal total2 = 0;
                decimal.TryParse(txtPor.Text, out total2);
                decimal sumtotal = Math.Round(Convert.ToDecimal(total1 * total2 / 100), 2);
                txtMon.Text = sumtotal.ToString();
            }
        }

        private void txtPor_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar > 100)
            {
                txtPor.Text = "";
            }

            if (char.IsDigit(e.KeyChar)) //permite ingresar solo numericos
            {
                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))//permite ingresar la tecla backspace
            {
                e.Handled = false;
            }
            else if (e.KeyChar == '.' && !txtPor.Text.Contains(".")) //verifica si hay un punto decimal
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                btnAgrGen.Focus();
            }
        }

        private void txtMon_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (Char.IsDigit(e.KeyChar))
            //{
            //    e.Handled = false;
            //}
            //else if (Char.IsControl(e.KeyChar))
            //{
            //    e.Handled = false;
            //}
            //else if (Char.IsSeparator(e.KeyChar))
            //{
            //    e.Handled = false;
            //}
            //else if (e.KeyChar == '.' && !txtMon.Text.Contains(".")) //verifica si hay un punto decimal
            //{
            //    e.Handled = false;
            //}
            //else
            //{
            //    e.Handled = true;
            //}



            if (e.KeyChar == (char)13)
            {
                btnAgrGen.Focus();
            }
        }

        private void txtIntDia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar)) //permite ingresar solo numericos
            {
                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))//permite ingresar la tecla backspace
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                txtNumCuo.Focus();
            }
        }

        private void txtNumCuo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar)) //permite ingresar solo numericos
            {
                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))//permite ingresar la tecla backspace
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            
            if (e.KeyChar == (char)13)
            {
                btnAgrGen.Focus();
            }
        }
       
        private void Validaciones()
        {
            //DateTime FecCuo;
            //double TotAntCuo=0;
            decimal Monto = 0;

            decimal.TryParse(txtMon.Text, out Monto);

            if (Monto == 0)
            {
                MessageBox.Show("El valor indicado en monto no puede ser menor o igual a cero", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (fg.Rows.Count > 1)
            {
                fg.Rows.Remove(fg.Rows[fg.Rows.Count - 1]);
            }

            //validamos si es el tab manual

            if (tabCon.TabPages[0] == tabCon.SelectedTab)
            {
                txtPor.Focus();
                Monto= Convert.ToDecimal(txtMon.Text);
                fg.Rows.Add();
                fg.Rows[fg.Rows.Count - 1][0] = fg.Rows.Count - 1;
                fg.Rows[fg.Rows.Count - 1][1] = dtpFecCuoAnt.Value.Date.ToShortDateString();
                fg.Rows[fg.Rows.Count - 1][2] = Monto;
            }

            txtPor.Clear();
            txtMon.Clear();
            txtIntDia.Clear();
            txtNumCuo.Clear();

            VEN_CroPag_SumaTotal();
            //MontoRestante();
        }

        private void btnAgrGen_Click(object sender, EventArgs e)
        {
            Validaciones();
        }

        

        private void VEN_CroPag_SumaTotal()
        {
            //recorre la columna 2 y suma los valores
            double suma = 0;
            double suma2 = 0;

            int i = 0;
            string d = fg.Rows[fg.Rows.Count - 1][0].ToString();
            if (fg.Rows.Count > 1 && fg.Rows[fg.Rows.Count - 1][0].ToString() == "TOTAL")  fg.RemoveItem(fg.Rows.Count - 1);
         
            for (i = 1; i < fg.Rows.Count; i++)
            {
                suma += Convert.ToDouble(fg.Rows[i][2]);
                suma2 += Convert.ToDouble(fg.Rows[i][6]);
            }

            if (lblMonResCA.Text == "")
            {
                lblMonCA.Visible = false;
                lblTipMonRes.Visible = false;
            }

            fg.Rows.Add();
            fg.Rows[fg.Rows.Count - 1][0] = "TOTAL";
            fg.Rows[fg.Rows.Count - 1][2] = Math.Round(suma,2);
            fg.Rows[fg.Rows.Count - 1][6] = Math.Round(suma2, 2);
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Botones(btnNuevo);
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            Botones(btnAbrir);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Botones(btnModificar);
        }

        private void btnDeshacer_Click(object sender, EventArgs e)
        {
            Botones(btnDeshacer);
        }
        private void LimpiarControles()
        {
            txtNumCro.Clear();
            txtTotDocCA.Clear();
            txtTotDocOFV.Clear();
            txtPor.Clear();
            txtMon.Clear();
            chkIndAnt.Checked = false;
            txtIntDia.Clear();
            txtNumCuo.Clear();
            fg.Rows.Count = 1;
            fgCotVin.Rows.Count = 1;   
            txtObs.Clear();
            lblMonResCA.Text = "";
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            txtPor.Clear();
            txtMon.Clear();
            txtIntDia.Clear();
            txtNumCuo.Clear();
        }

        private void dtpFecIni_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtIntDia.Focus();
            }
        }
        private void btnAgrCot_Click(object sender, EventArgs e)
        {
            OriLla = 1;

            string cadnummovcot = "";

            for (int i = 1; i < fgCotVin.Rows.Count; i++)
            {
                cadnummovcot = cadnummovcot + fgCotVin.Rows[i][0].ToString() + ","; 
            }

            cadnummovcot = cadnummovcot.Substring(0, cadnummovcot.Length - 1);

            CargarCotMig(Convert.ToInt32(txtNumRq.Text), cadnummovcot);           

        }

        private void CargarCotMig(Int32 rq, string cadnummovcot)
        {
            DataTable dt = new DataTable();

            dt = dc.VEN_CroPag_CotMigRQ(rq, cadnummovcot);

            //valida si hay datos
            if (dt.Rows.Count > 0)
            {
                fgCotMig.Rows.Count = 1;

                foreach (DataRow row in dt.Rows)
                {
                    fgCotMig.Rows.Add();
                    fgCotMig.Rows[fgCotMig.Rows.Count - 1][1] = row["NumMov"].ToString();
                    fgCotMig.Rows[fgCotMig.Rows.Count - 1][2] = row["N° COT"].ToString();
                    fgCotMig.Rows[fgCotMig.Rows.Count - 1][3] = row["Cliente"].ToString();
                    fgCotMig.Rows[fgCotMig.Rows.Count - 1][4] = row["Vendedor"].ToString();
                }

                pnlfgCotMig.Visible = true;
                pnlFon.Visible = true;
                pnlFon.Dock = DockStyle.None;
                pnlNumRq.Visible = false;
            }
            else if(dt.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron Cotizaciones, revise que no se encuentren todas ya asignadas", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNumRQP.Focus();
                return;
            }
            
        }
        private void btnCanRq_Click(object sender, EventArgs e)
        {
            txtNumRQP.Clear();

            if (Origen == 1 && txtNumCro.Text == "") //por fuera boton nuevo cronograma
            {
                this.Close();
            }
            else if (Origen == 0 && txtNumCro.Text == "") //por dentro boton nuevo  y cancelar
            {
                pnlNumRq.Visible = false;
                VEN_CroPag_EstBot("deshacer");
            }
            else if (Origen == 0 && txtNumCro.Text != "")
            {
                pnlNumRq.Visible = false;
                pnlFon.Visible = false;
                VEN_CroPag_EstBot("deshacer");
            }
        }

        private void txtNumRQP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar)) //permite ingresar solo numericos
            {
                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))//permite ingresar la tecla backspace
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

            if (e.KeyChar == (char)13)
            {
                btnAceRq.Focus();
            }
        }

        private void btnAceRq_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(txtNumRQP.Text) == true) // validamos si esta vació
            {
                MessageBox.Show("Ingrese un numero de Rq", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNumRQP.Focus();
                return;
            }
            else
            {
                CargarCotMig(Convert.ToInt32(txtNumRQP.Text),"");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (OriLla == 1)
            {
                pnlNumRq.Visible = false;
                pnlFon.Visible = false;
            }
            else
            {
                pnlNumRq.Visible = true;                
                pnlFon.Visible = true;
            }

            pnlfgCotMig.Visible = false;

            //if (btnGuardar.Enabled == true && btnDeshacer.Enabled == true)
            //{
            //    pnlNumRq.Visible = false;
            //    fgCotMig.Rows.Count = 1;
            //    pnlFon.Visible = false;
            //    return;
            //}
            //else
            //{
            //    pnlfgCotMig.Visible = false;
            //    pnlNumRq.Visible = true;
            //    fgCotMig.Rows.Count = 1;
            //}

            OriLla = 0;       
        }

        private void fgCotMig_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string numCot = "";
            //int nummovcot = 0;
            //decimal totalAc = 0;

            if (OriLla == 0) //Si es nuevo se limpia el grid de cotizaciones
            {
                fgCotVin.Rows.Count = 1;                
            }            

            //valida si se actuliza o se crea uno nuevo con el nummov existente
            if (txtNumCro.Text == "")
            {
                NumMov = 0;
            }

            int i;
            bool seleccionar = false;

            //valida solo si esta seleccionado
            for (i = 1; i < fgCotMig.Rows.Count; i++)
            {
                if (Convert.ToBoolean(fgCotMig.Rows[i][0]) == true)
                {
                    seleccionar = true;
                    break;
                }
            }

            // valida si no esta seleccionado
            if (seleccionar == false)
            {
                MessageBox.Show("Debe elegir un número de Orden", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            numCot = fgCotMig.Rows[i][1].ToString();

            //valida si existe el numero de movimiento de cotizacion
            for (int v = 0; v < fgCotVin.Rows.Count; v++)
            {
                if (Convert.ToString(fgCotVin.Rows[v][0]) == numCot)
                {
                    MessageBox.Show("La cotización selecionada ya esta incluida", "Mensaje del sistma", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            //añadimos la nueva fila con datos

            fgCotVin.Rows.Add();
            fgCotVin.Rows[fgCotVin.Rows.Count - 1][0] = numCot;
            fgCotVin.Rows[fgCotVin.Rows.Count - 1][1] = fgCotMig.Rows[i][2].ToString();


            VEN_CroPag_RecTot();



            if (OriLla == 0)
            {
                txtNumRq.Text = txtNumRQP.Text;
            }               

            pnlFon.Visible = false;
            pnlfgCotMig.Visible = false;
            btnAgrCot.Enabled = true;
            gpbOpc.Enabled = true;
            fgCotVin.Enabled = true;
            fg.Enabled = true;
            txtObs.ReadOnly = false;

            fgCotMig.Rows.Count = 1;
            if (OriLla == 0) fg.Rows.Count = 1;
            txtNumCro.Clear();
            //VEN_CroPag_SumaTotal();
            txtFecEmi.Text = Convert.ToString(DateTime.Now.Date.ToShortDateString());
            VEN_CroPag_EstBot("nuevo");

            OriLla = 0;
        }

        void VEN_CroPag_RecTot()
        {
            txtTotDocCA.Text = "0";
            txtTotDocOFV.Text = "0";
            txtTotDocODV.Text = "0";

            //crear un documento nuevo con rq
            //DataSet CroPag_Enc_rec = new DataSet();
            DataTable VEN_CroPag_Tot = new DataTable();

            for (int f = 1; f < fgCotVin.Rows.Count; f++)
            {
                VEN_CroPag_Tot = dc.VEN_CroPag_Tot_CA_OFV_ODV(Convert.ToString(fgCotVin.Rows[f][0]));

                txtTotDocCA.Text = (Convert.ToDecimal(txtTotDocCA.Text) + Convert.ToDecimal(VEN_CroPag_Tot.Rows[0][0])).ToString();
                txtTotDocOFV.Text = (Convert.ToDecimal(txtTotDocOFV.Text) + Convert.ToDecimal(VEN_CroPag_Tot.Rows[0][1])).ToString();
                txtTotDocODV.Text = (Convert.ToDecimal(txtTotDocODV.Text) + Convert.ToDecimal(VEN_CroPag_Tot.Rows[0][2])).ToString();

            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Botones(btnGuardar);
        }

        private void fgCotVin_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void fg_BeforeEdit(object sender, RowColEventArgs e)
        {
            if (e.Row == fg.Rows.Count -1)
            {
                e.Cancel = true;
            }

            if (e.Col == 2 || e.Col == 6)
            {
                //VEN_CroPag_SumaTotal();
            }
           
        }

        private void frmVEN_CroPag_Resize(object sender, EventArgs e)
        {
            pnlFon.Height = this.Height; pnlFon.Width = this.Width;
            pnlFon.Top = 0; pnlFon.Left = 0;

            grpObs.Top = this.Height - 150;
        }

        private void fg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (fg.Row != fg.Rows.Count - 1)
                {
                    fg.RemoveItem(fg.Row);
                    //VEN_CroPag_SumaTotal();
                }
            }
        }

        private void fgCotVin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (fgCotVin.Rows.Count > 2)
                {
                    fgCotVin.RemoveItem(fgCotVin.Row);
                    VEN_CroPag_RecTot();
                }
                else
                {
                    MessageBox.Show("La lista no puede quedar vacia.","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
        }

        private void dtpFecIni_KeyPress_1(object sender, KeyPressEventArgs e)
        {

        }

        private void dtpFecCuoAnt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtMon.Focus();
            }
        }
    }
}
