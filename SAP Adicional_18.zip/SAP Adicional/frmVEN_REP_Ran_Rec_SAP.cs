﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmVEN_REP_Ran_Rec_SAP : Form
    {
        NConsultas nc = new NConsultas();
        public frmVEN_REP_Ran_Rec_SAP()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            if (dtpInicio.Value.Date > dtpFinal.Value.Date)
            {
                MessageBox.Show("La fecha inicial no puede ser mayor a la fecha final", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dtpInicio.Focus();
                return;
            }
            if (dtpFinal.Value.Date > DateTime.Now.Date)
            {
                MessageBox.Show("La fecha final no puede ser mayor a la fecha actual", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dtpFinal.Focus();
                return;
            }

            DataTable dt = new DataTable();
            dt = nc.RANKING_DE_RECOMENDADORES_POR_PERIODOS(Convert.ToDateTime(dtpInicio.Value.Date), Convert.ToDateTime(dtpFinal.Value.Date));
            if (dt.Rows.Count != 0)
            {
                fg.DataSource = dt;
            }
            else
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dtpInicio.Focus();
                return;
            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            ExportarExcel();
        }
        private void ExportarExcel()
        {

            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                FileFlags flags = FileFlags.IncludeFixedCells;
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch { }
        }

        private void FormatoColumnas()
        {

            for (int i = 6; i < fg.Cols.Count; i ++)
            {
                fg.Cols[i].Format = "0.00";
            }
           
            fg.Cols["COD. RECOMENDADOR"].Width = 120;
            fg.Cols["NOMBRE RECOMENDADOR"].Width = 150;
            fg.Cols["Profesión"].Width = 50;
            fg.Cols["Año"].Width = 30;
            fg.Cols["N° RQ"].Width = 40;
            fg.Cols["N° ORV"].Width = 50;
            fg.Cols["Enero"].Width = 40;
            fg.Cols["Febrero"].Width = 45;
            fg.Cols["Marzo"].Width = 35;
            fg.Cols["Abril"].Width = 35;
            fg.Cols["Mayo"].Width = 35;
            fg.Cols["Junio"].Width = 35;
            fg.Cols["Julio"].Width = 35;
            fg.Cols["Agosto"].Width = 50;
            fg.Cols["Setiembre"].Width = 50;
            fg.Cols["Octubre"].Width = 50;
            fg.Cols["Noviembre"].Width = 55;
            fg.Cols["Diciembre"].Width = 55;
        }
        
        private void FormatoGeneral()
        {
            fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;
            fg.AllowFreezing = AllowFreezingEnum.Both;
            fg.Cols.Frozen = 2;
        }

        private void fg_AfterDataRefresh(object sender, System.ComponentModel.ListChangedEventArgs e)
        {
            FormatoColumnas();
            FormatoGeneral();
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }
    }
}
