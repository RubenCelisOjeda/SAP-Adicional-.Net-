﻿namespace SAP_Adicional
{
    partial class frmPri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.wdasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dsaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tmrIna = new System.Windows.Forms.Timer(this.components);
            this.tmrMsg = new System.Windows.Forms.Timer(this.components);
            this.stpPri = new System.Windows.Forms.StatusStrip();
            this.tlsLblMen = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.stpPri.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wdasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1311, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // wdasToolStripMenuItem
            // 
            this.wdasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dsaToolStripMenuItem});
            this.wdasToolStripMenuItem.Name = "wdasToolStripMenuItem";
            this.wdasToolStripMenuItem.Size = new System.Drawing.Size(12, 20);
            // 
            // dsaToolStripMenuItem
            // 
            this.dsaToolStripMenuItem.Name = "dsaToolStripMenuItem";
            this.dsaToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // tmrIna
            // 
            this.tmrIna.Interval = 1000;
            this.tmrIna.Tick += new System.EventHandler(this.tmrIna_Tick);
            // 
            // tmrMsg
            // 
            this.tmrMsg.Interval = 6000;
            this.tmrMsg.Tick += new System.EventHandler(this.tmrMsg_Tick);
            // 
            // stpPri
            // 
            this.stpPri.BackColor = System.Drawing.Color.White;
            this.stpPri.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlsLblMen});
            this.stpPri.Location = new System.Drawing.Point(0, 704);
            this.stpPri.Name = "stpPri";
            this.stpPri.Size = new System.Drawing.Size(1311, 22);
            this.stpPri.TabIndex = 5;
            this.stpPri.Text = "statusStrip1";
            // 
            // tlsLblMen
            // 
            this.tlsLblMen.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlsLblMen.ForeColor = System.Drawing.Color.White;
            this.tlsLblMen.Name = "tlsLblMen";
            this.tlsLblMen.Size = new System.Drawing.Size(0, 17);
            // 
            // frmPri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1311, 726);
            this.Controls.Add(this.stpPri);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPri";
            this.Text = "SAP Adicional";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPri_FormClosing);
            this.Load += new System.EventHandler(this.frmPri_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmPri_KeyUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.stpPri.ResumeLayout(false);
            this.stpPri.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem wdasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dsaToolStripMenuItem;
        internal System.Windows.Forms.Timer tmrIna;
        public System.Windows.Forms.Timer tmrMsg;
        public System.Windows.Forms.StatusStrip stpPri;
        public System.Windows.Forms.ToolStripStatusLabel tlsLblMen;
    }
}