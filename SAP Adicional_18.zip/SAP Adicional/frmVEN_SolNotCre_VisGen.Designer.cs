﻿namespace SAP_Adicional
{
    partial class frmVEN_SolNotCre_VisGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNueSol = new System.Windows.Forms.Button();
            this.chkMosTod = new System.Windows.Forms.CheckBox();
            this.btnMosAct = new System.Windows.Forms.Button();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNueSol
            // 
            this.btnNueSol.Location = new System.Drawing.Point(133, 16);
            this.btnNueSol.Name = "btnNueSol";
            this.btnNueSol.Size = new System.Drawing.Size(115, 22);
            this.btnNueSol.TabIndex = 1;
            this.btnNueSol.Text = "Nueva Solicitud";
            this.btnNueSol.UseVisualStyleBackColor = true;
            this.btnNueSol.Click += new System.EventHandler(this.btnNueSol_Click);
            // 
            // chkMosTod
            // 
            this.chkMosTod.AutoSize = true;
            this.chkMosTod.Location = new System.Drawing.Point(254, 21);
            this.chkMosTod.Name = "chkMosTod";
            this.chkMosTod.Size = new System.Drawing.Size(88, 17);
            this.chkMosTod.TabIndex = 6;
            this.chkMosTod.Text = "Mostrar todo";
            this.chkMosTod.UseVisualStyleBackColor = true;
            // 
            // btnMosAct
            // 
            this.btnMosAct.Location = new System.Drawing.Point(12, 16);
            this.btnMosAct.Name = "btnMosAct";
            this.btnMosAct.Size = new System.Drawing.Size(115, 22);
            this.btnMosAct.TabIndex = 7;
            this.btnMosAct.Text = "Mostrar/Actualizar";
            this.btnMosAct.UseVisualStyleBackColor = true;
            this.btnMosAct.Click += new System.EventHandler(this.btnMosAct_Click);
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(12, 58);
            this.fg.Name = "fg";
            this.fg.Rows.Count = 1;
            this.fg.Rows.DefaultSize = 19;
            this.fg.Size = new System.Drawing.Size(1329, 642);
            this.fg.TabIndex = 8;
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            this.fg.DoubleClick += new System.EventHandler(this.fg_DoubleClick);
            // 
            // frmVEN_SolNotCre_VisGen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1353, 712);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.btnMosAct);
            this.Controls.Add(this.chkMosTod);
            this.Controls.Add(this.btnNueSol);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_SolNotCre_VisGen";
            this.Text = "Solicitu de Nota de Credito - Vista General";
            this.Load += new System.EventHandler(this.frmOPE_Pro_VisGen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNueSol;
        private System.Windows.Forms.CheckBox chkMosTod;
        private System.Windows.Forms.Button btnMosAct;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
    }
}