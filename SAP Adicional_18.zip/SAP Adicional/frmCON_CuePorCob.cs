﻿
using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;
using Entidades.CON_CuePorCob;

namespace SAP_Adicional
{
    public partial class frmCON_CuePorCob : Form
    {
        VarGlo varglo = VarGlo.Instance();
        NCON_CuePorCob nc = new NCON_CuePorCob();
        DataTable dtRec_CuePorCob;
        CellStyle styCat, stySeg, styEst;
        string cod;

        public frmCON_CuePorCob()
        {
            InitializeComponent();
        }

        private void frmCON_CuePorCob_Load(object sender, EventArgs e)
        {
            fg.SelectionMode = SelectionModeEnum.Row; // tipo de seleccion
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                chkMosTod.Focus();
            }
        }

        private void chkMosTod_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            dtRec_CuePorCob = new DataTable();

            if (dtpInicio.Value.Date > dtpFinal.Value.Date)
            {
                MessageBox.Show("La fecha inicial no puede ser mayor a la fecha final","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                dtpInicio.Focus();
                return;
            }

            if (dtpFinal.Value.Date > DateTime.Now.Date)
            {
                MessageBox.Show("La fecha final no puede ser mayor a la fecha actual", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dtpFinal.Focus();
                return;
            }

            dtRec_CuePorCob = nc.CON_CuePorCob(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text), chkMosTod.Checked ? 1 : 0);
            if (dtRec_CuePorCob.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del Sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dtpInicio.Focus();
                return;
            }
            else
            {
                fg.DataSource = dtRec_CuePorCob;
                DatosEncargado();
               
            } 
        }

        public void FormatoGeneral()
        {
            //fg.AutoSizeCols();
            fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;
            fg.AllowFreezing = AllowFreezingEnum.Both;

            CellStyle s = fg.Styles[CellStyleEnum.Subtotal0];
            s.BackColor = Color.Yellow;
            s.ForeColor = Color.Blue;
            fg.Cols.Frozen = 2;

            //tamaño de columnas
            fg.Cols["Correlativo"].Width = 55;
            fg.Cols["Tipo"].Width = 30;
            fg.Cols["Codcat"].Visible = false;
            fg.Cols["Codest"].Visible = false;
            fg.Cols["Codseg"].Visible = false;
            fg.Cols["Encargado"].Width = 120;
            fg.Cols["Nombre Venta"].Width = 280;
            fg.Cols["Cliente"].Width = 250;
            fg.Cols["Vendedor"].Width = 180;
            fg.Cols["Categoria"].Width = 160;
            fg.Cols["Estados"].Width = 160;
            fg.Cols["Seguimiento"].Width = 160;
            fg.Cols["obs"].Width = 315;
            fg.Cols["obs2"].Width = 315;
            fg.Cols["Cor1"].Width = 50;
            fg.Cols["Cor2"].Width = 50;
            fg.Cols["Cor3"].Width = 50;

            //tamaño de columnas
            fg.Cols["Importe del documento"].Style.Format = "0.00";
            fg.Cols["Importe Pagado"].Style.Format = "0.00";
            fg.Cols["Saldo"].Style.Format = "0.00";

        }

        public void Suma()
        {
            fg.Subtotal(AggregateEnum.Sum, 0,-1, 11, "Totales");
            fg.Subtotal(AggregateEnum.Sum, 0, -1, 12, "Totales");
            fg.Subtotal(AggregateEnum.Sum, 0, -1, 13, "Totales");
           
            fg.Cols[0][1] = "Totales";
            fg.Rows[1].Style.BackColor = Color.Yellow;
            fg.Rows[1].Style.ForeColor = Color.Blue;
            fg.Rows[1].Style.Font = new Font("Tahoma", 8f, FontStyle.Bold);
        }

        private void DatosCategoriaSeg()
        {
            //llena de datos la columna de seguimiento
            DataTable dtRecCatSeg = new DataTable();

            if (cod == "")
            {
                GuardarDatos();
                return;
            }

            dtRecCatSeg = nc.CON_CuePorCob_CatSeg(Convert.ToInt16(cod));

            ListDictionary lisSeg = new ListDictionary();

            for (int i = 0; i <= dtRecCatSeg.Rows.Count - 1; i++)
            {
                string key = dtRecCatSeg.Rows[i][1].ToString();
                string value = dtRecCatSeg.Rows[i][0].ToString();
                lisSeg.Add(key, value);
            }

            fg.Cols["Seguimiento"].AllowEditing = true;
            stySeg = fg.Styles.Add("Seguimiento");
            stySeg.DataMap = lisSeg;
        }

        
        private void DatosCategoriaEst()
        {
            //llena de datos la columna de estado
            DataTable dtRecCatEst = new DataTable();

            if (cod == "")
            {
                GuardarDatos();
                return;
            }
           
            dtRecCatEst = nc.CON_CuePorCob_CatEst(Convert.ToInt16(cod)); //
            ListDictionary  lisEst = new ListDictionary();

            for (int i = 0; i <= dtRecCatEst.Rows.Count - 1; i++)
            {
                string key = dtRecCatEst.Rows[i][1].ToString();
                string value = dtRecCatEst.Rows[i][0].ToString();
                lisEst.Add(key, value);
            }

            fg.Cols["Estados"].AllowEditing = true;
            styEst = fg.Styles.Add("Estados");
            styEst.DataMap = lisEst;
            //styEst.ComboList= "ruben|este|todo";


        }
        private void DatosCategoria()
        {
            //llena de datos la columna de categoria
            DataTable dtRecCat_ = new DataTable();
            dtRecCat_ = nc.CON_CuePorCob_cat();

            ListDictionary lisCat = new ListDictionary();

            for (int i = 0; i <= dtRecCat_.Rows.Count -1; i++)
            {
                string key = dtRecCat_.Rows[i][0].ToString();
                string value = dtRecCat_.Rows[i][1].ToString();
                lisCat.Add(key, value);
            }

            fg.Cols["Categoria"].AllowEditing = true;
            styCat = fg.Styles.Add("Categoria");
            styCat.DataMap = lisCat;
            fg.Cols["Categoria"].Style = styCat;
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //if (e.Col == 23 || e.Col == 24)
            //{
            //    if (e.KeyChar != 3 && e.KeyChar != 27)
            //    {
            //        e.Handled = false; //habilita el editar columna 23 y 24
            //    }
            //}
            //else
            //{
            //    e.Handled = true;
            //}
        }

        private void fg_AfterEdit(object sender, RowColEventArgs e)
        {
            try
            {
                if (e.Col == 14 || e.Col == 16 || e.Col == 18)
                {
                    // pasa el valor a la siguiente columna
                    cod = Convert.ToString(fg[e.Row, e.Col]);
                    fg[e.Row, e.Col + 1] = cod;

                    if (e.Col == 14)
                    {
                        if (fg[e.Row, 15].ToString() == "0") //limpia las demas columnas
                        {
                            fg[e.Row, 16] = "";
                            fg[e.Row, 17] = "";
                            fg[e.Row, 18] = "";
                            fg[e.Row, 19] = "";
                        }
                        else
                        {
                            fg[e.Row, 16] = "";
                            fg[e.Row, 17] = "";
                            fg[e.Row, 18] = "";
                            fg[e.Row, 19] = "";
                        }
                    }
                    if (e.Col == 16)
                    {
                        if (fg[e.Row, 16].ToString() == "") //valida la columna si esta vacia
                        {
                            fg[e.Row, 17] = "";
                            fg[e.Row, 18] = "";
                            fg[e.Row, 19] = "";
                        }
                        else
                        {
                            fg[e.Row, 18] = "";
                            fg[e.Row, 19] = "";
                        }
                    }
                }
            }
            catch { }
            
            GuardarDatos();
        }
        void GuardarDatos()
        {
            CON_CuePorCob_Col_actval Enc = new CON_CuePorCob_Col_actval();
            Enc.DocNum = Convert.ToInt32(fg[fg.Row, 0]);
            Enc.Tipo = Convert.ToString(fg[fg.Row, 1]);
            Enc.Enc = Convert.ToString(fg[fg.Row, 9]);

            var codcat = Convert.ToString(fg[fg.Row, 15]); //validamos si es valor es null
            if (string.IsNullOrEmpty(codcat.ToString())) codcat = "0";
            Enc.CodCat = Convert.ToInt16(codcat);

            var codest = Convert.ToString(fg[fg.Row, 17]);
            if (string.IsNullOrEmpty(codest.ToString())) codest = "0";
            Enc.CodEst = Convert.ToInt16(codest);

            var codseg = Convert.ToString(fg[fg.Row, 19]);
            if (string.IsNullOrEmpty(codseg.ToString())) codseg = "0";
            Enc.CodSeg = Convert.ToInt16(codseg);

            Enc.Cor1 = Convert.ToBoolean(fg[fg.Row, 20]);
            Enc.Cor2 = Convert.ToBoolean(fg[fg.Row, 21]);
            Enc.Cor3 = Convert.ToBoolean(fg[fg.Row, 22]);
            Enc.Obs = Convert.ToString(fg[fg.Row, 23]);
            Enc.CodUsu = Convert.ToInt16(varglo.CodUsuAct);
            Enc.FicXTrazzo = Convert.ToString(fg[fg.Row, 2]);
            Enc.FecXTrazzo = Convert.ToDateTime(fg[fg.Row, 3]);
            Enc.Ven = Convert.ToString(fg[fg.Row, 8]);
            Enc.Obs2 = Convert.ToString(fg[fg.Row, 24]);

            nc.CON_CuePorCob_Col_actval(Enc); // //guardando datos
        }

        private void fg_Click(object sender, EventArgs e)
        {
            try
            {
                if (fg.Col == 14) //valida columna
                {
                    DatosCategoria(); //llama al metodo

                    if (styCat.DataMap.Count > 0) //valida si hay datos
                    {

                        fg.SetCellStyle(fg.Row, 14, styCat); //llena la columna
                    }
                }

                if (fg.Col == 16)
                {
                    if (fg[fg.Row, 15].ToString() != "")
                    {
                        cod = fg[fg.Row, 15].ToString(); //toma el codigo anterior para llenar la columna seleccionada
                    }

                    DatosCategoriaEst();

                    if (styEst.DataMap.Count > 0)
                    {
                        fg.SetCellStyle(fg.Row, 16, styEst);
                    }
                }

                if (fg.Col == 18)
                {
                    if (fg[fg.Row, 17].ToString() != "")
                    {
                        cod = fg[fg.Row, 17].ToString();
                    }

                    DatosCategoriaSeg();

                    if (stySeg.DataMap.Count > 0)
                    {
                        fg.SetCellStyle(fg.Row, 18, stySeg);
                    }
                }
            }
            catch { }
        }

        private void fg_AfterFilter(object sender, EventArgs e)
        {
            Suma();
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            fg.Cols[0].Style.DataType = typeof(string);
            FormatoGeneral();
            Suma();
        }

        private void DatosEncargado()
        {
            CellStyle style;
            DataTable dtRecEnc = new DataTable();
            dtRecEnc = nc.CON_CuePorCob_Enc();
            ListDictionary list = new ListDictionary();

            for (int i = 0; i <= dtRecEnc.Rows.Count - 1; i++)
            {
                list.Add(dtRecEnc.Rows[i][0], dtRecEnc.Rows[i][0]);
            }

            style = fg.Styles.Add("Encargado");
            style.DataMap = list;
            fg.Cols["Encargado"].AllowEditing = true;
            fg.Cols["Encargado"].Style = style;
        }


        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);

            }
            catch { }

        }
    }
    
}
