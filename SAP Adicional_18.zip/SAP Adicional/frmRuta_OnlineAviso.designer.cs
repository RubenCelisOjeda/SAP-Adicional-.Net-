﻿namespace SAP_Adicional
{
    partial class frmRuta_OnlineAviso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCerAvi = new System.Windows.Forms.Button();
            this.fgRutOnlAvi = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fgRutOnlAvi)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCerAvi
            // 
            this.btnCerAvi.Location = new System.Drawing.Point(462, 286);
            this.btnCerAvi.Name = "btnCerAvi";
            this.btnCerAvi.Size = new System.Drawing.Size(75, 23);
            this.btnCerAvi.TabIndex = 1;
            this.btnCerAvi.Text = "Cerrar";
            this.btnCerAvi.UseVisualStyleBackColor = true;
            this.btnCerAvi.Click += new System.EventHandler(this.btnCerAvi_Click);
            // 
            // fgRutOnlAvi
            // 
            this.fgRutOnlAvi.AllowFiltering = true;
            this.fgRutOnlAvi.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgRutOnlAvi.Location = new System.Drawing.Point(2, 0);
            this.fgRutOnlAvi.Name = "fgRutOnlAvi";
            this.fgRutOnlAvi.Rows.DefaultSize = 19;
            this.fgRutOnlAvi.Size = new System.Drawing.Size(535, 280);
            this.fgRutOnlAvi.TabIndex = 0;
            this.fgRutOnlAvi.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgRutOnlAvi_KeyPressEdit);
            // 
            // frmRuta_OnlineAviso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 312);
            this.Controls.Add(this.btnCerAvi);
            this.Controls.Add(this.fgRutOnlAvi);
            this.Name = "frmRuta_OnlineAviso";
            this.Text = "Ruta Online - Aviso";
            ((System.ComponentModel.ISupportInitialize)(this.fgRutOnlAvi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Button btnCerAvi;
        public C1.Win.C1FlexGrid.C1FlexGrid fgRutOnlAvi;
    }
}