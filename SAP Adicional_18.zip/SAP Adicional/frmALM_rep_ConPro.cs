﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_rep_ConPro : Form
    {
        NConsultas nc = new NConsultas();
        
        public frmALM_rep_ConPro()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtpInicio.Checked==true && dtpFinal.Checked==true)
                {
                    this.fg.DataSource = nc.TRZ_ALM_ConPro(Convert.ToDateTime(dtpInicio.Text),Convert.ToDateTime(dtpFinal.Text));
                    FormatoGeneral();
                }               
            }
            catch
            {
                DataTable dt2 = (DataTable)fg.DataSource;
                dt2.Clear();         
            }
        }

        public void FormatoGeneral()
        {
            fg.Cols.Frozen = 3;

            fg.Cols[0].Width = 90;
            fg.Cols[1].Width = 375;
            fg.Cols[2].Width = 280;

            for (int i = 3; i < fg.Cols.Count; i++)
            {
                fg.Cols[i].Width = 70;
                fg.Cols[i].Format = "0.00";
            }

            fg.AllowFreezing = AllowFreezingEnum.Both;

            CellStyle s = fg.Styles[CellStyleEnum.Frozen];            
            s.ForeColor = Color.Blue;
        }

        private void frmALM_rep_ConPro_Load(object sender, EventArgs e)
        {

        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar !=3 && e.KeyChar !=27)
            {
                e.Handled = true;
            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch
            {

            }
        }
    }
}
