﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Entidades.Ruta_Item;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmRutaDocRel : Form, Ruta_ItemDocRel
    {
        private NRuta_Item rutIte = new NRuta_Item();
        private Int16 index = 0;
        private VarGlo varglo = VarGlo.Instance();
        private NConsultas nc = new NConsultas();
        private string _mensaje = "";
       
        public frmRutaDocRel()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private void frmRutaDocRel_Load(object sender, EventArgs e)
        {
            this.RutaDocRel_FormatoColumnas();
            this.RutaDocRel_FormatoGeneral();
            this.RutaDocRel_RutDocVin();
            this.txtNumMov.ReadOnly = true;
            this.txtNumMov.ReadOnly = true;
        }
        private void RutaDocRel_FormatoGeneral()
        {
            try
            {
                this.fgRutRel.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
                this.fgRutRel.VisualStyle = VisualStyle.Office2010Silver;
                this.fgRutRel.Styles.Alternate.BackColor = Color.LightBlue;
                this.fgRutRel.Styles.Highlight.BackColor = Color.Blue;
                this.fgRutRel.Styles.Highlight.ForeColor = Color.White;
                this.fgRutRel.AllowFreezing = AllowFreezingEnum.Both;
            }
            catch { }
        }
        private void RutaDocRel_FormatoColumnas()
        {
            this.fgRutRel.Cols.Count = 3;
            this.fgRutRel.Rows.Count = 1;

            //nombre de columnas
            this.fgRutRel.Cols[0].Caption = "CodTipDoc";
            this.fgRutRel.Cols[1].Caption = "TipDoc";
            this.fgRutRel.Cols[2].Caption = "Num Doc";

            //tamaño de columnas
            this.fgRutRel.Cols[0].Width = 60;
            this.fgRutRel.Cols[1].Width = 150;
            this.fgRutRel.Cols[2].Width = 70;
        }
        private void RutaDocRel_RutDocVin()
        {
            DataTable dtRecDocVin = new DataTable();
            dtRecDocVin = rutIte.Ruta_Item_RecDocRel(Convert.ToInt32(this.txtNumMov.Text));

            if (dtRecDocVin.Rows.Count > 0)
            {
                for (int i=0; i < dtRecDocVin.Rows.Count; i++)
                {
                    this.fgRutRel.Rows.Add();
                    this.fgRutRel.Rows[fgRutRel.Rows.Count - 1][0] = dtRecDocVin.Rows[i]["TipDoc"].ToString();
                    this.fgRutRel.Rows[fgRutRel.Rows.Count - 1][1] = dtRecDocVin.Rows[i]["Doc"].ToString();
                    this.fgRutRel.Rows[fgRutRel.Rows.Count - 1][2] = dtRecDocVin.Rows[i]["NumDoc"].ToString();
                }
            }
            else
            {
                return;
            }
        }

        private void btnSelDoc_Click(object sender, EventArgs e)
        {
            int rq = 0;
            int.TryParse(this.lblRq.Text, out rq);
            int NumRq = 0;
            string vista = "";
            string procedimiento = "";
            string FecDoc = "";
           
            if (this.cboTipDoc.SelectedIndex == -1) //valida si hay item
            {
                _mensaje = "Debe elegir un tipo de documento";
                this.ALM_RutaDocRel_MosMsgStrip(_mensaje,Color.DodgerBlue);
                cboTipDoc.Focus();
                return;
            }
            else
            {
                index = Convert.ToInt16(this.cboTipDoc.SelectedIndex + 1); //indicie del documento(combobox)

                //valida  el procedimiento segun el indice seleccionado
                switch (index)
                {
                    case 1:
                        vista = "Entrega";
                        procedimiento = "Rut_SelDocEnt";
                        NumRq = rq;
                        break;

                    case 2:
                        vista = "Solicitud de traslado";
                        procedimiento = "Rut_SelDocSolTra";
                        NumRq = rq;
                        FecDoc = this.lblFecRut.Text;
                        break;

                    case 3:
                        vista = "Traslado";
                        procedimiento = "Rut_SelDocTra";
                        NumRq = rq;
                        FecDoc = this.lblFecRut.Text;
                        break;

                    case 4:
                        vista = "Herramientas";
                        procedimiento = "Rut_SelDocHerMov";
                        FecDoc = this.lblFecRut.Text;
                        break;
                }

                DataTable dtRutIteFil = new DataTable();
                dtRutIteFil = rutIte.Ruta_Item_Filtros(vista, procedimiento, NumRq.ToString(), FecDoc);

                if (dtRutIteFil.Rows.Count > 1)
                {
                    frmConsulta_Varios frmConVar = new frmConsulta_Varios();
                    frmConVar.Formulario = 2;
                    frmConVar.Text = vista;
                    frmConVar.Vista = vista;
                    frmConVar.dg.DataSource = dtRutIteFil;
                    frmConVar.Ruta_ItemDocRel_Rec = this;
                    frmConVar.ShowDialog();
                }
                else if (dtRutIteFil.Rows.Count == 1) 
                {
                    DataRow row = dtRutIteFil.Rows[0];

                    switch (vista)
                    {
                        case "Entrega":
                        case "Solicitud de traslado":
                        case "Traslado":
                        case "Herramientas":
                            this.txtNumDoc.Text = row["DocNum"].ToString();
                            this.btnAgr.Focus();
                            break;

                        default:
                            break;
                    }
                }
                else if (dtRutIteFil.Rows.Count == 0)
                {
                    varglo.Elegi = false;
                    _mensaje = "No se encontraron registros";
                    this.ALM_RutaDocRel_MosMsgStrip(_mensaje, Color.Red);
                    this.txtNumDoc.Text = "";
                }
            }
        }

        public void recdat_Ruta_Item_DocRel(string NumDoc)
        {
            this.txtNumDoc.Text = NumDoc;
        }

        private void fgRutRel_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 | e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnAgr_Click(object sender, EventArgs e)
        {
            if (this.cboTipDoc.SelectedIndex == -1) //valida si hay item
            {
                _mensaje = "Debe elegir un tipo de documento";
                this.ALM_RutaDocRel_MosMsgStrip(_mensaje, Color.DodgerBlue);
                this.cboTipDoc.Focus();
                return;
            }

            if (string.IsNullOrEmpty(txtNumDoc.Text))
            {
                _mensaje = "Debe elegir un documento a vincular";
                this.ALM_RutaDocRel_MosMsgStrip(_mensaje, Color.DodgerBlue);
                this.btnSelDoc.Focus();
                return;
            }

            //agregamos el nuevo documento
            int index = this.cboTipDoc.SelectedIndex + 1;

            this.fgRutRel.Rows.Add();
            this.fgRutRel.Rows[fgRutRel.Rows.Count - 1][0] = index;
            this.fgRutRel.Rows[fgRutRel.Rows.Count - 1][1] = cboTipDoc.Text.ToString().Remove(0,4); //remuve los 4 primeras letras
            this.fgRutRel.Rows[fgRutRel.Rows.Count - 1][2] = txtNumDoc.Text.ToString();

            ////guardamos el nuevo documento
            Ruta_Item_Enc DocRel = new Ruta_Item_Enc();

            DocRel.NumMovRut = Convert.ToInt32(this.txtNumMov.Text);
            DocRel.TipDoc = Convert.ToInt16(index);
            DocRel.NumDoc = Convert.ToInt32(this.txtNumDoc.Text);

            rutIte.Ruta_ItemDocRel_Guardar(DocRel); //ejecutamos la consulta

            this.cboTipDoc.SelectedIndex = -1;
            this.txtNumDoc.Text = "";
        }

        private void fgRutRel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (this.fgRutRel.IsCellSelected(this.fgRutRel.Row, this.fgRutRel.Col))
                {
                    if (this.fgRutRel.Rows.Count != 0)
                    {
                        DialogResult mensaje = MessageBox.Show("¿Esta seguro de eliminar este item?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (mensaje == DialogResult.Yes)
                        {

                            rutIte.Ruta_ItemDocRel_Eliminar(Convert.ToInt32(txtNumMov.Text), 
                                                            Convert.ToInt16(fgRutRel.Rows[fgRutRel.Row][0]),
                                                            Convert.ToInt32(fgRutRel.Rows[fgRutRel.Row][2]));

                            this.fgRutRel.Rows.Remove(this.fgRutRel.Row);

                            _mensaje = "Se elimino correctamente";
                            this.ALM_RutaDocRel_MosMsgStrip(_mensaje, Color.Green);
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                else
                {
                    _mensaje = "No hay registros para eliminar";
                    this.ALM_RutaDocRel_MosMsgStrip(_mensaje, Color.DodgerBlue);
                    this.btnAgr.Focus();
                    return;
                }
            }
        }

        private void ALM_RutaDocRel_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }
    }
}
