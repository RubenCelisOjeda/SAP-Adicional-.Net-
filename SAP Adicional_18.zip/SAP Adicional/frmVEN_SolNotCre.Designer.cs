﻿namespace SAP_Adicional
{
    partial class frmVEN_SolNotCre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVEN_SolNotCre));
            this.tlsBot = new System.Windows.Forms.ToolStrip();
            this.btnNue = new System.Windows.Forms.ToolStripButton();
            this.btnAbr = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGua = new System.Windows.Forms.ToolStripButton();
            this.btnDes = new System.Windows.Forms.ToolStripButton();
            this.btnMod = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.btnRec = new System.Windows.Forms.ToolStripButton();
            this.btnApr = new System.Windows.Forms.ToolStripButton();
            this.btnAnu = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnMigSAP = new System.Windows.Forms.ToolStripButton();
            this.btnPro = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAte = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnImp = new System.Windows.Forms.ToolStripSplitButton();
            this.solicitiudDeNotaDeCréditoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.solicitudDeDevoluciónAClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnEnc = new System.Windows.Forms.Panel();
            this.txtTipNotCre = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDocNum = new System.Windows.Forms.TextBox();
            this.txtTipDoc = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnCarColCanSol = new System.Windows.Forms.Button();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.txtEst = new System.Windows.Forms.TextBox();
            this.txtNumDocNotCre = new System.Windows.Forms.TextBox();
            this.txtRQ = new System.Windows.Forms.TextBox();
            this.txtCli = new System.Windows.Forms.TextBox();
            this.txtCodCli = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pnCub = new System.Windows.Forms.Panel();
            this.gbTipOri = new System.Windows.Forms.GroupBox();
            this.txtDocNumOri = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRQ_Ini = new System.Windows.Forms.TextBox();
            this.rbMer = new System.Windows.Forms.RadioButton();
            this.btnCanTip = new System.Windows.Forms.Button();
            this.rbCon = new System.Windows.Forms.RadioButton();
            this.btnAceTip = new System.Windows.Forms.Button();
            this.lblRQ = new System.Windows.Forms.Label();
            this.pnDocOri = new System.Windows.Forms.Panel();
            this.btnCanDoc = new System.Windows.Forms.Button();
            this.btnAceDoc = new System.Windows.Forms.Button();
            this.dgvDoc = new System.Windows.Forms.DataGridView();
            this.txtNumSol = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFecEmi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbcSolNot = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gpbAplNotCre = new System.Windows.Forms.GroupBox();
            this.btnCanSol = new System.Windows.Forms.Button();
            this.gpbSolDel = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtOtrBan = new System.Windows.Forms.TextBox();
            this.txtCueInt = new System.Windows.Forms.TextBox();
            this.txtCuenBan = new System.Windows.Forms.TextBox();
            this.txtTipCue = new System.Windows.Forms.TextBox();
            this.cboEntBan = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtMonSolDev = new System.Windows.Forms.TextBox();
            this.gpbTipDel = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTipDevDes = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cboTipDel = new System.Windows.Forms.ComboBox();
            this.btnLim = new System.Windows.Forms.Button();
            this.pnlDet = new System.Windows.Forms.Panel();
            this.tlsBot.SuspendLayout();
            this.pnEnc.SuspendLayout();
            this.pnCub.SuspendLayout();
            this.gbTipOri.SuspendLayout();
            this.pnDocOri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoc)).BeginInit();
            this.tbcSolNot.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.gpbAplNotCre.SuspendLayout();
            this.gpbSolDel.SuspendLayout();
            this.gpbTipDel.SuspendLayout();
            this.pnlDet.SuspendLayout();
            this.SuspendLayout();
            // 
            // tlsBot
            // 
            this.tlsBot.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlsBot.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNue,
            this.btnAbr,
            this.toolStripSeparator1,
            this.btnGua,
            this.btnDes,
            this.btnMod,
            this.toolStripSeparator,
            this.btnRec,
            this.btnApr,
            this.btnAnu,
            this.toolStripSeparator2,
            this.btnMigSAP,
            this.btnPro,
            this.toolStripSeparator3,
            this.btnAte,
            this.toolStripSeparator4,
            this.btnImp});
            this.tlsBot.Location = new System.Drawing.Point(0, 0);
            this.tlsBot.Name = "tlsBot";
            this.tlsBot.Size = new System.Drawing.Size(1356, 36);
            this.tlsBot.TabIndex = 43;
            this.tlsBot.Text = "toolStrip1";
            // 
            // btnNue
            // 
            this.btnNue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNue.Image = ((System.Drawing.Image)(resources.GetObject("btnNue.Image")));
            this.btnNue.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNue.Name = "btnNue";
            this.btnNue.Size = new System.Drawing.Size(42, 33);
            this.btnNue.Text = "&Nuevo";
            this.btnNue.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNue.Click += new System.EventHandler(this.btnNue_Click);
            // 
            // btnAbr
            // 
            this.btnAbr.Image = ((System.Drawing.Image)(resources.GetObject("btnAbr.Image")));
            this.btnAbr.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAbr.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbr.Name = "btnAbr";
            this.btnAbr.Size = new System.Drawing.Size(34, 33);
            this.btnAbr.Text = "&Abrir";
            this.btnAbr.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAbr.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbr.Click += new System.EventHandler(this.btnAbr_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 36);
            // 
            // btnGua
            // 
            this.btnGua.Image = ((System.Drawing.Image)(resources.GetObject("btnGua.Image")));
            this.btnGua.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGua.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGua.Name = "btnGua";
            this.btnGua.Size = new System.Drawing.Size(50, 33);
            this.btnGua.Text = "&Guardar";
            this.btnGua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGua.Click += new System.EventHandler(this.btnGua_Click);
            // 
            // btnDes
            // 
            this.btnDes.Image = ((System.Drawing.Image)(resources.GetObject("btnDes.Image")));
            this.btnDes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDes.Name = "btnDes";
            this.btnDes.Size = new System.Drawing.Size(56, 33);
            this.btnDes.Text = "Deshacer";
            this.btnDes.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDes.Click += new System.EventHandler(this.btnDes_Click);
            // 
            // btnMod
            // 
            this.btnMod.Image = ((System.Drawing.Image)(resources.GetObject("btnMod.Image")));
            this.btnMod.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(54, 33);
            this.btnMod.Text = "Modificar";
            this.btnMod.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMod.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 36);
            // 
            // btnRec
            // 
            this.btnRec.Image = ((System.Drawing.Image)(resources.GetObject("btnRec.Image")));
            this.btnRec.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRec.Name = "btnRec";
            this.btnRec.Size = new System.Drawing.Size(56, 33);
            this.btnRec.Tag = "5";
            this.btnRec.Text = "Rechazar";
            this.btnRec.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRec.Click += new System.EventHandler(this.btnRec_Click);
            // 
            // btnApr
            // 
            this.btnApr.Image = ((System.Drawing.Image)(resources.GetObject("btnApr.Image")));
            this.btnApr.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnApr.Name = "btnApr";
            this.btnApr.Size = new System.Drawing.Size(50, 33);
            this.btnApr.Tag = "12";
            this.btnApr.Text = "Aprobar";
            this.btnApr.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnApr.Click += new System.EventHandler(this.btnApr_Click);
            // 
            // btnAnu
            // 
            this.btnAnu.Image = ((System.Drawing.Image)(resources.GetObject("btnAnu.Image")));
            this.btnAnu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAnu.Name = "btnAnu";
            this.btnAnu.Size = new System.Drawing.Size(42, 33);
            this.btnAnu.Tag = "4";
            this.btnAnu.Text = "Anular";
            this.btnAnu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAnu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAnu.Click += new System.EventHandler(this.btnAnu_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 36);
            // 
            // btnMigSAP
            // 
            this.btnMigSAP.Image = ((System.Drawing.Image)(resources.GetObject("btnMigSAP.Image")));
            this.btnMigSAP.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMigSAP.Name = "btnMigSAP";
            this.btnMigSAP.Size = new System.Drawing.Size(63, 33);
            this.btnMigSAP.Text = "Migrar SAP";
            this.btnMigSAP.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMigSAP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMigSAP.Click += new System.EventHandler(this.btnMigSAP_Click);
            // 
            // btnPro
            // 
            this.btnPro.Image = ((System.Drawing.Image)(resources.GetObject("btnPro.Image")));
            this.btnPro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPro.Name = "btnPro";
            this.btnPro.Size = new System.Drawing.Size(53, 33);
            this.btnPro.Tag = "8";
            this.btnPro.Text = "Procesar";
            this.btnPro.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPro.Click += new System.EventHandler(this.btnPro_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 36);
            // 
            // btnAte
            // 
            this.btnAte.Image = ((System.Drawing.Image)(resources.GetObject("btnAte.Image")));
            this.btnAte.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAte.Name = "btnAte";
            this.btnAte.Size = new System.Drawing.Size(54, 33);
            this.btnAte.Tag = "11";
            this.btnAte.Text = "Atendido";
            this.btnAte.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAte.Click += new System.EventHandler(this.btnAte_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 36);
            // 
            // btnImp
            // 
            this.btnImp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.solicitiudDeNotaDeCréditoToolStripMenuItem,
            this.solicitudDeDevoluciónAClienteToolStripMenuItem});
            this.btnImp.Image = ((System.Drawing.Image)(resources.GetObject("btnImp.Image")));
            this.btnImp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImp.Name = "btnImp";
            this.btnImp.Size = new System.Drawing.Size(96, 33);
            this.btnImp.Tag = "12";
            this.btnImp.Text = "Opc. Impresión";
            this.btnImp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnImp.ButtonClick += new System.EventHandler(this.btnImp_ButtonClick);
            // 
            // solicitiudDeNotaDeCréditoToolStripMenuItem
            // 
            this.solicitiudDeNotaDeCréditoToolStripMenuItem.Name = "solicitiudDeNotaDeCréditoToolStripMenuItem";
            this.solicitiudDeNotaDeCréditoToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.solicitiudDeNotaDeCréditoToolStripMenuItem.Text = "Solicitiud de Nota de Crédito";
            this.solicitiudDeNotaDeCréditoToolStripMenuItem.Click += new System.EventHandler(this.solicitiudDeNotaDeCréditoToolStripMenuItem_Click);
            // 
            // solicitudDeDevoluciónAClienteToolStripMenuItem
            // 
            this.solicitudDeDevoluciónAClienteToolStripMenuItem.Name = "solicitudDeDevoluciónAClienteToolStripMenuItem";
            this.solicitudDeDevoluciónAClienteToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.solicitudDeDevoluciónAClienteToolStripMenuItem.Text = "Solicitud de Devolución a Cliente";
            this.solicitudDeDevoluciónAClienteToolStripMenuItem.Click += new System.EventHandler(this.solicitudDeDevoluciónAClienteToolStripMenuItem_Click);
            // 
            // pnEnc
            // 
            this.pnEnc.Controls.Add(this.txtTipNotCre);
            this.pnEnc.Controls.Add(this.label15);
            this.pnEnc.Controls.Add(this.txtDocNum);
            this.pnEnc.Controls.Add(this.txtTipDoc);
            this.pnEnc.Controls.Add(this.label14);
            this.pnEnc.Controls.Add(this.btnCarColCanSol);
            this.pnEnc.Controls.Add(this.txtObs);
            this.pnEnc.Controls.Add(this.txtEst);
            this.pnEnc.Controls.Add(this.txtNumDocNotCre);
            this.pnEnc.Controls.Add(this.txtRQ);
            this.pnEnc.Controls.Add(this.txtCli);
            this.pnEnc.Controls.Add(this.txtCodCli);
            this.pnEnc.Controls.Add(this.label5);
            this.pnEnc.Controls.Add(this.label2);
            this.pnEnc.Controls.Add(this.label1);
            this.pnEnc.Controls.Add(this.label3);
            this.pnEnc.Controls.Add(this.label4);
            this.pnEnc.Location = new System.Drawing.Point(2, 39);
            this.pnEnc.Name = "pnEnc";
            this.pnEnc.Size = new System.Drawing.Size(965, 170);
            this.pnEnc.TabIndex = 44;
            this.pnEnc.Visible = false;
            // 
            // txtTipNotCre
            // 
            this.txtTipNotCre.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTipNotCre.ForeColor = System.Drawing.Color.Blue;
            this.txtTipNotCre.Location = new System.Drawing.Point(79, 20);
            this.txtTipNotCre.Name = "txtTipNotCre";
            this.txtTipNotCre.ReadOnly = true;
            this.txtTipNotCre.Size = new System.Drawing.Size(103, 21);
            this.txtTipNotCre.TabIndex = 25;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(35, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Tipo NC:";
            // 
            // txtDocNum
            // 
            this.txtDocNum.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtDocNum.ForeColor = System.Drawing.Color.Blue;
            this.txtDocNum.Location = new System.Drawing.Point(292, 20);
            this.txtDocNum.Name = "txtDocNum";
            this.txtDocNum.ReadOnly = true;
            this.txtDocNum.Size = new System.Drawing.Size(88, 21);
            this.txtDocNum.TabIndex = 24;
            // 
            // txtTipDoc
            // 
            this.txtTipDoc.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTipDoc.ForeColor = System.Drawing.Color.Blue;
            this.txtTipDoc.Location = new System.Drawing.Point(246, 20);
            this.txtTipDoc.Name = "txtTipDoc";
            this.txtTipDoc.ReadOnly = true;
            this.txtTipDoc.Size = new System.Drawing.Size(44, 21);
            this.txtTipDoc.TabIndex = 22;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(186, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "Doc Origen:";
            // 
            // btnCarColCanSol
            // 
            this.btnCarColCanSol.Location = new System.Drawing.Point(687, 132);
            this.btnCarColCanSol.Name = "btnCarColCanSol";
            this.btnCarColCanSol.Size = new System.Drawing.Size(182, 21);
            this.btnCarColCanSol.TabIndex = 11;
            this.btnCarColCanSol.Text = "Cargar columna Cantidad-Sol";
            this.btnCarColCanSol.UseVisualStyleBackColor = true;
            this.btnCarColCanSol.Click += new System.EventHandler(this.btnCarColCanSol_Click);
            // 
            // txtObs
            // 
            this.txtObs.ForeColor = System.Drawing.Color.Blue;
            this.txtObs.Location = new System.Drawing.Point(79, 99);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(548, 57);
            this.txtObs.TabIndex = 9;
            // 
            // txtEst
            // 
            this.txtEst.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtEst.ForeColor = System.Drawing.Color.Blue;
            this.txtEst.Location = new System.Drawing.Point(726, 20);
            this.txtEst.Name = "txtEst";
            this.txtEst.ReadOnly = true;
            this.txtEst.Size = new System.Drawing.Size(144, 21);
            this.txtEst.TabIndex = 7;
            // 
            // txtNumDocNotCre
            // 
            this.txtNumDocNotCre.ForeColor = System.Drawing.Color.Blue;
            this.txtNumDocNotCre.Location = new System.Drawing.Point(292, 73);
            this.txtNumDocNotCre.Name = "txtNumDocNotCre";
            this.txtNumDocNotCre.Size = new System.Drawing.Size(335, 21);
            this.txtNumDocNotCre.TabIndex = 5;
            // 
            // txtRQ
            // 
            this.txtRQ.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtRQ.ForeColor = System.Drawing.Color.Blue;
            this.txtRQ.Location = new System.Drawing.Point(79, 73);
            this.txtRQ.Name = "txtRQ";
            this.txtRQ.ReadOnly = true;
            this.txtRQ.Size = new System.Drawing.Size(103, 21);
            this.txtRQ.TabIndex = 2;
            this.txtRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCli
            // 
            this.txtCli.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCli.ForeColor = System.Drawing.Color.Blue;
            this.txtCli.Location = new System.Drawing.Point(188, 47);
            this.txtCli.Name = "txtCli";
            this.txtCli.ReadOnly = true;
            this.txtCli.Size = new System.Drawing.Size(682, 21);
            this.txtCli.TabIndex = 1;
            // 
            // txtCodCli
            // 
            this.txtCodCli.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodCli.ForeColor = System.Drawing.Color.Blue;
            this.txtCodCli.Location = new System.Drawing.Point(79, 47);
            this.txtCodCli.Name = "txtCodCli";
            this.txtCodCli.ReadOnly = true;
            this.txtCodCli.Size = new System.Drawing.Size(103, 21);
            this.txtCodCli.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Obs:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "RQ:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Cliente:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(250, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "N° Doc:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(684, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Estado:";
            // 
            // pnCub
            // 
            this.pnCub.BackColor = System.Drawing.SystemColors.Window;
            this.pnCub.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnCub.Controls.Add(this.gbTipOri);
            this.pnCub.Controls.Add(this.pnDocOri);
            this.pnCub.Location = new System.Drawing.Point(1267, 171);
            this.pnCub.Name = "pnCub";
            this.pnCub.Size = new System.Drawing.Size(570, 518);
            this.pnCub.TabIndex = 47;
            this.pnCub.Visible = false;
            this.pnCub.Resize += new System.EventHandler(this.pnCub_Resize);
            // 
            // gbTipOri
            // 
            this.gbTipOri.Controls.Add(this.txtDocNumOri);
            this.gbTipOri.Controls.Add(this.label8);
            this.gbTipOri.Controls.Add(this.txtRQ_Ini);
            this.gbTipOri.Controls.Add(this.rbMer);
            this.gbTipOri.Controls.Add(this.btnCanTip);
            this.gbTipOri.Controls.Add(this.rbCon);
            this.gbTipOri.Controls.Add(this.btnAceTip);
            this.gbTipOri.Controls.Add(this.lblRQ);
            this.gbTipOri.Location = new System.Drawing.Point(34, 62);
            this.gbTipOri.Name = "gbTipOri";
            this.gbTipOri.Size = new System.Drawing.Size(288, 158);
            this.gbTipOri.TabIndex = 2;
            this.gbTipOri.TabStop = false;
            this.gbTipOri.Text = "Tipo y origen:";
            // 
            // txtDocNumOri
            // 
            this.txtDocNumOri.Location = new System.Drawing.Point(168, 55);
            this.txtDocNumOri.Name = "txtDocNumOri";
            this.txtDocNumOri.Size = new System.Drawing.Size(75, 21);
            this.txtDocNumOri.TabIndex = 6;
            this.txtDocNumOri.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDocNumOri.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(113, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Corr. Doc:";
            this.label8.Visible = false;
            // 
            // txtRQ_Ini
            // 
            this.txtRQ_Ini.Location = new System.Drawing.Point(168, 28);
            this.txtRQ_Ini.Name = "txtRQ_Ini";
            this.txtRQ_Ini.Size = new System.Drawing.Size(75, 21);
            this.txtRQ_Ini.TabIndex = 4;
            this.txtRQ_Ini.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRQ_Ini.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRQ_Ini_KeyPress);
            // 
            // rbMer
            // 
            this.rbMer.AutoSize = true;
            this.rbMer.Location = new System.Drawing.Point(33, 30);
            this.rbMer.Name = "rbMer";
            this.rbMer.Size = new System.Drawing.Size(78, 17);
            this.rbMer.TabIndex = 0;
            this.rbMer.TabStop = true;
            this.rbMer.Text = "Mercaderia";
            this.rbMer.UseVisualStyleBackColor = true;
            this.rbMer.CheckedChanged += new System.EventHandler(this.rbMer_CheckedChanged);
            // 
            // btnCanTip
            // 
            this.btnCanTip.Location = new System.Drawing.Point(151, 109);
            this.btnCanTip.Name = "btnCanTip";
            this.btnCanTip.Size = new System.Drawing.Size(97, 22);
            this.btnCanTip.TabIndex = 3;
            this.btnCanTip.Text = "Cancelar";
            this.btnCanTip.UseVisualStyleBackColor = true;
            this.btnCanTip.Click += new System.EventHandler(this.btnCanTip_Click);
            // 
            // rbCon
            // 
            this.rbCon.AutoSize = true;
            this.rbCon.Location = new System.Drawing.Point(33, 53);
            this.rbCon.Name = "rbCon";
            this.rbCon.Size = new System.Drawing.Size(71, 17);
            this.rbCon.TabIndex = 1;
            this.rbCon.TabStop = true;
            this.rbCon.Text = "Concepto";
            this.rbCon.UseVisualStyleBackColor = true;
            this.rbCon.Visible = false;
            this.rbCon.CheckedChanged += new System.EventHandler(this.rbCon_CheckedChanged);
            // 
            // btnAceTip
            // 
            this.btnAceTip.Location = new System.Drawing.Point(46, 109);
            this.btnAceTip.Name = "btnAceTip";
            this.btnAceTip.Size = new System.Drawing.Size(97, 22);
            this.btnAceTip.TabIndex = 2;
            this.btnAceTip.Text = "Aceptar";
            this.btnAceTip.UseVisualStyleBackColor = true;
            this.btnAceTip.Click += new System.EventHandler(this.btnAceTip_Click);
            // 
            // lblRQ
            // 
            this.lblRQ.AutoSize = true;
            this.lblRQ.Location = new System.Drawing.Point(144, 32);
            this.lblRQ.Name = "lblRQ";
            this.lblRQ.Size = new System.Drawing.Size(26, 13);
            this.lblRQ.TabIndex = 5;
            this.lblRQ.Text = "RQ:";
            // 
            // pnDocOri
            // 
            this.pnDocOri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnDocOri.Controls.Add(this.btnCanDoc);
            this.pnDocOri.Controls.Add(this.btnAceDoc);
            this.pnDocOri.Controls.Add(this.dgvDoc);
            this.pnDocOri.Location = new System.Drawing.Point(328, 135);
            this.pnDocOri.Name = "pnDocOri";
            this.pnDocOri.Size = new System.Drawing.Size(582, 301);
            this.pnDocOri.TabIndex = 1;
            this.pnDocOri.Visible = false;
            // 
            // btnCanDoc
            // 
            this.btnCanDoc.Location = new System.Drawing.Point(330, 256);
            this.btnCanDoc.Name = "btnCanDoc";
            this.btnCanDoc.Size = new System.Drawing.Size(97, 22);
            this.btnCanDoc.TabIndex = 5;
            this.btnCanDoc.Text = "Cancelar";
            this.btnCanDoc.UseVisualStyleBackColor = true;
            this.btnCanDoc.Click += new System.EventHandler(this.btnCanDoc_Click);
            // 
            // btnAceDoc
            // 
            this.btnAceDoc.Location = new System.Drawing.Point(225, 256);
            this.btnAceDoc.Name = "btnAceDoc";
            this.btnAceDoc.Size = new System.Drawing.Size(97, 22);
            this.btnAceDoc.TabIndex = 4;
            this.btnAceDoc.Text = "Aceptar";
            this.btnAceDoc.UseVisualStyleBackColor = true;
            // 
            // dgvDoc
            // 
            this.dgvDoc.AllowUserToAddRows = false;
            this.dgvDoc.AllowUserToDeleteRows = false;
            this.dgvDoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoc.Location = new System.Drawing.Point(15, 13);
            this.dgvDoc.MultiSelect = false;
            this.dgvDoc.Name = "dgvDoc";
            this.dgvDoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDoc.Size = new System.Drawing.Size(593, 228);
            this.dgvDoc.TabIndex = 0;
            // 
            // txtNumSol
            // 
            this.txtNumSol.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumSol.ForeColor = System.Drawing.Color.Blue;
            this.txtNumSol.Location = new System.Drawing.Point(745, 10);
            this.txtNumSol.Name = "txtNumSol";
            this.txtNumSol.ReadOnly = true;
            this.txtNumSol.Size = new System.Drawing.Size(96, 21);
            this.txtNumSol.TabIndex = 48;
            this.txtNumSol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(694, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 49;
            this.label6.Text = "N° SOL:";
            // 
            // txtFecEmi
            // 
            this.txtFecEmi.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtFecEmi.ForeColor = System.Drawing.Color.Blue;
            this.txtFecEmi.Location = new System.Drawing.Point(892, 10);
            this.txtFecEmi.Name = "txtFecEmi";
            this.txtFecEmi.ReadOnly = true;
            this.txtFecEmi.Size = new System.Drawing.Size(96, 21);
            this.txtFecEmi.TabIndex = 50;
            this.txtFecEmi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(847, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 51;
            this.label7.Text = "Emisión:";
            // 
            // tbcSolNot
            // 
            this.tbcSolNot.Controls.Add(this.tabPage1);
            this.tbcSolNot.Controls.Add(this.tabPage2);
            this.tbcSolNot.Location = new System.Drawing.Point(3, 12);
            this.tbcSolNot.Name = "tbcSolNot";
            this.tbcSolNot.SelectedIndex = 0;
            this.tbcSolNot.Size = new System.Drawing.Size(1218, 433);
            this.tbcSolNot.TabIndex = 53;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.fg);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1210, 407);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Detalle";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(7, 6);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.Size = new System.Drawing.Size(1200, 390);
            this.fg.TabIndex = 0;
            this.fg.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fg_AfterEdit);
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.gpbAplNotCre);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1210, 407);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Otros Datos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // gpbAplNotCre
            // 
            this.gpbAplNotCre.Controls.Add(this.btnCanSol);
            this.gpbAplNotCre.Controls.Add(this.gpbSolDel);
            this.gpbAplNotCre.Controls.Add(this.gpbTipDel);
            this.gpbAplNotCre.Controls.Add(this.btnLim);
            this.gpbAplNotCre.Location = new System.Drawing.Point(6, 9);
            this.gpbAplNotCre.Name = "gpbAplNotCre";
            this.gpbAplNotCre.Size = new System.Drawing.Size(1198, 395);
            this.gpbAplNotCre.TabIndex = 0;
            this.gpbAplNotCre.TabStop = false;
            this.gpbAplNotCre.Text = "Aplicación de Nota de Crédito";
            // 
            // btnCanSol
            // 
            this.btnCanSol.BackColor = System.Drawing.SystemColors.Control;
            this.btnCanSol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCanSol.Location = new System.Drawing.Point(480, 358);
            this.btnCanSol.Name = "btnCanSol";
            this.btnCanSol.Size = new System.Drawing.Size(92, 32);
            this.btnCanSol.TabIndex = 21;
            this.btnCanSol.Text = "Cancelar";
            this.btnCanSol.UseVisualStyleBackColor = false;
            this.btnCanSol.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // gpbSolDel
            // 
            this.gpbSolDel.Controls.Add(this.label22);
            this.gpbSolDel.Controls.Add(this.txtOtrBan);
            this.gpbSolDel.Controls.Add(this.txtCueInt);
            this.gpbSolDel.Controls.Add(this.txtCuenBan);
            this.gpbSolDel.Controls.Add(this.txtTipCue);
            this.gpbSolDel.Controls.Add(this.cboEntBan);
            this.gpbSolDel.Controls.Add(this.label11);
            this.gpbSolDel.Controls.Add(this.label20);
            this.gpbSolDel.Controls.Add(this.label18);
            this.gpbSolDel.Controls.Add(this.label17);
            this.gpbSolDel.Controls.Add(this.label12);
            this.gpbSolDel.Controls.Add(this.txtMonSolDev);
            this.gpbSolDel.ForeColor = System.Drawing.Color.Blue;
            this.gpbSolDel.Location = new System.Drawing.Point(7, 131);
            this.gpbSolDel.Name = "gpbSolDel";
            this.gpbSolDel.Size = new System.Drawing.Size(932, 219);
            this.gpbSolDel.TabIndex = 6;
            this.gpbSolDel.TabStop = false;
            this.gpbSolDel.Text = "Solicitud de Devolución ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(599, 69);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 13);
            this.label22.TabIndex = 11;
            this.label22.Text = "Banco :";
            // 
            // txtOtrBan
            // 
            this.txtOtrBan.Location = new System.Drawing.Point(643, 61);
            this.txtOtrBan.Name = "txtOtrBan";
            this.txtOtrBan.Size = new System.Drawing.Size(225, 21);
            this.txtOtrBan.TabIndex = 12;
            this.txtOtrBan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOtrBan_KeyPress);
            // 
            // txtCueInt
            // 
            this.txtCueInt.Location = new System.Drawing.Point(214, 179);
            this.txtCueInt.Name = "txtCueInt";
            this.txtCueInt.Size = new System.Drawing.Size(184, 21);
            this.txtCueInt.TabIndex = 19;
            this.txtCueInt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCueInt_KeyPress);
            // 
            // txtCuenBan
            // 
            this.txtCuenBan.Location = new System.Drawing.Point(214, 138);
            this.txtCuenBan.Name = "txtCuenBan";
            this.txtCuenBan.Size = new System.Drawing.Size(182, 21);
            this.txtCuenBan.TabIndex = 16;
            this.txtCuenBan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCuenBan_KeyPress);
            // 
            // txtTipCue
            // 
            this.txtTipCue.Location = new System.Drawing.Point(214, 99);
            this.txtTipCue.Name = "txtTipCue";
            this.txtTipCue.Size = new System.Drawing.Size(136, 21);
            this.txtTipCue.TabIndex = 14;
            this.txtTipCue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipCue_KeyPress);
            // 
            // cboEntBan
            // 
            this.cboEntBan.FormattingEnabled = true;
            this.cboEntBan.Items.AddRange(new object[] {
            "BANCO DE CRÉDITO DEL PERU (BCP)",
            "BANCO INTERAMERICANO DEL FINANZAS (BANBIF)",
            "BANCO FINANCIERO DEL PERU",
            "BANCO INTERNACIONAL DEL PERU",
            "BBVA BANCO CONTINENTAL",
            "BANCO SCOTIABANK DEL PERU",
            "BANCO CITIBANK",
            "OTROS"});
            this.cboEntBan.Location = new System.Drawing.Point(214, 61);
            this.cboEntBan.Name = "cboEntBan";
            this.cboEntBan.Size = new System.Drawing.Size(370, 21);
            this.cboEntBan.TabIndex = 10;
            this.cboEntBan.SelectedIndexChanged += new System.EventHandler(this.cboEntBan_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(6, 185);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(189, 26);
            this.label11.TabIndex = 18;
            this.label11.Text = "Cuenta Interbancaria                         :\r\n\r\n";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(8, 146);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(189, 26);
            this.label20.TabIndex = 15;
            this.label20.Text = "Cuenta Bancaria                                 :\r\n\r\n";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(9, 106);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(186, 26);
            this.label18.TabIndex = 13;
            this.label18.Text = "Tipo de Cuenta                                  :\r\n\r\n";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(11, 69);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(196, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "Entidad Bancaria                                :   \r\n";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(11, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(188, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "Monto                                                 :";
            // 
            // txtMonSolDev
            // 
            this.txtMonSolDev.Location = new System.Drawing.Point(215, 23);
            this.txtMonSolDev.Name = "txtMonSolDev";
            this.txtMonSolDev.Size = new System.Drawing.Size(137, 21);
            this.txtMonSolDev.TabIndex = 8;
            this.txtMonSolDev.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMonSolDev_KeyPress);
            // 
            // gpbTipDel
            // 
            this.gpbTipDel.Controls.Add(this.label10);
            this.gpbTipDel.Controls.Add(this.txtTipDevDes);
            this.gpbTipDel.Controls.Add(this.label9);
            this.gpbTipDel.Controls.Add(this.cboTipDel);
            this.gpbTipDel.ForeColor = System.Drawing.Color.Blue;
            this.gpbTipDel.Location = new System.Drawing.Point(7, 29);
            this.gpbTipDel.Name = "gpbTipDel";
            this.gpbTipDel.Size = new System.Drawing.Size(932, 79);
            this.gpbTipDel.TabIndex = 1;
            this.gpbTipDel.TabStop = false;
            this.gpbTipDel.Text = "Solicitud de Nota de Crédito";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(311, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Descripción:";
            // 
            // txtTipDevDes
            // 
            this.txtTipDevDes.Location = new System.Drawing.Point(382, 23);
            this.txtTipDevDes.Multiline = true;
            this.txtTipDevDes.Name = "txtTipDevDes";
            this.txtTipDevDes.Size = new System.Drawing.Size(378, 38);
            this.txtTipDevDes.TabIndex = 5;
            this.txtTipDevDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipDevDes_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Tipo de Devolución";
            // 
            // cboTipDel
            // 
            this.cboTipDel.FormattingEnabled = true;
            this.cboTipDel.Items.AddRange(new object[] {
            "",
            "Cheque",
            "Transferencia",
            "RQ"});
            this.cboTipDel.Location = new System.Drawing.Point(109, 23);
            this.cboTipDel.Name = "cboTipDel";
            this.cboTipDel.Size = new System.Drawing.Size(142, 21);
            this.cboTipDel.TabIndex = 3;
            // 
            // btnLim
            // 
            this.btnLim.BackColor = System.Drawing.SystemColors.Control;
            this.btnLim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLim.Location = new System.Drawing.Point(389, 358);
            this.btnLim.Name = "btnLim";
            this.btnLim.Size = new System.Drawing.Size(92, 32);
            this.btnLim.TabIndex = 20;
            this.btnLim.Text = "Limpiar";
            this.btnLim.UseVisualStyleBackColor = false;
            this.btnLim.Click += new System.EventHandler(this.btnLim_Click);
            this.btnLim.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnLim_KeyPress);
            // 
            // pnlDet
            // 
            this.pnlDet.Controls.Add(this.tbcSolNot);
            this.pnlDet.Location = new System.Drawing.Point(2, 222);
            this.pnlDet.Name = "pnlDet";
            this.pnlDet.Size = new System.Drawing.Size(1224, 479);
            this.pnlDet.TabIndex = 54;
            // 
            // frmVEN_SolNotCre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1356, 742);
            this.Controls.Add(this.pnCub);
            this.Controls.Add(this.pnlDet);
            this.Controls.Add(this.txtFecEmi);
            this.Controls.Add(this.txtNumSol);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pnEnc);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tlsBot);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_SolNotCre";
            this.Text = "Solicitud - Nota de Credito";
            this.Load += new System.EventHandler(this.frmVEN_SolNotCre_Load);
            this.Resize += new System.EventHandler(this.frmVEN_SolNotCre_Resize);
            this.tlsBot.ResumeLayout(false);
            this.tlsBot.PerformLayout();
            this.pnEnc.ResumeLayout(false);
            this.pnEnc.PerformLayout();
            this.pnCub.ResumeLayout(false);
            this.gbTipOri.ResumeLayout(false);
            this.gbTipOri.PerformLayout();
            this.pnDocOri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoc)).EndInit();
            this.tbcSolNot.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.gpbAplNotCre.ResumeLayout(false);
            this.gpbSolDel.ResumeLayout(false);
            this.gpbSolDel.PerformLayout();
            this.gpbTipDel.ResumeLayout(false);
            this.gpbTipDel.PerformLayout();
            this.pnlDet.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tlsBot;
        private System.Windows.Forms.ToolStripButton btnAbr;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnGua;
        private System.Windows.Forms.ToolStripButton btnDes;
        private System.Windows.Forms.ToolStripButton btnMod;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.Panel pnEnc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRQ;
        private System.Windows.Forms.TextBox txtCli;
        private System.Windows.Forms.TextBox txtCodCli;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNumDocNotCre;
        private System.Windows.Forms.Panel pnCub;
        private System.Windows.Forms.Button btnCanTip;
        private System.Windows.Forms.Button btnAceTip;
        private System.Windows.Forms.RadioButton rbCon;
        private System.Windows.Forms.RadioButton rbMer;
        private System.Windows.Forms.Panel pnDocOri;
        private System.Windows.Forms.DataGridView dgvDoc;
        private System.Windows.Forms.Button btnCanDoc;
        private System.Windows.Forms.Button btnAceDoc;
        private System.Windows.Forms.Label lblRQ;
        private System.Windows.Forms.Button btnCarColCanSol;
        private System.Windows.Forms.TextBox txtNumSol;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripButton btnAnu;
        private System.Windows.Forms.ToolStripButton btnPro;
        private System.Windows.Forms.ToolStripButton btnMigSAP;
        public System.Windows.Forms.ToolStripButton btnNue;
        private System.Windows.Forms.TextBox txtFecEmi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDocNumOri;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTipNotCre;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtDocNum;
        private System.Windows.Forms.TextBox txtTipDoc;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ToolStripButton btnApr;
        private System.Windows.Forms.ToolStripButton btnRec;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        public System.Windows.Forms.TextBox txtRQ_Ini;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnAte;
        private System.Windows.Forms.TabControl tbcSolNot;
        private System.Windows.Forms.TabPage tabPage1;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gpbAplNotCre;
        private System.Windows.Forms.Button btnCanSol;
        private System.Windows.Forms.GroupBox gpbSolDel;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtOtrBan;
        private System.Windows.Forms.TextBox txtCueInt;
        private System.Windows.Forms.TextBox txtCuenBan;
        private System.Windows.Forms.TextBox txtTipCue;
        private System.Windows.Forms.ComboBox cboEntBan;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtMonSolDev;
        private System.Windows.Forms.GroupBox gpbTipDel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTipDevDes;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboTipDel;
        private System.Windows.Forms.Button btnLim;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        public System.Windows.Forms.Panel pnlDet;
        public System.Windows.Forms.GroupBox gbTipOri;
        private System.Windows.Forms.ToolStripSplitButton btnImp;
        private System.Windows.Forms.ToolStripMenuItem solicitiudDeNotaDeCréditoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem solicitudDeDevoluciónAClienteToolStripMenuItem;
    }
}