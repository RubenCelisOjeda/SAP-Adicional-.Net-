﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmLOG_SegDoc : Form
    {
        NLOG_SegDoc2 nc = new NLOG_SegDoc2();
        CellStyle style1;
        VarGlo varglo = VarGlo.Instance();

        public frmLOG_SegDoc()
        {
            InitializeComponent();
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch { }
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {

            this.fg.DataSource = nc.LOG_SegDoc2(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text));

            }
            catch { }
        }

        public void FormatoGeneral()
        {
            fg.Cols[0].Visible = false;
            fg.Cols.Frozen = 8;
            fg.AllowFreezing = AllowFreezingEnum.Both;

            //fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;

            //CellStyle s = fg.Styles[CellStyleEnum.Subtotal0];
            //s.BackColor = Color.Yellow;
            //s.ForeColor = Color.Blue;      
        }

        public void Diseno()
        {
            //for (int i = 0; i < fg.Cols.Count; i++)
            //{
            fg.Cols[1].TextAlign = TextAlignEnum.RightCenter;
            //}

            fg.Cols[1].Width = 50;
            fg.Cols[2].Width = 70;
            fg.Cols[3].Width = 65;
            fg.Cols[4].Width = 50; //Serie doc.
            fg.Cols[5].Width = 80;
            fg.Cols[6].Width = 170;
            fg.Cols[7].Width = 260; //Cliente
            fg.Cols[8].Width = 120;
            fg.Cols[9].Width = 70;
            fg.Cols[10].Width = 70;
            fg.Cols[11].Width = 140; //Vendedor
            fg.Cols[12].Width = 140;
            fg.Cols[13].Width = 130;
            fg.Cols[16].Width = 345;
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            
            if (e.Col != 16)
            {
                if (e.KeyChar !=3 && e.KeyChar !=27)
                {
                    e.Handled = true;
                }
            }
        }

        public void Datos()
        {
            DataTable dt = new DataTable();
            dt = nc.LOG_SegDoc_Est();

            ListDictionary list = new ListDictionary();

            for (int i = 0; i <= dt.Rows.Count - 1; i++)
            {
                list.Add(dt.Rows[i][1], dt.Rows[i][1]);
            }

            style1 = fg.Styles.Add("Estado");
            style1.DataMap = list;
            fg.Cols["Estado"].Style = style1;
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            Datos();
            FormatoGeneral();
            Diseno();
        }

        private void frmLOG_SegDoc_Load(object sender, EventArgs e)
        {
            //.AutoResize = true;
            fg.Styles.Normal.WordWrap = true;
            fg.Rows.Count = 1;
            fg.Cols.Count = 1;
            fg.Rows[0].Height = 50;
        }

        private void fg_AfterEdit(object sender, RowColEventArgs e)
        {
            try
            {
                if (e.Col == 14 || e.Col == 16)
                {
                    nc.LOG_SegDoc_Est_(Convert.ToString(fg[e.Row, 0]), Convert.ToInt32(fg[e.Row, 3]), Convert.ToString(fg[e.Row, 14]), Convert.ToString(fg[e.Row, 16]), Convert.ToInt16(varglo.CodUsuAct));
                }
            }
            catch { }     
        }
    }
}
