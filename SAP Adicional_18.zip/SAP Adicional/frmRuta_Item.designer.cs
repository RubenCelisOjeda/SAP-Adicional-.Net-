﻿namespace SAP_Adicional
{
    partial class frmRuta_Item
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRuta_Item));
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.btnAbrir = new System.Windows.Forms.ToolStripButton();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.btnDeshacer = new System.Windows.Forms.ToolStripButton();
            this.btnModificar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnEli = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCer = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.pnlRutIte = new System.Windows.Forms.Panel();
            this.txtDesTipRut = new System.Windows.Forms.TextBox();
            this.lblNomFecMod = new System.Windows.Forms.Label();
            this.txtDirRut = new System.Windows.Forms.TextBox();
            this.pnlInsCar = new System.Windows.Forms.Panel();
            this.rdoTraiLu = new System.Windows.Forms.RadioButton();
            this.rdoCli = new System.Windows.Forms.RadioButton();
            this.mkdHor = new System.Windows.Forms.MaskedTextBox();
            this.pnlHoOpc = new System.Windows.Forms.Panel();
            this.rdoHorExa = new System.Windows.Forms.RadioButton();
            this.rdoRanHor = new System.Windows.Forms.RadioButton();
            this.btnVinRq = new System.Windows.Forms.Button();
            this.dtpFecDes = new System.Windows.Forms.DateTimePicker();
            this.btnVerRutOnl = new System.Windows.Forms.Button();
            this.btnDocVin = new System.Windows.Forms.Button();
            this.cmbTipTra = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDesTra = new System.Windows.Forms.TextBox();
            this.txtDesMedTra = new System.Windows.Forms.TextBox();
            this.txtDesCor = new System.Windows.Forms.TextBox();
            this.txtEncDet = new System.Windows.Forms.TextBox();
            this.txtCor = new System.Windows.Forms.TextBox();
            this.txtCon = new System.Windows.Forms.TextBox();
            this.txtDesDis = new System.Windows.Forms.TextBox();
            this.txtCodTra = new System.Windows.Forms.TextBox();
            this.txtCodMedTra = new System.Windows.Forms.TextBox();
            this.txtCodRut = new System.Windows.Forms.TextBox();
            this.txtCodCor = new System.Windows.Forms.TextBox();
            this.txtCodDis = new System.Windows.Forms.TextBox();
            this.txtCodTipRut = new System.Windows.Forms.TextBox();
            this.txtDesTipVen = new System.Windows.Forms.TextBox();
            this.txtDesRq = new System.Windows.Forms.TextBox();
            this.txtCodTipVen = new System.Windows.Forms.TextBox();
            this.txtCodRq = new System.Windows.Forms.TextBox();
            this.txtNumMovRut = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTra = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip2.SuspendLayout();
            this.pnlRutIte.SuspendLayout();
            this.pnlInsCar.SuspendLayout();
            this.pnlHoOpc.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip2
            // 
            this.toolStrip2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.btnAbrir,
            this.btnGuardar,
            this.btnDeshacer,
            this.btnModificar,
            this.toolStripSeparator2,
            this.btnEli,
            this.toolStripSeparator1,
            this.btnCer,
            this.toolStripSeparator3});
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(991, 36);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip1";
            // 
            // btnNuevo
            // 
            this.btnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("btnNuevo.Image")));
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.btnNuevo.Size = new System.Drawing.Size(42, 33);
            this.btnNuevo.Tag = "";
            this.btnNuevo.Text = "&Nuevo";
            this.btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnAbrir
            // 
            this.btnAbrir.Image = ((System.Drawing.Image)(resources.GetObject("btnAbrir.Image")));
            this.btnAbrir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAbrir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(34, 33);
            this.btnAbrir.Text = "&Abrir";
            this.btnAbrir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAbrir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbrir.Click += new System.EventHandler(this.btnAbrir_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(50, 33);
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnDeshacer
            // 
            this.btnDeshacer.Image = ((System.Drawing.Image)(resources.GetObject("btnDeshacer.Image")));
            this.btnDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDeshacer.Name = "btnDeshacer";
            this.btnDeshacer.Size = new System.Drawing.Size(56, 33);
            this.btnDeshacer.Text = "&Deshacer";
            this.btnDeshacer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDeshacer.Click += new System.EventHandler(this.btnDeshacer_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(54, 33);
            this.btnModificar.Text = "&Modificar";
            this.btnModificar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 36);
            // 
            // btnEli
            // 
            this.btnEli.Image = ((System.Drawing.Image)(resources.GetObject("btnEli.Image")));
            this.btnEli.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEli.Name = "btnEli";
            this.btnEli.Size = new System.Drawing.Size(47, 33);
            this.btnEli.Text = "&Eliminar";
            this.btnEli.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEli.Click += new System.EventHandler(this.btnEli_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 36);
            // 
            // btnCer
            // 
            this.btnCer.Image = ((System.Drawing.Image)(resources.GetObject("btnCer.Image")));
            this.btnCer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCer.Name = "btnCer";
            this.btnCer.Size = new System.Drawing.Size(42, 33);
            this.btnCer.Text = "&Cerrar";
            this.btnCer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCer.Click += new System.EventHandler(this.btnCer_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 36);
            // 
            // pnlRutIte
            // 
            this.pnlRutIte.AutoScroll = true;
            this.pnlRutIte.Controls.Add(this.txtDesTipRut);
            this.pnlRutIte.Controls.Add(this.lblNomFecMod);
            this.pnlRutIte.Controls.Add(this.txtDirRut);
            this.pnlRutIte.Controls.Add(this.pnlInsCar);
            this.pnlRutIte.Controls.Add(this.mkdHor);
            this.pnlRutIte.Controls.Add(this.pnlHoOpc);
            this.pnlRutIte.Controls.Add(this.btnVinRq);
            this.pnlRutIte.Controls.Add(this.dtpFecDes);
            this.pnlRutIte.Controls.Add(this.btnVerRutOnl);
            this.pnlRutIte.Controls.Add(this.btnDocVin);
            this.pnlRutIte.Controls.Add(this.cmbTipTra);
            this.pnlRutIte.Controls.Add(this.label3);
            this.pnlRutIte.Controls.Add(this.txtDesTra);
            this.pnlRutIte.Controls.Add(this.txtDesMedTra);
            this.pnlRutIte.Controls.Add(this.txtDesCor);
            this.pnlRutIte.Controls.Add(this.txtEncDet);
            this.pnlRutIte.Controls.Add(this.txtCor);
            this.pnlRutIte.Controls.Add(this.txtCon);
            this.pnlRutIte.Controls.Add(this.txtDesDis);
            this.pnlRutIte.Controls.Add(this.txtCodTra);
            this.pnlRutIte.Controls.Add(this.txtCodMedTra);
            this.pnlRutIte.Controls.Add(this.txtCodRut);
            this.pnlRutIte.Controls.Add(this.txtCodCor);
            this.pnlRutIte.Controls.Add(this.txtCodDis);
            this.pnlRutIte.Controls.Add(this.txtCodTipRut);
            this.pnlRutIte.Controls.Add(this.txtDesTipVen);
            this.pnlRutIte.Controls.Add(this.txtDesRq);
            this.pnlRutIte.Controls.Add(this.txtCodTipVen);
            this.pnlRutIte.Controls.Add(this.txtCodRq);
            this.pnlRutIte.Controls.Add(this.txtNumMovRut);
            this.pnlRutIte.Controls.Add(this.label4);
            this.pnlRutIte.Controls.Add(this.lblTra);
            this.pnlRutIte.Controls.Add(this.label16);
            this.pnlRutIte.Controls.Add(this.label14);
            this.pnlRutIte.Controls.Add(this.label11);
            this.pnlRutIte.Controls.Add(this.label13);
            this.pnlRutIte.Controls.Add(this.label12);
            this.pnlRutIte.Controls.Add(this.label10);
            this.pnlRutIte.Controls.Add(this.label9);
            this.pnlRutIte.Controls.Add(this.label8);
            this.pnlRutIte.Controls.Add(this.lbl);
            this.pnlRutIte.Controls.Add(this.label7);
            this.pnlRutIte.Controls.Add(this.label5);
            this.pnlRutIte.Controls.Add(this.label2);
            this.pnlRutIte.Controls.Add(this.label1);
            this.pnlRutIte.Location = new System.Drawing.Point(5, 39);
            this.pnlRutIte.Name = "pnlRutIte";
            this.pnlRutIte.Size = new System.Drawing.Size(781, 698);
            this.pnlRutIte.TabIndex = 1;
            // 
            // txtDesTipRut
            // 
            this.txtDesTipRut.BackColor = System.Drawing.Color.White;
            this.txtDesTipRut.ForeColor = System.Drawing.Color.Blue;
            this.txtDesTipRut.Location = new System.Drawing.Point(150, 61);
            this.txtDesTipRut.Name = "txtDesTipRut";
            this.txtDesTipRut.Size = new System.Drawing.Size(167, 21);
            this.txtDesTipRut.TabIndex = 3;
            this.txtDesTipRut.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesTipRut_KeyPress);
            // 
            // lblNomFecMod
            // 
            this.lblNomFecMod.AutoSize = true;
            this.lblNomFecMod.ForeColor = System.Drawing.Color.Blue;
            this.lblNomFecMod.Location = new System.Drawing.Point(27, 11);
            this.lblNomFecMod.Name = "lblNomFecMod";
            this.lblNomFecMod.Size = new System.Drawing.Size(0, 13);
            this.lblNomFecMod.TabIndex = 35;
            // 
            // txtDirRut
            // 
            this.txtDirRut.Location = new System.Drawing.Point(98, 195);
            this.txtDirRut.Multiline = true;
            this.txtDirRut.Name = "txtDirRut";
            this.txtDirRut.Size = new System.Drawing.Size(672, 64);
            this.txtDirRut.TabIndex = 15;
            // 
            // pnlInsCar
            // 
            this.pnlInsCar.Controls.Add(this.rdoTraiLu);
            this.pnlInsCar.Controls.Add(this.rdoCli);
            this.pnlInsCar.Location = new System.Drawing.Point(101, 448);
            this.pnlInsCar.Name = "pnlInsCar";
            this.pnlInsCar.Size = new System.Drawing.Size(200, 30);
            this.pnlInsCar.TabIndex = 28;
            // 
            // rdoTraiLu
            // 
            this.rdoTraiLu.AutoSize = true;
            this.rdoTraiLu.Location = new System.Drawing.Point(81, 11);
            this.rdoTraiLu.Name = "rdoTraiLu";
            this.rdoTraiLu.Size = new System.Drawing.Size(113, 17);
            this.rdoTraiLu.TabIndex = 30;
            this.rdoTraiLu.TabStop = true;
            this.rdoTraiLu.Text = "Trazzo Iluminación";
            this.rdoTraiLu.UseVisualStyleBackColor = true;
            // 
            // rdoCli
            // 
            this.rdoCli.AutoSize = true;
            this.rdoCli.Location = new System.Drawing.Point(8, 11);
            this.rdoCli.Name = "rdoCli";
            this.rdoCli.Size = new System.Drawing.Size(58, 17);
            this.rdoCli.TabIndex = 29;
            this.rdoCli.TabStop = true;
            this.rdoCli.Text = "Cliente";
            this.rdoCli.UseVisualStyleBackColor = true;
            // 
            // mkdHor
            // 
            this.mkdHor.Location = new System.Drawing.Point(334, 334);
            this.mkdHor.Mask = "00:00";
            this.mkdHor.Name = "mkdHor";
            this.mkdHor.Size = new System.Drawing.Size(61, 21);
            this.mkdHor.TabIndex = 25;
            this.mkdHor.ValidatingType = typeof(System.DateTime);
            // 
            // pnlHoOpc
            // 
            this.pnlHoOpc.Controls.Add(this.rdoHorExa);
            this.pnlHoOpc.Controls.Add(this.rdoRanHor);
            this.pnlHoOpc.Location = new System.Drawing.Point(100, 326);
            this.pnlHoOpc.Name = "pnlHoOpc";
            this.pnlHoOpc.Size = new System.Drawing.Size(200, 36);
            this.pnlHoOpc.TabIndex = 22;
            // 
            // rdoHorExa
            // 
            this.rdoHorExa.AutoSize = true;
            this.rdoHorExa.Location = new System.Drawing.Point(108, 11);
            this.rdoHorExa.Name = "rdoHorExa";
            this.rdoHorExa.Size = new System.Drawing.Size(84, 17);
            this.rdoHorExa.TabIndex = 24;
            this.rdoHorExa.TabStop = true;
            this.rdoHorExa.Text = "Hora Exacta";
            this.rdoHorExa.UseVisualStyleBackColor = true;
            this.rdoHorExa.CheckedChanged += new System.EventHandler(this.rdoHorExa_CheckedChanged);
            // 
            // rdoRanHor
            // 
            this.rdoRanHor.AutoSize = true;
            this.rdoRanHor.Location = new System.Drawing.Point(4, 10);
            this.rdoRanHor.Name = "rdoRanHor";
            this.rdoRanHor.Size = new System.Drawing.Size(97, 17);
            this.rdoRanHor.TabIndex = 23;
            this.rdoRanHor.TabStop = true;
            this.rdoRanHor.Text = "Rango de Hora";
            this.rdoRanHor.UseVisualStyleBackColor = true;
            this.rdoRanHor.CheckedChanged += new System.EventHandler(this.rdoRanHor_CheckedChanged);
            // 
            // btnVinRq
            // 
            this.btnVinRq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVinRq.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVinRq.Image = ((System.Drawing.Image)(resources.GetObject("btnVinRq.Image")));
            this.btnVinRq.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVinRq.Location = new System.Drawing.Point(687, 141);
            this.btnVinRq.Name = "btnVinRq";
            this.btnVinRq.Size = new System.Drawing.Size(85, 31);
            this.btnVinRq.TabIndex = 12;
            this.btnVinRq.Text = "Vincular RQ";
            this.btnVinRq.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVinRq.UseVisualStyleBackColor = true;
            this.btnVinRq.Click += new System.EventHandler(this.btnVinRq_Click);
            // 
            // dtpFecDes
            // 
            this.dtpFecDes.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecDes.Location = new System.Drawing.Point(477, 63);
            this.dtpFecDes.Name = "dtpFecDes";
            this.dtpFecDes.Size = new System.Drawing.Size(121, 21);
            this.dtpFecDes.TabIndex = 4;
            // 
            // btnVerRutOnl
            // 
            this.btnVerRutOnl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerRutOnl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerRutOnl.Image = ((System.Drawing.Image)(resources.GetObject("btnVerRutOnl.Image")));
            this.btnVerRutOnl.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVerRutOnl.Location = new System.Drawing.Point(611, 292);
            this.btnVerRutOnl.Name = "btnVerRutOnl";
            this.btnVerRutOnl.Size = new System.Drawing.Size(161, 23);
            this.btnVerRutOnl.TabIndex = 21;
            this.btnVerRutOnl.Text = "Ver Ruta Online";
            this.btnVerRutOnl.UseVisualStyleBackColor = true;
            this.btnVerRutOnl.Click += new System.EventHandler(this.btnVerRutOnl_Click);
            // 
            // btnDocVin
            // 
            this.btnDocVin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDocVin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDocVin.Image = ((System.Drawing.Image)(resources.GetObject("btnDocVin.Image")));
            this.btnDocVin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDocVin.Location = new System.Drawing.Point(611, 60);
            this.btnDocVin.Name = "btnDocVin";
            this.btnDocVin.Size = new System.Drawing.Size(132, 23);
            this.btnDocVin.TabIndex = 5;
            this.btnDocVin.Text = "Doc. Vinculados ...";
            this.btnDocVin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDocVin.UseVisualStyleBackColor = true;
            this.btnDocVin.Click += new System.EventHandler(this.btnDocVin_Click);
            // 
            // cmbTipTra
            // 
            this.cmbTipTra.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipTra.FormattingEnabled = true;
            this.cmbTipTra.ItemHeight = 13;
            this.cmbTipTra.Items.AddRange(new object[] {
            "Envia productos a obra",
            "Recoger productos de obra"});
            this.cmbTipTra.Location = new System.Drawing.Point(98, 88);
            this.cmbTipTra.Name = "cmbTipTra";
            this.cmbTipTra.Size = new System.Drawing.Size(219, 21);
            this.cmbTipTra.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(379, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Fecha Despacho:";
            // 
            // txtDesTra
            // 
            this.txtDesTra.Location = new System.Drawing.Point(526, 118);
            this.txtDesTra.Name = "txtDesTra";
            this.txtDesTra.Size = new System.Drawing.Size(246, 21);
            this.txtDesTra.TabIndex = 9;
            this.txtDesTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesTra_KeyPress);
            // 
            // txtDesMedTra
            // 
            this.txtDesMedTra.BackColor = System.Drawing.Color.White;
            this.txtDesMedTra.ForeColor = System.Drawing.Color.Blue;
            this.txtDesMedTra.Location = new System.Drawing.Point(150, 118);
            this.txtDesMedTra.Name = "txtDesMedTra";
            this.txtDesMedTra.Size = new System.Drawing.Size(199, 21);
            this.txtDesMedTra.TabIndex = 7;
            this.txtDesMedTra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesMedTra_KeyPress);
            // 
            // txtDesCor
            // 
            this.txtDesCor.BackColor = System.Drawing.Color.White;
            this.txtDesCor.ForeColor = System.Drawing.Color.Blue;
            this.txtDesCor.Location = new System.Drawing.Point(150, 289);
            this.txtDesCor.Name = "txtDesCor";
            this.txtDesCor.Size = new System.Drawing.Size(199, 21);
            this.txtDesCor.TabIndex = 19;
            this.txtDesCor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesCor_KeyPress);
            // 
            // txtEncDet
            // 
            this.txtEncDet.Location = new System.Drawing.Point(100, 484);
            this.txtEncDet.Multiline = true;
            this.txtEncDet.Name = "txtEncDet";
            this.txtEncDet.Size = new System.Drawing.Size(672, 180);
            this.txtEncDet.TabIndex = 31;
            // 
            // txtCor
            // 
            this.txtCor.Location = new System.Drawing.Point(100, 394);
            this.txtCor.Name = "txtCor";
            this.txtCor.Size = new System.Drawing.Size(348, 21);
            this.txtCor.TabIndex = 27;
            // 
            // txtCon
            // 
            this.txtCon.Location = new System.Drawing.Point(100, 368);
            this.txtCon.Name = "txtCon";
            this.txtCon.Size = new System.Drawing.Size(672, 21);
            this.txtCon.TabIndex = 26;
            // 
            // txtDesDis
            // 
            this.txtDesDis.BackColor = System.Drawing.Color.White;
            this.txtDesDis.ForeColor = System.Drawing.Color.Blue;
            this.txtDesDis.Location = new System.Drawing.Point(150, 265);
            this.txtDesDis.Name = "txtDesDis";
            this.txtDesDis.Size = new System.Drawing.Size(199, 21);
            this.txtDesDis.TabIndex = 17;
            this.txtDesDis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesDis_KeyPress);
            // 
            // txtCodTra
            // 
            this.txtCodTra.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodTra.Location = new System.Drawing.Point(474, 118);
            this.txtCodTra.Name = "txtCodTra";
            this.txtCodTra.Size = new System.Drawing.Size(51, 21);
            this.txtCodTra.TabIndex = 8;
            // 
            // txtCodMedTra
            // 
            this.txtCodMedTra.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodMedTra.ForeColor = System.Drawing.Color.DarkGray;
            this.txtCodMedTra.Location = new System.Drawing.Point(98, 118);
            this.txtCodMedTra.Name = "txtCodMedTra";
            this.txtCodMedTra.Size = new System.Drawing.Size(51, 21);
            this.txtCodMedTra.TabIndex = 6;
            this.txtCodMedTra.Tag = "1";
            this.txtCodMedTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodMedTra.TextChanged += new System.EventHandler(this.txtCodMedTra_TextChanged);
            // 
            // txtCodRut
            // 
            this.txtCodRut.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodRut.Location = new System.Drawing.Point(355, 289);
            this.txtCodRut.Name = "txtCodRut";
            this.txtCodRut.Size = new System.Drawing.Size(40, 21);
            this.txtCodRut.TabIndex = 20;
            this.txtCodRut.Tag = "1";
            this.txtCodRut.Visible = false;
            // 
            // txtCodCor
            // 
            this.txtCodCor.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodCor.ForeColor = System.Drawing.Color.DarkGray;
            this.txtCodCor.Location = new System.Drawing.Point(98, 289);
            this.txtCodCor.Name = "txtCodCor";
            this.txtCodCor.Size = new System.Drawing.Size(51, 21);
            this.txtCodCor.TabIndex = 18;
            this.txtCodCor.Tag = "1";
            this.txtCodCor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodDis
            // 
            this.txtCodDis.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodDis.ForeColor = System.Drawing.Color.DarkGray;
            this.txtCodDis.Location = new System.Drawing.Point(98, 265);
            this.txtCodDis.Name = "txtCodDis";
            this.txtCodDis.Size = new System.Drawing.Size(51, 21);
            this.txtCodDis.TabIndex = 16;
            this.txtCodDis.Tag = "1";
            this.txtCodDis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodTipRut
            // 
            this.txtCodTipRut.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodTipRut.ForeColor = System.Drawing.Color.DarkGray;
            this.txtCodTipRut.Location = new System.Drawing.Point(98, 61);
            this.txtCodTipRut.Name = "txtCodTipRut";
            this.txtCodTipRut.Size = new System.Drawing.Size(51, 21);
            this.txtCodTipRut.TabIndex = 2;
            this.txtCodTipRut.Tag = "1";
            this.txtCodTipRut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDesTipVen
            // 
            this.txtDesTipVen.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtDesTipVen.ForeColor = System.Drawing.Color.Blue;
            this.txtDesTipVen.Location = new System.Drawing.Point(150, 169);
            this.txtDesTipVen.Name = "txtDesTipVen";
            this.txtDesTipVen.Size = new System.Drawing.Size(199, 21);
            this.txtDesTipVen.TabIndex = 14;
            this.txtDesTipVen.Tag = "100";
            // 
            // txtDesRq
            // 
            this.txtDesRq.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtDesRq.Location = new System.Drawing.Point(203, 143);
            this.txtDesRq.Name = "txtDesRq";
            this.txtDesRq.Size = new System.Drawing.Size(478, 21);
            this.txtDesRq.TabIndex = 11;
            this.txtDesRq.Tag = "1";
            // 
            // txtCodTipVen
            // 
            this.txtCodTipVen.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodTipVen.Location = new System.Drawing.Point(98, 169);
            this.txtCodTipVen.Name = "txtCodTipVen";
            this.txtCodTipVen.Size = new System.Drawing.Size(51, 21);
            this.txtCodTipVen.TabIndex = 13;
            this.txtCodTipVen.Tag = "1";
            // 
            // txtCodRq
            // 
            this.txtCodRq.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodRq.Location = new System.Drawing.Point(98, 143);
            this.txtCodRq.Name = "txtCodRq";
            this.txtCodRq.Size = new System.Drawing.Size(104, 21);
            this.txtCodRq.TabIndex = 10;
            this.txtCodRq.Tag = "1";
            this.txtCodRq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumMovRut
            // 
            this.txtNumMovRut.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtNumMovRut.Location = new System.Drawing.Point(98, 35);
            this.txtNumMovRut.Name = "txtNumMovRut";
            this.txtNumMovRut.Size = new System.Drawing.Size(104, 21);
            this.txtNumMovRut.TabIndex = 1;
            this.txtNumMovRut.Tag = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tipo de trabajo:";
            // 
            // lblTra
            // 
            this.lblTra.AutoSize = true;
            this.lblTra.Location = new System.Drawing.Point(397, 125);
            this.lblTra.Name = "lblTra";
            this.lblTra.Size = new System.Drawing.Size(75, 13);
            this.lblTra.TabIndex = 0;
            this.lblTra.Text = "Transportista:";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(35, 483);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 39);
            this.label16.TabIndex = 0;
            this.label16.Text = "Encargo (Detallar):";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(27, 450);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 33);
            this.label14.TabIndex = 0;
            this.label14.Text = "Instalación a cargo de:";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(46, 326);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 33);
            this.label11.TabIndex = 0;
            this.label11.Text = "Hora Opción:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 401);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Coordinador:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(36, 375);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Contacto:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(54, 292);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Corte:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(48, 270);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Distrito:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(37, 195);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Dirección:";
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(17, 176);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(77, 13);
            this.lbl.TabIndex = 0;
            this.lbl.Text = "Tipo de Venta:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(54, 150);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "N° RQ:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Medio Transporte:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tipo de ruta:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "N° Mov:";
            // 
            // frmRuta_Item
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(991, 742);
            this.Controls.Add(this.pnlRutIte);
            this.Controls.Add(this.toolStrip2);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmRuta_Item";
            this.Text = "Ruta - Item";
            this.Load += new System.EventHandler(this.frmRuta_Item_Load);
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.pnlRutIte.ResumeLayout(false);
            this.pnlRutIte.PerformLayout();
            this.pnlInsCar.ResumeLayout(false);
            this.pnlInsCar.PerformLayout();
            this.pnlHoOpc.ResumeLayout(false);
            this.pnlHoOpc.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ToolStrip toolStrip2;
        public System.Windows.Forms.ToolStripButton btnNuevo;
        private System.Windows.Forms.ToolStripButton btnAbrir;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton btnDeshacer;
        private System.Windows.Forms.ToolStripButton btnModificar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btnEli;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnCer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumMovRut;
        private System.Windows.Forms.TextBox txtCodTipRut;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbTipTra;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDesMedTra;
        private System.Windows.Forms.TextBox txtCodMedTra;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDesTra;
        private System.Windows.Forms.TextBox txtCodTra;
        private System.Windows.Forms.Label lblTra;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDesRq;
        private System.Windows.Forms.TextBox txtCodRq;
        private System.Windows.Forms.TextBox txtDesTipVen;
        private System.Windows.Forms.TextBox txtCodTipVen;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDesCor;
        private System.Windows.Forms.TextBox txtDesDis;
        private System.Windows.Forms.TextBox txtCodCor;
        private System.Windows.Forms.TextBox txtCodDis;
        private System.Windows.Forms.Button btnVerRutOnl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton rdoRanHor;
        private System.Windows.Forms.RadioButton rdoHorExa;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCor;
        private System.Windows.Forms.TextBox txtCon;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton rdoTraiLu;
        private System.Windows.Forms.RadioButton rdoCli;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtEncDet;
        private System.Windows.Forms.DateTimePicker dtpFecDes;
        private System.Windows.Forms.Button btnDocVin;
        private System.Windows.Forms.Button btnVinRq;
        private System.Windows.Forms.Panel pnlHoOpc;
        private System.Windows.Forms.MaskedTextBox mkdHor;
        public System.Windows.Forms.Panel pnlRutIte;
        private System.Windows.Forms.Panel pnlInsCar;
        private System.Windows.Forms.TextBox txtDirRut;
        private System.Windows.Forms.TextBox txtCodRut;
        private System.Windows.Forms.Label lblNomFecMod;
        private System.Windows.Forms.TextBox txtDesTipRut;
    }
}