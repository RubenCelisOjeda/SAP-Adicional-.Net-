﻿namespace SAP_Adicional
{
    partial class frmVEN_CotImp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.fgAmb = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.chkOcuCol = new System.Windows.Forms.CheckBox();
            this.chkMosRef = new System.Windows.Forms.CheckBox();
            this.chkMosLog = new System.Windows.Forms.CheckBox();
            this.chkMosNom = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtConAdi2 = new System.Windows.Forms.TextBox();
            this.txtConAdi1 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtConEnt = new System.Windows.Forms.TextBox();
            this.txtAde = new System.Windows.Forms.TextBox();
            this.btnAneIma = new System.Windows.Forms.Button();
            this.btnVisPreImg = new System.Windows.Forms.Button();
            this.btnVisPre = new System.Windows.Forms.Button();
            this.btnImp = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAmb)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.fgAmb);
            this.groupBox1.Controls.Add(this.chkOcuCol);
            this.groupBox1.Controls.Add(this.chkMosRef);
            this.groupBox1.Controls.Add(this.chkMosLog);
            this.groupBox1.Controls.Add(this.chkMosNom);
            this.groupBox1.Location = new System.Drawing.Point(11, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(346, 304);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // fgAmb
            // 
            this.fgAmb.ColumnInfo = "3,0,0,0,0,95,Columns:0{Width:33;}\t1{Width:206;}\t2{Width:61;}\t";
            this.fgAmb.Location = new System.Drawing.Point(9, 88);
            this.fgAmb.Name = "fgAmb";
            this.fgAmb.Rows.Count = 1;
            this.fgAmb.Rows.DefaultSize = 19;
            this.fgAmb.Size = new System.Drawing.Size(331, 201);
            this.fgAmb.TabIndex = 4;
            this.fgAmb.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgAmb_KeyPressEdit);
            // 
            // chkOcuCol
            // 
            this.chkOcuCol.AutoSize = true;
            this.chkOcuCol.Location = new System.Drawing.Point(144, 51);
            this.chkOcuCol.Name = "chkOcuCol";
            this.chkOcuCol.Size = new System.Drawing.Size(137, 17);
            this.chkOcuCol.TabIndex = 3;
            this.chkOcuCol.Text = "Ocultar columna Dscto.";
            this.chkOcuCol.UseVisualStyleBackColor = true;
            // 
            // chkMosRef
            // 
            this.chkMosRef.AutoSize = true;
            this.chkMosRef.Location = new System.Drawing.Point(144, 23);
            this.chkMosRef.Name = "chkMosRef";
            this.chkMosRef.Size = new System.Drawing.Size(115, 17);
            this.chkMosRef.TabIndex = 2;
            this.chkMosRef.Text = "Mostrar referencia";
            this.chkMosRef.UseVisualStyleBackColor = true;
            // 
            // chkMosLog
            // 
            this.chkMosLog.AutoSize = true;
            this.chkMosLog.Location = new System.Drawing.Point(14, 51);
            this.chkMosLog.Name = "chkMosLog";
            this.chkMosLog.Size = new System.Drawing.Size(94, 17);
            this.chkMosLog.TabIndex = 1;
            this.chkMosLog.Text = "Mostrar Logos";
            this.chkMosLog.UseVisualStyleBackColor = true;
            // 
            // chkMosNom
            // 
            this.chkMosNom.AutoSize = true;
            this.chkMosNom.Location = new System.Drawing.Point(14, 23);
            this.chkMosNom.Name = "chkMosNom";
            this.chkMosNom.Size = new System.Drawing.Size(103, 17);
            this.chkMosNom.TabIndex = 0;
            this.chkMosNom.Text = "Mostrar Nombre";
            this.chkMosNom.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(363, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(397, 303);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Condiciones de cotización";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtConAdi2);
            this.groupBox4.Controls.Add(this.txtConAdi1);
            this.groupBox4.Location = new System.Drawing.Point(10, 122);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(381, 158);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Condiciones adicionales:";
            // 
            // txtConAdi2
            // 
            this.txtConAdi2.Location = new System.Drawing.Point(6, 93);
            this.txtConAdi2.Multiline = true;
            this.txtConAdi2.Name = "txtConAdi2";
            this.txtConAdi2.Size = new System.Drawing.Size(369, 59);
            this.txtConAdi2.TabIndex = 2;
            // 
            // txtConAdi1
            // 
            this.txtConAdi1.Location = new System.Drawing.Point(6, 20);
            this.txtConAdi1.Multiline = true;
            this.txtConAdi1.Name = "txtConAdi1";
            this.txtConAdi1.Size = new System.Drawing.Size(369, 67);
            this.txtConAdi1.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtConEnt);
            this.groupBox3.Controls.Add(this.txtAde);
            this.groupBox3.Location = new System.Drawing.Point(10, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(381, 84);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Formas de pago:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(11, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Contra entrega:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(29, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Adelantado:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(171, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 35);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ingrese solos los montos de porcentaje de pagos.";
            // 
            // txtConEnt
            // 
            this.txtConEnt.Location = new System.Drawing.Point(97, 47);
            this.txtConEnt.Name = "txtConEnt";
            this.txtConEnt.Size = new System.Drawing.Size(62, 21);
            this.txtConEnt.TabIndex = 1;
            this.txtConEnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAde
            // 
            this.txtAde.Location = new System.Drawing.Point(97, 22);
            this.txtAde.Name = "txtAde";
            this.txtAde.Size = new System.Drawing.Size(62, 21);
            this.txtAde.TabIndex = 0;
            this.txtAde.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnAneIma
            // 
            this.btnAneIma.Location = new System.Drawing.Point(287, 313);
            this.btnAneIma.Name = "btnAneIma";
            this.btnAneIma.Size = new System.Drawing.Size(118, 24);
            this.btnAneIma.TabIndex = 2;
            this.btnAneIma.Text = "&Anexo Imagenes";
            this.btnAneIma.UseVisualStyleBackColor = true;
            // 
            // btnVisPreImg
            // 
            this.btnVisPreImg.Location = new System.Drawing.Point(405, 313);
            this.btnVisPreImg.Name = "btnVisPreImg";
            this.btnVisPreImg.Size = new System.Drawing.Size(118, 24);
            this.btnVisPreImg.TabIndex = 3;
            this.btnVisPreImg.Text = "&Vista Previa (Imagen)";
            this.btnVisPreImg.UseVisualStyleBackColor = true;
            this.btnVisPreImg.Click += new System.EventHandler(this.btnVisPreImg_Click);
            // 
            // btnVisPre
            // 
            this.btnVisPre.Location = new System.Drawing.Point(523, 313);
            this.btnVisPre.Name = "btnVisPre";
            this.btnVisPre.Size = new System.Drawing.Size(118, 24);
            this.btnVisPre.TabIndex = 4;
            this.btnVisPre.Text = "&Vista Previa";
            this.btnVisPre.UseVisualStyleBackColor = true;
            this.btnVisPre.Click += new System.EventHandler(this.btnVisPre_Click);
            // 
            // btnImp
            // 
            this.btnImp.Location = new System.Drawing.Point(641, 313);
            this.btnImp.Name = "btnImp";
            this.btnImp.Size = new System.Drawing.Size(118, 24);
            this.btnImp.TabIndex = 5;
            this.btnImp.Text = "&Imprimir";
            this.btnImp.UseVisualStyleBackColor = true;
            this.btnImp.Click += new System.EventHandler(this.btnImp_Click);
            // 
            // frmVEN_CotImp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 344);
            this.Controls.Add(this.btnImp);
            this.Controls.Add(this.btnVisPre);
            this.Controls.Add(this.btnVisPreImg);
            this.Controls.Add(this.btnAneIma);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Name = "frmVEN_CotImp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Opciones de Impresión";
            this.Load += new System.EventHandler(this.frmVEN_CotImp_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmVEN_CotImp_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgAmb)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkOcuCol;
        private System.Windows.Forms.CheckBox chkMosRef;
        private System.Windows.Forms.CheckBox chkMosLog;
        private System.Windows.Forms.CheckBox chkMosNom;
        private C1.Win.C1FlexGrid.C1FlexGrid fgAmb;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtConAdi2;
        private System.Windows.Forms.TextBox txtConAdi1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtConEnt;
        private System.Windows.Forms.TextBox txtAde;
        private System.Windows.Forms.Button btnAneIma;
        private System.Windows.Forms.Button btnVisPreImg;
        private System.Windows.Forms.Button btnVisPre;
        private System.Windows.Forms.Button btnImp;
    }
}