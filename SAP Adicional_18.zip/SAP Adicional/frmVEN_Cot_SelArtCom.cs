﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using System.Windows;


namespace SAP_Adicional
{
    public partial class frmVEN_Cot_SelArtCom : Form
    {
        public string moneda;
        public string tipoventa;
        public VEN_Cot_Filtros Ven_Cot { get; set; }
        public frmVEN_Cot fvencont;
        public byte TipoColumna;

        NVEN_Cot nvc = new NVEN_Cot();

        public frmVEN_Cot_SelArtCom()
        {
            InitializeComponent();
        }

        private void formatoGrid()
        {            

            fg.Cols[0].Width = 80; //Codigo
            fg.Cols[1].Width = 400; //Des
            fg.Cols[2].Width = 60; //ValorVenta
            fg.Cols[3].Width = 60; //SIS
            fg.Cols[4].Width = 60; //SQO
            fg.Cols[5].Width = 60; //SHO
            fg.Cols[6].Width = 60; //REM

            for (int i = 2; i < fg.Cols.Count; i++)
            {
                fg.Cols[i].Format = "#,###.00";
            }            

            fg.Cols[7].Width = 100; //DESCONTINUADO

        }

        private void txtFiltro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (this.lblFiltro.Text == "") return;

            string Filtro;

            Filtro = "";

            if (e.KeyChar == 13)
            {
                if (TipoColumna == 1)
                {
                    Filtro = "WHERE [" + this.lblFiltro.Text + "] = " + this.txtFiltro.Text;
                }

                if (TipoColumna == 2)
                {
                    Filtro = "WHERE [" + this.lblFiltro.Text + "] LIKE '%" + this.txtFiltro.Text + "%'";
                }

                if (TipoColumna == 3)
                {
                    Filtro = "WHERE [" + this.lblFiltro.Text + "] = '" + this.txtFiltro.Text + "'";
                }

                try
                {

                    fg.DataSource = nvc.VEN_Cot_Art(Filtro, moneda, tipoventa);
                    fg.Focus();

                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(ex.Message, "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void frmVEN_Cot_SelArtCom_Load(object sender, EventArgs e)
        {
            this.fg.DataSource = nvc.VEN_Cot_Art(txtFiltro.Text, moneda, tipoventa);
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            formatoGrid();
        }

        private void fg_BeforeSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
        {
            if (fg.Cols[e.Col].DataType == typeof(decimal) ||
                    fg.Cols[e.Col].DataType == typeof(Int16) ||
                    fg.Cols[e.Col].DataType == typeof(Int32) ||
                    fg.Cols[e.Col].DataType == typeof(Int64))
            {//Si es numerico es 1
                TipoColumna = 1;
            }

            if (fg.Cols[e.Col].DataType == typeof(string))
            {//Si es texto es 2
                TipoColumna = 2;
            }

            if (fg.Cols[e.Col].DataType == typeof(DateTime))
            {//Si es fecha es 3
                TipoColumna = 3;
            }

            this.lblFiltro.Text = fg.Cols[e.Col].Name;
            this.txtFiltro.Focus();
        }

        private void txtFiltro_TextChanged(object sender, EventArgs e)
        {

        }

        private void fg_Click(object sender, EventArgs e)
        {

        }

        private void fg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtCan.Focus();
            }
        }

        private void txtCan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnAce.Focus();
            }
        }

        private void btnAce_Click(object sender, EventArgs e)
        {
            int Can = 0;
            int.TryParse(txtCan.Text,out Can);

            if (Can <= 0)
            {
                System.Windows.Forms.MessageBox.Show("Cantidad menor o igual a cero","SAP ADICIONAL",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            //Primero validamos que el codigo no se repita
            for (int i = 1; i < fvencont.fgCom.Rows.Count; i++)
            {
                if (fg.Rows[fg.Row][0].ToString() == fvencont.fgCom.Rows[i][0].ToString())
                {
                    System.Windows.Forms.MessageBox.Show("El codigo ya existe en la lista", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            Ven_Cot.recdat_frmVEN_Cot_ArtCom(fg.Rows[fg.Row][0].ToString(),
                fg.Rows[fg.Row][1].ToString(),
                txtCan.Text,
                fg.Rows[fg.Row][2].ToString());

            this.Dispose();
        }

        private void fg_DoubleClick(object sender, EventArgs e)
        {
            txtCan.Focus();
        }
    }
}
 