﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using CapaNegocio;
using System.Globalization;
using C1.Win.C1FlexGrid;
using System.Diagnostics;
using SAP_Adicional.Reportes;
using CrystalDecisions.CrystalReports.Engine;

namespace SAP_Adicional
{
    public partial class frmVEN_CAIF_rep : Form
    {

        NVEN_CAIF nc = new NVEN_CAIF();
        VarGlo varglo = VarGlo.Instance();


        public frmVEN_CAIF_rep()
        {
            InitializeComponent();
        }

        private void frmVEN_CAIF_Metas_Load(object sender, EventArgs e)
        {
            cbTipMet.ValueMember = "CodTipMet";
            cbTipMet.DisplayMember = "Des";

            cbTipMet.DataSource = nc.VEN_CAIF_MetTip();

            fg.Rows.Count = 2;
            CrearColumasGrid();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            this.fg.AutoGenerateColumns = true;

            this.fg.DataSource = nc.VEN_CAIF_rep(this.dtpFec.Value, Convert.ToInt16(this.cbTipMet.SelectedValue), varglo.CodUsuAct);
            
        }

        private void CrearColumasGrid()
        {
            Int32 AñoAnt;
            Int32 AñoAct;       
            
            string Mes;

            fg.Styles.Normal.WordWrap = true;
            fg.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;

            AñoAnt = dtpFec.Value.Year - 1;
            AñoAct = dtpFec.Value.Year;

            Mes = dtpFec.Value.ToString("MMMMM").ToUpper();

            fg.Rows[0].AllowMerging = true;
            fg.Styles.Fixed.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
            
            fg.Rows.Fixed = 2;
            fg.Cols.Count = 24;
            fg.Rows[1].Height = 50;

            fg.Cols[6].AllowMerging = true;
            fg.Cols[14].AllowMerging = true;

            this.fg.Cols[6].Width = 10;
            this.fg.Cols[14].Width = 10;

            C1.Win.C1FlexGrid.CellRange cr;

            cr = fg.GetCellRange(0, 0, 0, 3);
            cr.Data = " ";

            cr = fg.GetCellRange(0, 4, 0, 5);
            cr.Data = "ACUMULADOS";

            cr = fg.GetCellRange(0, 6, 1, 6);
            cr.Data = " ";

            cr = fg.GetCellRange(0, 7, 0, 14);
            cr.Data = "ACUMULADOS A LA FECHA";

            cr = fg.GetCellRange(0, 15, 1, 15);
            cr.Data = " ";

            cr = fg.GetCellRange(0, 16, 0, 23);
            cr.Data = Mes;

            //------------------------------

            cr = fg.GetCellRange(1, 0, 1, 0);
            cr.Data = "Cod. Ven";

            cr = fg.GetCellRange(1, 1, 1, 1);
            cr.Data = "Emp. Ventas";

            cr = fg.GetCellRange(1, 2, 1, 2);
            cr.Data = "CodCenVenCAIF";

            cr = fg.GetCellRange(1, 3, 1,3);
            cr.Data = "Grupo C. Venta";

            cr = fg.GetCellRange(1, 4, 1, 4);
            cr.Data = "ACUMULADO " + AñoAnt;

            cr = fg.GetCellRange(1, 5, 1, 5);
            cr.Data = "ACUMULADO " + AñoAct;

            //---------------------------------------------

            cr = fg.GetCellRange(1, 7, 1, 7);
            cr.Data = "ACUMULADO A LA FECHA " + AñoAnt;

            cr = fg.GetCellRange(1, 8, 1, 8);
            cr.Data = "ACUMULADO A LA FECHA " + AñoAct;

            cr = fg.GetCellRange(1, 9, 1, 9);
            cr.Data = AñoAct + " VS " + AñoAnt;

            cr = fg.GetCellRange(1, 10, 1, 10);
            cr.Data = "META ACUMULADA A LA FECHA " + AñoAnt;

            cr = fg.GetCellRange(1, 11, 1, 11);
            cr.Data = "ALCANCE DE LA META " + AñoAnt;

            cr = fg.GetCellRange(1, 12, 1, 12);
            cr.Data = "META ACUMULADA A LA FECHA "  + AñoAct ;

            cr = fg.GetCellRange(1, 13, 1, 13);
            cr.Data = "PENDIENTE PARA LLEGAR A LA META " + AñoAct;

            cr = fg.GetCellRange(1, 14, 1, 14);
            cr.Data = "ALCANCE DE LA META " + AñoAct;

            //------------------------------

            cr = fg.GetCellRange(1, 16, 1, 16);
            cr.Data = Mes + " " + AñoAnt;

            cr = fg.GetCellRange(1, 17, 1, 17);
            cr.Data = Mes + " " + AñoAct;

            cr = fg.GetCellRange(1, 18, 1, 18);
            cr.Data = AñoAct + " VS " + AñoAnt;

            cr = fg.GetCellRange(1, 19, 1, 19);
            cr.Data = "META " + Mes + " " + AñoAnt;

            cr = fg.GetCellRange(1, 20, 1, 20);
            cr.Data = "ALCANCE DE LA META " + AñoAnt;

            cr = fg.GetCellRange(1, 21, 1, 21);
            cr.Data = "META " + Mes + " " + AñoAct;

            cr = fg.GetCellRange(1, 22, 1, 22);
            cr.Data = "PENDIENTE PARA LLEGAR A LA META " + Mes + " " + AñoAct;

            cr = fg.GetCellRange(1, 23, 1, 23);
            cr.Data = "ALCANCE DE LA META " + AñoAct;



        }

        private void FormatoGrid()
        {
            CrearColumasGrid();

            fg.Cols[9].Style.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
            fg.Cols[11].Style.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
            fg.Cols[14].Style.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;

            fg.Cols[18].Style.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
            fg.Cols[20].Style.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;
            fg.Cols[23].Style.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.RightCenter;

            this.fg.Cols[0].Visible = false;
            this.fg.Cols[2].Visible = false;            
            this.fg.Cols[4].Visible = false;
            this.fg.Cols[5].Visible = false;

            //Recorro columnas
            for (int i = 4; i < fg.Cols.Count; i++)
            {
                this.fg.Cols[i].Width = 90;
                fg.Cols[i].Format = "#,###,###";
            }

            this.fg.Cols[1].Width = 200;
            this.fg.Cols[3].Width = 100;

            this.fg.Cols[6].Width = 10;
            this.fg.Cols[15].Width = 10;

            //Recorro filas
            for (int i = 2; i < fg.Rows.Count; i++)
            {


                if (fg.Cols[0][i].ToString() == "" && fg.Cols[2][i].ToString() != "")
                {

                    this.fg.GetCellRange(i, 0, i, fg.Cols.Count - 1).StyleNew.BackColor = Color.GreenYellow;
                }

                if (fg.Cols[0][i].ToString() == "" && fg.Cols[2][i].ToString() == "")
                {

                    this.fg.GetCellRange(i, 0, i, fg.Cols.Count - 1).StyleNew.BackColor = Color.Orange;
                }

            }

            CellStyle cs = this.fg.Styles.Add("NewFont");
            cs.Font = new Font("Arial", 6, FontStyle.Regular);        

            fg.SetCellStyle(1, 13, "NewFont");
            fg.SetCellStyle(1, 22, "NewFont");

        }

        private void fg_Click(object sender, EventArgs e)
        {

        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGrid();
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {

            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void fg_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }

        private void cbTipMet_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.dtpFec.Focus();
            }
        }

        private void dtpFec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.btnMos.Focus();
            }
        }

        private void btnMosGra_Click(object sender, EventArgs e)
        {
            frmVisor f = new frmVisor();
            rptVEN_CAIF rpt = new rptVEN_CAIF();

            Int16 Tipo = 0;

            if (fg.Row >= 3)
            {
                if (fg.Rows[fg.Row][0].ToString() != "") //Si hay codigo de empleado
                {
                    Tipo = 1;
                }

                //Si no hay codigo de empleado y si hay codigo de centro de venta
                if (fg.Rows[fg.Row][0].ToString() == "" && fg.Rows[fg.Row][2].ToString() != "")
                {
                    Tipo = 2;
                }

                //Si no hay ni codigo de empledo ni codigo de centro de venta
                if (fg.Rows[fg.Row][0].ToString() == "" && fg.Rows[fg.Row][2].ToString() == "")
                {
                    Tipo = 3;
                }

                rpt.SetDatabaseLogon("sa","SQL400%");            
                rpt.SetParameterValue("@FecFin", this.dtpFec.Value);
                rpt.SetParameterValue("@tipo", Tipo);

                TextObject text;

                text = (TextObject)rpt.Section2.ReportObjects["txtTit"];
                text.Text = "REPORTE CAIF AL " + this.dtpFec.Value.ToShortDateString();

                text = (TextObject)rpt.Section2.ReportObjects["txtCon"];
                if (Tipo == 1)
                    text.Text = "EMP. VENTAS";
                else
                    text.Text = "GRUPO C. VENTA";

                text = (TextObject)rpt.Section2.ReportObjects["txtAcuMet"];
          
                text.Text = "Acumulado Meta " + Convert.ToString(this.dtpFec.Value.Year);

                text = (TextObject)rpt.Section2.ReportObjects["txtAcuMes"];

                DateTimeFormatInfo dtinfo = new CultureInfo("es-ES", false).DateTimeFormat;
                text.Text = "Acumulado " + Convert.ToString(dtinfo.GetMonthName(this.dtpFec.Value.Month)) + "-" +
                                             Convert.ToString(this.dtpFec.Value.Year);


                //rep.SetDataSource(nc.VEN_CAIF_gra(1, this.dtpFec.Value, Tipo, Convert.ToInt32(fg.Rows[fg.Row][0]), fg.Rows[fg.Row][2].ToString()));

                f.MdiParent = this.MdiParent;

                //f.crv.ParameterFieldInfo = paramFields;

                f.crv.ReportSource = rpt;
                f.crv.Zoom(120);
                f.WindowState = FormWindowState.Maximized;
                f.Show();
                           
            }
            else
            {
                MessageBox.Show("Seleccione una linea de Emp. Ventas o de Grupo C. Venta para mostrar los graficos","SAP Adicional",
                                MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }        

        }
    }
}
