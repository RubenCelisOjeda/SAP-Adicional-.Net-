﻿namespace SAP_Adicional
{
    partial class frmCambiarContraseña
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUsu = new System.Windows.Forms.TextBox();
            this.txtCla = new System.Windows.Forms.TextBox();
            this.txtNueCla = new System.Windows.Forms.TextBox();
            this.txtConCla = new System.Windows.Forms.TextBox();
            this.btnAce = new System.Windows.Forms.Button();
            this.btnCan = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightGray;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(95, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ingrese sus datos requeridos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightGray;
            this.label2.Location = new System.Drawing.Point(59, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Usuario:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightGray;
            this.label3.Location = new System.Drawing.Point(67, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Clave:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightGray;
            this.label4.Location = new System.Drawing.Point(33, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Nueva Clave:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightGray;
            this.label5.Location = new System.Drawing.Point(8, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Confirme su Clave:";
            // 
            // txtUsu
            // 
            this.txtUsu.BackColor = System.Drawing.Color.Silver;
            this.txtUsu.ForeColor = System.Drawing.Color.Blue;
            this.txtUsu.Location = new System.Drawing.Point(114, 76);
            this.txtUsu.Name = "txtUsu";
            this.txtUsu.Size = new System.Drawing.Size(165, 21);
            this.txtUsu.TabIndex = 1;
            this.txtUsu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUsu_KeyPress);
            // 
            // txtCla
            // 
            this.txtCla.ForeColor = System.Drawing.Color.Blue;
            this.txtCla.Location = new System.Drawing.Point(114, 107);
            this.txtCla.Name = "txtCla";
            this.txtCla.PasswordChar = '*';
            this.txtCla.Size = new System.Drawing.Size(165, 21);
            this.txtCla.TabIndex = 2;
            this.txtCla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCla_KeyPress);
            // 
            // txtNueCla
            // 
            this.txtNueCla.ForeColor = System.Drawing.Color.Blue;
            this.txtNueCla.Location = new System.Drawing.Point(114, 140);
            this.txtNueCla.Name = "txtNueCla";
            this.txtNueCla.PasswordChar = '*';
            this.txtNueCla.Size = new System.Drawing.Size(165, 21);
            this.txtNueCla.TabIndex = 3;
            this.txtNueCla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNueCla_KeyPress);
            // 
            // txtConCla
            // 
            this.txtConCla.ForeColor = System.Drawing.Color.Blue;
            this.txtConCla.Location = new System.Drawing.Point(114, 171);
            this.txtConCla.Name = "txtConCla";
            this.txtConCla.PasswordChar = '*';
            this.txtConCla.Size = new System.Drawing.Size(165, 21);
            this.txtConCla.TabIndex = 4;
            this.txtConCla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtConCla_KeyPress);
            // 
            // btnAce
            // 
            this.btnAce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAce.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAce.Location = new System.Drawing.Point(62, 215);
            this.btnAce.Name = "btnAce";
            this.btnAce.Size = new System.Drawing.Size(105, 30);
            this.btnAce.TabIndex = 5;
            this.btnAce.Text = "&Aceptar";
            this.btnAce.UseVisualStyleBackColor = true;
            this.btnAce.Click += new System.EventHandler(this.btnAce_Click);
            // 
            // btnCan
            // 
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Location = new System.Drawing.Point(173, 215);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(106, 30);
            this.btnCan.TabIndex = 6;
            this.btnCan.Text = "&Cancelar";
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.btnCan);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnAce);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtConCla);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNueCla);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCla);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtUsu);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(344, 268);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // frmCambiarContraseña
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 299);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmCambiarContraseña";
            this.Text = "Cambiar Contraseña";
            this.Load += new System.EventHandler(this.frmCambiarContraseña_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUsu;
        private System.Windows.Forms.TextBox txtCla;
        private System.Windows.Forms.TextBox txtNueCla;
        private System.Windows.Forms.TextBox txtConCla;
        private System.Windows.Forms.Button btnAce;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}