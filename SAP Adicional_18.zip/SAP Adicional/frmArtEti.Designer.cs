﻿namespace SAP_Adicional
{
    partial class frmArtEti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmArtEti));
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodSap = new System.Windows.Forms.TextBox();
            this.txtCodXtr = new System.Windows.Forms.TextBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.txtDesArt = new System.Windows.Forms.TextBox();
            this.txtClaGen = new System.Windows.Forms.TextBox();
            this.txtNomUni = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCarAdi = new System.Windows.Forms.TextBox();
            this.gpbOpcImp = new System.Windows.Forms.GroupBox();
            this.cboImp = new System.Windows.Forms.ComboBox();
            this.txtCan = new System.Windows.Forms.TextBox();
            this.btnCal = new System.Windows.Forms.Button();
            this.btnEtiGra = new System.Windows.Forms.Button();
            this.btnEtiMed = new System.Windows.Forms.Button();
            this.btnEtiPeq = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.priDoc = new System.Drawing.Printing.PrintDocument();
            this.gpbOpcImp.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Buscador:";
            // 
            // txtCodSap
            // 
            this.txtCodSap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodSap.ForeColor = System.Drawing.Color.Silver;
            this.txtCodSap.Location = new System.Drawing.Point(76, 22);
            this.txtCodSap.Name = "txtCodSap";
            this.txtCodSap.Size = new System.Drawing.Size(100, 21);
            this.txtCodSap.TabIndex = 1;
            this.txtCodSap.Text = "(Código SAP)";
            this.txtCodSap.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCodSap.Enter += new System.EventHandler(this.txtCodSap_Enter);
            this.txtCodSap.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodSap_KeyPress);
            this.txtCodSap.Leave += new System.EventHandler(this.txtCodSap_Leave);
            // 
            // txtCodXtr
            // 
            this.txtCodXtr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodXtr.ForeColor = System.Drawing.Color.Silver;
            this.txtCodXtr.Location = new System.Drawing.Point(177, 22);
            this.txtCodXtr.Name = "txtCodXtr";
            this.txtCodXtr.Size = new System.Drawing.Size(100, 21);
            this.txtCodXtr.TabIndex = 2;
            this.txtCodXtr.Text = "(Código XTrazzo)";
            this.txtCodXtr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCodXtr.Enter += new System.EventHandler(this.txtCodXtr_Enter);
            this.txtCodXtr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodXtr_KeyPress);
            this.txtCodXtr.Leave += new System.EventHandler(this.txtCodXtr_Leave);
            // 
            // txtDes
            // 
            this.txtDes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDes.ForeColor = System.Drawing.Color.Silver;
            this.txtDes.Location = new System.Drawing.Point(278, 22);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(394, 21);
            this.txtDes.TabIndex = 3;
            this.txtDes.Text = "(Descripción)";
            this.txtDes.Enter += new System.EventHandler(this.txtDes_Enter);
            this.txtDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDes_KeyPress);
            this.txtDes.Leave += new System.EventHandler(this.txtDes_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Articulo a imprimir:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(92, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Codigo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Descripción:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 149);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Clasificación General:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Nombre Unico:";
            // 
            // txtCod
            // 
            this.txtCod.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCod.Location = new System.Drawing.Point(135, 88);
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(100, 21);
            this.txtCod.TabIndex = 6;
            // 
            // txtDesArt
            // 
            this.txtDesArt.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtDesArt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesArt.Location = new System.Drawing.Point(135, 114);
            this.txtDesArt.Name = "txtDesArt";
            this.txtDesArt.Size = new System.Drawing.Size(537, 21);
            this.txtDesArt.TabIndex = 8;
            // 
            // txtClaGen
            // 
            this.txtClaGen.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtClaGen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClaGen.Location = new System.Drawing.Point(135, 141);
            this.txtClaGen.Name = "txtClaGen";
            this.txtClaGen.Size = new System.Drawing.Size(537, 21);
            this.txtClaGen.TabIndex = 10;
            // 
            // txtNomUni
            // 
            this.txtNomUni.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtNomUni.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNomUni.Location = new System.Drawing.Point(135, 168);
            this.txtNomUni.Name = "txtNomUni";
            this.txtNomUni.Size = new System.Drawing.Size(537, 21);
            this.txtNomUni.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 203);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Caracteristicas Adiconal:";
            // 
            // txtCarAdi
            // 
            this.txtCarAdi.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCarAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCarAdi.Location = new System.Drawing.Point(136, 195);
            this.txtCarAdi.Name = "txtCarAdi";
            this.txtCarAdi.Size = new System.Drawing.Size(537, 21);
            this.txtCarAdi.TabIndex = 14;
            // 
            // gpbOpcImp
            // 
            this.gpbOpcImp.Controls.Add(this.cboImp);
            this.gpbOpcImp.Controls.Add(this.txtCan);
            this.gpbOpcImp.Controls.Add(this.btnCal);
            this.gpbOpcImp.Controls.Add(this.btnEtiGra);
            this.gpbOpcImp.Controls.Add(this.btnEtiMed);
            this.gpbOpcImp.Controls.Add(this.btnEtiPeq);
            this.gpbOpcImp.Controls.Add(this.label9);
            this.gpbOpcImp.Controls.Add(this.label8);
            this.gpbOpcImp.Location = new System.Drawing.Point(16, 236);
            this.gpbOpcImp.Name = "gpbOpcImp";
            this.gpbOpcImp.Size = new System.Drawing.Size(637, 157);
            this.gpbOpcImp.TabIndex = 15;
            this.gpbOpcImp.TabStop = false;
            this.gpbOpcImp.Text = "Opciones para Impresión";
            // 
            // cboImp
            // 
            this.cboImp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboImp.FormattingEnabled = true;
            this.cboImp.Location = new System.Drawing.Point(435, 26);
            this.cboImp.Name = "cboImp";
            this.cboImp.Size = new System.Drawing.Size(189, 21);
            this.cboImp.TabIndex = 22;
            // 
            // txtCan
            // 
            this.txtCan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCan.Location = new System.Drawing.Point(225, 28);
            this.txtCan.Name = "txtCan";
            this.txtCan.Size = new System.Drawing.Size(65, 21);
            this.txtCan.TabIndex = 20;
            this.txtCan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCal
            // 
            this.btnCal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCal.Image = ((System.Drawing.Image)(resources.GetObject("btnCal.Image")));
            this.btnCal.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCal.Location = new System.Drawing.Point(175, 111);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(119, 40);
            this.btnCal.TabIndex = 23;
            this.btnCal.Text = "Calibrar";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // btnEtiGra
            // 
            this.btnEtiGra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEtiGra.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEtiGra.Image = ((System.Drawing.Image)(resources.GetObject("btnEtiGra.Image")));
            this.btnEtiGra.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEtiGra.Location = new System.Drawing.Point(11, 111);
            this.btnEtiGra.Name = "btnEtiGra";
            this.btnEtiGra.Size = new System.Drawing.Size(126, 40);
            this.btnEtiGra.TabIndex = 18;
            this.btnEtiGra.Text = "Etiqueta Grande";
            this.btnEtiGra.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEtiGra.UseVisualStyleBackColor = true;
            this.btnEtiGra.Click += new System.EventHandler(this.btnEtiGra_Click);
            // 
            // btnEtiMed
            // 
            this.btnEtiMed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEtiMed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEtiMed.Image = ((System.Drawing.Image)(resources.GetObject("btnEtiMed.Image")));
            this.btnEtiMed.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEtiMed.Location = new System.Drawing.Point(11, 65);
            this.btnEtiMed.Name = "btnEtiMed";
            this.btnEtiMed.Size = new System.Drawing.Size(126, 40);
            this.btnEtiMed.TabIndex = 17;
            this.btnEtiMed.Text = "Etiqueta Mediana";
            this.btnEtiMed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEtiMed.UseVisualStyleBackColor = true;
            this.btnEtiMed.Click += new System.EventHandler(this.btnEtiMed_Click);
            // 
            // btnEtiPeq
            // 
            this.btnEtiPeq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEtiPeq.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEtiPeq.Image = ((System.Drawing.Image)(resources.GetObject("btnEtiPeq.Image")));
            this.btnEtiPeq.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEtiPeq.Location = new System.Drawing.Point(11, 20);
            this.btnEtiPeq.Name = "btnEtiPeq";
            this.btnEtiPeq.Size = new System.Drawing.Size(126, 40);
            this.btnEtiPeq.TabIndex = 16;
            this.btnEtiPeq.Text = "Etiqueta Pequeña";
            this.btnEtiPeq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEtiPeq.UseVisualStyleBackColor = true;
            this.btnEtiPeq.Click += new System.EventHandler(this.btnEtiPeq_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(375, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Impresora:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(172, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Cantidad:";
            // 
            // priDoc
            // 
            this.priDoc.OriginAtMargins = true;
            this.priDoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.priDoc_PrintPage);
            // 
            // frmArtEti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 405);
            this.Controls.Add(this.gpbOpcImp);
            this.Controls.Add(this.txtCarAdi);
            this.Controls.Add(this.txtNomUni);
            this.Controls.Add(this.txtClaGen);
            this.Controls.Add(this.txtDesArt);
            this.Controls.Add(this.txtCod);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDes);
            this.Controls.Add(this.txtCodXtr);
            this.Controls.Add(this.txtCodSap);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmArtEti";
            this.Text = "Articulo - Etiquetas";
            this.Load += new System.EventHandler(this.frmArtEti_Load);
            this.gpbOpcImp.ResumeLayout(false);
            this.gpbOpcImp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodSap;
        private System.Windows.Forms.TextBox txtCodXtr;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCod;
        private System.Windows.Forms.TextBox txtDesArt;
        private System.Windows.Forms.TextBox txtClaGen;
        private System.Windows.Forms.TextBox txtNomUni;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCarAdi;
        private System.Windows.Forms.GroupBox gpbOpcImp;
        private System.Windows.Forms.Button btnEtiPeq;
        private System.Windows.Forms.Button btnEtiGra;
        private System.Windows.Forms.Button btnEtiMed;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboImp;
        private System.Windows.Forms.TextBox txtCan;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnCal;
        private System.Drawing.Printing.PrintDocument priDoc;
    }
}