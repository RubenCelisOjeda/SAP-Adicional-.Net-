﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmAccFrm : Form, AccFrm
    {
        private int posX;
        private int posY;
        private NAccFrm accFrm = new NAccFrm();
        private VarGlo varglo = VarGlo.Instance();
        private bool Valida = true;

        public frmAccFrm()
        {
            InitializeComponent();
        }

        private void lblCer_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void lblMini_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Minimized;
            }
        }

        private void pnlBarra_MouseMove(object sender, MouseEventArgs e)
        {
            AccFrm_MoverForm(sender, e);
        }

        private void lblTit_MouseMove(object sender, MouseEventArgs e)
        {
            AccFrm_MoverForm(sender,e);
        }
        private void AccFrm_MoverForm(object sender, MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }
        }

        private void lblMaxMin_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void frmAccFrm_Load(object sender, EventArgs e)
        {
            txtCodUsu.ReadOnly = true;
            txtCodDoc.ReadOnly = true;
            txtDesUsu.Focus();

            btnCopAcc.BackColor = Color.Gainsboro;
            btnCopAcc.ForeColor = Color.DarkGray;
            btnCopAcc.Cursor = Cursors.Default;
            btnCopAcc.Enabled = false;
        }

        private void AccFrm_RecUsuEmp()
        {
          /******************************************
          * Nombre: "Recuperar los datos del usuario/empleado"
          * Proposito: <Mostrar todos los usuarios menos el usuario origen>
          * Creado por: Ruben C.
          *****************************************/
            DataTable dtRecUsuEmp = accFrm.AccFrm_RecUsuEmp(Convert.ToInt32(txtCodUsu.Text));
            if (dtRecUsuEmp.Rows.Count > 0)
            {
                DataColumn col = new DataColumn();
                col.DataType = typeof(bool);
                col.DefaultValue = false;
                col.Caption = "Copia";
                
                dtRecUsuEmp.Columns.Add(col);
                fgCopUsu.DataSource = dtRecUsuEmp;
                AccFrm_ForColFgCopUsu();
            }
        }

        private void AccFrm_ForColFgCopUsu()
        {
            fgCopUsu.Cols[0].Width = 50;
            fgCopUsu.Cols[1].Width = 110;
            fgCopUsu.Cols[2].Width = 110;
            fgCopUsu.Cols[3].Width = 50;
        }
        private void AccFrm_RecFrmUsu(int CodUsuAct)
        {
            /******************************************
            * Nombre: "Recuperar  documentos  del usuario"
            * Proposito: <Recuperar solo los documentos que esten creados>
            * Creado por: Ruben C.
            *****************************************/

            DataTable dtRecFrm = accFrm.Acc_Frm_RecFrmUsu(CodUsuAct);

            if (dtRecFrm.Rows.Count > 0)
            {
                fgAccUsu.DataSource = dtRecFrm;
                AccFrm_ForCol();
            }
            else
            {
                //cambia de formato el boton cuando el codigo de usuario no tiene documentos 
                btnCopAcc.BackColor = Color.Gainsboro;
                btnCopAcc.ForeColor = Color.DarkGray;
                btnCopAcc.Enabled = false;
                btnCopAcc.Cursor = Cursors.Default;

                MessageBox.Show("No se encontraron documentos para el usuario", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AccFrm_LimFg();
                txtDesUsu.Focus();
            }
            //siempre se limpia para los 2 casos
            txtCodDoc.Text = "";
            txtDesDoc.Text = "";
        }

        private void AccFrm_LimFg()
        {
            //limpia el grid
            DataTable dtClear = new DataTable();
            dtClear.Clear();
            fgAccUsu.DataSource = dtClear;

        }
        private void AccFrm_ForCol()
        {
            try
            {
                //formato de columnas
                for (int i = 0; i < fgAccUsu.Cols.Count; i++)
                {
                    fgAccUsu.Cols[i].TextAlignFixed = TextAlignEnum.CenterCenter;
                }

                //tamaño de la primera fila
                fgAccUsu.Rows[0].Height = 40;

                //Estilo para el color del encabezado
                CellStyle style = fgAccUsu.Styles.Add("custon");
                style.BackColor = Color.Gray;
                style.ForeColor = Color.Gold;
                fgAccUsu.Rows[0].Style = style;

                //tamaño de  columnas
                fgAccUsu.Cols[0].Width = 200;
                fgAccUsu.Cols[1].Width = 50;
                fgAccUsu.Cols[2].Width = 50;
                fgAccUsu.Cols[3].Width = 55;
                fgAccUsu.Cols[4].Width = 50;
                fgAccUsu.Cols[5].Width = 50;
                fgAccUsu.Cols[6].Width = 55;
                fgAccUsu.Cols[7].Width = 55;
                fgAccUsu.Cols[8].Width = 55;
                fgAccUsu.Cols[9].Width = 55;
                fgAccUsu.Cols[10].Width = 55;
                fgAccUsu.Cols[11].Width = 60;
                fgAccUsu.Cols[12].Width = 60;
                fgAccUsu.Cols[13].Width = 60;
                fgAccUsu.Cols[14].Width = 60;
                fgAccUsu.Cols[15].Width = 60;
                fgAccUsu.Cols[16].Width = 60;
                fgAccUsu.Cols[17].Width = 60;

                //visible
                fgAccUsu.Cols[1].Visible = false;
                fgAccUsu.Cols[2].Visible = false;

            } catch { }
            
        }

        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                AccFrm_ConDat("Usuario", "Filtro_EmpleadosUsuario", txtDesUsu.Text.Trim(),0);

                if (txtCodUsu.Text != "" )
                {
                    //cambia el formato para el boton de accesos
                    btnCopAcc.BackColor = Color.Gold;
                    btnCopAcc.ForeColor = Color.Black;
                    btnCopAcc.Cursor = Cursors.Hand;
                    btnCopAcc.Enabled = true;
                }

                //solo recupera los datos si tiene documentos el usuario
                if (Valida)
                {
                    AccFrm_RecFrmUsu(Convert.ToInt32(txtCodUsu.Text == "" ? 0 : Convert.ToInt32(txtCodUsu.Text)));
                }
            }
        }

        private void AccFrm_ConDat(string vista, string procedimiento, string param1,int CodUsu)
        {
           /******************************************
            * Nombre: "filtro de datos"
            * Proposito: <Consulta los datos del Empleado/Usuario recuperando por el codigo del usuario>
            * Ouptut : <"">
            * Creado por: Ruben C.
            *****************************************/

            DataTable dtFil = new DataTable();
            frmConsulta_Varios frm = new frmConsulta_Varios();

            DataRow row;
            dtFil = accFrm.AccFrm_Filtros(vista, procedimiento, param1, CodUsu);

            if (dtFil.Rows.Count > 1)
            {
                frm.Formulario = 45;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFil;
                frm.AccFrm_Rec = this;
                frm.ShowDialog();
            }
            else if (dtFil.Rows.Count == 1)
            {
                row = dtFil.Rows[0];

                switch (vista)
                {
                    case "Usuario":
                        txtCodUsu.Text = row["Codigo"].ToString();
                        txtDesUsu.Text = row["Empleado"].ToString();
                        txtDesDoc.Focus();
                        break;
                }
            }
            else if (dtFil.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Valida = false; //varible para validar los documento del usuario
                AccFrm_LimFg();
                txtDesUsu.Focus();
            }
        }

        public void recdat_Usu(string CodUsu, string DesUsu)
        {
            Valida = true;//varible para validar los documento del usuario
            txtCodUsu.Text = CodUsu;
            txtDesUsu.Text = DesUsu;
        }
        
        private void txtDesDoc_KeyPress(object sender, KeyPressEventArgs e)
        {
           /******************************************
            * Nombre: "Recuperar  documentos"
            * Proposito: <Recuperar los documentos faltantes del usuario filtrando con el codigo de usuario>
            * Creado por: Ruben C.
            *****************************************/

            if (e.KeyChar == (char)13)
            {
                if (txtCodUsu.Text == "")
                {
                    MessageBox.Show("Para poder filtrar ingrese un usuario","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    txtDesUsu.Focus();
                    return;
                }

                DataTable dtFil = new DataTable();
                frmConsulta_Varios frm = new frmConsulta_Varios();

                DataRow row;
                dtFil = accFrm.AccFrm_Filtros("Documento", "Filtro_UsuarioDocumento", "", Convert.ToInt32(txtCodUsu.Text));

                if (dtFil.Rows.Count > 1)
                {
                    frm.Formulario = 45;
                    frm.Text = "Documento";
                    frm.Vista = "Documento";
                    frm.dg.DataSource = dtFil;
                    frm.AccFrm_Rec = this;
                    frm.ShowDialog();
                }
                else if (dtFil.Rows.Count == 1)
                {
                    row = dtFil.Rows[0];
                    
                    txtCodDoc.Text = row["Codigo"].ToString();
                    txtDesDoc.Text = row["Nombre formulario"].ToString();

                }
                else if (dtFil.Rows.Count == 0)
                {
                    MessageBox.Show("El usuario tiene todos los documentos creados", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDesUsu.Focus();
                    return;
                }
            }

            btnAgr.Focus();
        }

        public void recdat_Doc(string CodCod, string DesDoc)
        {
            txtCodDoc.Text = CodCod;
            txtDesDoc.Text = DesDoc;
        }

        private void btnAgr_Click(object sender, EventArgs e)
        {
            /******************************************
            * Nombre: "Agregar documento"
            * Proposito: <valida los campos de textos,insertando el codigo de documento y usuario para mostrarlo en el grid>
            * Creado por: Ruben C.
            *****************************************/

            if (txtCodUsu.Text == "")
            {
                MessageBox.Show("Ingrese el codigo del usuario", "Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtDesUsu.Focus();
            }
            else if(txtCodDoc.Text == "")
            {
                MessageBox.Show("Ingrese el codigo del documento", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDesDoc.Focus();
            }
            else
            {
                //ejecutamos la consulta
                accFrm.AccFrm_InsUsu(Convert.ToInt32(txtCodUsu.Text),Convert.ToInt32(txtCodDoc.Text));
                MessageBox.Show("Se registro correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //recupera los datos guardados
                DataTable dtRecFrm = accFrm.Acc_Frm_RecFrmUsu(Convert.ToInt32(txtCodUsu.Text));

                if (dtRecFrm.Rows.Count > 0)
                {
                    fgAccUsu.DataSource = dtRecFrm;
                    AccFrm_ForCol();
                }

                txtCodDoc.Text = "";
                txtDesDoc.Text = "";
            }
        }

        private void txtCodUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtDesUsu.Focus();
            }
        }

        private void txtCodDoc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                txtDesDoc.Focus();
            }
        }

        private void btnCopAcc_Click(object sender, EventArgs e)
        {
            AccFrm_RecUsuEmp();

            //cambia de formato el boton aceptar
            btnAceCop.BackColor = Color.Gainsboro;
            btnAceCop.ForeColor = Color.DarkGray;

            //muestra el panel con los usuarios a copiar
            pnlUsuCop.Visible = true;
            btnAceCop.Enabled = false;
            btnAceCop.Cursor = Cursors.Default;
        }

        private void fgAccUsu_AfterEdit(object sender, RowColEventArgs e)
        {
          /******************************************
           * Nombre: "Flexgrid Acceso usuario"
           * Proposito: <actualiza el acceso con el codigo de usuario y documento,validando las columnas y que este seleccinado>
           * Creado por: Ruben C.
           *****************************************/

            if (fgAccUsu.IsCellSelected(fgAccUsu.Row,fgAccUsu.Col))
            {
                if (e.Col != 0 )  
                {
                    int CodUsu = Convert.ToInt32(fgAccUsu.Rows[fgAccUsu.RowSel][1]);
                    int CodDoc = Convert.ToInt32(fgAccUsu.Rows[fgAccUsu.RowSel][2]);
                    string Campo = fgAccUsu.Cols[e.Col].Caption;
                    bool Check = Convert.ToBoolean(fgAccUsu[e.Row, e.Col]);
                    accFrm.AccFrm_UpdAccUsu(CodUsu, CodDoc, Campo, Check);
                }
            }
        }

        private void fgCopUsu_AfterEdit(object sender, RowColEventArgs e)
        {
           /******************************************
           * Nombre: "Flexgrid Copia usuario"
           * Proposito: <se habilita el boton aceptar y el formato solo cuando se da check y es  = ó > a 1  para poder copiar los dato del otro usuario>
           * Creado por: Ruben C.
           *****************************************/

            if (e.Col == 3)
            {
                if (Convert.ToBoolean(fgCopUsu[e.Row, e.Col])) //por defecto true
                {
                    btnAceCop.BackColor = Color.Gold;
                    btnAceCop.ForeColor = Color.Black;
                    btnAceCop.Enabled = true;
                    btnAceCop.Cursor = Cursors.Hand;
                }
                else
                {
                    btnAceCop.BackColor = Color.Gainsboro;
                    btnAceCop.ForeColor = Color.DarkGray;
                    btnAceCop.Enabled = false;
                    btnAceCop.Cursor = Cursors.Default;
                }
            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            pnlUsuCop.Visible = false;
        }

        private void btnAce_Click(object sender, EventArgs e)
        {
           /******************************************
            * Nombre: "Aceptar copia"
            * Proposito: <Guarda todos los documentos seleccionados de los usuario a copiar> 
            * Creado por: Ruben C.
            *****************************************/

            Cursor.Current = Cursors.WaitCursor;
            int CodUsuDes;

            if (fgCopUsu.IsCellSelected(fgCopUsu.Row, fgCopUsu.Col))
            {
                for (int i = 1;i < fgCopUsu.Rows.Count;i++)
                {
                    CodUsuDes = Convert.ToInt32(fgCopUsu.Rows[i][0]);

                    if (Convert.ToInt32(fgCopUsu.Rows[i][3]) != 0)
                    {
                        accFrm.AccFrm_CopDocUsu(Convert.ToInt32(txtCodUsu.Text), CodUsuDes); //insert los accesos al usuario destino a copiar
                    }
                }
            }

            MessageBox.Show("Se copiaron los datos correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            Cursor.Current = Cursors.Default;
        }

        private void fgCopUsu_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 || e.KeyChar != 27)
            {
                e.Handled = true;   
            }
        }

        private void fgAccUsu_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //valida que no permita editar solo en la primnera columna
            if (e.Col == 0)
            {
                if (e.KeyChar != 3 || e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }
    }
}
