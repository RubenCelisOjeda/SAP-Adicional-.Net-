﻿namespace SAP_Adicional
{
    partial class frmOPE_OFVAprInsPro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.fgOFV = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.fgODV = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnMosAct = new System.Windows.Forms.Button();
            this.chkOFV = new System.Windows.Forms.CheckBox();
            this.btnExp = new System.Windows.Forms.Button();
            this.tb.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgOFV)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgODV)).BeginInit();
            this.SuspendLayout();
            // 
            // tb
            // 
            this.tb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb.Controls.Add(this.tabPage1);
            this.tb.Controls.Add(this.tabPage2);
            this.tb.Location = new System.Drawing.Point(12, 58);
            this.tb.Name = "tb";
            this.tb.SelectedIndex = 0;
            this.tb.Size = new System.Drawing.Size(1002, 600);
            this.tb.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.fgOFV);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(994, 574);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "01. Ofertas de Venta";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // fgOFV
            // 
            this.fgOFV.AllowFiltering = true;
            this.fgOFV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgOFV.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgOFV.EditOptions = ((C1.Win.C1FlexGrid.EditFlags)((((((C1.Win.C1FlexGrid.EditFlags.AutoSearch | C1.Win.C1FlexGrid.EditFlags.MultiCheck) 
            | C1.Win.C1FlexGrid.EditFlags.UseNumericEditor) 
            | C1.Win.C1FlexGrid.EditFlags.DelayedCommit) 
            | C1.Win.C1FlexGrid.EditFlags.ExitOnLeftRightKeys) 
            | C1.Win.C1FlexGrid.EditFlags.EditOnRequest)));
            this.fgOFV.Location = new System.Drawing.Point(8, 4);
            this.fgOFV.Name = "fgOFV";
            this.fgOFV.Rows.Count = 1;
            this.fgOFV.Rows.DefaultSize = 19;
            this.fgOFV.Size = new System.Drawing.Size(976, 559);
            this.fgOFV.TabIndex = 0;
            this.fgOFV.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgOFV_AfterEdit);
            this.fgOFV.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgOFV_KeyPressEdit);
            this.fgOFV.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgOFV_AfterDataRefresh);
            this.fgOFV.Click += new System.EventHandler(this.fgOFV_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.fgODV);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(994, 574);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "02. Ordenes de Venta";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // fgODV
            // 
            this.fgODV.AllowFiltering = true;
            this.fgODV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgODV.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgODV.EditOptions = ((C1.Win.C1FlexGrid.EditFlags)((((((C1.Win.C1FlexGrid.EditFlags.AutoSearch | C1.Win.C1FlexGrid.EditFlags.MultiCheck) 
            | C1.Win.C1FlexGrid.EditFlags.UseNumericEditor) 
            | C1.Win.C1FlexGrid.EditFlags.DelayedCommit) 
            | C1.Win.C1FlexGrid.EditFlags.ExitOnLeftRightKeys) 
            | C1.Win.C1FlexGrid.EditFlags.EditOnRequest)));
            this.fgODV.Location = new System.Drawing.Point(9, 8);
            this.fgODV.Name = "fgODV";
            this.fgODV.Rows.Count = 1;
            this.fgODV.Rows.DefaultSize = 19;
            this.fgODV.Size = new System.Drawing.Size(976, 559);
            this.fgODV.TabIndex = 1;
            this.fgODV.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgODV_AfterEdit);
            this.fgODV.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgODV_KeyPressEdit);
            this.fgODV.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgODV_AfterDataRefresh);
            //this.fgODV.OwnerDrawCell += new C1.Win.C1FlexGrid.OwnerDrawCellEventHandler(this.fgODV_OwnerDrawCell);
            // 
            // btnMosAct
            // 
            this.btnMosAct.Location = new System.Drawing.Point(16, 21);
            this.btnMosAct.Name = "btnMosAct";
            this.btnMosAct.Size = new System.Drawing.Size(115, 22);
            this.btnMosAct.TabIndex = 1;
            this.btnMosAct.Text = "Mostrar/Actualizar";
            this.btnMosAct.UseVisualStyleBackColor = true;
            this.btnMosAct.Click += new System.EventHandler(this.btnMosAct_Click);
            // 
            // chkOFV
            // 
            this.chkOFV.AutoSize = true;
            this.chkOFV.Location = new System.Drawing.Point(142, 25);
            this.chkOFV.Name = "chkOFV";
            this.chkOFV.Size = new System.Drawing.Size(88, 17);
            this.chkOFV.TabIndex = 2;
            this.chkOFV.Text = "Mostrar todo";
            this.chkOFV.UseVisualStyleBackColor = true;
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(250, 20);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(111, 23);
            this.btnExp.TabIndex = 5;
            this.btnExp.Text = "Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // frmOPE_OFVAprInsPro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1026, 670);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.chkOFV);
            this.Controls.Add(this.btnMosAct);
            this.Controls.Add(this.tb);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmOPE_OFVAprInsPro";
            this.Text = "OFV Aprob. Servicios de Instalación y Programación";
            this.tb.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgOFV)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgODV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tb;
        private System.Windows.Forms.TabPage tabPage1;
        private C1.Win.C1FlexGrid.C1FlexGrid fgOFV;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnMosAct;
        private System.Windows.Forms.CheckBox chkOFV;
        private C1.Win.C1FlexGrid.C1FlexGrid fgODV;
        private System.Windows.Forms.Button btnExp;
    }
}