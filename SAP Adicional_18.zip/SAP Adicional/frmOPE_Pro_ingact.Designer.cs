﻿namespace SAP_Adicional
{
    partial class frmOPE_Pro_ingact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFecIng = new System.Windows.Forms.TextBox();
            this.txtDis = new System.Windows.Forms.TextBox();
            this.txtDir = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtNumMov = new System.Windows.Forms.TextBox();
            this.btnCreAct = new System.Windows.Forms.Button();
            this.dgvRQ = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.pnDat = new System.Windows.Forms.Panel();
            this.txtCodTipPre = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTipPre = new System.Windows.Forms.TextBox();
            this.btnCan = new System.Windows.Forms.Button();
            this.chkPen = new System.Windows.Forms.CheckBox();
            this.chkTip = new System.Windows.Forms.CheckBox();
            this.txtCodTip = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.txtCodAdmPed = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtAdmPed = new System.Windows.Forms.TextBox();
            this.txtCodSup = new System.Windows.Forms.TextBox();
            this.txtCodIngOpe = new System.Windows.Forms.TextBox();
            this.txtCodDis = new System.Windows.Forms.TextBox();
            this.txtCodCom = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSup = new System.Windows.Forms.TextBox();
            this.txtIngOpe = new System.Windows.Forms.TextBox();
            this.txtDise = new System.Windows.Forms.TextBox();
            this.txtVen = new System.Windows.Forms.TextBox();
            this.txtCom = new System.Windows.Forms.TextBox();
            this.txtSocNeg = new System.Windows.Forms.TextBox();
            this.txtRQ = new System.Windows.Forms.TextBox();
            this.btnAgrRQ = new System.Windows.Forms.Button();
            this.mtxtFecIns = new System.Windows.Forms.MaskedTextBox();
            this.lblFecfin = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRQ)).BeginInit();
            this.pnDat.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "N° Proyecto:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre del Proyecto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(99, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Dirección:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(108, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Distrito:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(345, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Fecha de Ingreso:";
            // 
            // txtFecIng
            // 
            this.txtFecIng.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtFecIng.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtFecIng.Location = new System.Drawing.Point(440, 46);
            this.txtFecIng.Name = "txtFecIng";
            this.txtFecIng.ReadOnly = true;
            this.txtFecIng.Size = new System.Drawing.Size(100, 21);
            this.txtFecIng.TabIndex = 1;
            this.txtFecIng.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDis
            // 
            this.txtDis.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDis.Location = new System.Drawing.Point(149, 118);
            this.txtDis.Name = "txtDis";
            this.txtDis.Size = new System.Drawing.Size(391, 21);
            this.txtDis.TabIndex = 5;
            this.txtDis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDis_KeyPress);
            // 
            // txtDir
            // 
            this.txtDir.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDir.Location = new System.Drawing.Point(149, 94);
            this.txtDir.Name = "txtDir";
            this.txtDir.Size = new System.Drawing.Size(391, 21);
            this.txtDir.TabIndex = 4;
            this.txtDir.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDir_KeyPress);
            // 
            // txtNom
            // 
            this.txtNom.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNom.Location = new System.Drawing.Point(149, 70);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(391, 21);
            this.txtNom.TabIndex = 3;
            this.txtNom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNom_KeyPress);
            // 
            // txtNumMov
            // 
            this.txtNumMov.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumMov.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtNumMov.Location = new System.Drawing.Point(149, 46);
            this.txtNumMov.Name = "txtNumMov";
            this.txtNumMov.ReadOnly = true;
            this.txtNumMov.Size = new System.Drawing.Size(100, 21);
            this.txtNumMov.TabIndex = 0;
            this.txtNumMov.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCreAct
            // 
            this.btnCreAct.Location = new System.Drawing.Point(675, 46);
            this.btnCreAct.Name = "btnCreAct";
            this.btnCreAct.Size = new System.Drawing.Size(127, 21);
            this.btnCreAct.TabIndex = 2;
            this.btnCreAct.Text = "Crear / Actualizar";
            this.btnCreAct.UseVisualStyleBackColor = true;
            this.btnCreAct.Click += new System.EventHandler(this.btnCreAct_Click);
            // 
            // dgvRQ
            // 
            this.dgvRQ.AllowUserToAddRows = false;
            this.dgvRQ.AllowUserToDeleteRows = false;
            this.dgvRQ.AllowUserToResizeRows = false;
            this.dgvRQ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRQ.Location = new System.Drawing.Point(20, 312);
            this.dgvRQ.Name = "dgvRQ";
            this.dgvRQ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRQ.Size = new System.Drawing.Size(1344, 393);
            this.dgvRQ.TabIndex = 25;
            this.dgvRQ.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvRQ_CellBeginEdit);
            this.dgvRQ.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRQ_CellContentClick);
            this.dgvRQ.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRQ_CellValueChanged);
            this.dgvRQ.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvRQ_EditingControlShowing);
            this.dgvRQ.DoubleClick += new System.EventHandler(this.dgvRQ_DoubleClick);
            this.dgvRQ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvRQ_KeyDown);
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Location = new System.Drawing.Point(20, 148);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(1344, 2);
            this.label15.TabIndex = 32;
            // 
            // pnDat
            // 
            this.pnDat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnDat.AutoScroll = true;
            this.pnDat.Controls.Add(this.txtCodTipPre);
            this.pnDat.Controls.Add(this.label16);
            this.pnDat.Controls.Add(this.txtTipPre);
            this.pnDat.Controls.Add(this.btnCan);
            this.pnDat.Controls.Add(this.chkPen);
            this.pnDat.Controls.Add(this.chkTip);
            this.pnDat.Controls.Add(this.txtCodTip);
            this.pnDat.Controls.Add(this.label14);
            this.pnDat.Controls.Add(this.txtTipo);
            this.pnDat.Controls.Add(this.txtCodAdmPed);
            this.pnDat.Controls.Add(this.label13);
            this.pnDat.Controls.Add(this.txtAdmPed);
            this.pnDat.Controls.Add(this.txtCodSup);
            this.pnDat.Controls.Add(this.txtCodIngOpe);
            this.pnDat.Controls.Add(this.txtCodDis);
            this.pnDat.Controls.Add(this.txtCodCom);
            this.pnDat.Controls.Add(this.label12);
            this.pnDat.Controls.Add(this.label11);
            this.pnDat.Controls.Add(this.label10);
            this.pnDat.Controls.Add(this.label9);
            this.pnDat.Controls.Add(this.label8);
            this.pnDat.Controls.Add(this.label7);
            this.pnDat.Controls.Add(this.label6);
            this.pnDat.Controls.Add(this.txtSup);
            this.pnDat.Controls.Add(this.txtIngOpe);
            this.pnDat.Controls.Add(this.txtDise);
            this.pnDat.Controls.Add(this.txtVen);
            this.pnDat.Controls.Add(this.txtCom);
            this.pnDat.Controls.Add(this.txtSocNeg);
            this.pnDat.Controls.Add(this.txtRQ);
            this.pnDat.Controls.Add(this.btnAgrRQ);
            this.pnDat.Location = new System.Drawing.Point(20, 153);
            this.pnDat.Name = "pnDat";
            this.pnDat.Size = new System.Drawing.Size(1344, 153);
            this.pnDat.TabIndex = 36;
            // 
            // txtCodTipPre
            // 
            this.txtCodTipPre.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodTipPre.Location = new System.Drawing.Point(1092, 44);
            this.txtCodTipPre.Name = "txtCodTipPre";
            this.txtCodTipPre.ReadOnly = true;
            this.txtCodTipPre.Size = new System.Drawing.Size(37, 21);
            this.txtCodTipPre.TabIndex = 64;
            this.txtCodTipPre.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1026, 47);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 66;
            this.label16.Text = "Tipo Predio:";
            // 
            // txtTipPre
            // 
            this.txtTipPre.Location = new System.Drawing.Point(1128, 44);
            this.txtTipPre.Name = "txtTipPre";
            this.txtTipPre.Size = new System.Drawing.Size(121, 21);
            this.txtTipPre.TabIndex = 65;
            this.txtTipPre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipPre_KeyPress);
            // 
            // btnCan
            // 
            this.btnCan.Location = new System.Drawing.Point(113, 108);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(95, 23);
            this.btnCan.TabIndex = 61;
            this.btnCan.Text = "Cancelar";
            this.btnCan.UseVisualStyleBackColor = true;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // chkPen
            // 
            this.chkPen.AutoSize = true;
            this.chkPen.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkPen.Location = new System.Drawing.Point(121, 20);
            this.chkPen.Name = "chkPen";
            this.chkPen.Size = new System.Drawing.Size(74, 17);
            this.chkPen.TabIndex = 37;
            this.chkPen.Text = "Pendiente";
            this.chkPen.UseVisualStyleBackColor = true;
            this.chkPen.CheckedChanged += new System.EventHandler(this.chkPen_CheckedChanged);
            // 
            // chkTip
            // 
            this.chkTip.AutoSize = true;
            this.chkTip.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkTip.Location = new System.Drawing.Point(30, 19);
            this.chkTip.Name = "chkTip";
            this.chkTip.Size = new System.Drawing.Size(53, 17);
            this.chkTip.TabIndex = 36;
            this.chkTip.Text = "Tipico";
            this.chkTip.UseVisualStyleBackColor = true;
            this.chkTip.CheckedChanged += new System.EventHandler(this.chkTip_CheckedChanged);
            this.chkTip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkTip_KeyPress);
            // 
            // txtCodTip
            // 
            this.txtCodTip.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodTip.Location = new System.Drawing.Point(265, 17);
            this.txtCodTip.Name = "txtCodTip";
            this.txtCodTip.ReadOnly = true;
            this.txtCodTip.Size = new System.Drawing.Size(37, 21);
            this.txtCodTip.TabIndex = 38;
            this.txtCodTip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(234, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 13);
            this.label14.TabIndex = 63;
            this.label14.Text = "Tipo:";
            // 
            // txtTipo
            // 
            this.txtTipo.Location = new System.Drawing.Point(301, 17);
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.Size = new System.Drawing.Size(171, 21);
            this.txtTipo.TabIndex = 39;
            this.txtTipo.TextChanged += new System.EventHandler(this.txtTipo_TextChanged);
            this.txtTipo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipo_KeyPress);
            // 
            // txtCodAdmPed
            // 
            this.txtCodAdmPed.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodAdmPed.Location = new System.Drawing.Point(1092, 71);
            this.txtCodAdmPed.Name = "txtCodAdmPed";
            this.txtCodAdmPed.ReadOnly = true;
            this.txtCodAdmPed.Size = new System.Drawing.Size(37, 21);
            this.txtCodAdmPed.TabIndex = 58;
            this.txtCodAdmPed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1015, 75);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 13);
            this.label13.TabIndex = 62;
            this.label13.Text = "Adm. Pedidos:";
            // 
            // txtAdmPed
            // 
            this.txtAdmPed.Location = new System.Drawing.Point(1128, 71);
            this.txtAdmPed.Name = "txtAdmPed";
            this.txtAdmPed.Size = new System.Drawing.Size(135, 21);
            this.txtAdmPed.TabIndex = 59;
            this.txtAdmPed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdmPed_KeyPress);
            // 
            // txtCodSup
            // 
            this.txtCodSup.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodSup.Location = new System.Drawing.Point(826, 71);
            this.txtCodSup.Name = "txtCodSup";
            this.txtCodSup.ReadOnly = true;
            this.txtCodSup.Size = new System.Drawing.Size(37, 21);
            this.txtCodSup.TabIndex = 53;
            this.txtCodSup.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodIngOpe
            // 
            this.txtCodIngOpe.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodIngOpe.Location = new System.Drawing.Point(579, 71);
            this.txtCodIngOpe.Name = "txtCodIngOpe";
            this.txtCodIngOpe.ReadOnly = true;
            this.txtCodIngOpe.Size = new System.Drawing.Size(37, 21);
            this.txtCodIngOpe.TabIndex = 49;
            this.txtCodIngOpe.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodDis
            // 
            this.txtCodDis.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodDis.Location = new System.Drawing.Point(265, 71);
            this.txtCodDis.Name = "txtCodDis";
            this.txtCodDis.ReadOnly = true;
            this.txtCodDis.Size = new System.Drawing.Size(37, 21);
            this.txtCodDis.TabIndex = 45;
            this.txtCodDis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodCom
            // 
            this.txtCodCom.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodCom.Location = new System.Drawing.Point(779, 44);
            this.txtCodCom.Name = "txtCodCom";
            this.txtCodCom.ReadOnly = true;
            this.txtCodCom.Size = new System.Drawing.Size(37, 21);
            this.txtCodCom.TabIndex = 42;
            this.txtCodCom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(766, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 13);
            this.label12.TabIndex = 57;
            this.label12.Text = "Supervisor:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(222, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 56;
            this.label11.Text = "Diseño:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(488, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 13);
            this.label10.TabIndex = 54;
            this.label10.Text = "Ing. Operaciones:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 51;
            this.label9.Text = "Vendedor:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(713, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 50;
            this.label8.Text = "Complejidad:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(173, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 13);
            this.label7.TabIndex = 47;
            this.label7.Text = "Socio de Negocio:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 46;
            this.label6.Text = "N° RQ:";
            // 
            // txtSup
            // 
            this.txtSup.Location = new System.Drawing.Point(862, 71);
            this.txtSup.Name = "txtSup";
            this.txtSup.Size = new System.Drawing.Size(135, 21);
            this.txtSup.TabIndex = 55;
            this.txtSup.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSup_KeyPress);
            // 
            // txtIngOpe
            // 
            this.txtIngOpe.Location = new System.Drawing.Point(615, 71);
            this.txtIngOpe.Name = "txtIngOpe";
            this.txtIngOpe.Size = new System.Drawing.Size(140, 21);
            this.txtIngOpe.TabIndex = 52;
            this.txtIngOpe.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIngOpe_KeyPress);
            // 
            // txtDise
            // 
            this.txtDise.Location = new System.Drawing.Point(301, 71);
            this.txtDise.Name = "txtDise";
            this.txtDise.Size = new System.Drawing.Size(171, 21);
            this.txtDise.TabIndex = 48;
            this.txtDise.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDise_KeyPress);
            // 
            // txtVen
            // 
            this.txtVen.Location = new System.Drawing.Point(70, 72);
            this.txtVen.Name = "txtVen";
            this.txtVen.Size = new System.Drawing.Size(145, 21);
            this.txtVen.TabIndex = 44;
            // 
            // txtCom
            // 
            this.txtCom.Location = new System.Drawing.Point(815, 44);
            this.txtCom.Name = "txtCom";
            this.txtCom.Size = new System.Drawing.Size(121, 21);
            this.txtCom.TabIndex = 43;
            this.txtCom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCom_KeyPress);
            // 
            // txtSocNeg
            // 
            this.txtSocNeg.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtSocNeg.Location = new System.Drawing.Point(265, 44);
            this.txtSocNeg.Name = "txtSocNeg";
            this.txtSocNeg.ReadOnly = true;
            this.txtSocNeg.Size = new System.Drawing.Size(440, 21);
            this.txtSocNeg.TabIndex = 41;
            // 
            // txtRQ
            // 
            this.txtRQ.Location = new System.Drawing.Point(70, 44);
            this.txtRQ.Name = "txtRQ";
            this.txtRQ.Size = new System.Drawing.Size(77, 21);
            this.txtRQ.TabIndex = 40;
            this.txtRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRQ.TextChanged += new System.EventHandler(this.txtRQ_TextChanged);
            this.txtRQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRQ_KeyPress);
            // 
            // btnAgrRQ
            // 
            this.btnAgrRQ.Location = new System.Drawing.Point(12, 108);
            this.btnAgrRQ.Name = "btnAgrRQ";
            this.btnAgrRQ.Size = new System.Drawing.Size(95, 23);
            this.btnAgrRQ.TabIndex = 60;
            this.btnAgrRQ.Text = "Agregar";
            this.btnAgrRQ.UseVisualStyleBackColor = true;
            this.btnAgrRQ.Click += new System.EventHandler(this.btnAgrRQ_Click);
            // 
            // mtxtFecIns
            // 
            this.mtxtFecIns.Location = new System.Drawing.Point(639, 70);
            this.mtxtFecIns.Name = "mtxtFecIns";
            this.mtxtFecIns.Size = new System.Drawing.Size(163, 21);
            this.mtxtFecIns.TabIndex = 61;
            this.mtxtFecIns.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtxtFecIns.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // lblFecfin
            // 
            this.lblFecfin.AutoSize = true;
            this.lblFecfin.Location = new System.Drawing.Point(544, 73);
            this.lblFecfin.Name = "lblFecfin";
            this.lblFecfin.Size = new System.Drawing.Size(98, 13);
            this.lblFecfin.TabIndex = 60;
            this.lblFecfin.Text = "Fecha Aprox. Ins.:";
            // 
            // frmOPE_Pro_ingact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1385, 717);
            this.Controls.Add(this.mtxtFecIns);
            this.Controls.Add(this.lblFecfin);
            this.Controls.Add(this.pnDat);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dgvRQ);
            this.Controls.Add(this.btnCreAct);
            this.Controls.Add(this.txtNumMov);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.txtDir);
            this.Controls.Add(this.txtDis);
            this.Controls.Add(this.txtFecIng);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmOPE_Pro_ingact";
            this.Text = "Proyecto - Crear / Actualizar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOPE_Pro_ingact_FormClosing);
            this.Load += new System.EventHandler(this.frmOPE_Pro_ingact_Load);
            this.Shown += new System.EventHandler(this.frmOPE_Pro_ingact_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRQ)).EndInit();
            this.pnDat.ResumeLayout(false);
            this.pnDat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFecIng;
        private System.Windows.Forms.TextBox txtDis;
        private System.Windows.Forms.TextBox txtDir;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Button btnCreAct;
        private System.Windows.Forms.DataGridView dgvRQ;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox txtNumMov;
        private System.Windows.Forms.Panel pnDat;
        private System.Windows.Forms.TextBox txtCodTipPre;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtTipPre;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.CheckBox chkPen;
        private System.Windows.Forms.CheckBox chkTip;
        private System.Windows.Forms.TextBox txtCodTip;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.TextBox txtCodAdmPed;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtAdmPed;
        private System.Windows.Forms.TextBox txtCodSup;
        private System.Windows.Forms.TextBox txtCodIngOpe;
        private System.Windows.Forms.TextBox txtCodDis;
        private System.Windows.Forms.TextBox txtCodCom;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSup;
        private System.Windows.Forms.TextBox txtIngOpe;
        private System.Windows.Forms.TextBox txtDise;
        private System.Windows.Forms.TextBox txtVen;
        private System.Windows.Forms.TextBox txtCom;
        private System.Windows.Forms.TextBox txtSocNeg;
        private System.Windows.Forms.TextBox txtRQ;
        private System.Windows.Forms.Button btnAgrRQ;
        private System.Windows.Forms.MaskedTextBox mtxtFecIns;
        private System.Windows.Forms.Label lblFecfin;
    }
}