﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmCambioSesion : Form
    {
        private VarGlo varglo = VarGlo.Instance();
        private NConsultas nc = new NConsultas();
        private NLogin nl = new NLogin();
        private int _posY = 0;
        private int _posX = 0;

        public frmCambioSesion()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private void btnAce_Click(object sender, EventArgs e)
        {
            NLogin valUsu = new NLogin();
            valUsu.CreateConnectionString(this.cboBasesCer.SelectedValue.ToString());

            // Asigno valores
            string User = this.txtUsu.Text;
            string Password = this.txtCon.Text;

            if (User == "" || Password == "") //si no tiene usuario o password aparece mensaje de error
            {
                MessageBox.Show("Usuario y/o password incorrecto", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtUsu.Focus();
                return;
            }
            else
            {
                if (valUsu.ValidarUsuario(this.txtUsu.Text, this.txtCon.Text) == 0)
                {
                    MessageBox.Show("Usuario y/o password incorrecto", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    varglo.CodUsuAct = valUsu.ValidarUsuario(this.txtUsu.Text, this.txtCon.Text);
                    varglo.Base = this.cboBasesCer.SelectedValue.ToString();
                    varglo.Empresa = this.cboBasesCer.Text;

                    //Codigo para guardar el nombre en el appconfig
                    Properties.Settings.Default.DataBase = this.cboBasesCer.Text;
                    Properties.Settings.Default.RecordarUsu = this.txtUsu.Text;
                    Properties.Settings.Default.Check = this.chbRecUsu.Checked;
                    Properties.Settings.Default.Save();

                    var fPri = (frmPri)this.MdiParent;

                    if (fPri != null )
                    {
                        varglo.ValFormClose = true;
                        fPri.Close();
                    }

                    frmPri fPriNew = new frmPri();
                    fPriNew.Show();
                    fPriNew.Text = "SAP Adicional - " + varglo.Empresa;

                    varglo.ValFormClose = false;
                }
            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            this.Close();

            //Habilita el MenuStrip
            foreach (Control menu in VarGlo.Instance().frmNuevo.Controls)
            {
                if (menu is MenuStrip)
                {
                    menu.Enabled = true;
                }
            }

            //Habilita los Formularios
            foreach (var menu in VarGlo.Instance().frmNuevo.MdiChildren)
            {
                 menu.Enabled = true;
            }
        }

        private void frmCambioSesion_Load(object sender, EventArgs e)
        {
            this.CambioSesion_MosBasDeDat();
            this.CambioSesion_MostrarLogoBase();

            //recupera el nombre desde el appconfig
            this.cboBasesCer.Text = Properties.Settings.Default.DataBase;
            this.chbRecUsu.Checked = Properties.Settings.Default.Check;

            if (this.chbRecUsu.Checked)
            {
                this.txtUsu.Text = Properties.Settings.Default.RecordarUsu;
                this.chbRecUsu.Checked = true;
            }
            else
            {
                Properties.Settings.Default.Check = false;
                Properties.Settings.Default.RecordarUsu = "";
            }
        }

        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.txtCon.Focus();
            }
        }

        private void txtCon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.btnAce.Focus();
            }
        }

        private void CambioSesion_MosBasDeDat() //mostrar bases de datos
        {
            string nomBas = "";
            string nomEmp = "";

            DataTable dt = new DataTable();
            dt = nl.RecuperoBases();

            DataTable dtCrear = new DataTable();

            DataColumn CNomBas = dtCrear.Columns.Add("NombreBase");
            DataColumn CNomEmp = dtCrear.Columns.Add("NomEmp");

            DataRow row;

            this.cboBasesCer.ValueMember = "NombreBase";
            this.cboBasesCer.DisplayMember = "NomEmp";

            foreach (DataRow rows in dt.Rows)
            {
                nomBas = nl.ConectarBases(rows[0].ToString());
                nomEmp = rows[0].ToString();

                if (nomBas != "")
                {
                    row = dtCrear.NewRow();

                    row["NombreBase"] = nomEmp;
                    row["NomEmp"] = nomBas;

                    dtCrear.Rows.Add(row);
                }
            }

            this.cboBasesCer.DataSource = dtCrear;
        }

        private void cboBases_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.txtUsu.Focus();
            }
        }

        private void cboBases_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.CambioSesion_MostrarLogoBase();
        }

        private void CambioSesion_MostrarLogoBase()
        {
            if (this.cboBasesCer.Text.Contains("TRAZZO"))
            {
                this.lblHom.Visible = false;
                this.lblIlu.Visible = true;
            }
            else if (this.cboBasesCer.Text.Contains("HOME"))
            {
                this.lblIlu.Visible = false;
                this.lblHom.Visible = true;
            }
            else
            {
                this.lblIlu.Visible = false;
                this.lblHom.Visible = false;
            }
        }
        private void CambioSesion_LoginMoverFormulario(MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                _posX = e.X;
                _posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - _posX);
                Top = Top + (e.Y - _posY);
            }
        }

        private void pnlLogin_MouseMove(object sender, MouseEventArgs e)
        {
            this.CambioSesion_LoginMoverFormulario(e);
        }

        private void frmCambioSesion_MouseMove(object sender, MouseEventArgs e)
        {
            this.CambioSesion_LoginMoverFormulario(e);
        }
    }
}
