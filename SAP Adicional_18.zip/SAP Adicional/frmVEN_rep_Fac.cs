﻿
using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace SAP_Adicional
{
    public partial class frmVEN_rep_Fac : Form
    {
        NConsultas nc = new NConsultas();
        DataTable dt;
        VarGlo varglo = VarGlo.Instance();

        public frmVEN_rep_Fac()
        {
            InitializeComponent();
        }

        private void frmVEN_rep_Fac_Load(object sender, EventArgs e)
        {
            DisenoColumnas();
            dgv.Rows.Count = 5;
            ColumnasTamano();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtpInicio.Checked == false && dtpFinal.Checked == false)
                {
                    return;
                }
                else
                {
                    this.dt = nc.VEN_rep_Fac(Convert.ToDateTime(dtpInicio.Text), Convert.ToDateTime(dtpFinal.Text));
                    this.dgv.DataSource = dt;

                    FormatoGeneral();
                    ColumnasTamano();
                }
            }
            catch
            {

            }
        }
        public void DisenoColumnas()
        {
            //DISEÑO DE COLUMNAS
            dgv.Styles.Normal.WordWrap = true;

            //if (Strings.InStr(varglo.Empresa, "TRAZZO", CompareMethod.Text) != 0)
            //{
            //    dgv.Cols.Count = 54;
            //}
            //else
            //{
            //    dgv.Cols.Count = 19;
            //}

            dgv.Rows.Fixed = 5;
            dgv.Rows.Frozen = 1;
            dgv.Cols.Frozen = 6;
            dgv.AllowMerging = C1.Win.C1FlexGrid.AllowMergingEnum.FixedOnly;
            dgv.Styles.Fixed.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
            C1.Win.C1FlexGrid.CellRange rng;
            dgv.Rows[0].AllowMerging = true;
            dgv.Rows[1].AllowMerging = true;

            for (int i = 0; i < dgv.Cols.Count; i++)
            {
                dgv.Cols[i].AllowMerging = true;
            }

            rng = dgv.GetCellRange(0, 0, 4, 0);
            rng.Data = "RQ";

            rng = dgv.GetCellRange(0, 1, 4, 1);
            rng.Data = "             Nombre de Cliente " + "           ";

            rng = dgv.GetCellRange(0, 2, 4, 2);
            rng.Data = "             Nombre de la Venta " + "           ";

            rng = dgv.GetCellRange(0, 3, 4, 3);
            rng.Data = "     Empleado de Ventas " + "   ";

            rng = dgv.GetCellRange(0, 4, 4, 4);
            rng.Data = "Motivo";

            rng = dgv.GetCellRange(0, 5, 4, 5);
            rng.Data = "Centro Venta";

            rng = dgv.GetCellRange(0, 6, 4, 6);
            rng.Data = "Tipo de Venta";

            rng = dgv.GetCellRange(0, 7, 4, 7);
            rng.Data = "Tipo de Venta Relativo";

            rng = dgv.GetCellRange(0, 8, 4, 8);
            rng.Data = "Rubro";

            rng = dgv.GetCellRange(0, 9, 4, 9);
            rng.Data = "Tipo de Obra";

            rng = dgv.GetCellRange(0, 10, 4, 10);
            rng.Data = "Dimension";

            rng = dgv.GetCellRange(0, 11, 4, 11);
            rng.Data = "Moneda";

            rng = dgv.GetCellRange(0, 12, 0, 14);
            rng.Data = "V. VTA USD";

            rng = dgv.GetCellRange(1, 12, 4, 12);
            rng.Data = "Mercaderia";

            rng = dgv.GetCellRange(1, 13, 4, 13);
            rng.Data = "Servicio";

            rng = dgv.GetCellRange(1, 14, 4, 14);
            rng.Data = "Gran Total SIN IGV";

            //if (Strings.InStr(varglo.Empresa, "TRAZZO", CompareMethod.Text) != 0)
            //{
            //    //FILA PRINCIPAL
            //    rng = dgv.GetCellRange(0, 15, 0, 53); rng.Data = "V. Venta USD -Servicios";

            //    rng = dgv.GetCellRange(1, 15, 1, 18);
            //    rng.Data = "PROGRAMACIÓN";

            //    rng = dgv.GetCellRange(1, 19, 1, 32);
            //    rng.Data = "TRABAJOS DE INSTALACION";

            //    rng = dgv.GetCellRange(1, 33, 1, 36);
            //    rng.Data = "DISEÑO";

            //    rng = dgv.GetCellRange(1, 37, 1, 38);
            //    rng.Data = "SUP. Y OPERACIONES";

            //    rng = dgv.GetCellRange(1, 39, 1, 41);
            //    rng.Data = "SERV. TERCEROS";

            //    rng = dgv.GetCellRange(1, 42, 1, 48);
            //    rng.Data = "MANTENIMIENTOS Y TRABAJOS EN TALLER";

            //    rng = dgv.GetCellRange(1, 49, 1, 51);
            //    rng.Data = "MOVILIDAD Y TRANSPORTES";

            //    rng = dgv.GetCellRange(1, 52, 1, 53);
            //    rng.Data = "SERV. FINANCIEROS";

            //    CellStyle cs = this.dgv.Styles.Add("NewFont");
            //    cs.Font = new Font("Arial", 6, FontStyle.Regular);

            //    DataTable dt = new DataTable();

            //    dt = nc.VEN_rep_CotAprCol();

            //    for (int i = 0; i < dt.Rows.Count; i++)
            //    {
            //        rng = dgv.GetCellRange(2, i + 15, 4, i + 15);
            //        rng.Data = dt.Rows[i][0].ToString();
            //        dgv.SetCellStyle(1, i + 15, "NewFont");
            //        dgv.SetCellStyle(2, i + 15, "NewFont");
            //    }
            //}

            // Alinea y autosize las celdas.
            dgv.Styles.Fixed.TextAlign = C1.Win.C1FlexGrid.TextAlignEnum.CenterCenter;
        }
        public void FormatoGeneral()
        {                       
            dgv.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            dgv.Styles.Alternate.BackColor = Color.LightBlue;
            dgv.Styles.Highlight.BackColor = Color.Blue;
            dgv.Styles.Highlight.ForeColor = Color.White;
            dgv.AllowFreezing = AllowFreezingEnum.Both;
            CellStyle s = dgv.Styles[CellStyleEnum.Subtotal0];
            s.BackColor = Color.Yellow;
            s.ForeColor = Color.Blue;

            //DAR FORMATO DECIMAL A LA GRILLA
            for (int col = 11; col < dgv.Cols.Count; col++)
            {
                dgv.Cols[col].Caption = dgv.Cols[col].Format = " #,###.00";
                dgv.Cols[col].TextAlign = TextAlignEnum.RightCenter;
            }

            DisenoColumnas();        
        }
        public void ColumnasTamano()
        {
            
            dgv.Cols[0].Width = 60;
            dgv.Cols[1].Width = 195;
            dgv.Cols[2].Width = 200;
            dgv.Cols[3].Width = 130;
            dgv.Cols[4].Width = 70;//Motivo
            dgv.Cols[5].Width = 100;//Centro Venta
            dgv.Cols[6].Width = 112;
            dgv.Cols[7].Width = 70;
            dgv.Cols[8].Width = 80;
            dgv.Cols[9].Width = 70;
            dgv.Cols[10].Width = 70;
            dgv.Cols[11].Width = 50;//Moneda

            for (int col = 15; col < dgv.Cols.Count; col++)
            {
                dgv.Cols[col].Width = 90;
                dgv.Cols[col].TextAlign = TextAlignEnum.RightCenter;
            }
        }
        private void dgv_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {          
            Suma();
        }

        public void Suma()
        {
            try
            {
                for (int celda = 12; celda < dgv.Cols.Count; celda++)
                {                   
                    dgv.Subtotal(AggregateEnum.Sum , 0, -1, celda,"TOTALES");
                    dgv.Cols[0][5] = "TOTALES";
                }            
            }
            catch
            {

            }
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void dgv_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        public void ExportExcel()
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            dgv.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }    
          
        private void btnExp_Click(object sender, EventArgs e)
        {
            ExportExcel();
        }

        private void dgv_AfterFilter(object sender, EventArgs e)
        {
            Suma();
        }
    }

}
