﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SAP_Adicional
{
    public partial class frmALM_MovIngxEnc_Rango : Form, ALM_MovIngxEnc
    {
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();
        
        public frmALM_MovIngxEnc_Rango()
        {
            InitializeComponent();
        }

        private void frmALM_MovIngxEnc_Rango_Load(object sender, EventArgs e)
        {
            this.txtEnc.Focus();
        }

        private void txtEnc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Encargado", "Filtro_Alm_AlmEnc", this.txtEnc.Text.Trim(), "");

                if (varglo.Elegi == true)
                {
                    dtpInicio.Focus();
                }
            }
            
        }

        public void ConsultaDatos(string vista, string procedimiento, string param1, string param2)
        {
            DataTable dt = new DataTable();

            dt = nc.ALM_MovIngxEnc_Filtros(vista, procedimiento, param1, param2);

            if (dt.Rows.Count > 1)
            {

                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 14;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.ALM_MovIngxEnc = this;
                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Encargado":
                        txtCodEnc.Text = row["Codigo"].ToString();
                        txtEnc.Text = row["Nombre"].ToString();
                        dtpInicio.Focus();
                        break;
                   
                    default:
                        break;
                }
            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

        private void btnMos_Click(object sender, EventArgs e)
        {

            if (txtEnc.Text == "")
            {
                MessageBox.Show("Debe seleccionar un encargado");
                txtEnc.Focus();
            }
            else if (dtpInicio.Checked == false && dtpFinal.Checked == false)
            {
                return;
            }
            else
            {
                this.fg.DataSource = nc.ALM_MovIng_EncAlm(Convert.ToInt32(txtCodEnc.Text),Convert.ToDateTime(dtpInicio.Text),Convert.ToDateTime(dtpFinal.Text));
                FormatoGeneral();
            }
        }

        public void recdat_ALM_MovIngxEnc_Rango(string CodEnc, string NomEnc)
        {
            txtCodEnc.Text = CodEnc;
            txtEnc.Text = NomEnc;
            
        }

        private void dtpInicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                dtpFinal.Focus();
            }
        }

        private void dtpFinal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnMos.Focus();
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch
            {

            }
        }

        public void FormatoGeneral()
        {
            fg.Cols[1].Width = 90;
            fg.Cols[2].Width = 50;
            fg.Cols[3].Width = 50;
            fg.Cols[4].Width = 350;
            fg.Cols[6].Width = 80;
            fg.Cols[7].Width = 80;
            fg.Cols[8].Width = 240;
            fg.Cols.Frozen = 4;
            //fg.Font = new Font("Tahoma", 10F, GraphicsUnit.Pixel);
            fg.SelectionMode = SelectionModeEnum.Row;
            fg.Styles.Alternate.BackColor = Color.LightBlue;
            fg.Styles.Highlight.BackColor = Color.Blue;
            fg.Styles.Highlight.ForeColor = Color.White;
            fg.AllowFreezing = AllowFreezingEnum.Both;

            //CellStyle s = fg.Styles[CellStyleEnum.Subtotal0];
            //s.BackColor = Color.Yellow;
            //s.ForeColor = Color.Blue;
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGeneral();
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar !=3 && e.KeyChar!=27)
            {
                e.Handled = true;
            }
        }
    }
}
