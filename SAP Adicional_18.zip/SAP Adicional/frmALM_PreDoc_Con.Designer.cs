﻿namespace SAP_Adicional
{
    partial class frmALM_PreDoc_Con
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmALM_PreDoc_Con));
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDes = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpHas = new System.Windows.Forms.DateTimePicker();
            this.chkAgr = new System.Windows.Forms.CheckBox();
            this.chkSolSto = new System.Windows.Forms.CheckBox();
            this.chkInfTra = new System.Windows.Forms.CheckBox();
            this.gpbRut = new System.Windows.Forms.GroupBox();
            this.txtDesAlm = new System.Windows.Forms.TextBox();
            this.txtDesRut = new System.Windows.Forms.TextBox();
            this.txtCodAlm = new System.Windows.Forms.TextBox();
            this.txtCodRut = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnMos = new System.Windows.Forms.Button();
            this.btnLim = new System.Windows.Forms.Button();
            this.btnExp = new System.Windows.Forms.Button();
            this.btnImp = new System.Windows.Forms.Button();
            this.fgDocCon = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.gpbRut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDocCon)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Desde:";
            // 
            // dtpDes
            // 
            this.dtpDes.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDes.Location = new System.Drawing.Point(47, 15);
            this.dtpDes.Name = "dtpDes";
            this.dtpDes.Size = new System.Drawing.Size(94, 21);
            this.dtpDes.TabIndex = 1;
            this.dtpDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpDes_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(147, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hasta:";
            // 
            // dtpHas
            // 
            this.dtpHas.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpHas.Location = new System.Drawing.Point(185, 15);
            this.dtpHas.Name = "dtpHas";
            this.dtpHas.Size = new System.Drawing.Size(94, 21);
            this.dtpHas.TabIndex = 3;
            this.dtpHas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpHas_KeyPress);
            // 
            // chkAgr
            // 
            this.chkAgr.AutoSize = true;
            this.chkAgr.Location = new System.Drawing.Point(294, 15);
            this.chkAgr.Name = "chkAgr";
            this.chkAgr.Size = new System.Drawing.Size(73, 17);
            this.chkAgr.TabIndex = 4;
            this.chkAgr.Text = "Agrupado";
            this.chkAgr.UseVisualStyleBackColor = true;
            // 
            // chkSolSto
            // 
            this.chkSolSto.AutoSize = true;
            this.chkSolSto.Location = new System.Drawing.Point(373, 15);
            this.chkSolSto.Name = "chkSolSto";
            this.chkSolSto.Size = new System.Drawing.Size(95, 17);
            this.chkSolSto.TabIndex = 5;
            this.chkSolSto.Text = "Solo con Stock";
            this.chkSolSto.UseVisualStyleBackColor = true;
            // 
            // chkInfTra
            // 
            this.chkInfTra.AutoSize = true;
            this.chkInfTra.Location = new System.Drawing.Point(474, 15);
            this.chkInfTra.Name = "chkInfTra";
            this.chkInfTra.Size = new System.Drawing.Size(115, 17);
            this.chkInfTra.TabIndex = 6;
            this.chkInfTra.Text = "Info Transferencia";
            this.chkInfTra.UseVisualStyleBackColor = true;
            // 
            // gpbRut
            // 
            this.gpbRut.Controls.Add(this.txtDesAlm);
            this.gpbRut.Controls.Add(this.txtDesRut);
            this.gpbRut.Controls.Add(this.txtCodAlm);
            this.gpbRut.Controls.Add(this.txtCodRut);
            this.gpbRut.Controls.Add(this.label4);
            this.gpbRut.Controls.Add(this.label3);
            this.gpbRut.Location = new System.Drawing.Point(6, 45);
            this.gpbRut.Name = "gpbRut";
            this.gpbRut.Size = new System.Drawing.Size(605, 38);
            this.gpbRut.TabIndex = 9;
            this.gpbRut.TabStop = false;
            // 
            // txtDesAlm
            // 
            this.txtDesAlm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesAlm.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesAlm.Location = new System.Drawing.Point(379, 11);
            this.txtDesAlm.Name = "txtDesAlm";
            this.txtDesAlm.Size = new System.Drawing.Size(217, 21);
            this.txtDesAlm.TabIndex = 14;
            this.txtDesAlm.Text = "Presione enter o ingrese un almacén";
            this.txtDesAlm.Enter += new System.EventHandler(this.txtDesAlm_Enter);
            this.txtDesAlm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesAlm_KeyPress);
            this.txtDesAlm.Leave += new System.EventHandler(this.txtDesAlm_Leave);
            // 
            // txtDesRut
            // 
            this.txtDesRut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesRut.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesRut.Location = new System.Drawing.Point(71, 11);
            this.txtDesRut.Name = "txtDesRut";
            this.txtDesRut.Size = new System.Drawing.Size(217, 21);
            this.txtDesRut.TabIndex = 11;
            this.txtDesRut.Text = "Presione enter o ingrese una ruta";
            this.txtDesRut.Enter += new System.EventHandler(this.txtDesRut_Enter);
            this.txtDesRut.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesRut_KeyPress);
            this.txtDesRut.Leave += new System.EventHandler(this.txtDesRut_Leave);
            // 
            // txtCodAlm
            // 
            this.txtCodAlm.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodAlm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodAlm.Location = new System.Drawing.Point(342, 11);
            this.txtCodAlm.Name = "txtCodAlm";
            this.txtCodAlm.Size = new System.Drawing.Size(38, 21);
            this.txtCodAlm.TabIndex = 13;
            // 
            // txtCodRut
            // 
            this.txtCodRut.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodRut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodRut.Location = new System.Drawing.Point(34, 11);
            this.txtCodRut.Name = "txtCodRut";
            this.txtCodRut.Size = new System.Drawing.Size(38, 21);
            this.txtCodRut.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(294, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Almacén:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Ruta:";
            // 
            // btnMos
            // 
            this.btnMos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMos.Image = ((System.Drawing.Image)(resources.GetObject("btnMos.Image")));
            this.btnMos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMos.Location = new System.Drawing.Point(613, 15);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(125, 23);
            this.btnMos.TabIndex = 7;
            this.btnMos.Text = "Mostrar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // btnLim
            // 
            this.btnLim.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLim.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLim.Image = ((System.Drawing.Image)(resources.GetObject("btnLim.Image")));
            this.btnLim.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLim.Location = new System.Drawing.Point(737, 15);
            this.btnLim.Name = "btnLim";
            this.btnLim.Size = new System.Drawing.Size(125, 23);
            this.btnLim.TabIndex = 8;
            this.btnLim.Text = "Limpiar Filtro";
            this.btnLim.UseVisualStyleBackColor = true;
            this.btnLim.Click += new System.EventHandler(this.btnLim_Click);
            // 
            // btnExp
            // 
            this.btnExp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExp.Image = ((System.Drawing.Image)(resources.GetObject("btnExp.Image")));
            this.btnExp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExp.Location = new System.Drawing.Point(613, 55);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(125, 23);
            this.btnExp.TabIndex = 15;
            this.btnExp.Text = "&Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // btnImp
            // 
            this.btnImp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnImp.Image = global::SAP_Adicional.Properties.Resources.prtpv_16;
            this.btnImp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImp.Location = new System.Drawing.Point(737, 55);
            this.btnImp.Name = "btnImp";
            this.btnImp.Size = new System.Drawing.Size(125, 23);
            this.btnImp.TabIndex = 16;
            this.btnImp.Text = "&Imprimir";
            this.btnImp.UseVisualStyleBackColor = true;
            this.btnImp.Click += new System.EventHandler(this.btnImp_Click);
            // 
            // fgDocCon
            // 
            this.fgDocCon.AllowFiltering = true;
            this.fgDocCon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgDocCon.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgDocCon.Location = new System.Drawing.Point(6, 89);
            this.fgDocCon.Name = "fgDocCon";
            this.fgDocCon.Rows.DefaultSize = 19;
            this.fgDocCon.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgDocCon.Size = new System.Drawing.Size(1065, 318);
            this.fgDocCon.TabIndex = 17;
            this.fgDocCon.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgDocCon_KeyPressEdit);
            this.fgDocCon.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgDocCon_AfterDataRefresh);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.txtObs);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(6, 413);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(830, 55);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            // 
            // txtObs
            // 
            this.txtObs.Location = new System.Drawing.Point(34, 14);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(790, 35);
            this.txtObs.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Obs:";
            // 
            // frmALM_PreDoc_Con
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 474);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.fgDocCon);
            this.Controls.Add(this.btnImp);
            this.Controls.Add(this.btnLim);
            this.Controls.Add(this.btnExp);
            this.Controls.Add(this.btnMos);
            this.Controls.Add(this.gpbRut);
            this.Controls.Add(this.chkInfTra);
            this.Controls.Add(this.chkSolSto);
            this.Controls.Add(this.chkAgr);
            this.Controls.Add(this.dtpHas);
            this.Controls.Add(this.dtpDes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_PreDoc_Con";
            this.Text = "Documentos Consolidado";
            this.Load += new System.EventHandler(this.frmALM_PreDoc_Con_Load);
            this.gpbRut.ResumeLayout(false);
            this.gpbRut.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgDocCon)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpDes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpHas;
        private System.Windows.Forms.CheckBox chkAgr;
        private System.Windows.Forms.CheckBox chkSolSto;
        private System.Windows.Forms.CheckBox chkInfTra;
        private System.Windows.Forms.GroupBox gpbRut;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDesRut;
        private System.Windows.Forms.TextBox txtCodRut;
        private System.Windows.Forms.TextBox txtDesAlm;
        private System.Windows.Forms.TextBox txtCodAlm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.Button btnLim;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Button btnImp;
        private C1.Win.C1FlexGrid.C1FlexGrid fgDocCon;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtObs;
    }
}