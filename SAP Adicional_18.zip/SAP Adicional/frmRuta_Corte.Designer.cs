﻿namespace SAP_Adicional
{
    partial class frmRuta_Corte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMos = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodCor = new System.Windows.Forms.TextBox();
            this.txtDesCor = new System.Windows.Forms.TextBox();
            this.dtpFec = new System.Windows.Forms.DateTimePicker();
            this.btnReaCor = new System.Windows.Forms.Button();
            this.fgCorPed = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fgCorPed)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMos
            // 
            this.btnMos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMos.Location = new System.Drawing.Point(0, 21);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(139, 23);
            this.btnMos.TabIndex = 0;
            this.btnMos.Text = "&Mostrar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(159, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Corte:";
            // 
            // txtCodCor
            // 
            this.txtCodCor.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodCor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodCor.Location = new System.Drawing.Point(196, 24);
            this.txtCodCor.Name = "txtCodCor";
            this.txtCodCor.Size = new System.Drawing.Size(32, 21);
            this.txtCodCor.TabIndex = 2;
            // 
            // txtDesCor
            // 
            this.txtDesCor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesCor.Location = new System.Drawing.Point(227, 24);
            this.txtDesCor.Name = "txtDesCor";
            this.txtDesCor.Size = new System.Drawing.Size(229, 21);
            this.txtDesCor.TabIndex = 3;
            this.txtDesCor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesCor_KeyPress);
            // 
            // dtpFec
            // 
            this.dtpFec.Location = new System.Drawing.Point(462, 25);
            this.dtpFec.Name = "dtpFec";
            this.dtpFec.Size = new System.Drawing.Size(200, 21);
            this.dtpFec.TabIndex = 4;
            // 
            // btnReaCor
            // 
            this.btnReaCor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReaCor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReaCor.Location = new System.Drawing.Point(668, 23);
            this.btnReaCor.Name = "btnReaCor";
            this.btnReaCor.Size = new System.Drawing.Size(117, 23);
            this.btnReaCor.TabIndex = 5;
            this.btnReaCor.Text = "Realizar Corte";
            this.btnReaCor.UseVisualStyleBackColor = true;
            this.btnReaCor.Click += new System.EventHandler(this.btnReaCor_Click);
            // 
            // fgCorPed
            // 
            this.fgCorPed.AllowFiltering = true;
            this.fgCorPed.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgCorPed.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgCorPed.Location = new System.Drawing.Point(0, 61);
            this.fgCorPed.Name = "fgCorPed";
            this.fgCorPed.Rows.DefaultSize = 19;
            this.fgCorPed.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgCorPed.Size = new System.Drawing.Size(937, 399);
            this.fgCorPed.TabIndex = 6;
            this.fgCorPed.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgCorPed_KeyPressEdit);
            this.fgCorPed.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgCorPed_AfterDataRefresh);
            this.fgCorPed.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgCorPed_KeyDown);
            // 
            // frmRuta_Corte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(937, 489);
            this.Controls.Add(this.fgCorPed);
            this.Controls.Add(this.dtpFec);
            this.Controls.Add(this.txtDesCor);
            this.Controls.Add(this.txtCodCor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnReaCor);
            this.Controls.Add(this.btnMos);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmRuta_Corte";
            this.Text = "Corte Pedido - Corte";
            this.Load += new System.EventHandler(this.frmRuta_Corte_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fgCorPed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodCor;
        private System.Windows.Forms.TextBox txtDesCor;
        private System.Windows.Forms.DateTimePicker dtpFec;
        private System.Windows.Forms.Button btnReaCor;
        private C1.Win.C1FlexGrid.C1FlexGrid fgCorPed;
    }
}