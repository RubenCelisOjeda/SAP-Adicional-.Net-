﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmSeguridad : Form
    {
        private NConsultas nc = new NConsultas();
        private int posX;
        private int posY;

        public frmSeguridad()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private void frmSeguridad_MouseMove(object sender, MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }
        }

        private void pnlLogin_MouseMove(object sender, MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            //Pregunta si sale del sistema o continua despues de la inactividad
            DialogResult msg = MessageBox.Show("¿Desea salir del sistema?","Mensaje del sistema",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (msg == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void btnAce_Click(object sender, EventArgs e)
        {
            //Valida la contraseña ingresada del usuario
            if (this.txtCon.Text == "")
            {
                MessageBox.Show("Ingrese su contraseña","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.txtCon.Focus();
            }
            else if(nc.Seguridad_ValPass(Convert.ToInt16(VarGlo.Instance().CodUsuAct),this.txtCon.Text) == false)
            {
                MessageBox.Show("Contraseña incorrecta", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtCon.Focus();
            }
            else
            {
                //Habilita el MenuStrip del formulario principal
                foreach (Control menu in this.MdiParent.Controls)
                {
                    if (menu is MenuStrip)
                    {
                        menu.Enabled = true;
                    }
                }

                //Habilita los formualrios hijos del principal
                foreach (var menu in this.MdiParent.MdiChildren)
                {
                    menu.Enabled = true;
                }

                this.Seguridad_RenaudarTmr();
                this.Close();
            }
        }

        private void frmSeguridad_Load(object sender, EventArgs e)
        {
            //Cambie el color del titulo del sap adicional dependiendo en que base se conecto
            if (VarGlo.Instance().Base.Contains("Trazzo"))
            {
                this.lblSap.ForeColor = Color.Brown;
            }
            else if (VarGlo.Instance().Base.Contains("Home"))
            {
                this.lblSap.ForeColor = Color.Purple;
            }
            else
            {
                this.lblSap.ForeColor = Color.Black;
            }
        }

        private void Seguridad_RenaudarTmr()
        {
            //Obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            var tmr = fPri.tmrIna;
            tmr.Stop();
            tmr.Start();
        }
    }
}
