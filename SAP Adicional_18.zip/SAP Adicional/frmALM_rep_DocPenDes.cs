﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_rep_DocPenDes : Form
    {
        NConsultas nc = new NConsultas();

        public frmALM_rep_DocPenDes()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {            
                this.fg.DataSource = nc.ALM_rep_DocPenDes();
                FormatoGeneral();
            }
            catch
            {

            }
        }
        public void FormatoGeneral()
        {
            fg.Cols[2].TextAlign = TextAlignEnum.RightCenter;
            fg.Cols[3].TextAlign = TextAlignEnum.RightCenter;

            fg.Cols[0].Width = 100;
            fg.Cols[1].Width = 340;
            fg.Cols[2].Width = 90;            
            fg.Cols[3].Width = 90;
            fg.Cols[4].Width = 170;
            fg.Cols[5].Width = 90;
            fg.Cols[6].Width = 270;

            fg.Cols.Frozen = 2;
            fg.AllowFreezing = AllowFreezingEnum.Columns;
            CellStyle s = fg.Styles[CellStyleEnum.Frozen];
            s.ForeColor = Color.Blue;
          
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            DateTime Hoy = DateTime.Now;
            string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
            FileFlags flags = FileFlags.IncludeFixedCells;
            string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
            fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
            Process.Start(Ruta);
        }

        private void frmALM_rep_DocPenDes_Load(object sender, EventArgs e)
        {

        }
    }
}
