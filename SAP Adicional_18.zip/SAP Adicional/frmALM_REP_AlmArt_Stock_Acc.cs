﻿using CapaNegocio;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmALM_REP_AlmArt_Stock_Acc : Form
    {
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();        

        public frmALM_REP_AlmArt_Stock_Acc()
        {
            InitializeComponent();           
        }

        private void frmALM_REP_AlmArt_Stock_Acc_Load(object sender, EventArgs e)
        {
            txtCodAlm.ReadOnly = true;
            txtCodAre.ReadOnly = true;
        }


        public void ConsulDatos(string vista, string procedimiento, string param1="", int param2 = 0)
        {

            DataTable dt = new DataTable();
            dt = nc.ALM_AlmArt_Stock_Filtros(vista, procedimiento, param1); //

            if (dt.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 24;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                //frm.Alm_rep_AlmArt_Stock = this;

                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Empleado":

                        txtCodAre.Text = row["Codigo"].ToString();
                        txtAre.Text = row["Empleado"].ToString();
                        txtAre.Focus();
                        break;

                    case "Area":
                        txtCodAre.Text = row["Codigo"].ToString();
                        txtAre.Text = row["Descripcion"].ToString();

                        txtAre.Focus();
                        break;

                    case "Almacen":

                        txtCodAlm.Text = row["Codigo"].ToString();
                        txtAlm.Text = row["Almacen"].ToString();

                        txtAlm.Focus();
                        break;
                    default:
                        break;
                }
            }
            else if (dt.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del Sistemas", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }            
        }

        public void recdat_ALM_REP_AlmArt_Stock_Acc_Empleado(string CodEmp, string NomEmp)
        {
            txtCodAre.Text = CodEmp;
            txtAre.Text = NomEmp;
        }

        public void recdat_ALM_REP_AlmArt_Stock_Acc_Area(string CodAre, string NomAre)
        {
            txtCodAre.Text = CodAre;
            txtAre.Text = NomAre;
        }

        public void recdat_ALM_REP_AlmArt_Stock_Acc_Almacen(string Codigo, string Almacen)
        {
            txtCodAlm.Text = Codigo;
            txtAlm.Text = Almacen;
        }

        private void txtUsuAre_KeyPress(object sender, KeyPressEventArgs e)
        {
           
            if (chkSelAre.Checked == true)
            {
                ConsultDatosFormato(1, e); //area
            }
            else
            {
                ConsultDatosFormato(2, e); //empleado
            }
        }

        private void txtAlm_KeyPress(object sender, KeyPressEventArgs e)
        {
         ConsultDatosFormato(3, e); //almacen
        }

        public void ConsultDatosFormato(int consulta, KeyPressEventArgs e)
        {
            switch (consulta)
            {
                case 1:
                    if (e.KeyChar == 13)
                    {                       
                        ConsulDatos("Area", "Filtro_Area", this.txtAre.Text.Trim());
                        
                        if (txtCodAre.Text != "")
                        {
                            fg.DataSource = nc.ALM_rep_AccAlm(1, Convert.ToInt16(txtCodAre.Text), txtCodAlm.Text);
                            txtCodAlm.Clear(); txtAlm.Clear();
                            fg.Cols[0].Width = 55;
                            fg.Cols[1].Width = 250;
                            fg.Cols[2].Width = 50;
                            fg.Cols[2].Style.DataType = typeof(bool);
                            fg.Cols[2].ImageAlign = C1.Win.C1FlexGrid.ImageAlignEnum.CenterCenter;
                        }                  
                    }
                    break;

                case 2:

                    if (e.KeyChar == 13)
                    {                      
                        ConsulDatos("Empleado", "Filtro_Empleados", this.txtAre.Text.Trim()); //
                        if (txtCodAre.Text != "")
                        {               
                            fg.DataSource = nc.ALM_rep_AccAlm(0, Convert.ToInt16(txtCodAre.Text), txtCodAlm.Text);

                            txtCodAlm.Clear();txtAlm.Clear();

                            fg.Cols[0].Width = 55;
                            fg.Cols[1].Width = 250;
                            fg.Cols[2].Width = 50;
                            fg.Cols[2].Style.DataType = typeof(bool);
                            fg.Cols[2].ImageAlign = C1.Win.C1FlexGrid.ImageAlignEnum.CenterCenter;
                        }                                           
                    }
                    break;

                case 3:
                    if (e.KeyChar == 13)
                    {
                        ConsulDatos("Almacen", "Filtro_Almacenes", this.txtAlm.Text.Trim());
                        Int16 codigo = 0;

                        if (this.txtCodAre.Text != "")
                        {
                            codigo = Convert.ToInt16(txtCodAre.Text);
                        }
                        
                        if (txtCodAlm.Text != "")
                        {
                            fg.DataSource = nc.ALM_rep_AccAlm(2, codigo, txtCodAlm.Text);
                            txtCodAre.Clear(); txtAre.Clear();
                            fg.Cols[0].Width = 55;
                            fg.Cols[1].Width = 250;
                            fg.Cols[2].Width = 50;
                            fg.Cols[3].Width = 30;
                            fg.Cols[2].Style.DataType = typeof(bool);
                            fg.Cols[2].ImageAlign = C1.Win.C1FlexGrid.ImageAlignEnum.CenterCenter;
                        }                       
                    }
                    break;

                default:
                    break;
            }
        }

        private void LimpiarTextos()
        {
            txtCodAre.Clear();
            txtAre.Clear();
            txtCodAlm.Clear();
            txtAlm.Clear();
            DataTable dt = new DataTable();
            dt.Clear();
            fg.DataSource = dt;
        }
        private void chkSelAre_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSelAre.Checked == true)
            {
                LimpiarTextos();               
            }
            else
            {
                LimpiarTextos();
            }
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.Col == 2)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void fg_AfterEdit(object sender, C1.Win.C1FlexGrid.RowColEventArgs e)
        {
            if (e.Col == 2) //columna del checkbox
            {

                if (txtCodAre.Text != "" && chkSelAre.Checked == false) //filtra por empleado
                {
                    nc.ALM_rep_AlmArt_AccAlm_InsDel(Convert.ToString(fg.Rows[fg.RowSel][0]), Convert.ToInt16(txtCodAre.Text), 0, Convert.ToBoolean(fg.Rows[fg.RowSel][2])); //guarda el checkbox
                }
                else if (txtCodAre.Text != "" && chkSelAre.Checked == true) //filtra por area
                {
                    nc.ALM_rep_AlmArt_AccAlm_InsDel(Convert.ToString(fg.Rows[fg.RowSel][0]), Convert.ToInt16(txtCodAre.Text), 1, Convert.ToBoolean(fg.Rows[fg.RowSel][2]));//guarda el checkbox
                }
                else
                {   
                    nc.ALM_rep_AlmArt_AccAlm_InsDel(txtCodAlm.Text, Convert.ToInt16(fg.Rows[fg.RowSel][0]), Convert.ToByte(fg.Rows[fg.RowSel][3]), Convert.ToBoolean(fg.Rows[fg.RowSel][2]));//guarda el checkbox
                }
            }                                                                      
        }

        private void txtAre_TextChanged(object sender, EventArgs e)
        {
            //
        }
    }
}
