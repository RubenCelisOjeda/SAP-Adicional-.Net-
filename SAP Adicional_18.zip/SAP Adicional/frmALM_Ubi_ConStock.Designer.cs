﻿namespace SAP_Adicional
{
    partial class frmALM_Ubi_ConStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmALM_Ubi_ConStock));
            this.gpbParCon = new System.Windows.Forms.GroupBox();
            this.txtDesAlmP = new System.Windows.Forms.TextBox();
            this.txtCodAlmP = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.pnlFec = new System.Windows.Forms.Panel();
            this.dtpFecFin = new System.Windows.Forms.DateTimePicker();
            this.lblFIni = new System.Windows.Forms.Label();
            this.dtpFecIni = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.btnCan = new System.Windows.Forms.Button();
            this.btnAceCon = new System.Windows.Forms.Button();
            this.txtDesArtPar = new System.Windows.Forms.TextBox();
            this.txtCodArtPar = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.chkSolArt = new System.Windows.Forms.CheckBox();
            this.pnlPri = new System.Windows.Forms.Panel();
            this.pnlOpcTipMov = new System.Windows.Forms.Panel();
            this.btnCanMov = new System.Windows.Forms.Button();
            this.btnAceMov = new System.Windows.Forms.Button();
            this.rdbSalP = new System.Windows.Forms.RadioButton();
            this.rdbIngP = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.lblPre = new System.Windows.Forms.Label();
            this.btnMosTodP = new System.Windows.Forms.Button();
            this.btnConP = new System.Windows.Forms.Button();
            this.btnMosCruP = new System.Windows.Forms.Button();
            this.btnCreUbiP = new System.Windows.Forms.Button();
            this.pnlCreUbi = new System.Windows.Forms.Panel();
            this.btnVolMenUbi = new System.Windows.Forms.Button();
            this.gpbAgrUbi = new System.Windows.Forms.GroupBox();
            this.pnlUbi = new System.Windows.Forms.Panel();
            this.btnCanUbi = new System.Windows.Forms.Button();
            this.fgUbis = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.label25 = new System.Windows.Forms.Label();
            this.btnVerUbi = new System.Windows.Forms.Button();
            this.btnAgrUbi = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gpbArt = new System.Windows.Forms.GroupBox();
            this.cboSer = new System.Windows.Forms.ComboBox();
            this.txtDesRes = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCodRes = new System.Windows.Forms.TextBox();
            this.mskFecLle = new System.Windows.Forms.MaskedTextBox();
            this.txtRq = new System.Windows.Forms.TextBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.txtNumCor = new System.Windows.Forms.TextBox();
            this.txtDesArt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCodXtr = new System.Windows.Forms.TextBox();
            this.txtSto = new System.Windows.Forms.TextBox();
            this.txtCan = new System.Windows.Forms.TextBox();
            this.txtCodArtSap = new System.Windows.Forms.TextBox();
            this.txtFil = new System.Windows.Forms.TextBox();
            this.txtCol = new System.Windows.Forms.TextBox();
            this.txtRac = new System.Windows.Forms.TextBox();
            this.txtZon = new System.Windows.Forms.TextBox();
            this.btnLeeUbi = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rdbSal = new System.Windows.Forms.RadioButton();
            this.rdbIng = new System.Windows.Forms.RadioButton();
            this.txtDesAlm = new System.Windows.Forms.TextBox();
            this.txtNumDocCon = new System.Windows.Forms.TextBox();
            this.txtFec = new System.Windows.Forms.TextBox();
            this.txtCodAlm = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlMosTod = new System.Windows.Forms.Panel();
            this.chkIncEliP2 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtDesAlmP2 = new System.Windows.Forms.TextBox();
            this.txtCodAlmP2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dtpFecFinMosTod = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.dtpFecIniMosTod = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.txtDesArtP2 = new System.Windows.Forms.TextBox();
            this.txtCodArtP2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.btnVolMenMosTod = new System.Windows.Forms.Button();
            this.btnBus = new System.Windows.Forms.Button();
            this.fgMosTod = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.btnExpMosTod = new System.Windows.Forms.Button();
            this.gpbComSal = new System.Windows.Forms.GroupBox();
            this.btnExpCom = new System.Windows.Forms.Button();
            this.btnMosCom = new System.Windows.Forms.Button();
            this.fgCru = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.cboCom = new System.Windows.Forms.ComboBox();
            this.fgUbi = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.pnlCru = new System.Windows.Forms.Panel();
            this.btnVolMenCru = new System.Windows.Forms.Button();
            this.stpUbi = new System.Windows.Forms.StatusStrip();
            this.tslPgbUbi = new System.Windows.Forms.ToolStripProgressBar();
            this.lblPor = new System.Windows.Forms.Label();
            this.btnPauExp = new System.Windows.Forms.Button();
            this.btnCanExp = new System.Windows.Forms.Button();
            this.pnlCon = new System.Windows.Forms.Panel();
            this.btnVolMenCon = new System.Windows.Forms.Button();
            this.btnConPar = new System.Windows.Forms.Button();
            this.chkIncEli = new System.Windows.Forms.CheckBox();
            this.btnExpConPar = new System.Windows.Forms.Button();
            this.gpbParCon.SuspendLayout();
            this.pnlFec.SuspendLayout();
            this.pnlPri.SuspendLayout();
            this.pnlOpcTipMov.SuspendLayout();
            this.pnlCreUbi.SuspendLayout();
            this.gpbAgrUbi.SuspendLayout();
            this.pnlUbi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgUbis)).BeginInit();
            this.gpbArt.SuspendLayout();
            this.pnlMosTod.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMosTod)).BeginInit();
            this.gpbComSal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgUbi)).BeginInit();
            this.pnlCru.SuspendLayout();
            this.stpUbi.SuspendLayout();
            this.pnlCon.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbParCon
            // 
            this.gpbParCon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gpbParCon.BackColor = System.Drawing.Color.White;
            this.gpbParCon.Controls.Add(this.txtDesAlmP);
            this.gpbParCon.Controls.Add(this.txtCodAlmP);
            this.gpbParCon.Controls.Add(this.label18);
            this.gpbParCon.Controls.Add(this.pnlFec);
            this.gpbParCon.Controls.Add(this.btnCan);
            this.gpbParCon.Controls.Add(this.btnAceCon);
            this.gpbParCon.Controls.Add(this.txtDesArtPar);
            this.gpbParCon.Controls.Add(this.txtCodArtPar);
            this.gpbParCon.Controls.Add(this.label17);
            this.gpbParCon.Controls.Add(this.chkSolArt);
            this.gpbParCon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gpbParCon.ForeColor = System.Drawing.Color.Black;
            this.gpbParCon.Location = new System.Drawing.Point(-273, 83);
            this.gpbParCon.Name = "gpbParCon";
            this.gpbParCon.Size = new System.Drawing.Size(830, 149);
            this.gpbParCon.TabIndex = 0;
            this.gpbParCon.TabStop = false;
            this.gpbParCon.Text = "Parametro consulta";
            this.gpbParCon.Visible = false;
            // 
            // txtDesAlmP
            // 
            this.txtDesAlmP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesAlmP.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesAlmP.Location = new System.Drawing.Point(132, 55);
            this.txtDesAlmP.Name = "txtDesAlmP";
            this.txtDesAlmP.Size = new System.Drawing.Size(215, 21);
            this.txtDesAlmP.TabIndex = 6;
            this.txtDesAlmP.Text = "Presione enter o ingrese un almacén";
            this.txtDesAlmP.Enter += new System.EventHandler(this.txtDesAlmP_Enter);
            this.txtDesAlmP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesAlmP_KeyPress);
            this.txtDesAlmP.Leave += new System.EventHandler(this.txtDesAlmP_Leave);
            // 
            // txtCodAlmP
            // 
            this.txtCodAlmP.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodAlmP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodAlmP.ForeColor = System.Drawing.Color.Blue;
            this.txtCodAlmP.Location = new System.Drawing.Point(69, 55);
            this.txtCodAlmP.Name = "txtCodAlmP";
            this.txtCodAlmP.Size = new System.Drawing.Size(64, 21);
            this.txtCodAlmP.TabIndex = 5;
            this.txtCodAlmP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodAlmP_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 13);
            this.label18.TabIndex = 95;
            this.label18.Text = "Almacén:";
            // 
            // pnlFec
            // 
            this.pnlFec.Controls.Add(this.dtpFecFin);
            this.pnlFec.Controls.Add(this.lblFIni);
            this.pnlFec.Controls.Add(this.dtpFecIni);
            this.pnlFec.Controls.Add(this.label16);
            this.pnlFec.Location = new System.Drawing.Point(6, 14);
            this.pnlFec.Name = "pnlFec";
            this.pnlFec.Size = new System.Drawing.Size(360, 30);
            this.pnlFec.TabIndex = 1;
            // 
            // dtpFecFin
            // 
            this.dtpFecFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecFin.Location = new System.Drawing.Point(239, 7);
            this.dtpFecFin.Name = "dtpFecFin";
            this.dtpFecFin.Size = new System.Drawing.Size(102, 21);
            this.dtpFecFin.TabIndex = 3;
            this.dtpFecFin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpFecFin_KeyPress);
            // 
            // lblFIni
            // 
            this.lblFIni.AutoSize = true;
            this.lblFIni.Location = new System.Drawing.Point(9, 14);
            this.lblFIni.Name = "lblFIni";
            this.lblFIni.Size = new System.Drawing.Size(51, 13);
            this.lblFIni.TabIndex = 8;
            this.lblFIni.Text = "F. Inicial:";
            // 
            // dtpFecIni
            // 
            this.dtpFecIni.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecIni.Location = new System.Drawing.Point(63, 8);
            this.dtpFecIni.Name = "dtpFecIni";
            this.dtpFecIni.Size = new System.Drawing.Size(104, 21);
            this.dtpFecIni.TabIndex = 2;
            this.dtpFecIni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpFecIni_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(194, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 13);
            this.label16.TabIndex = 7;
            this.label16.Text = "F. Final:";
            // 
            // btnCan
            // 
            this.btnCan.BackColor = System.Drawing.SystemColors.Control;
            this.btnCan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCan.Image = ((System.Drawing.Image)(resources.GetObject("btnCan.Image")));
            this.btnCan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCan.Location = new System.Drawing.Point(429, 109);
            this.btnCan.Name = "btnCan";
            this.btnCan.Size = new System.Drawing.Size(94, 34);
            this.btnCan.TabIndex = 10;
            this.btnCan.Text = "  &Cancelar";
            this.btnCan.UseVisualStyleBackColor = false;
            this.btnCan.Click += new System.EventHandler(this.btnCan_Click);
            // 
            // btnAceCon
            // 
            this.btnAceCon.BackColor = System.Drawing.SystemColors.Control;
            this.btnAceCon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAceCon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAceCon.Image = ((System.Drawing.Image)(resources.GetObject("btnAceCon.Image")));
            this.btnAceCon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceCon.Location = new System.Drawing.Point(332, 109);
            this.btnAceCon.Name = "btnAceCon";
            this.btnAceCon.Size = new System.Drawing.Size(98, 34);
            this.btnAceCon.TabIndex = 9;
            this.btnAceCon.Text = "&Aceptar";
            this.btnAceCon.UseVisualStyleBackColor = false;
            this.btnAceCon.Click += new System.EventHandler(this.btnAceCon_Click);
            // 
            // txtDesArtPar
            // 
            this.txtDesArtPar.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesArtPar.Location = new System.Drawing.Point(168, 82);
            this.txtDesArtPar.Name = "txtDesArtPar";
            this.txtDesArtPar.Size = new System.Drawing.Size(660, 21);
            this.txtDesArtPar.TabIndex = 8;
            this.txtDesArtPar.Text = "Presione enter o ingrese un artìculo";
            this.txtDesArtPar.Enter += new System.EventHandler(this.txtDesArtPar_Enter);
            this.txtDesArtPar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArtPar_KeyPress);
            this.txtDesArtPar.Leave += new System.EventHandler(this.txtDesArtPar_Leave);
            // 
            // txtCodArtPar
            // 
            this.txtCodArtPar.Location = new System.Drawing.Point(69, 82);
            this.txtCodArtPar.Name = "txtCodArtPar";
            this.txtCodArtPar.Size = new System.Drawing.Size(100, 21);
            this.txtCodArtPar.TabIndex = 7;
            this.txtCodArtPar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArtPar_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(21, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Artículo:";
            // 
            // chkSolArt
            // 
            this.chkSolArt.AutoSize = true;
            this.chkSolArt.Location = new System.Drawing.Point(372, 20);
            this.chkSolArt.Name = "chkSolArt";
            this.chkSolArt.Size = new System.Drawing.Size(84, 17);
            this.chkSolArt.TabIndex = 4;
            this.chkSolArt.Text = "Solo artículo";
            this.chkSolArt.UseVisualStyleBackColor = true;
            this.chkSolArt.CheckedChanged += new System.EventHandler(this.chkSolArt_CheckedChanged);
            this.chkSolArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.chkSolArt_KeyPress);
            // 
            // pnlPri
            // 
            this.pnlPri.Controls.Add(this.pnlOpcTipMov);
            this.pnlPri.Controls.Add(this.lblPre);
            this.pnlPri.Controls.Add(this.btnMosTodP);
            this.pnlPri.Controls.Add(this.btnConP);
            this.pnlPri.Controls.Add(this.btnMosCruP);
            this.pnlPri.Controls.Add(this.btnCreUbiP);
            this.pnlPri.Location = new System.Drawing.Point(704, 28);
            this.pnlPri.Name = "pnlPri";
            this.pnlPri.Size = new System.Drawing.Size(266, 238);
            this.pnlPri.TabIndex = 75;
            this.pnlPri.Visible = false;
            // 
            // pnlOpcTipMov
            // 
            this.pnlOpcTipMov.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlOpcTipMov.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.pnlOpcTipMov.Controls.Add(this.btnCanMov);
            this.pnlOpcTipMov.Controls.Add(this.btnAceMov);
            this.pnlOpcTipMov.Controls.Add(this.rdbSalP);
            this.pnlOpcTipMov.Controls.Add(this.rdbIngP);
            this.pnlOpcTipMov.Controls.Add(this.label15);
            this.pnlOpcTipMov.Location = new System.Drawing.Point(-91, 13);
            this.pnlOpcTipMov.Name = "pnlOpcTipMov";
            this.pnlOpcTipMov.Size = new System.Drawing.Size(473, 203);
            this.pnlOpcTipMov.TabIndex = 88;
            this.pnlOpcTipMov.Visible = false;
            // 
            // btnCanMov
            // 
            this.btnCanMov.BackColor = System.Drawing.SystemColors.Control;
            this.btnCanMov.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCanMov.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCanMov.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCanMov.Image = ((System.Drawing.Image)(resources.GetObject("btnCanMov.Image")));
            this.btnCanMov.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCanMov.Location = new System.Drawing.Point(254, 146);
            this.btnCanMov.Name = "btnCanMov";
            this.btnCanMov.Size = new System.Drawing.Size(94, 34);
            this.btnCanMov.TabIndex = 3;
            this.btnCanMov.Text = "  &Cancelar";
            this.btnCanMov.UseVisualStyleBackColor = false;
            this.btnCanMov.Click += new System.EventHandler(this.btnCanMov_Click);
            // 
            // btnAceMov
            // 
            this.btnAceMov.BackColor = System.Drawing.SystemColors.Control;
            this.btnAceMov.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAceMov.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAceMov.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceMov.Image = ((System.Drawing.Image)(resources.GetObject("btnAceMov.Image")));
            this.btnAceMov.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceMov.Location = new System.Drawing.Point(114, 146);
            this.btnAceMov.Name = "btnAceMov";
            this.btnAceMov.Size = new System.Drawing.Size(98, 34);
            this.btnAceMov.TabIndex = 2;
            this.btnAceMov.Text = "&Aceptar";
            this.btnAceMov.UseVisualStyleBackColor = false;
            this.btnAceMov.Click += new System.EventHandler(this.btnAceMov_Click);
            // 
            // rdbSalP
            // 
            this.rdbSalP.AutoSize = true;
            this.rdbSalP.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSalP.ForeColor = System.Drawing.Color.White;
            this.rdbSalP.Location = new System.Drawing.Point(195, 103);
            this.rdbSalP.Name = "rdbSalP";
            this.rdbSalP.Size = new System.Drawing.Size(64, 20);
            this.rdbSalP.TabIndex = 1;
            this.rdbSalP.TabStop = true;
            this.rdbSalP.Text = "Salida";
            this.rdbSalP.UseVisualStyleBackColor = true;
            // 
            // rdbIngP
            // 
            this.rdbIngP.AutoSize = true;
            this.rdbIngP.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbIngP.ForeColor = System.Drawing.Color.White;
            this.rdbIngP.Location = new System.Drawing.Point(195, 73);
            this.rdbIngP.Name = "rdbIngP";
            this.rdbIngP.Size = new System.Drawing.Size(76, 20);
            this.rdbIngP.TabIndex = 0;
            this.rdbIngP.TabStop = true;
            this.rdbIngP.Text = "Ingreso";
            this.rdbIngP.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gold;
            this.label15.Location = new System.Drawing.Point(77, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(328, 25);
            this.label15.TabIndex = 106;
            this.label15.Text = "Seleccione un tipo de movimiento";
            // 
            // lblPre
            // 
            this.lblPre.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPre.AutoSize = true;
            this.lblPre.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.lblPre.Location = new System.Drawing.Point(-26, -44);
            this.lblPre.Name = "lblPre";
            this.lblPre.Size = new System.Drawing.Size(346, 35);
            this.lblPre.TabIndex = 5;
            this.lblPre.Text = "¿Qué quieres hacer?";
            // 
            // btnMosTodP
            // 
            this.btnMosTodP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMosTodP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnMosTodP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosTodP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMosTodP.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMosTodP.ForeColor = System.Drawing.Color.White;
            this.btnMosTodP.Image = ((System.Drawing.Image)(resources.GetObject("btnMosTodP.Image")));
            this.btnMosTodP.Location = new System.Drawing.Point(102, 113);
            this.btnMosTodP.Name = "btnMosTodP";
            this.btnMosTodP.Size = new System.Drawing.Size(262, 102);
            this.btnMosTodP.TabIndex = 4;
            this.btnMosTodP.Text = "Mostrar todo";
            this.btnMosTodP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMosTodP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnMosTodP.UseVisualStyleBackColor = false;
            this.btnMosTodP.Click += new System.EventHandler(this.btnMosTodP_Click);
            // 
            // btnConP
            // 
            this.btnConP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnConP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnConP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConP.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConP.ForeColor = System.Drawing.Color.White;
            this.btnConP.Image = ((System.Drawing.Image)(resources.GetObject("btnConP.Image")));
            this.btnConP.Location = new System.Drawing.Point(279, 28);
            this.btnConP.Name = "btnConP";
            this.btnConP.Size = new System.Drawing.Size(85, 79);
            this.btnConP.TabIndex = 3;
            this.btnConP.Text = "Consultar";
            this.btnConP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnConP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnConP.UseVisualStyleBackColor = false;
            this.btnConP.Click += new System.EventHandler(this.btnConP_Click);
            // 
            // btnMosCruP
            // 
            this.btnMosCruP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMosCruP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnMosCruP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosCruP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMosCruP.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMosCruP.ForeColor = System.Drawing.Color.White;
            this.btnMosCruP.Image = ((System.Drawing.Image)(resources.GetObject("btnMosCruP.Image")));
            this.btnMosCruP.Location = new System.Drawing.Point(-63, 113);
            this.btnMosCruP.Name = "btnMosCruP";
            this.btnMosCruP.Size = new System.Drawing.Size(159, 102);
            this.btnMosCruP.TabIndex = 2;
            this.btnMosCruP.Text = "Mostrar cruce";
            this.btnMosCruP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMosCruP.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnMosCruP.UseVisualStyleBackColor = false;
            this.btnMosCruP.Click += new System.EventHandler(this.btnMosCruP_Click);
            // 
            // btnCreUbiP
            // 
            this.btnCreUbiP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCreUbiP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.btnCreUbiP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreUbiP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCreUbiP.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreUbiP.ForeColor = System.Drawing.Color.White;
            this.btnCreUbiP.Image = ((System.Drawing.Image)(resources.GetObject("btnCreUbiP.Image")));
            this.btnCreUbiP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCreUbiP.Location = new System.Drawing.Point(-63, 28);
            this.btnCreUbiP.Name = "btnCreUbiP";
            this.btnCreUbiP.Size = new System.Drawing.Size(336, 79);
            this.btnCreUbiP.TabIndex = 1;
            this.btnCreUbiP.Text = "Crear ubicación de Sotck";
            this.btnCreUbiP.UseVisualStyleBackColor = false;
            this.btnCreUbiP.Click += new System.EventHandler(this.btnCreUbiP_Click);
            // 
            // pnlCreUbi
            // 
            this.pnlCreUbi.Controls.Add(this.btnVolMenUbi);
            this.pnlCreUbi.Controls.Add(this.gpbAgrUbi);
            this.pnlCreUbi.Location = new System.Drawing.Point(44, 28);
            this.pnlCreUbi.Name = "pnlCreUbi";
            this.pnlCreUbi.Size = new System.Drawing.Size(162, 242);
            this.pnlCreUbi.TabIndex = 83;
            this.pnlCreUbi.Visible = false;
            // 
            // btnVolMenUbi
            // 
            this.btnVolMenUbi.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMenUbi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolMenUbi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolMenUbi.Image = ((System.Drawing.Image)(resources.GetObject("btnVolMenUbi.Image")));
            this.btnVolMenUbi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolMenUbi.Location = new System.Drawing.Point(3, 3);
            this.btnVolMenUbi.Name = "btnVolMenUbi";
            this.btnVolMenUbi.Size = new System.Drawing.Size(101, 33);
            this.btnVolMenUbi.TabIndex = 0;
            this.btnVolMenUbi.Text = " Volver a menú";
            this.btnVolMenUbi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVolMenUbi.UseVisualStyleBackColor = false;
            this.btnVolMenUbi.Click += new System.EventHandler(this.btnVolMenUbi_Click);
            // 
            // gpbAgrUbi
            // 
            this.gpbAgrUbi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gpbAgrUbi.Controls.Add(this.pnlUbi);
            this.gpbAgrUbi.Controls.Add(this.btnVerUbi);
            this.gpbAgrUbi.Controls.Add(this.btnAgrUbi);
            this.gpbAgrUbi.Controls.Add(this.label9);
            this.gpbAgrUbi.Controls.Add(this.label8);
            this.gpbAgrUbi.Controls.Add(this.label7);
            this.gpbAgrUbi.Controls.Add(this.gpbArt);
            this.gpbAgrUbi.Controls.Add(this.txtFil);
            this.gpbAgrUbi.Controls.Add(this.txtCol);
            this.gpbAgrUbi.Controls.Add(this.txtRac);
            this.gpbAgrUbi.Controls.Add(this.txtZon);
            this.gpbAgrUbi.Controls.Add(this.btnLeeUbi);
            this.gpbAgrUbi.Controls.Add(this.label5);
            this.gpbAgrUbi.Controls.Add(this.label4);
            this.gpbAgrUbi.Controls.Add(this.rdbSal);
            this.gpbAgrUbi.Controls.Add(this.rdbIng);
            this.gpbAgrUbi.Controls.Add(this.txtDesAlm);
            this.gpbAgrUbi.Controls.Add(this.txtNumDocCon);
            this.gpbAgrUbi.Controls.Add(this.txtFec);
            this.gpbAgrUbi.Controls.Add(this.txtCodAlm);
            this.gpbAgrUbi.Controls.Add(this.label3);
            this.gpbAgrUbi.Controls.Add(this.label2);
            this.gpbAgrUbi.Controls.Add(this.label1);
            this.gpbAgrUbi.Location = new System.Drawing.Point(-347, -10);
            this.gpbAgrUbi.Name = "gpbAgrUbi";
            this.gpbAgrUbi.Size = new System.Drawing.Size(1163, 317);
            this.gpbAgrUbi.TabIndex = 106;
            this.gpbAgrUbi.TabStop = false;
            this.gpbAgrUbi.Text = "Agregar Ubicación con Stock";
            // 
            // pnlUbi
            // 
            this.pnlUbi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.pnlUbi.Controls.Add(this.btnCanUbi);
            this.pnlUbi.Controls.Add(this.fgUbis);
            this.pnlUbi.Controls.Add(this.label25);
            this.pnlUbi.Location = new System.Drawing.Point(513, 15);
            this.pnlUbi.Name = "pnlUbi";
            this.pnlUbi.Size = new System.Drawing.Size(311, 230);
            this.pnlUbi.TabIndex = 112;
            this.pnlUbi.Visible = false;
            // 
            // btnCanUbi
            // 
            this.btnCanUbi.BackColor = System.Drawing.SystemColors.Control;
            this.btnCanUbi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCanUbi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCanUbi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCanUbi.Image = ((System.Drawing.Image)(resources.GetObject("btnCanUbi.Image")));
            this.btnCanUbi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCanUbi.Location = new System.Drawing.Point(117, 189);
            this.btnCanUbi.Name = "btnCanUbi";
            this.btnCanUbi.Size = new System.Drawing.Size(94, 34);
            this.btnCanUbi.TabIndex = 1;
            this.btnCanUbi.Text = "  &Cancelar";
            this.btnCanUbi.UseVisualStyleBackColor = false;
            this.btnCanUbi.Click += new System.EventHandler(this.btnCanUbi_Click);
            // 
            // fgUbis
            // 
            this.fgUbis.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgUbis.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgUbis.Location = new System.Drawing.Point(9, 50);
            this.fgUbis.Name = "fgUbis";
            this.fgUbis.Rows.DefaultSize = 19;
            this.fgUbis.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgUbis.Size = new System.Drawing.Size(292, 136);
            this.fgUbis.TabIndex = 0;
            this.fgUbis.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgUbis_KeyPressEdit);
            this.fgUbis.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgUbis_AfterDataRefresh);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Gold;
            this.label25.Location = new System.Drawing.Point(103, 16);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(108, 23);
            this.label25.TabIndex = 0;
            this.label25.Text = "Ubicaciones";
            // 
            // btnVerUbi
            // 
            this.btnVerUbi.BackColor = System.Drawing.SystemColors.Control;
            this.btnVerUbi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerUbi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerUbi.Image = ((System.Drawing.Image)(resources.GetObject("btnVerUbi.Image")));
            this.btnVerUbi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVerUbi.Location = new System.Drawing.Point(378, 106);
            this.btnVerUbi.Name = "btnVerUbi";
            this.btnVerUbi.Size = new System.Drawing.Size(121, 23);
            this.btnVerUbi.TabIndex = 12;
            this.btnVerUbi.Text = "Ver ubicaciones";
            this.btnVerUbi.UseVisualStyleBackColor = false;
            this.btnVerUbi.Click += new System.EventHandler(this.btnVerUbi_Click);
            // 
            // btnAgrUbi
            // 
            this.btnAgrUbi.BackColor = System.Drawing.SystemColors.Control;
            this.btnAgrUbi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgrUbi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAgrUbi.Image = ((System.Drawing.Image)(resources.GetObject("btnAgrUbi.Image")));
            this.btnAgrUbi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgrUbi.Location = new System.Drawing.Point(74, 275);
            this.btnAgrUbi.Name = "btnAgrUbi";
            this.btnAgrUbi.Size = new System.Drawing.Size(107, 35);
            this.btnAgrUbi.TabIndex = 25;
            this.btnAgrUbi.Text = "   &Agregar";
            this.btnAgrUbi.UseVisualStyleBackColor = false;
            this.btnAgrUbi.Click += new System.EventHandler(this.btnAgrUbi_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 232);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 110;
            this.label9.Text = "Serie:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 192);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 109;
            this.label8.Text = "Cantidad:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 163);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 13);
            this.label7.TabIndex = 108;
            this.label7.Text = "Artículo:";
            // 
            // gpbArt
            // 
            this.gpbArt.Controls.Add(this.cboSer);
            this.gpbArt.Controls.Add(this.txtDesRes);
            this.gpbArt.Controls.Add(this.label6);
            this.gpbArt.Controls.Add(this.txtCodRes);
            this.gpbArt.Controls.Add(this.mskFecLle);
            this.gpbArt.Controls.Add(this.txtRq);
            this.gpbArt.Controls.Add(this.txtObs);
            this.gpbArt.Controls.Add(this.txtNumCor);
            this.gpbArt.Controls.Add(this.txtDesArt);
            this.gpbArt.Controls.Add(this.label13);
            this.gpbArt.Controls.Add(this.label11);
            this.gpbArt.Controls.Add(this.label14);
            this.gpbArt.Controls.Add(this.label12);
            this.gpbArt.Controls.Add(this.label10);
            this.gpbArt.Controls.Add(this.txtCodXtr);
            this.gpbArt.Controls.Add(this.txtSto);
            this.gpbArt.Controls.Add(this.txtCan);
            this.gpbArt.Controls.Add(this.txtCodArtSap);
            this.gpbArt.Location = new System.Drawing.Point(73, 137);
            this.gpbArt.Name = "gpbArt";
            this.gpbArt.Size = new System.Drawing.Size(877, 134);
            this.gpbArt.TabIndex = 13;
            this.gpbArt.TabStop = false;
            // 
            // cboSer
            // 
            this.cboSer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSer.FormattingEnabled = true;
            this.cboSer.Items.AddRange(new object[] {
            "",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "9",
            "10",
            "OTI",
            "OTG",
            "OTV",
            "OTR",
            "ODS"});
            this.cboSer.Location = new System.Drawing.Point(7, 83);
            this.cboSer.Name = "cboSer";
            this.cboSer.Size = new System.Drawing.Size(40, 21);
            this.cboSer.TabIndex = 20;
            this.cboSer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboSer_KeyPress);
            // 
            // txtDesRes
            // 
            this.txtDesRes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesRes.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesRes.Location = new System.Drawing.Point(425, 81);
            this.txtDesRes.Name = "txtDesRes";
            this.txtDesRes.Size = new System.Drawing.Size(257, 21);
            this.txtDesRes.TabIndex = 24;
            this.txtDesRes.Text = "Presione enter o ingrese un responsable";
            this.txtDesRes.Enter += new System.EventHandler(this.txtDesRes_Enter);
            this.txtDesRes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesRes_KeyPress);
            this.txtDesRes.Leave += new System.EventHandler(this.txtDesRes_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(313, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Responsable:";
            // 
            // txtCodRes
            // 
            this.txtCodRes.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodRes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodRes.ForeColor = System.Drawing.Color.Blue;
            this.txtCodRes.Location = new System.Drawing.Point(386, 81);
            this.txtCodRes.Name = "txtCodRes";
            this.txtCodRes.Size = new System.Drawing.Size(40, 21);
            this.txtCodRes.TabIndex = 23;
            // 
            // mskFecLle
            // 
            this.mskFecLle.Location = new System.Drawing.Point(781, 83);
            this.mskFecLle.Mask = "00/00/0000";
            this.mskFecLle.Name = "mskFecLle";
            this.mskFecLle.Size = new System.Drawing.Size(90, 21);
            this.mskFecLle.TabIndex = 22;
            this.mskFecLle.ValidatingType = typeof(System.DateTime);
            this.mskFecLle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskFecLle_KeyPress);
            // 
            // txtRq
            // 
            this.txtRq.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRq.ForeColor = System.Drawing.Color.Blue;
            this.txtRq.Location = new System.Drawing.Point(248, 81);
            this.txtRq.Name = "txtRq";
            this.txtRq.Size = new System.Drawing.Size(61, 21);
            this.txtRq.TabIndex = 22;
            this.txtRq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRq_KeyPress);
            // 
            // txtObs
            // 
            this.txtObs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtObs.Location = new System.Drawing.Point(248, 42);
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(623, 21);
            this.txtObs.TabIndex = 19;
            this.txtObs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtObs_KeyPress);
            // 
            // txtNumCor
            // 
            this.txtNumCor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNumCor.ForeColor = System.Drawing.Color.Blue;
            this.txtNumCor.Location = new System.Drawing.Point(130, 81);
            this.txtNumCor.Name = "txtNumCor";
            this.txtNumCor.Size = new System.Drawing.Size(56, 21);
            this.txtNumCor.TabIndex = 21;
            this.txtNumCor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNumCor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumCor_KeyPress);
            // 
            // txtDesArt
            // 
            this.txtDesArt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDesArt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesArt.Location = new System.Drawing.Point(247, 12);
            this.txtDesArt.Name = "txtDesArt";
            this.txtDesArt.Size = new System.Drawing.Size(624, 21);
            this.txtDesArt.TabIndex = 16;
            this.txtDesArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArt_KeyPress);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(222, 88);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "RQ:";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(222, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Obs:";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(688, 91);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Fecha de llegada:";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(53, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "N° Correlativo:";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(86, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Stock:";
            // 
            // txtCodXtr
            // 
            this.txtCodXtr.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodXtr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodXtr.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodXtr.Location = new System.Drawing.Point(126, 12);
            this.txtCodXtr.Name = "txtCodXtr";
            this.txtCodXtr.Size = new System.Drawing.Size(118, 21);
            this.txtCodXtr.TabIndex = 15;
            this.txtCodXtr.Text = "(Código Xtrazzo)";
            this.txtCodXtr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodXtr.Enter += new System.EventHandler(this.txtCodXtr_Enter);
            this.txtCodXtr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodXtr_KeyPress);
            this.txtCodXtr.Leave += new System.EventHandler(this.txtCodXtr_Leave);
            // 
            // txtSto
            // 
            this.txtSto.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtSto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSto.Location = new System.Drawing.Point(126, 42);
            this.txtSto.Name = "txtSto";
            this.txtSto.Size = new System.Drawing.Size(76, 21);
            this.txtSto.TabIndex = 18;
            this.txtSto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCan
            // 
            this.txtCan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCan.Location = new System.Drawing.Point(7, 42);
            this.txtCan.Name = "txtCan";
            this.txtCan.Size = new System.Drawing.Size(73, 21);
            this.txtCan.TabIndex = 17;
            this.txtCan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCan_KeyPress);
            // 
            // txtCodArtSap
            // 
            this.txtCodArtSap.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodArtSap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodArtSap.ForeColor = System.Drawing.Color.DimGray;
            this.txtCodArtSap.Location = new System.Drawing.Point(6, 12);
            this.txtCodArtSap.Name = "txtCodArtSap";
            this.txtCodArtSap.Size = new System.Drawing.Size(117, 21);
            this.txtCodArtSap.TabIndex = 14;
            this.txtCodArtSap.Text = "(Código SAP)";
            this.txtCodArtSap.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodArtSap.Enter += new System.EventHandler(this.txtCodArtSap_Enter);
            this.txtCodArtSap.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArtSap_KeyPress);
            this.txtCodArtSap.Leave += new System.EventHandler(this.txtCodArtSap_Leave);
            // 
            // txtFil
            // 
            this.txtFil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFil.Location = new System.Drawing.Point(215, 107);
            this.txtFil.MaxLength = 1;
            this.txtFil.Name = "txtFil";
            this.txtFil.Size = new System.Drawing.Size(33, 21);
            this.txtFil.TabIndex = 10;
            this.txtFil.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFil.TextChanged += new System.EventHandler(this.txtFil_TextChanged);
            this.txtFil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFil_KeyPress);
            // 
            // txtCol
            // 
            this.txtCol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCol.Location = new System.Drawing.Point(167, 107);
            this.txtCol.MaxLength = 1;
            this.txtCol.Name = "txtCol";
            this.txtCol.Size = new System.Drawing.Size(33, 21);
            this.txtCol.TabIndex = 9;
            this.txtCol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCol.TextChanged += new System.EventHandler(this.txtCol_TextChanged);
            this.txtCol.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCol_KeyPress);
            // 
            // txtRac
            // 
            this.txtRac.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRac.Location = new System.Drawing.Point(118, 107);
            this.txtRac.MaxLength = 1;
            this.txtRac.Name = "txtRac";
            this.txtRac.Size = new System.Drawing.Size(33, 21);
            this.txtRac.TabIndex = 8;
            this.txtRac.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRac.TextChanged += new System.EventHandler(this.txtRac_TextChanged);
            this.txtRac.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRac_KeyPress);
            // 
            // txtZon
            // 
            this.txtZon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtZon.Location = new System.Drawing.Point(73, 107);
            this.txtZon.MaxLength = 2;
            this.txtZon.Name = "txtZon";
            this.txtZon.Size = new System.Drawing.Size(33, 21);
            this.txtZon.TabIndex = 7;
            this.txtZon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtZon.TextChanged += new System.EventHandler(this.txtZon_TextChanged);
            this.txtZon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtZon_KeyPress);
            // 
            // btnLeeUbi
            // 
            this.btnLeeUbi.BackColor = System.Drawing.SystemColors.Control;
            this.btnLeeUbi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLeeUbi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLeeUbi.Image = ((System.Drawing.Image)(resources.GetObject("btnLeeUbi.Image")));
            this.btnLeeUbi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLeeUbi.Location = new System.Drawing.Point(254, 106);
            this.btnLeeUbi.Name = "btnLeeUbi";
            this.btnLeeUbi.Size = new System.Drawing.Size(121, 23);
            this.btnLeeUbi.TabIndex = 11;
            this.btnLeeUbi.Text = "    Leer Ubicación";
            this.btnLeeUbi.UseVisualStyleBackColor = false;
            this.btnLeeUbi.Click += new System.EventHandler(this.btnLeeUbi_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 101;
            this.label5.Text = "Ubicación:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label4.Location = new System.Drawing.Point(71, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 13);
            this.label4.TabIndex = 100;
            this.label4.Text = "ZONA  -  RACK  -  COLUMNA  -  FILA\r\n";
            // 
            // rdbSal
            // 
            this.rdbSal.AutoSize = true;
            this.rdbSal.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSal.Location = new System.Drawing.Point(190, 55);
            this.rdbSal.Name = "rdbSal";
            this.rdbSal.Size = new System.Drawing.Size(67, 17);
            this.rdbSal.TabIndex = 6;
            this.rdbSal.TabStop = true;
            this.rdbSal.Text = "SALIDA";
            this.rdbSal.UseVisualStyleBackColor = true;
            // 
            // rdbIng
            // 
            this.rdbIng.AutoSize = true;
            this.rdbIng.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbIng.Location = new System.Drawing.Point(69, 55);
            this.rdbIng.Name = "rdbIng";
            this.rdbIng.Size = new System.Drawing.Size(74, 17);
            this.rdbIng.TabIndex = 5;
            this.rdbIng.TabStop = true;
            this.rdbIng.Text = "INGRESO";
            this.rdbIng.UseVisualStyleBackColor = true;
            // 
            // txtDesAlm
            // 
            this.txtDesAlm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesAlm.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesAlm.Location = new System.Drawing.Point(132, 23);
            this.txtDesAlm.Name = "txtDesAlm";
            this.txtDesAlm.Size = new System.Drawing.Size(215, 21);
            this.txtDesAlm.TabIndex = 2;
            this.txtDesAlm.Text = "Presione enter o ingrese un almacén";
            this.txtDesAlm.Enter += new System.EventHandler(this.txtDesAlm_Enter);
            this.txtDesAlm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesAlm_KeyPress);
            this.txtDesAlm.Leave += new System.EventHandler(this.txtDesAlm_Leave);
            // 
            // txtNumDocCon
            // 
            this.txtNumDocCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNumDocCon.Location = new System.Drawing.Point(395, 51);
            this.txtNumDocCon.Name = "txtNumDocCon";
            this.txtNumDocCon.Size = new System.Drawing.Size(91, 21);
            this.txtNumDocCon.TabIndex = 4;
            this.txtNumDocCon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNumDocCon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumDocCon_KeyPress);
            // 
            // txtFec
            // 
            this.txtFec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFec.ForeColor = System.Drawing.Color.Blue;
            this.txtFec.Location = new System.Drawing.Point(395, 23);
            this.txtFec.Name = "txtFec";
            this.txtFec.Size = new System.Drawing.Size(91, 21);
            this.txtFec.TabIndex = 3;
            this.txtFec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCodAlm
            // 
            this.txtCodAlm.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodAlm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodAlm.ForeColor = System.Drawing.Color.Blue;
            this.txtCodAlm.Location = new System.Drawing.Point(69, 23);
            this.txtCodAlm.Name = "txtCodAlm";
            this.txtCodAlm.Size = new System.Drawing.Size(64, 21);
            this.txtCodAlm.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(286, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 13);
            this.label3.TabIndex = 93;
            this.label3.Text = "N° Doc. Consolidado:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(355, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 94;
            this.label2.Text = "Fecha:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 92;
            this.label1.Text = "Almacén:";
            // 
            // pnlMosTod
            // 
            this.pnlMosTod.Controls.Add(this.chkIncEliP2);
            this.pnlMosTod.Controls.Add(this.label23);
            this.pnlMosTod.Controls.Add(this.label24);
            this.pnlMosTod.Controls.Add(this.txtDesAlmP2);
            this.pnlMosTod.Controls.Add(this.txtCodAlmP2);
            this.pnlMosTod.Controls.Add(this.label19);
            this.pnlMosTod.Controls.Add(this.panel2);
            this.pnlMosTod.Controls.Add(this.txtDesArtP2);
            this.pnlMosTod.Controls.Add(this.txtCodArtP2);
            this.pnlMosTod.Controls.Add(this.label22);
            this.pnlMosTod.Controls.Add(this.btnVolMenMosTod);
            this.pnlMosTod.Controls.Add(this.btnBus);
            this.pnlMosTod.Controls.Add(this.fgMosTod);
            this.pnlMosTod.Controls.Add(this.btnExpMosTod);
            this.pnlMosTod.Location = new System.Drawing.Point(265, 31);
            this.pnlMosTod.Name = "pnlMosTod";
            this.pnlMosTod.Size = new System.Drawing.Size(84, 176);
            this.pnlMosTod.TabIndex = 114;
            this.pnlMosTod.Visible = false;
            // 
            // chkIncEliP2
            // 
            this.chkIncEliP2.AutoSize = true;
            this.chkIncEliP2.Location = new System.Drawing.Point(370, 106);
            this.chkIncEliP2.Name = "chkIncEliP2";
            this.chkIncEliP2.Size = new System.Drawing.Size(107, 17);
            this.chkIncEliP2.TabIndex = 6;
            this.chkIncEliP2.Text = "Incluir eliminados";
            this.chkIncEliP2.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 134);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(51, 13);
            this.label23.TabIndex = 123;
            this.label23.Text = "Almacén:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(371, 131);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 13);
            this.label24.TabIndex = 122;
            this.label24.Text = "Artículo:";
            // 
            // txtDesAlmP2
            // 
            this.txtDesAlmP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDesAlmP2.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesAlmP2.Location = new System.Drawing.Point(129, 132);
            this.txtDesAlmP2.Name = "txtDesAlmP2";
            this.txtDesAlmP2.Size = new System.Drawing.Size(215, 21);
            this.txtDesAlmP2.TabIndex = 8;
            this.txtDesAlmP2.Text = "Presione enter o ingrese un almacén";
            this.txtDesAlmP2.Enter += new System.EventHandler(this.txtDesAlmP2_Enter);
            this.txtDesAlmP2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesAlmP2_KeyPress);
            this.txtDesAlmP2.Leave += new System.EventHandler(this.txtDesAlmP2_Leave);
            // 
            // txtCodAlmP2
            // 
            this.txtCodAlmP2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodAlmP2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodAlmP2.ForeColor = System.Drawing.Color.Blue;
            this.txtCodAlmP2.Location = new System.Drawing.Point(66, 132);
            this.txtCodAlmP2.Name = "txtCodAlmP2";
            this.txtCodAlmP2.Size = new System.Drawing.Size(64, 21);
            this.txtCodAlmP2.TabIndex = 7;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(-76, 97);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 13);
            this.label19.TabIndex = 120;
            this.label19.Text = "Almacén:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dtpFecFinMosTod);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.dtpFecIniMosTod);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Location = new System.Drawing.Point(0, 96);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(360, 30);
            this.panel2.TabIndex = 3;
            // 
            // dtpFecFinMosTod
            // 
            this.dtpFecFinMosTod.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecFinMosTod.Location = new System.Drawing.Point(239, 7);
            this.dtpFecFinMosTod.Name = "dtpFecFinMosTod";
            this.dtpFecFinMosTod.Size = new System.Drawing.Size(104, 21);
            this.dtpFecFinMosTod.TabIndex = 5;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(9, 14);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "F. Inicial:";
            // 
            // dtpFecIniMosTod
            // 
            this.dtpFecIniMosTod.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecIniMosTod.Location = new System.Drawing.Point(66, 8);
            this.dtpFecIniMosTod.Name = "dtpFecIniMosTod";
            this.dtpFecIniMosTod.Size = new System.Drawing.Size(104, 21);
            this.dtpFecIniMosTod.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(194, 13);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 13);
            this.label21.TabIndex = 7;
            this.label21.Text = "F. Final:";
            // 
            // txtDesArtP2
            // 
            this.txtDesArtP2.ForeColor = System.Drawing.Color.DimGray;
            this.txtDesArtP2.Location = new System.Drawing.Point(525, 131);
            this.txtDesArtP2.Name = "txtDesArtP2";
            this.txtDesArtP2.Size = new System.Drawing.Size(455, 21);
            this.txtDesArtP2.TabIndex = 10;
            this.txtDesArtP2.Text = "Presione enter o ingrese un artìculo";
            this.txtDesArtP2.Enter += new System.EventHandler(this.txtDesArtP2_Enter);
            this.txtDesArtP2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArtP2_KeyPress);
            this.txtDesArtP2.Leave += new System.EventHandler(this.txtDesArtP2_Leave);
            // 
            // txtCodArtP2
            // 
            this.txtCodArtP2.Location = new System.Drawing.Point(426, 131);
            this.txtCodArtP2.Name = "txtCodArtP2";
            this.txtCodArtP2.Size = new System.Drawing.Size(100, 21);
            this.txtCodArtP2.TabIndex = 9;
            this.txtCodArtP2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArtP2_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(-74, 132);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 13);
            this.label22.TabIndex = 115;
            this.label22.Text = "Artículo:";
            // 
            // btnVolMenMosTod
            // 
            this.btnVolMenMosTod.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMenMosTod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolMenMosTod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolMenMosTod.Image = ((System.Drawing.Image)(resources.GetObject("btnVolMenMosTod.Image")));
            this.btnVolMenMosTod.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolMenMosTod.Location = new System.Drawing.Point(9, 3);
            this.btnVolMenMosTod.Name = "btnVolMenMosTod";
            this.btnVolMenMosTod.Size = new System.Drawing.Size(101, 33);
            this.btnVolMenMosTod.TabIndex = 0;
            this.btnVolMenMosTod.Text = " Volver a menú";
            this.btnVolMenMosTod.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVolMenMosTod.UseVisualStyleBackColor = false;
            this.btnVolMenMosTod.Click += new System.EventHandler(this.btnVolMenMosTod_Click);
            // 
            // btnBus
            // 
            this.btnBus.BackColor = System.Drawing.SystemColors.Control;
            this.btnBus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBus.Image = ((System.Drawing.Image)(resources.GetObject("btnBus.Image")));
            this.btnBus.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBus.Location = new System.Drawing.Point(9, 56);
            this.btnBus.Name = "btnBus";
            this.btnBus.Size = new System.Drawing.Size(101, 34);
            this.btnBus.TabIndex = 1;
            this.btnBus.Text = "Buscar";
            this.btnBus.UseVisualStyleBackColor = false;
            this.btnBus.Click += new System.EventHandler(this.btnBus_Click);
            // 
            // fgMosTod
            // 
            this.fgMosTod.AllowFiltering = true;
            this.fgMosTod.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgMosTod.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgMosTod.Location = new System.Drawing.Point(9, 169);
            this.fgMosTod.Name = "fgMosTod";
            this.fgMosTod.Rows.DefaultSize = 19;
            this.fgMosTod.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgMosTod.Size = new System.Drawing.Size(66, 0);
            this.fgMosTod.TabIndex = 11;
            this.fgMosTod.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgMosTod_KeyPressEdit);
            this.fgMosTod.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgMosTod_AfterDataRefresh);
            // 
            // btnExpMosTod
            // 
            this.btnExpMosTod.BackColor = System.Drawing.SystemColors.Control;
            this.btnExpMosTod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpMosTod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExpMosTod.Image = ((System.Drawing.Image)(resources.GetObject("btnExpMosTod.Image")));
            this.btnExpMosTod.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExpMosTod.Location = new System.Drawing.Point(116, 56);
            this.btnExpMosTod.Name = "btnExpMosTod";
            this.btnExpMosTod.Size = new System.Drawing.Size(107, 34);
            this.btnExpMosTod.TabIndex = 2;
            this.btnExpMosTod.Text = "     &Exportar";
            this.btnExpMosTod.UseVisualStyleBackColor = false;
            this.btnExpMosTod.Click += new System.EventHandler(this.btnExpMosTod_Click);
            // 
            // gpbComSal
            // 
            this.gpbComSal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbComSal.Controls.Add(this.btnExpCom);
            this.gpbComSal.Controls.Add(this.btnMosCom);
            this.gpbComSal.Controls.Add(this.fgCru);
            this.gpbComSal.Controls.Add(this.cboCom);
            this.gpbComSal.Location = new System.Drawing.Point(12, 66);
            this.gpbComSal.Name = "gpbComSal";
            this.gpbComSal.Size = new System.Drawing.Size(208, 123);
            this.gpbComSal.TabIndex = 1;
            this.gpbComSal.TabStop = false;
            this.gpbComSal.Text = "Comparación de Saldos";
            // 
            // btnExpCom
            // 
            this.btnExpCom.BackColor = System.Drawing.SystemColors.Control;
            this.btnExpCom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpCom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExpCom.Image = ((System.Drawing.Image)(resources.GetObject("btnExpCom.Image")));
            this.btnExpCom.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExpCom.Location = new System.Drawing.Point(394, 18);
            this.btnExpCom.Name = "btnExpCom";
            this.btnExpCom.Size = new System.Drawing.Size(102, 23);
            this.btnExpCom.TabIndex = 4;
            this.btnExpCom.Text = "   &Exportar";
            this.btnExpCom.UseVisualStyleBackColor = false;
            this.btnExpCom.Click += new System.EventHandler(this.btnExpCom_Click);
            // 
            // btnMosCom
            // 
            this.btnMosCom.BackColor = System.Drawing.SystemColors.Control;
            this.btnMosCom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMosCom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMosCom.Image = ((System.Drawing.Image)(resources.GetObject("btnMosCom.Image")));
            this.btnMosCom.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMosCom.Location = new System.Drawing.Point(282, 18);
            this.btnMosCom.Name = "btnMosCom";
            this.btnMosCom.Size = new System.Drawing.Size(106, 23);
            this.btnMosCom.TabIndex = 3;
            this.btnMosCom.Text = "&Mostrar";
            this.btnMosCom.UseVisualStyleBackColor = false;
            this.btnMosCom.Click += new System.EventHandler(this.btnMosCom_Click);
            // 
            // fgCru
            // 
            this.fgCru.AllowFiltering = true;
            this.fgCru.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgCru.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgCru.Location = new System.Drawing.Point(8, 55);
            this.fgCru.Name = "fgCru";
            this.fgCru.Rows.DefaultSize = 19;
            this.fgCru.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgCru.Size = new System.Drawing.Size(193, 58);
            this.fgCru.TabIndex = 5;
            this.fgCru.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgCru_KeyPressEdit);
            this.fgCru.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgCru_AfterDataRefresh);
            // 
            // cboCom
            // 
            this.cboCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCom.FormattingEnabled = true;
            this.cboCom.Items.AddRange(new object[] {
            "Mostrar solo diferencias",
            "Mostrar solo cuadrados",
            "Mostrar ambos"});
            this.cboCom.Location = new System.Drawing.Point(8, 20);
            this.cboCom.Name = "cboCom";
            this.cboCom.Size = new System.Drawing.Size(193, 21);
            this.cboCom.TabIndex = 2;
            // 
            // fgUbi
            // 
            this.fgUbi.AllowFiltering = true;
            this.fgUbi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgUbi.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgUbi.Location = new System.Drawing.Point(9, 86);
            this.fgUbi.Name = "fgUbi";
            this.fgUbi.Rows.DefaultSize = 19;
            this.fgUbi.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgUbi.Size = new System.Drawing.Size(211, 167);
            this.fgUbi.TabIndex = 74;
            this.fgUbi.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgUbi_AfterEdit);
            this.fgUbi.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgUbi_KeyPressEdit);
            this.fgUbi.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgUbi_AfterDataRefresh);
            this.fgUbi.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fgUbi_KeyDown);
            // 
            // pnlCru
            // 
            this.pnlCru.Controls.Add(this.btnVolMenCru);
            this.pnlCru.Controls.Add(this.gpbComSal);
            this.pnlCru.Location = new System.Drawing.Point(462, 28);
            this.pnlCru.Name = "pnlCru";
            this.pnlCru.Size = new System.Drawing.Size(223, 204);
            this.pnlCru.TabIndex = 0;
            this.pnlCru.Visible = false;
            // 
            // btnVolMenCru
            // 
            this.btnVolMenCru.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMenCru.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolMenCru.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolMenCru.Image = ((System.Drawing.Image)(resources.GetObject("btnVolMenCru.Image")));
            this.btnVolMenCru.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolMenCru.Location = new System.Drawing.Point(12, 8);
            this.btnVolMenCru.Name = "btnVolMenCru";
            this.btnVolMenCru.Size = new System.Drawing.Size(101, 33);
            this.btnVolMenCru.TabIndex = 0;
            this.btnVolMenCru.Text = " Volver a menú";
            this.btnVolMenCru.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVolMenCru.UseVisualStyleBackColor = false;
            this.btnVolMenCru.Click += new System.EventHandler(this.btnVolMenCru_Click);
            // 
            // stpUbi
            // 
            this.stpUbi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslPgbUbi});
            this.stpUbi.Location = new System.Drawing.Point(0, 594);
            this.stpUbi.Name = "stpUbi";
            this.stpUbi.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.stpUbi.Size = new System.Drawing.Size(1081, 22);
            this.stpUbi.TabIndex = 84;
            this.stpUbi.Text = "statusStrip1";
            // 
            // tslPgbUbi
            // 
            this.tslPgbUbi.Name = "tslPgbUbi";
            this.tslPgbUbi.Size = new System.Drawing.Size(300, 20);
            this.tslPgbUbi.Step = 1;
            this.tslPgbUbi.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.tslPgbUbi.Visible = false;
            // 
            // lblPor
            // 
            this.lblPor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPor.AutoSize = true;
            this.lblPor.BackColor = System.Drawing.Color.Transparent;
            this.lblPor.Location = new System.Drawing.Point(148, 597);
            this.lblPor.Name = "lblPor";
            this.lblPor.Size = new System.Drawing.Size(0, 13);
            this.lblPor.TabIndex = 85;
            // 
            // btnPauExp
            // 
            this.btnPauExp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPauExp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPauExp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPauExp.Image = ((System.Drawing.Image)(resources.GetObject("btnPauExp.Image")));
            this.btnPauExp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPauExp.Location = new System.Drawing.Point(305, 591);
            this.btnPauExp.Name = "btnPauExp";
            this.btnPauExp.Size = new System.Drawing.Size(86, 23);
            this.btnPauExp.TabIndex = 86;
            this.btnPauExp.Text = "Pausar";
            this.btnPauExp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPauExp.UseVisualStyleBackColor = true;
            this.btnPauExp.Visible = false;
            this.btnPauExp.Click += new System.EventHandler(this.btnPauExp_Click);
            // 
            // btnCanExp
            // 
            this.btnCanExp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCanExp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCanExp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCanExp.Image = ((System.Drawing.Image)(resources.GetObject("btnCanExp.Image")));
            this.btnCanExp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCanExp.Location = new System.Drawing.Point(394, 591);
            this.btnCanExp.Name = "btnCanExp";
            this.btnCanExp.Size = new System.Drawing.Size(92, 23);
            this.btnCanExp.TabIndex = 87;
            this.btnCanExp.Text = "Cancelar";
            this.btnCanExp.UseVisualStyleBackColor = true;
            this.btnCanExp.Visible = false;
            this.btnCanExp.Click += new System.EventHandler(this.btnCanExp_Click);
            // 
            // pnlCon
            // 
            this.pnlCon.Controls.Add(this.btnVolMenCon);
            this.pnlCon.Controls.Add(this.btnConPar);
            this.pnlCon.Controls.Add(this.chkIncEli);
            this.pnlCon.Controls.Add(this.gpbParCon);
            this.pnlCon.Controls.Add(this.fgUbi);
            this.pnlCon.Controls.Add(this.btnExpConPar);
            this.pnlCon.Location = new System.Drawing.Point(51, 329);
            this.pnlCon.Name = "pnlCon";
            this.pnlCon.Size = new System.Drawing.Size(229, 256);
            this.pnlCon.TabIndex = 88;
            this.pnlCon.Visible = false;
            // 
            // btnVolMenCon
            // 
            this.btnVolMenCon.BackColor = System.Drawing.SystemColors.Control;
            this.btnVolMenCon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolMenCon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVolMenCon.Image = ((System.Drawing.Image)(resources.GetObject("btnVolMenCon.Image")));
            this.btnVolMenCon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolMenCon.Location = new System.Drawing.Point(9, 3);
            this.btnVolMenCon.Name = "btnVolMenCon";
            this.btnVolMenCon.Size = new System.Drawing.Size(101, 33);
            this.btnVolMenCon.TabIndex = 0;
            this.btnVolMenCon.Text = " Volver a menú";
            this.btnVolMenCon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnVolMenCon.UseVisualStyleBackColor = false;
            this.btnVolMenCon.Click += new System.EventHandler(this.btnVolMenCon_Click);
            // 
            // btnConPar
            // 
            this.btnConPar.BackColor = System.Drawing.SystemColors.Control;
            this.btnConPar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConPar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConPar.Image = ((System.Drawing.Image)(resources.GetObject("btnConPar.Image")));
            this.btnConPar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConPar.Location = new System.Drawing.Point(9, 46);
            this.btnConPar.Name = "btnConPar";
            this.btnConPar.Size = new System.Drawing.Size(108, 34);
            this.btnConPar.TabIndex = 1;
            this.btnConPar.Text = "Con. Parametro";
            this.btnConPar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnConPar.UseVisualStyleBackColor = false;
            this.btnConPar.Click += new System.EventHandler(this.btnConPar_Click);
            // 
            // chkIncEli
            // 
            this.chkIncEli.AutoSize = true;
            this.chkIncEli.Location = new System.Drawing.Point(236, 56);
            this.chkIncEli.Name = "chkIncEli";
            this.chkIncEli.Size = new System.Drawing.Size(107, 17);
            this.chkIncEli.TabIndex = 3;
            this.chkIncEli.Text = "Incluir eliminados";
            this.chkIncEli.UseVisualStyleBackColor = true;
            // 
            // btnExpConPar
            // 
            this.btnExpConPar.BackColor = System.Drawing.SystemColors.Control;
            this.btnExpConPar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExpConPar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExpConPar.Image = ((System.Drawing.Image)(resources.GetObject("btnExpConPar.Image")));
            this.btnExpConPar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExpConPar.Location = new System.Drawing.Point(123, 46);
            this.btnExpConPar.Name = "btnExpConPar";
            this.btnExpConPar.Size = new System.Drawing.Size(107, 34);
            this.btnExpConPar.TabIndex = 2;
            this.btnExpConPar.Text = "     &Exportar";
            this.btnExpConPar.UseVisualStyleBackColor = false;
            this.btnExpConPar.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // frmALM_Ubi_ConStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 616);
            this.Controls.Add(this.pnlMosTod);
            this.Controls.Add(this.pnlCon);
            this.Controls.Add(this.btnCanExp);
            this.Controls.Add(this.btnPauExp);
            this.Controls.Add(this.lblPor);
            this.Controls.Add(this.stpUbi);
            this.Controls.Add(this.pnlPri);
            this.Controls.Add(this.pnlCru);
            this.Controls.Add(this.pnlCreUbi);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_Ubi_ConStock";
            this.Text = "Almacen - Ubicaciones control de Stock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmALM_Ubi_ConStock_FormClosing);
            this.Load += new System.EventHandler(this.frmALM_Ubi_ConStock_Load);
            this.gpbParCon.ResumeLayout(false);
            this.gpbParCon.PerformLayout();
            this.pnlFec.ResumeLayout(false);
            this.pnlFec.PerformLayout();
            this.pnlPri.ResumeLayout(false);
            this.pnlPri.PerformLayout();
            this.pnlOpcTipMov.ResumeLayout(false);
            this.pnlOpcTipMov.PerformLayout();
            this.pnlCreUbi.ResumeLayout(false);
            this.gpbAgrUbi.ResumeLayout(false);
            this.gpbAgrUbi.PerformLayout();
            this.pnlUbi.ResumeLayout(false);
            this.pnlUbi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgUbis)).EndInit();
            this.gpbArt.ResumeLayout(false);
            this.gpbArt.PerformLayout();
            this.pnlMosTod.ResumeLayout(false);
            this.pnlMosTod.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMosTod)).EndInit();
            this.gpbComSal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgCru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fgUbi)).EndInit();
            this.pnlCru.ResumeLayout(false);
            this.stpUbi.ResumeLayout(false);
            this.stpUbi.PerformLayout();
            this.pnlCon.ResumeLayout(false);
            this.pnlCon.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gpbParCon;
        private System.Windows.Forms.Button btnCan;
        private System.Windows.Forms.Button btnAceCon;
        private System.Windows.Forms.TextBox txtDesArtPar;
        private System.Windows.Forms.TextBox txtCodArtPar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox chkSolArt;
        private System.Windows.Forms.Panel pnlPri;
        private System.Windows.Forms.Panel pnlCreUbi;
        private System.Windows.Forms.GroupBox gpbComSal;
        private System.Windows.Forms.Button btnMosCom;
        private C1.Win.C1FlexGrid.C1FlexGrid fgCru;
        private System.Windows.Forms.ComboBox cboCom;
        private C1.Win.C1FlexGrid.C1FlexGrid fgUbi;
        private System.Windows.Forms.Panel pnlFec;
        private System.Windows.Forms.DateTimePicker dtpFecFin;
        private System.Windows.Forms.Label lblFIni;
        private System.Windows.Forms.DateTimePicker dtpFecIni;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel pnlCru;
        public System.Windows.Forms.Button btnExpCom;
        private System.Windows.Forms.StatusStrip stpUbi;
        private System.Windows.Forms.Label lblPor;
        private System.Windows.Forms.ToolStripProgressBar tslPgbUbi;
        private System.Windows.Forms.Button btnPauExp;
        private System.Windows.Forms.Button btnCanExp;
        private System.Windows.Forms.Button btnCreUbiP;
        private System.Windows.Forms.Button btnMosCruP;
        private System.Windows.Forms.Button btnConP;
        private System.Windows.Forms.Button btnMosTodP;
        private System.Windows.Forms.Label lblPre;
        private System.Windows.Forms.Panel pnlOpcTipMov;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnCanMov;
        private System.Windows.Forms.Button btnAceMov;
        private System.Windows.Forms.RadioButton rdbSalP;
        private System.Windows.Forms.RadioButton rdbIngP;
        private System.Windows.Forms.Panel pnlCon;
        private System.Windows.Forms.CheckBox chkIncEli;
        private System.Windows.Forms.Button btnExpConPar;
        private System.Windows.Forms.GroupBox gpbAgrUbi;
        private System.Windows.Forms.Button btnAgrUbi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox gpbArt;
        private System.Windows.Forms.ComboBox cboSer;
        private System.Windows.Forms.TextBox txtDesRes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCodRes;
        private System.Windows.Forms.MaskedTextBox mskFecLle;
        private System.Windows.Forms.TextBox txtRq;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.TextBox txtNumCor;
        private System.Windows.Forms.TextBox txtDesArt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCodXtr;
        private System.Windows.Forms.TextBox txtSto;
        private System.Windows.Forms.TextBox txtCan;
        private System.Windows.Forms.TextBox txtCodArtSap;
        private System.Windows.Forms.TextBox txtFil;
        private System.Windows.Forms.TextBox txtCol;
        private System.Windows.Forms.TextBox txtRac;
        private System.Windows.Forms.TextBox txtZon;
        private System.Windows.Forms.Button btnLeeUbi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdbSal;
        private System.Windows.Forms.RadioButton rdbIng;
        private System.Windows.Forms.TextBox txtDesAlm;
        private System.Windows.Forms.TextBox txtNumDocCon;
        private System.Windows.Forms.TextBox txtFec;
        private System.Windows.Forms.TextBox txtCodAlm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVolMenUbi;
        private System.Windows.Forms.Button btnVolMenCru;
        private System.Windows.Forms.Button btnConPar;
        private System.Windows.Forms.Button btnVolMenCon;
        private System.Windows.Forms.TextBox txtCodAlmP;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel pnlMosTod;
        private System.Windows.Forms.Button btnVolMenMosTod;
        private System.Windows.Forms.Button btnBus;
        private C1.Win.C1FlexGrid.C1FlexGrid fgMosTod;
        private System.Windows.Forms.Button btnExpMosTod;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtCodAlmP2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtpFecFinMosTod;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker dtpFecIniMosTod;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtDesArtP2;
        private System.Windows.Forms.TextBox txtCodArtP2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox chkIncEliP2;
        private System.Windows.Forms.TextBox txtDesAlmP;
        private System.Windows.Forms.TextBox txtDesAlmP2;
        private System.Windows.Forms.Button btnVerUbi;
        private System.Windows.Forms.Panel pnlUbi;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnCanUbi;
        private C1.Win.C1FlexGrid.C1FlexGrid fgUbis;
    }
}