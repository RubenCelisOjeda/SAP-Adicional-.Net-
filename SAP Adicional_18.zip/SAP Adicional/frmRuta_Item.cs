﻿using CapaNegocio;
using Entidades.Ruta_Item;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Outlook = Microsoft.Office.Interop.Outlook;
namespace SAP_Adicional
{
    public partial class frmRuta_Item : Form, Ruta_Item
    {
        private NConsultas nc = new NConsultas();
        private NRuta_Item rutIte = new NRuta_Item();
        private VarGlo varglo = VarGlo.Instance();
        public Int16 _estReg = 0;
        public int NumMov = 0;
        public int NumMovOTI = 0;
        public int NumMovOTR = 0;
        public int NumMovODD = 0;
        private string _mensaje = "";

        public frmRuta_Item()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
        }

        private void txtDesTipRut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Item_ConsultaDatos("Tipo de Ruta", "[Filtro_ALM_CorPed_TipRut]", this.txtDesTipRut.Text.Trim());
                this.txtDesMedTra.Focus();
            }
        }

        private void Ruta_Item_ConsultaDatos(string vista, string procedimiento, string param1)
        {
            //Filtra los datos al presionar enter

            Cursor.Current = Cursors.WaitCursor; //cursor cargando

            DataTable dt = new DataTable();
            dt = rutIte.Ruta_Item_Filtros(vista, procedimiento, param1); //ejecuta el procedimiento

            if (dt.Rows.Count > 1)
            {
                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 2;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.Ruta_Item_Rec = this;
                frm.ShowDialog();
            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Tipo de Ruta":
                        this.txtCodTipRut.Text = row["Codigo"].ToString();
                        this.txtDesTipRut.Text = row["Tipo de ruta"].ToString();                    
                        break;
                    case "Medio Transporte":
                        this.txtCodMedTra.Text = row["Codigo"].ToString();
                        this.txtDesMedTra.Text = row["Tipo trabajo"].ToString();                                                     
                        break;
                    case "Transportista":
                        this.txtCodTra.Text = row["Codigo"].ToString();
                        this.txtDesTra.Text = row["Nombre"].ToString();                      
                        break;
                    case "Distrito":
                        this.txtCodDis.Text = row["Codigo"].ToString();
                        this.txtDesDis.Text = row["Distrito"].ToString();                       
                        break;
                    case "Corte":
                        this.txtCodCor.Text = row["Codigo"].ToString();
                        this.txtDesCor.Text = row["Descripcion"].ToString();
                        this.txtCodRut.Text = row["CodRut"].ToString();
                        break;
                    default:
                        break;
                }
            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                _mensaje = "No se encontraron registros";
                this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.Red);
            }

            Cursor.Current = Cursors.Default; //cursor por defecto
        }

        public void recdat_Ruta_Item_TipRut(string CodTipRut, string DesTipRut)
        {
            //Obtiene los datos del grid al hacer el doble click
            this.txtCodTipRut.Text = CodTipRut;
            this.txtDesTipRut.Text = DesTipRut;
        }

        private void frmRuta_Item_Load(object sender, EventArgs e)
        {
            this.Ruta_Item_HabilitarDesahabilitarControles("soloLectura");
            this.Ruta_Item_EstBot("deshacer");

            //Valida y recupera los datos cuando hay un numero de movimiento
            if (NumMov != 0 )
            {
                this.pnlRutIte.Visible = true;
                this.Ruta_Item_BuscarPorNumMov();
            }
            else
            {
                this.pnlRutIte.Visible = false;
            }
        }
        public void Ruta_Item_BuscarPorRq()
        {
            //Valida y recupera los datos del Rq al hacer doble click
            DataTable dtLisRq = new DataTable();
            dtLisRq = nc.Ruta_Item_RecRqInf(varglo.RqRutIte);

            if (dtLisRq.Rows.Count > 0)
            {
                this.txtCodRq.Text = dtLisRq.Rows[0][0].ToString(); //Rq
                this.txtDesRq.Text = dtLisRq.Rows[0]["Cliente"].ToString();
                this.txtDirRut.Text = dtLisRq.Rows[0]["DireccionObra"].ToString();
                this.txtCodTipVen.Text = dtLisRq.Rows[0][9].ToString(); //Cod. Tipo Venta
                this.txtDesTipVen.Text = dtLisRq.Rows[0]["TipoVenta"].ToString();
            }
        }
        private void Ruta_Item_BuscarPorNumMov()
        {
            //Recupera los datos en los controles
            DataTable dtRecEnc = new DataTable();
            dtRecEnc = rutIte.Ruta_Item_RecEnc(Convert.ToInt32(NumMov));

            //Valida si hay datos y recupera en los textBox
            if (dtRecEnc.Rows.Count > 0)
            {
                this.txtNumMovRut.Text = dtRecEnc.Rows[0]["Nº Movimiento"].ToString();
                this.txtCodTipRut.Text = dtRecEnc.Rows[0]["CodTipRut"].ToString();
                this.txtDesTipRut.Text = dtRecEnc.Rows[0]["tiprut"].ToString();
                this.dtpFecDes.Text = dtRecEnc.Rows[0]["FechaRuta"].ToString();

                Int16 Tipo = Convert.ToInt16(dtRecEnc.Rows[0]["Tipo"]); //el char convierte el vacio en 1
                this.cmbTipTra.SelectedIndex = Tipo;

                this.txtCodMedTra.Text = dtRecEnc.Rows[0]["CodTipPed"].ToString();
                this.txtDesMedTra.Text = dtRecEnc.Rows[0]["TipPed"].ToString();

                this.txtCodTra.Text = dtRecEnc.Rows[0]["CodTra"].ToString();
                this.txtDesTra.Text = dtRecEnc.Rows[0]["Tra"].ToString();
                this.txtCodRq.Text = dtRecEnc.Rows[0]["NumRQ"].ToString();

                this.txtDesRq.Text = dtRecEnc.Rows[0]["Cliente"].ToString();
                this.txtCodTipVen.Text = dtRecEnc.Rows[0]["CodTipVen"].ToString();
                this.txtDesTipVen.Text = dtRecEnc.Rows[0]["TipVen"].ToString();
                this.txtDirRut.Text = dtRecEnc.Rows[0]["Direccion"].ToString();
                this.txtCodDis.Text = dtRecEnc.Rows[0]["CodDis"].ToString();
                this.txtDesDis.Text = dtRecEnc.Rows[0]["Distrito"].ToString();
                this.txtCodCor.Text = dtRecEnc.Rows[0]["CodCorPed"].ToString();
                this.txtCor.Text = dtRecEnc.Rows[0]["Cor"].ToString();

                //valida la horaOpcion 
                short estHor = 0;
                estHor = Convert.ToInt16(dtRecEnc.Rows[0]["HoraOpcion"].ToString());

                if (estHor == 0)
                {
                    this.rdoHorExa.Checked = false;
                    this.rdoRanHor.Checked = true;
                }
                if (estHor == 1)
                {
                    this.rdoRanHor.Checked = false;
                    this.rdoHorExa.Checked = true;
                }

                this.mkdHor.Text = dtRecEnc.Rows[0]["Hora"].ToString();
                this.txtCon.Text = dtRecEnc.Rows[0]["Contacto"].ToString();
                this.txtCor.Text = dtRecEnc.Rows[0]["coo"].ToString();

                //valida el chek de la instalacion
                short estIns = 0;
                estIns = Convert.ToInt16(dtRecEnc.Rows[0]["Instalacion"].ToString());

                if (estIns == 0)
                {
                    this.rdoTraiLu.Checked = false;
                    this.rdoCli.Checked = true;
                }
                if (estIns == 1)
                {
                    this.rdoCli.Checked = false;
                    this.rdoTraiLu.Checked = true;
                }

                this.txtEncDet.Text = dtRecEnc.Rows[0]["Encargo"].ToString();
                _estReg = Convert.ToInt16(dtRecEnc.Rows[0]["EstadoRegistro"].ToString());
                DateTime fecha = Convert.ToDateTime(dtRecEnc.Rows[0]["FechaMod"].ToString());
                this.lblNomFecMod.Text = dtRecEnc.Rows[0]["Responsable"].ToString() + "  el " + fecha.ToShortDateString() + " a las " + fecha.ToShortTimeString();

                this.Ruta_Item_EstBot("abrir");
            }
        }

        private void txtDesRut_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Item_ConsultaDatos("Tipo de Ruta", "[Filtro_ALM_CorPed_TipRut]", this.txtDesTipRut.Text.Trim());
                this.cmbTipTra.Focus();
            }
        }
        private void txtDesDis_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Item_ConsultaDatos("Distrito", "[Filtro_Distrito]", this.txtDesDis.Text.Trim());
                this.txtDesCor.Focus();
            }
        }

        private void txtDesMedTra_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Item_ConsultaDatos("Medio Transporte", "[Filtro_ALM_CorPed_TipPed]", this.txtDesMedTra.Text.Trim());
                this.txtDesTra.Focus();
            }
        }

        private void txtDesTra_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Item_ConsultaDatos("Transportista", "[Filtro_ALM_CorPed_Tra]", this.txtDesTra.Text.Trim());
                this.btnVinRq.Focus();
            }
        }

        private void txtDesCor_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Filtra al presionar enter
            if (e.KeyChar == (char)13)
            {
                this.Ruta_Item_ConsultaDatos("Corte", "[Filtro_ALM_CorPed]", this.txtDesCor.Text.Trim());
                this.rdoRanHor.Focus();
            }
        }
        public void recdat_Ruta_Item_MedTra(string CodMedTra, string DesMedTra)
        {
            //Datos de las interfaces
            this.txtCodMedTra.Text = CodMedTra;
            this.txtDesMedTra.Text = DesMedTra;
        }
        public void recdat_Ruta_Item_Tra(string CodTra, string DesTra)
        {
            //Datos de las interfaces
            this.txtCodTra.Text = CodTra;
            this.txtDesTra.Text = DesTra;
        }

        public void recdat_Ruta_Item_Dis(string CodDis, string DesDis)
        {
            //Datos de las interfaces
            this.txtCodDis.Text = CodDis;
            this.txtDesDis.Text = DesDis;
        }

        public void recdat_Ruta_Item_Cor(string CodCor, string DesCor,string CodRut)
        {
            //Datos de las interfaces
            this.txtCodCor.Text = CodCor;
            this.txtDesCor.Text = DesCor;
            this.txtCodRut.Text = CodRut;
        }

        private void btnVerRutOnl_Click(object sender, EventArgs e)
        {
            //Muestra el formulario ruta online
            frmRuta_Online frmRutOnl = new frmRuta_Online();
            frmRutOnl.MdiParent = this.MdiParent;
            frmRutOnl.Show();
        }

        private void btnDocVin_Click(object sender, EventArgs e)
        {
            //Muestra el documento vinculado
            frmRutaDocRel frmDocRel = new frmRutaDocRel();
            frmDocRel.txtNumMov.Text = string.IsNullOrEmpty(this.txtNumMovRut.Text) ? "0": this.txtNumMovRut.Text; //valida el NumMov
            frmDocRel.lblRq.Text = this.txtCodRq.Text;
            frmDocRel.lblFecRut.Text = this.dtpFecDes.Text;
            frmDocRel.ShowDialog();
        }
        private void Ruta_Item_ValidarBotones(ToolStripButton boton)
        {
            //Valida el acceso de cada boton que corresponde

            switch (boton.Text)
            {
                case "&Nuevo":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct,7, "Nue", 0) == 1) //valida el boton nuevo
                    {
                        this.Ruta_Item_LimpiarTextos();
                        this.Ruta_Item_EstBot("nuevo");
                        this.Ruta_Item_HabilitarDesahabilitarControles("lecturaEscritura");
                        this.pnlRutIte.Visible = true;
                        _estReg = 0;
                    }
                    else
                    {
                        _mensaje = "No cuenta con acceso para realizar esta operación";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje,Color.DodgerBlue);
                    }
                    break;

                case "&Abrir":

                    bool existe;
                    existe = false;

                    //Obtiene el formulario
                    Form frm = this.MdiParent.MdiChildren.FirstOrDefault(x => x is frmGEN_AbrDoc && Convert.ToInt16(x.Tag) == 7);

                    //Pone al frente el fomulario si esta activo
                    if (frm != null)
                    {
                        frm.BringToFront();
                        frm.Show();
                        existe = true;
                    }

                    //Valida y abre el formulario
                    if (existe == false)
                    {
                        frmGEN_AbrDoc fAbrRut = new frmGEN_AbrDoc();
                        fAbrRut.Text = "Ruta Item - Abrir";
                        fAbrRut.Tag = 7;
                        fAbrRut.MdiParent = this.MdiParent;
                        fAbrRut.BringToFront();
                        fAbrRut.Show(); 
                    }
                    this.Dispose();
                    break;

                case "&Guardar":

                    //validamos el tipo de codigo de ruta
                    if (this.txtCodTipRut.Text == "3")
                    {
                        if (rutIte.Ruta_Item_AccTipVen("COM", Convert.ToInt16(varglo.CodUsuAct)) == false)
                        {
                            _mensaje = "No tiene acceso para crear este tipo de ruta";
                            this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.Red);
                            this.txtDesTipRut.Focus();
                            return;
                        }
                        else if (this.txtCodTipRut.Text == "4")
                        {
                            if (rutIte.Ruta_Item_AccTipVen("PRD", Convert.ToInt16(varglo.CodUsuAct)) == false)
                            {
                                _mensaje = "No tiene acceso para crear este tipo de ruta";
                                this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.Red);
                                this.txtDesTipRut.Focus();
                                return;
                            }
                        }
                    }

                    //validamos las cajas de textos
                    if (this.txtCodTipRut.Text == "")
                    {
                        _mensaje = "Debe Elegir un Tipo de Ruta";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.txtDesTipRut.Focus();
                        return;
                    }
                    if (this.txtCodCor.Text == "")
                    {
                        _mensaje = "Debe elegir un codigo de corte";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.txtDesCor.Focus();
                        return;
                    }
                    if (!this.rdoRanHor.Checked & !this.rdoHorExa.Checked)
                    {
                        _mensaje = "Elija una opción de Hora";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.pnlHoOpc.Focus();
                        return;
                    }
                    if (!this.rdoCli.Checked & !this.rdoTraiLu.Checked)
                    {
                        _mensaje = "¿La instalación a cargo de quien?";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.pnlInsCar.Focus();
                        return;
                    }
                    if (this.txtCon.Text == "")
                    {
                        _mensaje = "Debe ingresar una información de contacto";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.txtCon.Focus();
                        return;
                    }
                    if (this.txtCodMedTra.Text != "4" & this.txtDirRut.Text == "")
                    {
                        _mensaje = "Debe ingresar una dirección";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.txtDirRut.Focus();
                        return;
                    }
                    if (txtCodMedTra.Text == "")
                    {
                        _mensaje = "Debe ingresar un medio de transporte";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                        this.txtDesMedTra.Focus();
                        return;
                    }

                    //Se verifica si ya se realizo el corte y  se valida solo cuando es un nuevo documento


                    if (_estReg == 0)
                    {
                        if (rutIte.Ruta_Item_CorPed(Convert.ToInt16(this.txtCodCor.Text), this.dtpFecDes.Value.Date) > 0)
                        {
                            _mensaje = "Ya se produjo el corte de este pedido,intente con otro";
                            this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                            this.txtCor.Focus();
                            return;
                        }
                    }
                    

                    if (_estReg == 0)
                    {
                        string fecAct = DateTime.Now.ToLongDateString();
                        if (this.dtpFecDes.Value.Date < Convert.ToDateTime(fecAct))
                        {
                            _mensaje = "No se puede programar una ruta con una fecha menor a la actual";
                            this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);

                            this.dtpFecDes.Focus();
                            return;
                        }
                    }

                    if (_estReg == 0)
                    {
                        if (NumMovOTI == 0 & NumMovOTR == 0 & NumMovODD == 0 & this.txtCodMedTra.Text == "1" & this.txtCodTipRut.Text == "1")
                        {
                            _mensaje = "Esta deshabilitado la creación de rutas con este medio de transporte si no proviene de una OTI,OTR u ODD";
                            this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.DodgerBlue);
                            this.txtDesMedTra.Focus();
                            return;
                        }
                    }
                   

                    //guardamos o actualizamos los datos
                    Ruta_Item_Enc Enc = new Ruta_Item_Enc();
                    Enc.Acc = Convert.ToByte(_estReg);

                    //valida si esta vacio
                    int NumMovGua = 0;
                    int.TryParse(this.txtNumMovRut.Text, out NumMovGua);
                    Enc.NumMov = NumMovGua;

                    Enc.CodTipRut = Convert.ToByte(this.txtCodTipRut.Text);

                    //valida el rq si esta vacio
                    int Rq = 0;
                    int.TryParse(this.txtCodRq.Text, out Rq);
                    Enc.NumRq = Rq;

                    Enc.Cli = this.txtDesRq.Text;
                    Enc.FecRut = this.dtpFecDes.Value.Date;
                    Enc.CodTipPed = Convert.ToByte(this.txtCodMedTra.Text);

                    Enc.NumRq = Rq;

                    //valida el codigo de rq
                    short CodTra = 0;
                    short.TryParse(this.txtCodTra.Text, out CodTra);
                    Enc.CodTra = CodTra;

                    Enc.Dir = this.txtDirRut.Text;

                    //valida el codigo de distrito
                    Int16 CodDis = 0;
                    Int16.TryParse(this.txtCodDis.Text, out CodDis);
                    Enc.CodDis = Convert.ToInt16(CodDis);

                    Enc.CodCorPed = Convert.ToByte(this.txtCodCor.Text);

                    //Valida el codigo de ruta
                    if (this.txtCodRut.Text == "")
                    {
                        Enc.CodRut = 0;
                    }
                    else
                    {
                        Enc.CodRut = Convert.ToByte(this.txtCodRut.Text);
                    }

                    //valida el check de hora opcion
                    if (rdoRanHor.Checked)
                    {
                        Enc.Hora = "";
                        Enc.HOpcion = Convert.ToByte(this.rdoRanHor.Checked);
                    }

                    if (rdoHorExa.Checked)
                    {
                        Enc.Hora = this.mkdHor.Text;
                        Enc.HOpcion = Convert.ToByte(this.rdoHorExa.Checked);
                    }

                    Enc.Contacto = this.txtCon.Text;

                    //Valida el tipo de trabajo
                    string tipo = "";
                    if (this.cmbTipTra.SelectedIndex == 0)
                    {
                        tipo = "E";
                    }
                    if(this.cmbTipTra.SelectedIndex == 1)
                    {
                        tipo = "R";
                    }

                    Enc.Tipo = Convert.ToChar(tipo);

                    Enc.Encargo = this.txtEncDet.Text;
                    Enc.CodUsu = Convert.ToInt16(varglo.CodUsuAct);

                     //valida el check de instalacion a cargo
                    if (this.rdoCli.Checked)
                    {
                        Enc.Ins = 1;
                    }
                    if (this.rdoTraiLu.Checked)
                    {
                        Enc.Ins = 0;
                    }

                    Enc.CodTipVen = this.txtCodTipVen.Text;
                    Enc.Coo = this.txtCor.Text;

                    this.rutIte.Ruta_Item_GuardarActualizar(Enc);

                    //Valida si se guardo o se actualizo
                    if (_estReg == 0)
                    {
                        _mensaje = "Se guardo correctamente";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.Green);
                    }
                    else
                    {
                        _mensaje = "Se actualizo correctamente";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.Green);
                    }

                    
                    this.Ruta_Item_EstBot("guardar");
                    this.Ruta_Item_HabilitarDesahabilitarControles("soloLectura");
                    this.txtNumMovRut.Text = Enc.NumMov.ToString();
                    _estReg = 1;

                    Form f = this.MdiParent.MdiChildren.FirstOrDefault(x => x is frmGEN_AbrDoc && Convert.ToInt16(x.Tag) == 7);
                    if (f != null)
                    {
                        f.Close();
                    }
                    break;

                case "&Deshacer":

                    this.Ruta_Item_LimpiarTextos();
                    this.Ruta_Item_EstBot("deshacer");
                    this.pnlRutIte.Visible = false;
                    break;

                case "&Modificar":

                    this.Ruta_Item_EstBot("modificar");
                    this.Ruta_Item_HabilitarDesahabilitarControles("lecturaEscritura");
                    _estReg = 1;
                    break;

                case "&Eliminar":

                    DialogResult mensaje = MessageBox.Show("¿Esta seguro de eliminar?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (mensaje == DialogResult.Yes)
                    {
                        this.rutIte.Ruta_Item_Eliminar(Convert.ToInt32(this.txtNumMovRut.Text));
                        _mensaje = "Se elimino correctamente";
                        this.ALM_Ruta_Item_MosMsgStrip(_mensaje, Color.Green);
                        this.Ruta_Item_LimpiarTextos();
                        this.Ruta_Item_EstBot("eliminar");
                        this.pnlRutIte.Visible = false;

                        Form fEli = this.MdiParent.MdiChildren.FirstOrDefault(x => x is frmGEN_AbrDoc && Convert.ToInt16(x.Tag) == 7);

                        if (fEli != null)
                        {
                            fEli.Close();
                        }
                    }
                    else
                    {
                        return;
                    }
                    break;

                case "&Cerrar":
                    this.Close();
                    break;
            }
        }

        private void Ruta_Item_LimpiarTextos()
        {
            //limpia todos los controles
            foreach (Control c in this.Controls) //recorre el form
            {
                if (c is Panel) //valida dentro del panel
                {
                    foreach (Control t in c.Controls) //recorre  y valida que se un TextBox
                    {
                        if (t is TextBox)
                        {
                            t.Text = "";
                        }
                    }
                }
            }

            this.cmbTipTra.SelectedIndex = 0;
            this.rdoRanHor.Checked = true;
            this.rdoCli.Checked = true;
            this.dtpFecDes.Value = DateTime.Now;
        }
        public void Ruta_Item_HabilitarDesahabilitarControles(string EstBot)
        {
            //Recorre los textBox para poder habilitar o deshabilitar
            foreach (Control c in this.Controls)
            {
                if (c is Panel)
                {
                    foreach (Control t in c.Controls)
                    {
                        switch (EstBot)
                        {
                            case "soloLectura":

                                if (t is TextBox)
                                {
                                    ((TextBox)t).ReadOnly = true;
                                }

                                //Controles que se deshabilitan  por que son menos cantidad
                                this.dtpFecDes.Enabled = false;
                                this.cmbTipTra.Enabled = false;
                                this.btnDocVin.Enabled = false;
                                this.btnVinRq.Enabled = false;
                                this.pnlHoOpc.Enabled = false;
                                this.btnVerRutOnl.Enabled = false;
                                this.mkdHor.Enabled = false;
                                this.pnlInsCar.Enabled = false;
                                break;

                            case "lecturaEscritura":

                                if (t is TextBox)
                                {
                                    if (Convert.ToInt32(t.Tag) != 1) //solo estable lectura a los textos que no tiene tag
                                    {
                                        ((TextBox)t).ReadOnly = false;
                                    }
                                }

                                this.dtpFecDes.Enabled = true;
                                this.cmbTipTra.Enabled = true;
                                this.btnDocVin.Enabled = true;
                                this.btnVinRq.Enabled = true;
                                this.pnlHoOpc.Enabled = true;
                                this.btnVerRutOnl.Enabled = true;
                                this.mkdHor.Enabled = true;
                                this.pnlInsCar.Enabled = true;

                                break;
                        }
                    }
                }
            }
        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }
        public void Ruta_Item_EstBot(string botonEstado)
        {
            bool[] estadoM = { true };

            //nuevo, abrir, guardar, deshacer, modificar, eliminar,cerrar

            switch (botonEstado)
            {
                case "nuevo":
                case "modificar":
                    estadoM = matriz(false, false, true, true, false, false);
                    break;
                case "abrir":
                    switch (_estReg)
                    {
                        case 1:
                            estadoM = matriz(true, true, false, true, true, true);
                            break;
                        case 4:
                        case 8:
                            estadoM = matriz(true, true, false, true, false,false );
                            break;
                    }
                    break;
                case "deshacer":
                case "eliminar":
                    estadoM = matriz(true, true, false, true, false, false);
                    break;
                case "guardar":
                    estadoM = matriz(true, true, false, true, true, true);
                    break;
            }

            this.btnNuevo.Enabled = estadoM[0];
            this.btnAbrir.Enabled = estadoM[1];
            this.btnGuardar.Enabled = estadoM[2];
            this.btnDeshacer.Enabled = estadoM[3];
            this.btnModificar.Enabled = estadoM[4];
            this.btnEli.Enabled = estadoM[5];
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnNuevo);
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnAbrir);
        }
        private void btnCer_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnCer);
        }

        private void btnDeshacer_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnDeshacer);
        }
        private void btnEli_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnEli);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnModificar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            this.Ruta_Item_ValidarBotones(btnGuardar);
        }
        private void rdoRanHor_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdoRanHor.Checked)
            {
                this.mkdHor.Visible = false;
                this.mkdHor.Text = "";
            }
        }

        private void rdoHorExa_CheckedChanged(object sender, EventArgs e)
        {
            if (this.rdoHorExa.Checked)
            {
                this.mkdHor.Visible = true;
            }
        }

        private void txtCodMedTra_TextChanged(object sender, EventArgs e)
        {
            //muestra si 
            if (this.txtCodMedTra.Text == "1")
            {
                this.lblTra.Visible = false;
                this.txtCodTra.Visible = false;
                this.txtDesTra.Visible = false;
            }
            else
            {
                this.lblTra.Visible = true;
                this.txtCodTra.Visible = true;
                this.txtDesTra.Visible = true;
            }
        }

        private void btnVinRq_Click(object sender, EventArgs e)
        {
            //formulario frmGEN_AbrDoc con filtros desde el textbox
            frmGEN_AbrDoc frmAbrDoc = new frmGEN_AbrDoc();
            frmAbrDoc.Tag = 4;
            frmAbrDoc.Text = "Vincular RQ";
            frmAbrDoc.ShowDialog();
            this.Ruta_Item_BuscarPorRq();
        }

        private void ALM_Ruta_Item_MosMsgStrip(string msg, Color color)
        {
            //obtiene el formulario pri para poder acceder al control
            frmPri fPri = (frmPri)this.MdiParent;
            fPri.tmrMsg.Enabled = true;
            var lbl = fPri.tlsLblMen;

            lbl.Text = msg;
            fPri.stpPri.BackColor = color;
        }
    }
}
