﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Entidades.VEN_Cot;
using SAP_Adicional.Reportes;
using CrystalDecisions.CrystalReports.Engine;

namespace SAP_Adicional
{
    public partial class frmVEN_CotImp : Form
    {
        NConsultas nc = new NConsultas();
        NVEN_Cot nvc = new NVEN_Cot();
        VarGlo varglo = VarGlo.Instance();
       

        public Int64 nummov;
        public string tipven;

        bool Directo = false;

        public frmVEN_CotImp()
        {
            InitializeComponent();
        }

        private void frmVEN_CotImp_Load(object sender, EventArgs e)
        {
            frmVEN_CotImp_Buscar();

            fgAmb.Cols[1].Caption = "Ambiente";
            fgAmb.Cols[1].Width = 250;
            fgAmb.Cols[2].Width = 50;
        }

        private void frmVEN_CotImp_Buscar()
        {
            DataTable dtValImp = new DataTable();

            dtValImp = nvc.VEN_Cot_ValImp(nummov);

            if (dtValImp.Rows.Count > 0)
            {                                               
                if (Convert.ToDecimal(dtValImp.Rows[0]["Adelanto"]) + Convert.ToDecimal(dtValImp.Rows[0]["Contraentrega"]) != 100)
                {
                    txtAde.Text = "90"; txtConEnt.Text = "10";
                }
                else
                {
                    txtAde.Text = dtValImp.Rows[0]["Adelanto"].ToString();
                    txtConEnt.Text = dtValImp.Rows[0]["Contraentrega"].ToString();
                }

                txtConAdi1.Text = dtValImp.Rows[0]["Condicion01"].ToString();
                txtConAdi2.Text = dtValImp.Rows[0]["Condicion02"].ToString();            
            }
            else
            {
                txtAde.Text = "90"; txtConEnt.Text = "10";
            }

            fgAmb.DataSource = nvc.VEN_Cot_ValImpAmb(nummov);

            fgAmb.Cols[0].Visible = false;
            fgAmb.Cols[3].Visible = false;        

        }

        private void frmVEN_CotImp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }

        private void btnImp_Click(object sender, EventArgs e)
        {
            Directo = true;
            btnVisPre.PerformClick();    
        }

        private void fgAmb_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.Col != 2)
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        public void VEN_Cot_ActCotAmb()
        {
            VEN_Cot_AmbOrd AmbOrd = new VEN_Cot_AmbOrd();

            AmbOrd.NumMov = nummov;

            for (int i = 1; i < fgAmb.Rows.Count; i++)
            {
                VEN_Cot_AmbOrd reg = new VEN_Cot_AmbOrd();

                reg.NumMov = nummov;
                reg.CodAmb = Convert.ToInt32(fgAmb.Rows[i][0]);
                reg.Orden = Convert.ToInt16(fgAmb.Rows[i][2]);


                AmbOrd.AmbOrd.Add(reg);
            }

            nvc.VEN_Cot_AmbOrden(AmbOrd);
        }
        
        public void VEN_Cot_ValImpCon()
        {
            Int16 Ade = 0;
            Int16.TryParse(txtAde.Text, out Ade);

            Int16 ConEnt = 0;
            Int16.TryParse(txtConEnt.Text, out ConEnt);

            nvc.VEN_Cot_ValImpCon(nummov, Ade, ConEnt, txtConAdi1.Text, txtConAdi2.Text, varglo.CodUsuAct);
        }

        private bool VEN_Cot_ValAdeCon() 
        {
            short Ade = 0;
            short Con = 0;

            short.TryParse(this.txtAde.Text, out Ade);
            short.TryParse(this.txtConEnt.Text, out Con);  
            

            if (Ade + Con != 100)
            {
                MessageBox.Show("Los valores de pago por adelantado y contraentrega deben sumar 100.",
                "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return true;
            }
            else
            {
                return false;
            }
        }
        
        private void VistaPrevia(short Valor)
        {
            ReportDocument rpt;

            if (Valor ==1)
            {
                rpt = new rptVEN_Cot();
            }
            else
            {
                rpt = new rptVEN_CotImg();
            }

            //solicitud de nota de credito
            rpt.SetParameterValue("@nummov", nummov);
            rpt.SetParameterValue("@tipven", tipven);
            rpt.SetParameterValue("@logo", (chkMosLog.Checked ? 1 : 0));
            rpt.SetParameterValue("@nomcot", (chkMosNom.Checked ? 1 : 0));
            rpt.SetParameterValue("@ref", (chkMosRef.Checked ? 1 : 0));
            rpt.SetParameterValue("@pordes", (chkOcuCol.Checked ? 1 : 0));

            if (Directo == true)
            {                
                rpt.PrintToPrinter(1, false, 0, 0);
                Directo = false;
            }
            else
            {
                MetGlo.CRVisPre(rpt);
            }

            this.Dispose();
        }

        private void btnVisPre_Click(object sender, EventArgs e)
        {
            //Validamos que la suma del adelanto y la contraentrega den 100
            if (VEN_Cot_ValAdeCon() == true) return;

            VEN_Cot_ActCotAmb();
            VEN_Cot_ValImpCon();

            VistaPrevia(1);

        }

        private void btnVisPreImg_Click(object sender, EventArgs e)
        {
            //Validamos que la suma del adelanto y la contraentrega den 100
            if (VEN_Cot_ValAdeCon() == true) return;

            VEN_Cot_ActCotAmb();
            VEN_Cot_ValImpCon();

            VistaPrevia(2);
        }
    }
}
