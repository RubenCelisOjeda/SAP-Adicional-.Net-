﻿using CapaNegocio;
using Entidades.Men_Acc;
using Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SAP_Adicional
{
    public partial class frmMenus_Acceso : Form, Men_Acc_Filtros
    {
        NMen_Acc menAcc = new NMen_Acc();
        NMan_Men manMen = new NMan_Men();
        VarGlo varglo = VarGlo.Instance();
        DataRow row;
        string nota;
        public frmMenus_Acceso()
        {
            InitializeComponent();
        }

        private void frmMenus_Acceso_Load(object sender, EventArgs e)
        {
            Menu_Acceso_Cargar(0, null, treeVieMenAcc, 32);
            Menus_Acceso_SoloLectura();
            treeVieMenAcc.ExpandAll();
            txtNomUsu.Focus();
            txtCodUsu.ReadOnly = true;
            txtCodUsuCop.ReadOnly = true;
        }

        void Menus_Acceso_SoloLectura()
        {
            txtCodMen.ReadOnly = true;
            txtNomMen.ReadOnly = true;
            txtKeyNod.ReadOnly = true;
            txtRel.ReadOnly = true;
            txtFor.ReadOnly = true;
        }
        private void txtNomUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                Cursor.Current = Cursors.WaitCursor;

                if (chkSelPer.Checked == true)
                {
                    ConsultaDatosFormato(2, e); //area
                }
                else
                {
                    ConsultaDatosFormato(1, e); //empleado
                }

                Menus_Acceso_LimpiarTextos(); //se ejecuta el evento afterCheck a la hora de limpiar los nodos

                Cursor.Current = Cursors.Default;
            }
        }
        private void ConsultaDatos(string vista, string procedimiento, string param1)
        {
            DataTable dtFiltro = new DataTable();
            frmConsulta_Varios frm = new frmConsulta_Varios();

            dtFiltro = menAcc.Men_Acc_Filtros(vista, procedimiento, param1);

            if (dtFiltro.Rows.Count > 1)
            {
                frm.Formulario = 1;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dtFiltro;
                frm.Men_Acc_Filtros_Rec = this; 
                frm.ShowDialog();
            }
           
            else if (dtFiltro.Rows.Count == 1)
            {
                row = dtFiltro.Rows[0];

                switch (vista)
                {
                    case "Empleado/Usuario":
                        txtCodUsu.Text = row["Codigo"].ToString();
                        txtNomUsu.Text = row["Empleado"].ToString();
                        txtNomUsu.Focus();
                        break;

                    case "Empleado2/Usuario2":
                        txtCodUsuCop.Text = row["Codigo"].ToString();
                        txtNomUsuCop.Text = row["Empleado"].ToString();
                        break;

                    case "Area":
                        txtCodUsu.Text = row["Codigo"].ToString();
                        txtNomUsu.Text = row["Descripcion"].ToString();
                        txtNomUsu.Focus();
                        break;
                    default:
                        break;
                }
            }
            else if (dtFiltro.Rows.Count == 0)
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }
        private void RecuperarAcceso(Int32 IdMenu, TreeNodeCollection nodes)
        {
            Cursor.Current = Cursors.WaitCursor;

            string notac = "";
            int CodUsu = 0;
            int.TryParse(txtCodUsu.Text, out CodUsu);

            DataTable AccMen = new DataTable();
            AccMen = menAcc.RecMenUsu(Convert.ToInt16(CodUsu), Convert.ToInt16(chkSelPer.Checked));//recupera los accesos

            DataView Menus = new DataView(AccMen);
            Menus.RowFilter = AccMen.Columns["NivelSuperior"].ColumnName + "=" + IdMenu; //filta por relacion

            TreeNode n = new TreeNode();

            foreach (DataRowView fila in Menus)
            {
                notac = fila["Notacion"].ToString();

                foreach (TreeNode node in nodes)//recorre el treevew
                {
                    n = node;

                    if (node.Tag.ToString() == notac) //asigna el acceso y retorna al siguiente
                    {
                        node.Checked = true;
                        break;
                    }
                }

                RecuperarAcceso(int.Parse(fila["Codigo"].ToString()), n.Nodes); //recorre los hijos de los padres
            }

            Cursor.Current = Cursors.Default;
        }
        private void ConsultaDatosFormato(int consulta, KeyPressEventArgs e)
        {
            switch (consulta)
            {
                case 1:
                    ConsultaDatos("Empleado/Usuario", "Filtro_EmpleadosUsuario", this.txtNomUsu.Text.Trim());
                    Menus_Acceso_LimpiarNodos(treeVieMenAcc.Nodes);
                    RecuperarAcceso(0, treeVieMenAcc.Nodes);
                    txtNomUsu.Focus();
                    break;
                case 2:
                    ConsultaDatos("Area", "Filtro_Area", this.txtNomUsu.Text.Trim());
                    Menus_Acceso_LimpiarNodos(treeVieMenAcc.Nodes);
                    RecuperarAcceso(0, treeVieMenAcc.Nodes);
                    txtNomUsu.Focus();
                    break;
            }
        }

        public void recdat_Men_Acc_Filtros_Empleado(string CodEmp, string DesEmp)
        {
            txtCodUsu.Text = CodEmp;
            txtNomUsu.Text = DesEmp;
        }
        public void recdat_Men_Acc_Filtros_Empleado2(string CodEmp2, string DesEmp2)
        {
            txtCodUsuCop.Text = CodEmp2;
            txtNomUsuCop.Text = DesEmp2;
        }
        public void recdat_Men_Acc_Filtros_Area(string CodAre, string DesAre)
        {
            txtCodUsu.Text = CodAre;
            txtNomUsu.Text = DesAre;
        }

        public void Menu_Acceso_Cargar(Int32 IdMenu, TreeNode node, TreeView Menu, int CodUsuAct)
        {
            Cursor.Current = Cursors.WaitCursor; //cambiar el cursor a cargar

            DataTable menu = new DataTable();
            menu = manMen.Rec_Menus();

            if (menu.Rows.Count > 0)
            {
                DataView Menus = new DataView(menu);
                //El campo nivel superior es el campo que indica el codigo del Menu Padre
                Menus.RowFilter = menu.Columns["NivelSuperior"].ColumnName + "=" + IdMenu;

                foreach (DataRowView fila in Menus)
                {
                    TreeNode m = new TreeNode();

                    nota = fila["Notacion"].ToString();
                    m.Text = fila["Menu"].ToString();
                    m.Name = fila["Codigo"].ToString();
                    m.Tag = nota;

                    if (int.Parse(fila["NivelSuperior"].ToString()) == 0)
                    {
                        Menu.Nodes.Add(m);
                    }
                    else
                    {
                        node.Nodes.Add(m);
                    }

                    Menu_Acceso_Cargar(int.Parse(fila["Codigo"].ToString()), m, Menu, 32);
                }
            }
            else
            {
                MessageBox.Show("No se encontraron datos", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Cursor.Current = Cursors.Default; // cambiar el cursor por defecto
        }

        private void chkSelPer_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSelPer.Checked) //valida para poder limpiar los texto
            {
                txtCodUsu.Text = "";
                txtNomUsu.Text = "";
            }
            else
            {
                txtCodUsu.Text = "";
                txtNomUsu.Text = "";
            }

            Menus_Acceso_LimpiarNodos(treeVieMenAcc.Nodes);
            Menus_Acceso_LimpiarTextos();
        }
        private void Menus_Acceso_LimpiarTextos()
        {
            txtCodMen.Text = "";
            txtKeyNod.Text = "";
            txtRel.Text = "";
            txtFor.Text = "";
            txtNomMen.Text = "";
        }
        private void Menus_Acceso_LimpiarNodos(TreeNodeCollection colNode)
        {
            foreach (TreeNode trNode in colNode) //recorre los nodos
            {
                if (trNode.Nodes.Count > 0)
                {
                    Menus_Acceso_LimpiarNodos(trNode.Nodes); //recorre los hijos del padre
                }

                trNode.Checked = false;
            }
        }

        private void treeVieMenAcc_AfterSelect(object sender, TreeViewEventArgs e)
        {
            Menus_Acceso_ReckeyNod(e);
        }
        private void Menus_Acceso_ReckeyNod(TreeViewEventArgs e)
        {
            TreeNode nodo = new TreeNode();
            nodo = treeVieMenAcc.SelectedNode;
            txtCodMen.Text = treeVieMenAcc.SelectedNode.Tag.ToString(); //obtiene el key del nodo padre

            if (nodo == null) //valida si hay datos
            {
                txtCodMen.Text = "";
            }
            else
            {
                try
                {
                    txtRel.Text = (nodo.Text + " - " + nodo.Parent.Tag);
                }
                catch { txtRel.Text = ""; } //limpian en caso los nodos principales no tengan relacion

                DataTable dtKeyNod = new DataTable();
                dtKeyNod = menAcc.RecKeyNod(txtCodMen.Text.Trim());

                //recorre y muestra los datos
                foreach (DataRow row in dtKeyNod.Rows)
                {
                    txtCodMen.Text = row["Codigo"].ToString();
                    txtNomMen.Text = row["Menu"].ToString();
                    txtKeyNod.Text = row["Notacion"].ToString();
                    txtFor.Text = string.IsNullOrEmpty(row["Formulario"].ToString()) ? "" : row["Formulario"].ToString(); //valida si  hay datos
                }
            }
        }

        private void treeVieMenAcc_AfterCheck(object sender, TreeViewEventArgs e)
        {
            if (e.Action == TreeViewAction.ByMouse) //valida la accion del usuario que cambio el estado del checked
            {
                treeVieMenAcc.SelectedNode = e.Node;

                if (!string.IsNullOrEmpty(txtCodUsu.Text)) //valida si hay dato en el texto
                {
                    DataTable dtKeyNod = new DataTable();
                    dtKeyNod = menAcc.RecKeyNod(e.Node.Tag.ToString());

                    //recorre y muestra los datos
                    foreach (DataRow row in dtKeyNod.Rows)
                    {
                        txtCodMen.Text = row["Codigo"].ToString();
                        txtNomMen.Text = row["Menu"].ToString();
                        txtKeyNod.Text = row["Notacion"].ToString();
                        txtFor.Text = string.IsNullOrEmpty(row["Formulario"].ToString()) ? "" : row["Formulario"].ToString(); //valida si  hay datos
                    }
                    try
                    {
                        txtRel.Text = (e.Node.Text + " - " + e.Node.Parent.Tag);
                    }
                    catch { }

                    //valida los datos en caso no tena hijos el padre
                    if (menAcc.Men_Accesos_ValNod(Convert.ToInt32(txtCodUsu.Text), e.Node.Tag.ToString()) != 0)
                    {
                        e.Node.Checked = true;
                        MessageBox.Show("Debe quitar los nodos secundarios para poder quitar el principal", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (e.Node.Checked == true) //primer nodo 
                    {
                        Menus_Accesos_GuardarNodoParent(e);
                        treeVieMenAcc.SelectedNode = e.Node;

                        if (e.Node.Parent == null) //valida si el nodo no tiene padre
                        {
                            return;
                        }

                        if (e.Node.Parent.Checked == false) //valida si el nodo tiene padre
                        {
                            e.Node.Parent.Checked = true;
                            treeVieMenAcc.SelectedNode = e.Node.Parent; //selecciona el nodo actual o el padre para que los datos aparescan en los textos y guarden
                            Menus_Accesos_GuardarNodoParent(e);

                            if (e.Node.Parent.Parent == null) //valida si el nodo ya no tiene padre
                            {
                                return;
                            }

                            if (e.Node.Parent.Parent.Checked == false) //valida si el 2 nodo  tiene padre
                            {
                                e.Node.Parent.Parent.Checked = true;
                                treeVieMenAcc.SelectedNode = e.Node.Parent.Parent;
                                Menus_Accesos_GuardarNodoParent(e);

                                if (e.Node.Parent.Parent.Parent == null) //valida si el nodo ya no tiene padre
                                {
                                    return;
                                }

                                if (e.Node.Parent.Parent.Parent.Checked == false) //valida si el 3 nodo  tiene padre
                                {
                                    e.Node.Parent.Parent.Parent.Checked = true;
                                    treeVieMenAcc.SelectedNode = e.Node.Parent.Parent.Parent;
                                    Menus_Accesos_GuardarNodoParent(e);
                                }
                            }
                        }
                    }
                    else
                    {
                        MenuAcc_Enc MenEli = new MenuAcc_Enc();
                        MenEli.CodUsu = Convert.ToInt16(txtCodUsu.Text);
                        MenEli.CodMen = Convert.ToInt16(txtCodMen.Text);
                        menAcc.MenAccInsEli(MenEli, 0); //eliminamos los datos
                    }
                }
            }
        }
        void Menus_Accesos_GuardarNodoParent(TreeViewEventArgs e)
        {
            MenuAcc_Enc MenIns = new MenuAcc_Enc();
            MenIns.CodUsu = Convert.ToInt16(txtCodUsu.Text);
            MenIns.CodMen = Convert.ToInt16(txtCodMen.Text);
            MenIns.FecIng = DateTime.Now;
            MenIns.CodUsuRes = Convert.ToInt16(VarGlo.Instance().CodUsuAct);
            MenIns.SelPer = chkSelPer.Checked;
            menAcc.MenAccInsEli(MenIns, 1); //agremos los datos para guardar 
        }
        private void btnAcc_Click(object sender, EventArgs e)
        {
            if (chkSelPer.Checked)
            {
                MessageBox.Show("No se puede copiar accesos de perfil a usuario","Mensaje del sistema",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            if (btnAcc.Text == "Accesos >>")
            {
                txtCodUsuCop.Enabled = true;
                txtNomUsuCop.Enabled = true;
                txtNomUsuCop.ReadOnly = false;
                btnAcc.Text ="Copiar accesos >>";
                txtNomUsuCop.Focus();
                return;
            }

            if (btnAcc.Text == "Copiar accesos >>")
            {
                
                if (string.IsNullOrEmpty(txtCodUsu.Text))
                {
                    MessageBox.Show("Ingrese el codigo del usuario para copiar", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtNomUsu.Focus();
                    return;
                }
                else
                {
                    if (string.IsNullOrEmpty(txtCodUsuCop.Text))
                    {
                        MessageBox.Show("Ingrese el codigo del usuario a copiar", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtNomUsuCop.Focus();
                        return;
                    }

                    DialogResult mensaje = MessageBox.Show("¿Esta seguro de copiar los accesos al usuario?", "Mensaje del sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (mensaje == DialogResult.Yes)
                    {

                        MenuAcc_Enc Enc = new MenuAcc_Enc();
                        Enc.CodUsuOri = Convert.ToInt16(txtCodUsu.Text);
                        Enc.CodUsuDes = Convert.ToInt16(txtCodUsuCop.Text);
                        menAcc.Men_Accesos_CopiarAccesos(Enc);

                        MessageBox.Show("Se copiaron los accesos correctamente", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        btnAcc.Text = "Accesos >>";
                        txtCodUsuCop.Enabled = false;
                        txtNomUsuCop.Enabled = false;
                        txtCodUsuCop.Text = "";
                        txtNomUsuCop.Text = "";
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }

        private void txtNomUsuCop_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                ConsultaDatos("Empleado2/Usuario2", "Filtro_EmpleadosUsuario", this.txtNomUsuCop.Text.Trim());
            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            if (btnAcc.Text != "Accesos >>")
            {
                btnAcc.Text = "Accesos >>";
                txtCodUsuCop.Text = "";
                txtNomUsuCop.Text = "";
                txtCodUsuCop.ReadOnly = true;
                txtNomUsuCop.ReadOnly = true;
            }
        }
    }
}
