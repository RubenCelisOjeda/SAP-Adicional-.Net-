﻿using C1.Win.C1FlexGrid;
using CapaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Interfaces;

namespace SAP_Adicional
{
    public partial class frmVEN_rep_AdmRQ : Form, VEN_rep_AdmRQ
    {
        NConsultas nc = new NConsultas();

        
        public frmVEN_rep_AdmRQ()
        {
            InitializeComponent();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {

            this.fg.DataSource = nc.VEN_rep_AdmRQ(Convert.ToInt16(chkMosTod.Checked));                           
  
        }

        public void FormatoGeneral()
        {
            fg.Cols.Frozen = 3;

            fg.Cols[0].Width = 70; //RQ
            fg.Cols[0].TextAlign = TextAlignEnum.RightCenter;
            fg.Cols[1].Width = 300; //Cliente
            fg.Cols[2].Width = 400; //Nombre Venta
            fg.Cols[3].Width = 150; //Empleado Venta
            fg.Cols[4].Width = 120; //Centro Venta
            fg.Cols[5].Width = 120; //Tipo de Venta
            fg.Cols[6].Width = 120; //Venta relativa
            fg.Cols[7].Width = 150; //Adm. RQ
            fg.Cols[8].Width = 100; //Estado RQ

            fg.AllowFreezing = AllowFreezingEnum.Both;

            CellStyle s = fg.Styles[CellStyleEnum.Frozen];            
            s.ForeColor = Color.Blue;
        }

        private void fg_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar !=3 && e.KeyChar !=27)
            {
                e.Handled = true;
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime Hoy = DateTime.Now;
                string fecha = Hoy.ToString("yyyyMMdd") + Hoy.ToString("HH") + Hoy.ToString("mm");
                FileFlags flags = FileFlags.IncludeFixedCells;
                string RutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string Ruta = RutaEscritorio + @"\" + this.Text + " " + fecha + ".xlsx";
                fg.SaveGrid(Ruta, FileFormatEnum.Excel, flags);
                Process.Start(Ruta);
            }
            catch
            {

            }
        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            FormatoGeneral();
        }

        private void btnAdmAsig_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();

            dt = nc.VEN_Cot_Filtros("N° de RQ's asignados por Adm. RQ", "VEN_rep_AdmRQ_rqasi", "", "", "", "", "");

            frmConsulta_Varios frm = new frmConsulta_Varios();
            frm.Formulario = 19;
            frm.Text = "N° de RQ's asignados por Adm. RQ";
            frm.Vista = "N° de RQ's asignados por Adm. RQ";
            frm.dg.DataSource = dt;
            frm.VEN_rep_AdmRQ = this;
            frm.ShowDialog();
        }
            
    }
}
