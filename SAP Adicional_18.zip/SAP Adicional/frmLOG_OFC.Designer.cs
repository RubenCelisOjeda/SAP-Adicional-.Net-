﻿namespace SAP_Adicional
{
    partial class frmLOG_OFC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLOG_OFC));
            this.pnEnc = new System.Windows.Forms.Panel();
            this.txtCodMon = new System.Windows.Forms.TextBox();
            this.txtMon = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtNumOFC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCodEst = new System.Windows.Forms.TextBox();
            this.txtEst = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnTipSer = new System.Windows.Forms.Panel();
            this.txtCodTipSer = new System.Windows.Forms.TextBox();
            this.txtTipSer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodTipOFC = new System.Windows.Forms.TextBox();
            this.txtTipOFC = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnSer = new System.Windows.Forms.Panel();
            this.txtPreUni = new System.Windows.Forms.TextBox();
            this.btnRutArcAdj = new System.Windows.Forms.Button();
            this.txtRutArcAdj = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtRQ = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCodPro = new System.Windows.Forms.TextBox();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnSerAgr = new System.Windows.Forms.Button();
            this.btnSerCan = new System.Windows.Forms.Button();
            this.txtCodUniNeg = new System.Windows.Forms.TextBox();
            this.txtUniNeg = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCodSubAre = new System.Windows.Forms.TextBox();
            this.txtSubAre = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCodAre = new System.Windows.Forms.TextBox();
            this.txtAre = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCta = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCanSer = new System.Windows.Forms.TextBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.txtCodGas = new System.Windows.Forms.TextBox();
            this.txtDesGas = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCodCatGas = new System.Windows.Forms.TextBox();
            this.txtCatGas = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pnDet = new System.Windows.Forms.Panel();
            this.tbDet = new System.Windows.Forms.TabControl();
            this.tbSer = new System.Windows.Forms.TabPage();
            this.dgvSer = new System.Windows.Forms.DataGridView();
            this.tbArt = new System.Windows.Forms.TabPage();
            this.dgvArt = new System.Windows.Forms.DataGridView();
            this.tlsBot = new System.Windows.Forms.ToolStrip();
            this.btnNuevo = new System.Windows.Forms.ToolStripButton();
            this.btnAbrir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.btnDeshacer = new System.Windows.Forms.ToolStripButton();
            this.btnModificar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.pnEnc.SuspendLayout();
            this.pnTipSer.SuspendLayout();
            this.pnSer.SuspendLayout();
            this.pnDet.SuspendLayout();
            this.tbDet.SuspendLayout();
            this.tbSer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer)).BeginInit();
            this.tbArt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvArt)).BeginInit();
            this.tlsBot.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnEnc
            // 
            this.pnEnc.Controls.Add(this.txtCodMon);
            this.pnEnc.Controls.Add(this.txtMon);
            this.pnEnc.Controls.Add(this.label16);
            this.pnEnc.Controls.Add(this.txtNumOFC);
            this.pnEnc.Controls.Add(this.label4);
            this.pnEnc.Controls.Add(this.txtCodEst);
            this.pnEnc.Controls.Add(this.txtEst);
            this.pnEnc.Controls.Add(this.label3);
            this.pnEnc.Controls.Add(this.pnTipSer);
            this.pnEnc.Controls.Add(this.txtCodTipOFC);
            this.pnEnc.Controls.Add(this.txtTipOFC);
            this.pnEnc.Controls.Add(this.label1);
            this.pnEnc.Location = new System.Drawing.Point(12, 46);
            this.pnEnc.Name = "pnEnc";
            this.pnEnc.Size = new System.Drawing.Size(1100, 99);
            this.pnEnc.TabIndex = 0;
            // 
            // txtCodMon
            // 
            this.txtCodMon.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodMon.Location = new System.Drawing.Point(129, 68);
            this.txtCodMon.Name = "txtCodMon";
            this.txtCodMon.ReadOnly = true;
            this.txtCodMon.Size = new System.Drawing.Size(37, 21);
            this.txtCodMon.TabIndex = 69;
            this.txtCodMon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMon
            // 
            this.txtMon.BackColor = System.Drawing.SystemColors.Window;
            this.txtMon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtMon.Location = new System.Drawing.Point(165, 68);
            this.txtMon.Name = "txtMon";
            this.txtMon.Size = new System.Drawing.Size(158, 21);
            this.txtMon.TabIndex = 68;
            this.txtMon.TextChanged += new System.EventHandler(this.txtMon_TextChanged);
            this.txtMon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMon_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(79, 71);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 13);
            this.label16.TabIndex = 67;
            this.label16.Text = "Moneda:";
            // 
            // txtNumOFC
            // 
            this.txtNumOFC.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumOFC.Location = new System.Drawing.Point(527, 10);
            this.txtNumOFC.Name = "txtNumOFC";
            this.txtNumOFC.ReadOnly = true;
            this.txtNumOFC.Size = new System.Drawing.Size(87, 21);
            this.txtNumOFC.TabIndex = 66;
            this.txtNumOFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(479, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 65;
            this.label4.Text = "N° OFC:";
            // 
            // txtCodEst
            // 
            this.txtCodEst.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodEst.Location = new System.Drawing.Point(527, 36);
            this.txtCodEst.Name = "txtCodEst";
            this.txtCodEst.ReadOnly = true;
            this.txtCodEst.Size = new System.Drawing.Size(37, 21);
            this.txtCodEst.TabIndex = 64;
            this.txtCodEst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEst
            // 
            this.txtEst.BackColor = System.Drawing.SystemColors.Window;
            this.txtEst.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtEst.Location = new System.Drawing.Point(562, 36);
            this.txtEst.Name = "txtEst";
            this.txtEst.Size = new System.Drawing.Size(158, 21);
            this.txtEst.TabIndex = 63;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(482, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 62;
            this.label3.Text = "Estado:";
            // 
            // pnTipSer
            // 
            this.pnTipSer.Controls.Add(this.txtCodTipSer);
            this.pnTipSer.Controls.Add(this.txtTipSer);
            this.pnTipSer.Controls.Add(this.label2);
            this.pnTipSer.Location = new System.Drawing.Point(12, 32);
            this.pnTipSer.Name = "pnTipSer";
            this.pnTipSer.Size = new System.Drawing.Size(323, 30);
            this.pnTipSer.TabIndex = 61;
            this.pnTipSer.Visible = false;
            // 
            // txtCodTipSer
            // 
            this.txtCodTipSer.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodTipSer.Location = new System.Drawing.Point(117, 4);
            this.txtCodTipSer.Name = "txtCodTipSer";
            this.txtCodTipSer.ReadOnly = true;
            this.txtCodTipSer.Size = new System.Drawing.Size(37, 21);
            this.txtCodTipSer.TabIndex = 63;
            this.txtCodTipSer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTipSer
            // 
            this.txtTipSer.BackColor = System.Drawing.SystemColors.Window;
            this.txtTipSer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtTipSer.Location = new System.Drawing.Point(153, 4);
            this.txtTipSer.Name = "txtTipSer";
            this.txtTipSer.Size = new System.Drawing.Size(158, 21);
            this.txtTipSer.TabIndex = 62;
            this.txtTipSer.Enter += new System.EventHandler(this.txtTipSer_Enter);
            this.txtTipSer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipSer_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 61;
            this.label2.Text = "Tipo de Servicio:";
            // 
            // txtCodTipOFC
            // 
            this.txtCodTipOFC.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodTipOFC.Location = new System.Drawing.Point(129, 10);
            this.txtCodTipOFC.Name = "txtCodTipOFC";
            this.txtCodTipOFC.ReadOnly = true;
            this.txtCodTipOFC.Size = new System.Drawing.Size(37, 21);
            this.txtCodTipOFC.TabIndex = 60;
            this.txtCodTipOFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTipOFC
            // 
            this.txtTipOFC.BackColor = System.Drawing.SystemColors.Window;
            this.txtTipOFC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtTipOFC.Location = new System.Drawing.Point(165, 10);
            this.txtTipOFC.Name = "txtTipOFC";
            this.txtTipOFC.Size = new System.Drawing.Size(158, 21);
            this.txtTipOFC.TabIndex = 59;
            this.txtTipOFC.TextChanged += new System.EventHandler(this.txtTipOFC_TextChanged);
            this.txtTipOFC.Enter += new System.EventHandler(this.txtTipOFC_Enter);
            this.txtTipOFC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipOFC_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clase de OFC:";
            // 
            // pnSer
            // 
            this.pnSer.Controls.Add(this.txtPreUni);
            this.pnSer.Controls.Add(this.btnRutArcAdj);
            this.pnSer.Controls.Add(this.txtRutArcAdj);
            this.pnSer.Controls.Add(this.label15);
            this.pnSer.Controls.Add(this.txtRQ);
            this.pnSer.Controls.Add(this.label14);
            this.pnSer.Controls.Add(this.txtCodPro);
            this.pnSer.Controls.Add(this.txtPro);
            this.pnSer.Controls.Add(this.label13);
            this.pnSer.Controls.Add(this.btnSerAgr);
            this.pnSer.Controls.Add(this.btnSerCan);
            this.pnSer.Controls.Add(this.txtCodUniNeg);
            this.pnSer.Controls.Add(this.txtUniNeg);
            this.pnSer.Controls.Add(this.label12);
            this.pnSer.Controls.Add(this.txtCodSubAre);
            this.pnSer.Controls.Add(this.txtSubAre);
            this.pnSer.Controls.Add(this.label10);
            this.pnSer.Controls.Add(this.txtCodAre);
            this.pnSer.Controls.Add(this.txtAre);
            this.pnSer.Controls.Add(this.label11);
            this.pnSer.Controls.Add(this.txtCta);
            this.pnSer.Controls.Add(this.label9);
            this.pnSer.Controls.Add(this.label8);
            this.pnSer.Controls.Add(this.txtCanSer);
            this.pnSer.Controls.Add(this.txtDes);
            this.pnSer.Controls.Add(this.txtCodGas);
            this.pnSer.Controls.Add(this.txtDesGas);
            this.pnSer.Controls.Add(this.label6);
            this.pnSer.Controls.Add(this.txtCodCatGas);
            this.pnSer.Controls.Add(this.txtCatGas);
            this.pnSer.Controls.Add(this.label5);
            this.pnSer.Controls.Add(this.label7);
            this.pnSer.Controls.Add(this.label17);
            this.pnSer.Location = new System.Drawing.Point(11, 166);
            this.pnSer.Name = "pnSer";
            this.pnSer.Size = new System.Drawing.Size(1099, 185);
            this.pnSer.TabIndex = 1;
            // 
            // txtPreUni
            // 
            this.txtPreUni.BackColor = System.Drawing.SystemColors.Window;
            this.txtPreUni.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtPreUni.Location = new System.Drawing.Point(889, 68);
            this.txtPreUni.Name = "txtPreUni";
            this.txtPreUni.Size = new System.Drawing.Size(48, 21);
            this.txtPreUni.TabIndex = 94;
            this.txtPreUni.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPreUni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPreUni_KeyPress);
            // 
            // btnRutArcAdj
            // 
            this.btnRutArcAdj.Location = new System.Drawing.Point(909, 125);
            this.btnRutArcAdj.Name = "btnRutArcAdj";
            this.btnRutArcAdj.Size = new System.Drawing.Size(28, 21);
            this.btnRutArcAdj.TabIndex = 93;
            this.btnRutArcAdj.Text = "...";
            this.btnRutArcAdj.UseVisualStyleBackColor = true;
            this.btnRutArcAdj.Click += new System.EventHandler(this.btnRutArcAdj_Click);
            // 
            // txtRutArcAdj
            // 
            this.txtRutArcAdj.BackColor = System.Drawing.SystemColors.Window;
            this.txtRutArcAdj.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtRutArcAdj.Location = new System.Drawing.Point(345, 125);
            this.txtRutArcAdj.Name = "txtRutArcAdj";
            this.txtRutArcAdj.Size = new System.Drawing.Size(562, 21);
            this.txtRutArcAdj.TabIndex = 91;
            this.txtRutArcAdj.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRutArcAdj_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(221, 128);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(127, 13);
            this.label15.TabIndex = 92;
            this.label15.Text = "Ruta de archivo adjunto:";
            // 
            // txtRQ
            // 
            this.txtRQ.BackColor = System.Drawing.Color.White;
            this.txtRQ.Location = new System.Drawing.Point(132, 122);
            this.txtRQ.Name = "txtRQ";
            this.txtRQ.Size = new System.Drawing.Size(68, 21);
            this.txtRQ.TabIndex = 90;
            this.txtRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRQ_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(46, 125);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 13);
            this.label14.TabIndex = 89;
            this.label14.Text = "RQ Relacionado:";
            // 
            // txtCodPro
            // 
            this.txtCodPro.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodPro.Location = new System.Drawing.Point(454, 14);
            this.txtCodPro.Name = "txtCodPro";
            this.txtCodPro.ReadOnly = true;
            this.txtCodPro.Size = new System.Drawing.Size(114, 21);
            this.txtCodPro.TabIndex = 88;
            this.txtCodPro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtPro
            // 
            this.txtPro.BackColor = System.Drawing.SystemColors.Window;
            this.txtPro.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtPro.Location = new System.Drawing.Point(567, 14);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(370, 21);
            this.txtPro.TabIndex = 87;
            this.txtPro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPro_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(397, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 86;
            this.label13.Text = "Proveedor:";
            // 
            // btnSerAgr
            // 
            this.btnSerAgr.Location = new System.Drawing.Point(11, 158);
            this.btnSerAgr.Name = "btnSerAgr";
            this.btnSerAgr.Size = new System.Drawing.Size(123, 24);
            this.btnSerAgr.TabIndex = 84;
            this.btnSerAgr.Text = "Agregar";
            this.btnSerAgr.UseVisualStyleBackColor = true;
            this.btnSerAgr.Click += new System.EventHandler(this.btnSerAgr_Click);
            // 
            // btnSerCan
            // 
            this.btnSerCan.Location = new System.Drawing.Point(140, 158);
            this.btnSerCan.Name = "btnSerCan";
            this.btnSerCan.Size = new System.Drawing.Size(123, 24);
            this.btnSerCan.TabIndex = 85;
            this.btnSerCan.Text = "Cancelar";
            this.btnSerCan.UseVisualStyleBackColor = true;
            this.btnSerCan.Click += new System.EventHandler(this.btnSerCan_Click);
            // 
            // txtCodUniNeg
            // 
            this.txtCodUniNeg.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodUniNeg.Location = new System.Drawing.Point(731, 95);
            this.txtCodUniNeg.Name = "txtCodUniNeg";
            this.txtCodUniNeg.ReadOnly = true;
            this.txtCodUniNeg.Size = new System.Drawing.Size(37, 21);
            this.txtCodUniNeg.TabIndex = 83;
            this.txtCodUniNeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtUniNeg
            // 
            this.txtUniNeg.BackColor = System.Drawing.SystemColors.Window;
            this.txtUniNeg.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtUniNeg.Location = new System.Drawing.Point(767, 95);
            this.txtUniNeg.Name = "txtUniNeg";
            this.txtUniNeg.Size = new System.Drawing.Size(170, 21);
            this.txtUniNeg.TabIndex = 82;
            this.txtUniNeg.Enter += new System.EventHandler(this.txtUniNeg_Enter);
            this.txtUniNeg.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUniNeg_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(658, 98);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 13);
            this.label12.TabIndex = 81;
            this.label12.Text = "Und. Negocio:";
            // 
            // txtCodSubAre
            // 
            this.txtCodSubAre.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodSubAre.Location = new System.Drawing.Point(454, 95);
            this.txtCodSubAre.Name = "txtCodSubAre";
            this.txtCodSubAre.ReadOnly = true;
            this.txtCodSubAre.Size = new System.Drawing.Size(37, 21);
            this.txtCodSubAre.TabIndex = 80;
            this.txtCodSubAre.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSubAre
            // 
            this.txtSubAre.BackColor = System.Drawing.SystemColors.Window;
            this.txtSubAre.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtSubAre.Location = new System.Drawing.Point(490, 95);
            this.txtSubAre.Name = "txtSubAre";
            this.txtSubAre.Size = new System.Drawing.Size(148, 21);
            this.txtSubAre.TabIndex = 79;
            this.txtSubAre.Enter += new System.EventHandler(this.txtSubAre_Enter);
            this.txtSubAre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSubAre_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(405, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 78;
            this.label10.Text = "SubArea:";
            // 
            // txtCodAre
            // 
            this.txtCodAre.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodAre.Location = new System.Drawing.Point(132, 95);
            this.txtCodAre.Name = "txtCodAre";
            this.txtCodAre.ReadOnly = true;
            this.txtCodAre.Size = new System.Drawing.Size(37, 21);
            this.txtCodAre.TabIndex = 77;
            this.txtCodAre.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAre
            // 
            this.txtAre.BackColor = System.Drawing.SystemColors.Window;
            this.txtAre.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtAre.Location = new System.Drawing.Point(168, 95);
            this.txtAre.Name = "txtAre";
            this.txtAre.Size = new System.Drawing.Size(180, 21);
            this.txtAre.TabIndex = 76;
            this.txtAre.Enter += new System.EventHandler(this.txtAre_Enter);
            this.txtAre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAre_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(98, 98);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 75;
            this.label11.Text = "Area:";
            // 
            // txtCta
            // 
            this.txtCta.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCta.Location = new System.Drawing.Point(454, 41);
            this.txtCta.Name = "txtCta";
            this.txtCta.ReadOnly = true;
            this.txtCta.Size = new System.Drawing.Size(194, 21);
            this.txtCta.TabIndex = 73;
            this.txtCta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(380, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 71;
            this.label9.Text = "Cta. Asociada:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(745, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 70;
            this.label8.Text = "Can:";
            // 
            // txtCanSer
            // 
            this.txtCanSer.BackColor = System.Drawing.SystemColors.Window;
            this.txtCanSer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtCanSer.Location = new System.Drawing.Point(775, 68);
            this.txtCanSer.Name = "txtCanSer";
            this.txtCanSer.Size = new System.Drawing.Size(43, 21);
            this.txtCanSer.TabIndex = 69;
            this.txtCanSer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCanSer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCanSer_KeyPress);
            // 
            // txtDes
            // 
            this.txtDes.BackColor = System.Drawing.SystemColors.Window;
            this.txtDes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtDes.Location = new System.Drawing.Point(132, 68);
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(589, 21);
            this.txtDes.TabIndex = 67;
            this.txtDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDes_KeyPress);
            // 
            // txtCodGas
            // 
            this.txtCodGas.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodGas.Location = new System.Drawing.Point(132, 41);
            this.txtCodGas.Name = "txtCodGas";
            this.txtCodGas.ReadOnly = true;
            this.txtCodGas.Size = new System.Drawing.Size(37, 21);
            this.txtCodGas.TabIndex = 66;
            this.txtCodGas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDesGas
            // 
            this.txtDesGas.BackColor = System.Drawing.SystemColors.Window;
            this.txtDesGas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtDesGas.Location = new System.Drawing.Point(168, 41);
            this.txtDesGas.Name = "txtDesGas";
            this.txtDesGas.Size = new System.Drawing.Size(192, 21);
            this.txtDesGas.TabIndex = 65;
            this.txtDesGas.Enter += new System.EventHandler(this.txtDesGas_Enter);
            this.txtDesGas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesGas_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 64;
            this.label6.Text = "Gasto (Servicios):";
            // 
            // txtCodCatGas
            // 
            this.txtCodCatGas.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCodCatGas.Location = new System.Drawing.Point(132, 14);
            this.txtCodCatGas.Name = "txtCodCatGas";
            this.txtCodCatGas.ReadOnly = true;
            this.txtCodCatGas.Size = new System.Drawing.Size(37, 21);
            this.txtCodCatGas.TabIndex = 63;
            this.txtCodCatGas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtCatGas
            // 
            this.txtCatGas.BackColor = System.Drawing.SystemColors.Window;
            this.txtCatGas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtCatGas.Location = new System.Drawing.Point(168, 14);
            this.txtCatGas.Name = "txtCatGas";
            this.txtCatGas.Size = new System.Drawing.Size(158, 21);
            this.txtCatGas.TabIndex = 62;
            this.txtCatGas.Enter += new System.EventHandler(this.txtCatGas_Enter);
            this.txtCatGas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCatGas_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(75, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 61;
            this.label5.Text = "Categoria:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 13);
            this.label7.TabIndex = 68;
            this.label7.Text = "Descripción del servicio:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(838, 71);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 13);
            this.label17.TabIndex = 95;
            this.label17.Text = "Pre. Uni.:";
            // 
            // pnDet
            // 
            this.pnDet.Controls.Add(this.tbDet);
            this.pnDet.Location = new System.Drawing.Point(11, 357);
            this.pnDet.Name = "pnDet";
            this.pnDet.Size = new System.Drawing.Size(1098, 381);
            this.pnDet.TabIndex = 2;
            // 
            // tbDet
            // 
            this.tbDet.Controls.Add(this.tbSer);
            this.tbDet.Controls.Add(this.tbArt);
            this.tbDet.Location = new System.Drawing.Point(8, 12);
            this.tbDet.Name = "tbDet";
            this.tbDet.SelectedIndex = 0;
            this.tbDet.Size = new System.Drawing.Size(1076, 356);
            this.tbDet.TabIndex = 0;
            // 
            // tbSer
            // 
            this.tbSer.Controls.Add(this.dgvSer);
            this.tbSer.Location = new System.Drawing.Point(4, 22);
            this.tbSer.Name = "tbSer";
            this.tbSer.Padding = new System.Windows.Forms.Padding(3);
            this.tbSer.Size = new System.Drawing.Size(1068, 330);
            this.tbSer.TabIndex = 0;
            this.tbSer.Text = "0 - Servicios";
            this.tbSer.UseVisualStyleBackColor = true;
            // 
            // dgvSer
            // 
            this.dgvSer.AllowUserToAddRows = false;
            this.dgvSer.AllowUserToDeleteRows = false;
            this.dgvSer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSer.Location = new System.Drawing.Point(10, 13);
            this.dgvSer.Name = "dgvSer";
            this.dgvSer.Size = new System.Drawing.Size(1032, 297);
            this.dgvSer.TabIndex = 0;
            // 
            // tbArt
            // 
            this.tbArt.Controls.Add(this.dgvArt);
            this.tbArt.Location = new System.Drawing.Point(4, 22);
            this.tbArt.Name = "tbArt";
            this.tbArt.Padding = new System.Windows.Forms.Padding(3);
            this.tbArt.Size = new System.Drawing.Size(1068, 330);
            this.tbArt.TabIndex = 1;
            this.tbArt.Text = "1 - Articulos";
            this.tbArt.UseVisualStyleBackColor = true;
            // 
            // dgvArt
            // 
            this.dgvArt.AllowUserToAddRows = false;
            this.dgvArt.AllowUserToDeleteRows = false;
            this.dgvArt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvArt.Location = new System.Drawing.Point(11, 16);
            this.dgvArt.Name = "dgvArt";
            this.dgvArt.Size = new System.Drawing.Size(1032, 297);
            this.dgvArt.TabIndex = 1;
            // 
            // tlsBot
            // 
            this.tlsBot.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlsBot.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNuevo,
            this.btnAbrir,
            this.toolStripSeparator1,
            this.btnGuardar,
            this.btnDeshacer,
            this.btnModificar,
            this.toolStripSeparator});
            this.tlsBot.Location = new System.Drawing.Point(0, 0);
            this.tlsBot.Name = "tlsBot";
            this.tlsBot.Size = new System.Drawing.Size(1140, 36);
            this.tlsBot.TabIndex = 42;
            this.tlsBot.Text = "toolStrip1";
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("btnNuevo.Image")));
            this.btnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(42, 33);
            this.btnNuevo.Text = "&Nuevo";
            this.btnNuevo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnAbrir
            // 
            this.btnAbrir.Image = ((System.Drawing.Image)(resources.GetObject("btnAbrir.Image")));
            this.btnAbrir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAbrir.Name = "btnAbrir";
            this.btnAbrir.Size = new System.Drawing.Size(34, 33);
            this.btnAbrir.Text = "&Abrir";
            this.btnAbrir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAbrir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAbrir.Click += new System.EventHandler(this.btnAbrir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 36);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("btnGuardar.Image")));
            this.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(50, 33);
            this.btnGuardar.Text = "&Guardar";
            this.btnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnDeshacer
            // 
            this.btnDeshacer.Image = ((System.Drawing.Image)(resources.GetObject("btnDeshacer.Image")));
            this.btnDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDeshacer.Name = "btnDeshacer";
            this.btnDeshacer.Size = new System.Drawing.Size(56, 33);
            this.btnDeshacer.Text = "Deshacer";
            this.btnDeshacer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDeshacer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnModificar
            // 
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(54, 33);
            this.btnModificar.Text = "Modificar";
            this.btnModificar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnModificar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 36);
            // 
            // frmLOG_OFC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1140, 765);
            this.Controls.Add(this.tlsBot);
            this.Controls.Add(this.pnDet);
            this.Controls.Add(this.pnSer);
            this.Controls.Add(this.pnEnc);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmLOG_OFC";
            this.Text = "Comprador";
            this.Load += new System.EventHandler(this.frmLOG_OFC_Load);
            this.Resize += new System.EventHandler(this.frmLOG_OFC_Resize);
            this.pnEnc.ResumeLayout(false);
            this.pnEnc.PerformLayout();
            this.pnTipSer.ResumeLayout(false);
            this.pnTipSer.PerformLayout();
            this.pnSer.ResumeLayout(false);
            this.pnSer.PerformLayout();
            this.pnDet.ResumeLayout(false);
            this.tbDet.ResumeLayout(false);
            this.tbSer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSer)).EndInit();
            this.tbArt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvArt)).EndInit();
            this.tlsBot.ResumeLayout(false);
            this.tlsBot.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnEnc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodTipOFC;
        private System.Windows.Forms.TextBox txtTipOFC;
        private System.Windows.Forms.TextBox txtCodEst;
        private System.Windows.Forms.TextBox txtEst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnTipSer;
        private System.Windows.Forms.TextBox txtCodTipSer;
        private System.Windows.Forms.TextBox txtTipSer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnSer;
        private System.Windows.Forms.Panel pnDet;
        private System.Windows.Forms.TextBox txtNumOFC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCanSer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.TextBox txtCodGas;
        private System.Windows.Forms.TextBox txtDesGas;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCodCatGas;
        private System.Windows.Forms.TextBox txtCatGas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCodUniNeg;
        private System.Windows.Forms.TextBox txtUniNeg;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCodSubAre;
        private System.Windows.Forms.TextBox txtSubAre;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCodAre;
        private System.Windows.Forms.TextBox txtAre;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCta;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSerAgr;
        private System.Windows.Forms.Button btnSerCan;
        private System.Windows.Forms.TabControl tbDet;
        private System.Windows.Forms.TabPage tbSer;
        private System.Windows.Forms.TabPage tbArt;
        private System.Windows.Forms.DataGridView dgvSer;
        private System.Windows.Forms.DataGridView dgvArt;
        private System.Windows.Forms.ToolStrip tlsBot;
        private System.Windows.Forms.ToolStripButton btnAbrir;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton btnModificar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton btnDeshacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.TextBox txtCodPro;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtRQ;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtRutArcAdj;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnRutArcAdj;
        private System.Windows.Forms.TextBox txtCodMon;
        private System.Windows.Forms.TextBox txtMon;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtPreUni;
        private System.Windows.Forms.Label label17;
        public System.Windows.Forms.ToolStripButton btnNuevo;
    }
}