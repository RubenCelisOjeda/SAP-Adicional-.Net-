﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;

namespace SAP_Adicional
{
    public partial class frmLOG_MaeArt_ActDat : Form,  SAP_Variables
    {

        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        NGEN_SAPConexion sap = new NGEN_SAPConexion();

        Int32 SAP_Conecta;
        bool SAP_UserBad;

        double lon = 0;
        double anc = 0;
        double alt = 0;
        double pes = 0;

        public frmLOG_MaeArt_ActDat()
        {
            InitializeComponent();
        }

        private void txtCodArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Articulos", "LOG_MaeArt_ActDat_filtro", txtCodArt.Text.Trim(), "1");

                if (varglo.Elegi == true)
                {
                    txtLon.Focus();
                }

                if (txtCodArt.Text == "") return;

            }
        }

        public void ConsultaDatos(string vista, string procedimiento, string param1, string param2)
        {
            DataTable dt = new DataTable();

            dt = nc.LOG_MaeArt_ActDat_Filtros(vista, procedimiento, param1, param2);


            if (dt.Rows.Count > 1)
            {

                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 43;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                //frm.LOG_MaeArt_ActDat = this;
                frm.ShowDialog();

            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {                   
                    case "Articulos":
                        txtCodArt.Text = row["Codigo"].ToString();
                        txtArtDes.Text = row["Descripción"].ToString();
                        txtLon.Text = row["longitud"].ToString();
                        txtAnc.Text = row["ancho"].ToString();
                        txtAlt.Text = row["altura"].ToString();
                        txtVol.Text = row["volumen"].ToString();
                        txtPes.Text = row["peso"].ToString();
                        txtClaGen.Text = row["Clas. General"].ToString();
                        txtNomUni.Text = row["Nombre Unico"].ToString();
                        txtCarAdi.Text = row["Caract. Adicionales"].ToString();
                        break;                      
                    default:
                        break;
                }

                varglo.Elegi = true;

            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show("No se encontraron registros", "SAP Adicional");
            }
        }

        public void recdat_LOG_MaeArt_ActDat(string codart, string art, string longitud, 
                                            string anc, string alt, string vol, string pes, 
                                            string clagen, string nomuni, string caradi)
        {
            txtCodArt.Text = codart;
            txtArtDes.Text = art;
            txtLon.Text = longitud;
            txtAnc.Text = anc;
            txtAlt.Text = alt;
            txtVol.Text = vol;
            txtPes.Text = pes;
            txtClaGen.Text = clagen;
            txtNomUni.Text = nomuni;
            txtCarAdi.Text = caradi;

            
        }

        private void btnAct_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("¿Esta seguro de actualizar los valores del articulo.?",
                                            "SAP Adicional",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (res == DialogResult.No) { return; }

            if (lon < 0 || anc < 0 || alt < 0 || pes < 0) { MessageBox.Show("Ningún valor puede ser negativo, por favor revisar."); return; }

            string errorSAP = "";

            if (sap.SAP_ValidarUsuario(varglo.UsuSAP, varglo.PasSAP) != 0)
            {//La primera vez las variables van a estar vacias y devolvera error por lo que
             //mostrara el formulario de inicio de sesion
                frmGEN_SAP_IniSes f = new frmGEN_SAP_IniSes();

                f.SAP_Var = this;
                f.ShowDialog();

                if (SAP_UserBad == true) return;
            }
            else
            {
                SAP_Conecta = sap.SAP_ConectarCompañia(varglo.UsuSAP, varglo.PasSAP);
            }

            if (SAP_Conecta != 0)
            {
                MessageBox.Show("Se ha producido el error " + SAP_Conecta.ToString(), "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {                                 

                //sap.VEN_MaeArt_ActDat(out errorSAP, txtCodArt.Text, lon, anc, 
                //                     alt, pes, txtClaGen.Text, 
                //                     txtNomUni.Text, txtCarAdi.Text);

                if (errorSAP != "")
                {
                    MessageBox.Show(errorSAP, "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information); return;
                }
                else
                {
                    MessageBox.Show("Operación finalizada con éxito", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                      
            }
        }

        public void rec_SAP_UserBad(bool UserBad)
        {
            SAP_UserBad = UserBad;
        }

        public void rec_SAP_Connection(int ErrorCode)
        {
            SAP_Conecta = ErrorCode;
        }

        private void txtLon_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(txtLon.Text, out lon);

            Volumnen();
        }

        private void txtAnc_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(txtAnc.Text, out anc);

            Volumnen();
        }

        private void txtAlt_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(txtAlt.Text, out alt);

            Volumnen();
        }

        private void Volumnen()
        {
            if (lon > 0 && anc > 0 && alt > 0)
            {
                txtVol.Text = (lon * anc * alt).ToString();
            }
            else
            {
                txtVol.Text = "0";
            }
        }

        private void txtPes_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(txtPes.Text, out pes);
        }

        private void txtArtDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Articulos", "LOG_MaeArt_ActDat_filtro", txtArtDes.Text.Trim(), "2");

                if (varglo.Elegi == true)
                {
                    txtLon.Focus();
                }

                if (txtCodArt.Text == "") return;

            }
        }

        private void btnCer_Click(object sender, EventArgs e)
        {
            this.Dispose();            
        }
    }
}
