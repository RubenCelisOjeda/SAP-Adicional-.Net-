﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Interfaces;
using CapaNegocio;

namespace SAP_Adicional
{
    public partial class frmConsulta_Varios : Form
    {
        public frmVEN_RQ_Info f { get; set; }
        public VEN_Cot_Filtros Ven_Cot { get; set; }
        public OPE_Pro_Filtros OPE_Pro { get; set; }
        public OPE_Pro_Filtros_Act OPE_Pro_Act { get; set; }
        public LOG_OFC_Filtros LOG_OFC { get; set; }
        public ALM_MovIngxEnc ALM_MovIngxEnc { get; set; }
        public VEN_rep_AdmRQ VEN_rep_AdmRQ { get; set; }
        public Men_Acc_Filtros Men_Acc_Filtros_Rec { get; set; }
        public frm_Man_Usuarios frm_Man_Usuarios_Rec { get; set; }

        public Ruta_Online Ruta_Online_Rec { get; set; }
        public Ruta_Corte Ruta_Corte_Rec { get; set; }
        public ALM_PreDoc_Con ALM_PreDoc_Con_Rec { get; set; }
        public ArtEti ArtEti_Rec { get; set; }
        public IALM_Ubi_ConStock ALM_Ubi_ConStock_Rec { get; set; }
        public ALM_Inventario ALM_Inventario_Rec { get; set; }
        public Ruta_Item Ruta_Item_Rec { get; set; }
        public Ruta_ItemDocRel Ruta_ItemDocRel_Rec { get; set; }
        public frmMan_Articulo_Compuesto Man_ArtCom { get; set; }
        public LOG_InfRS LOG_InfRS_Rec { get; set; }
        public LOG_Imp LOG_Imp_Rec { get; set; }
        public AccFrm AccFrm_Rec { get; set; }
        public IMan_Contactos Man_Contactos { get; set; }


        public int SubCod = 0;

        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();

        public frmConsulta_Varios()
        {
            InitializeComponent();            
        }

        public int Formulario;
        public string Vista;

        private void frmConsulta_Varios_Load(object sender, EventArgs e)
        {
            dg.DefaultCellStyle.Font = new Font("Tahoma", 9F, GraphicsUnit.Pixel);
            dg.AutoSize = true;
            dg.AutoResizeColumns();
            TamañoColumnas();
            varglo.Elegi = false;
        }
        
        public void DevolverDatos()
        {
            this.Hide();
            //
            switch (this.Formulario)
            {
                case 1:
                    switch (this.Vista)
                    {
                        case "Empleado/Usuario":
                            Men_Acc_Filtros_Rec.recdat_Men_Acc_Filtros_Empleado(
                            this.dg.CurrentRow.Cells[0].Value.ToString(),
                            this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Empleado2/Usuario2":
                            Men_Acc_Filtros_Rec.recdat_Men_Acc_Filtros_Empleado2(
                           this.dg.CurrentRow.Cells[0].Value.ToString(),
                           this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;

                        case "Area":
                            Men_Acc_Filtros_Rec.recdat_Men_Acc_Filtros_Area(
                            this.dg.CurrentRow.Cells[0].Value.ToString(),
                            this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        default:
                            break;
                    }
                    break;
                case 2: //frmRuta_Item 

                    switch (this.Vista)
                    {
                        case "Tipo de Ruta":
                            Ruta_Item_Rec.recdat_Ruta_Item_TipRut(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Medio Transporte":
                            Ruta_Item_Rec.recdat_Ruta_Item_MedTra(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Transportista":
                            Ruta_Item_Rec.recdat_Ruta_Item_Tra(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Distrito":
                            Ruta_Item_Rec.recdat_Ruta_Item_Dis(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Corte":
                            Ruta_Item_Rec.recdat_Ruta_Item_Cor(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString());
                            varglo.Elegi = true;
                            break;

                            //Ruta item documento relacionado
                        case "Entrega":
                        case "Solicitud de traslado":
                        case "Traslado":
                        case "Herramientas":
                            Ruta_ItemDocRel_Rec.recdat_Ruta_Item_DocRel(
                               this.dg.CurrentRow.Cells[0].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 3:
                    switch (this.Vista)
                    {
                        case "Rutas":
                            ALM_PreDoc_Con_Rec.recdat_ALM_PreDoc_Con_Rut(
                              this.dg.CurrentRow.Cells[0].Value.ToString(),
                              this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Almacen":
                            ALM_PreDoc_Con_Rec.recdat_ALM_PreDoc_Con_Alm(
                            this.dg.CurrentRow.Cells[0].Value.ToString(),
                            this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;                      

                        default:
                            break;
                    }
                    break;
                case 4: //frmRuta_Online
                    switch (this.Vista)
                    {
                        case "Rutas":
                        case "Corte":
                             Ruta_Online_Rec.recdat_Ruta_Online_RutCor(
                                  this.dg.CurrentRow.Cells[0].Value.ToString(),
                                  this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Transportista":
                            Ruta_Online_Rec.recdat_Ruta_Online_Tra(
                                 this.dg.CurrentRow.Cells[0].Value.ToString(),
                                 this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;

                case 7:
                    switch (this.Vista)
                    {
                        case "Almacen":
                            ALM_Ubi_ConStock_Rec.recdat_ALM_Ubi_ConStock_Alm(
                                 this.dg.CurrentRow.Cells[0].Value.ToString(),
                                 this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Articulo":
                            ALM_Ubi_ConStock_Rec.recdat_ALM_Ubi_ConStock_Art(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Articulo2":
                            ALM_Ubi_ConStock_Rec.recdat_ALM_Ubi_ConStock_Art2(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Instalador":
                            ALM_Ubi_ConStock_Rec.recdat_ALM_Ubi_ConStock_Res(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 9:
                    switch (this.Vista)
                    {
                        case "Codigo Articulo":
                        case "Articulo Descripcion":
                            ArtEti_Rec.recdat_ArtEtic_Dat(
                                 this.dg.CurrentRow.Cells[0].Value.ToString(),
                                 this.dg.CurrentRow.Cells[1].Value.ToString(),
                                 this.dg.CurrentRow.Cells[2].Value.ToString(),
                                 this.dg.CurrentRow.Cells[0].Value.ToString(),
                                 this.dg.CurrentRow.Cells[2].Value.ToString(),
                                 this.dg.CurrentRow.Cells[3].Value.ToString(),
                                 this.dg.CurrentRow.Cells[4].Value.ToString(),
                                 this.dg.CurrentRow.Cells[5].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 13:
                    switch (this.Vista)
                    {
                        case "Almacen":
                            ALM_Inventario_Rec.recdat_ALM_Inventario_Dis(
                              this.dg.CurrentRow.Cells[0].Value.ToString(),
                              this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Articulo":
                            ALM_Inventario_Rec.recdat_ALM_Inventario_Alm(
                             this.dg.CurrentRow.Cells[0].Value.ToString(),
                             this.dg.CurrentRow.Cells[1].Value.ToString(),
                             this.dg.CurrentRow.Cells[2].Value.ToString(),
                             this.dg.CurrentRow.Cells[3].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 14: //recdat_ALM_MovIngxEnc_Rango
                    switch (this.Vista)
                    {
                        case "Encargado":
                            ALM_MovIngxEnc.recdat_ALM_MovIngxEnc_Rango (
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        default:
                            break;                       
                    }
                    break;
                case 18: //frmMan_ArticuloCompuesto
                    switch (this.Vista)
                    {
                        case "Tipo":
                            Man_ArtCom.recdat_TipSer(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Articulo":
                            Man_ArtCom.recdat_ArtCom(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString(),
                                this.dg.CurrentRow.Cells[3].Value.ToString(),
                                this.dg.CurrentRow.Cells[5].Value.ToString(),
                                this.dg.CurrentRow.Cells[6].Value.ToString(),
                                this.dg.CurrentRow.Cells[7].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        default:
                            break;
                    }
                    break;
                case 19: //frmVEN_Cot
                    switch (this.Vista)
                    {
                        case "Cliente":
                            Ven_Cot.recdat_frmVEN_Cot_Cliente(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString(),
                                this.dg.CurrentRow.Cells[4].Value.ToString(),
                                this.dg.CurrentRow.Cells[5].Value.ToString(),
                                this.dg.CurrentRow.Cells[6].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "EmpleadoVentas":
                            Ven_Cot.recdat_frmVEN_Cot_EmpleadoVentas(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Centro de Venta":
                            Ven_Cot.recdat_frmVEN_Cot_CentroVenta(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tipo de Venta":
                            Ven_Cot.recdat_frmVEN_Cot_TipoVenta(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tipo de Venta Relativo":
                            Ven_Cot.recdat_frmVEN_Cot_TipoVentaRelativo(
                                this.dg.CurrentRow.Cells[0].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Rubro":
                            Ven_Cot.recdat_frmVEN_Cot_Rubro(
                                this.dg.CurrentRow.Cells[0].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tipo de Obra":
                            Ven_Cot.recdat_frmVEN_Cot_TipoObra(
                                this.dg.CurrentRow.Cells[0].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Dimension":
                            Ven_Cot.recdat_frmVEN_Cot_Dimension(
                                this.dg.CurrentRow.Cells[0].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Recomendador":
                            Ven_Cot.recdat_frmVEN_Cot_Recomendador(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Articulo Compuesto":
                            Ven_Cot.recdat_frmVEN_Cot_ArticuloCompuesto(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString(),
                                this.dg.CurrentRow.Cells[3].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Ambientes (Articulo Compuesto)":
                            Ven_Cot.recdat_frmVEN_Cot_Ambiente(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Motivo":
                            Ven_Cot.recdat_frmVEN_Cot_Motivo(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "AdmRQ":
                            Ven_Cot.recdat_frmVEN_Cot_AdmRQ(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tiempo":
                            Ven_Cot.recdat_frmVEN_Cot_Tiempo(
                                this.dg.CurrentRow.Cells[0].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Ambientes (Otros Articulos)":
                            Ven_Cot.recdat_frmVEN_Cot_AmbienteAA(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Articulo Simple":
                            Ven_Cot.recdat_frmVEN_Cot_Articulo(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Ambientes (Articulo Simple)":
                            Ven_Cot.recdat_frmVEN_Cot_ArtAmb(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Falla En":
                            Ven_Cot.recdat_frmVEN_Cot_FalEn(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Linea Producto/Servicio":
                            Ven_Cot.recdat_frmVEN_Cot_LinPro(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tipo":
                            Ven_Cot.recdat_frmVEN_Cot_Tip(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "SubLinea":
                            Ven_Cot.recdat_frmVEN_Cot_SubLin(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Familia":
                            Ven_Cot.recdat_frmVEN_Cot_Fam(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Contacto Cliente":
                            Ven_Cot.recdat_frmVEN_Cot_CliCon(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Negocio":
                            Ven_Cot.recdat_frmVEN_Cot_Neg(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Envio":
                            Ven_Cot.recdat_frmVEN_Cot_Env(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Linea":
                            Ven_Cot.recdat_frmVEN_Cot_Lin(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "SubLineaAA":
                            Ven_Cot.recdat_frmVEN_Cot_SubLinAA(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "FamiliaAA":
                            Ven_Cot.recdat_frmVEN_Cot_FamAA(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "SubFamilia":
                            Ven_Cot.recdat_frmVEN_Cot_SubFam(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Marca":
                            Ven_Cot.recdat_frmVEN_Cot_Marca(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Proveedor":
                            Ven_Cot.recdat_frmVEN_Cot_Pro(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        //case "Color Mueble":
                        //    Ven_Cot.recdat_frmVEN_Cot_ColMue(
                        //        this.dg.CurrentRow.Cells[0].Value.ToString(),
                        //        this.dg.CurrentRow.Cells[1].Value.ToString());
                        //    varglo.Elegi = true;
                        //    break;
                        case "Material Base Mueble":
                            Ven_Cot.recdat_frmVEN_Cot_MatBasMue(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "ProveedorHome":
                            Ven_Cot.recdat_frmVEN_Cot_ProHom(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString(),
                                this.dg.CurrentRow.Cells[3].Value.ToString(),
                                this.dg.CurrentRow.Cells[4].Value.ToString(),
                                this.dg.CurrentRow.Cells[5].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Seleccionar RQ":
                            //Ven_Cot.recdat_frmVEN_Cot_RQ(
                            //    this.dg.CurrentRow.Cells[0].Value.ToString());
                            break;
                        default:
                            break;
                    }
                    break;
                case 23:
                    {
                        switch (this.Vista)
                        {
                            case "Distrito":
                                {
                                    this.Man_Contactos.RecDat_Dis(
                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                    this.dg.CurrentRow.Cells[1].Value.ToString());
                                    varglo.Elegi = true;
                                }
                                break;

                            case "Distrito2":
                                {
                                    this.Man_Contactos.RecDat_Dis2(
                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                    this.dg.CurrentRow.Cells[1].Value.ToString());
                                    varglo.Elegi = true;
                                }
                                break;

                            case "Profesion":
                                {
                                    this.Man_Contactos.RecDat_Pro(
                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                    this.dg.CurrentRow.Cells[1].Value.ToString());
                                    varglo.Elegi = true;
                                }
                                break;

                            case "TipoContacto":
                                {
                                    this.Man_Contactos.RecDat_TipCon(
                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                    this.dg.CurrentRow.Cells[1].Value.ToString());
                                    varglo.Elegi = true;
                                }
                                break;

                            case "Responsabilidad":
                                {
                                    this.Man_Contactos.RecDat_Res(
                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                    this.dg.CurrentRow.Cells[1].Value.ToString());
                                    varglo.Elegi = true;
                                }
                                break;

                            case "Categoria":
                                {
                                    this.Man_Contactos.RecDat_Cat(
                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                    this.dg.CurrentRow.Cells[1].Value.ToString());
                                    varglo.Elegi = true;
                                }
                                break;

                            default:
                                break;
                        }
                        
                    }
                    break;

                case 24: //frmALM_REP_AlmArt_Acc
                    switch (this.Vista)
                    {
                        case "Empleado":

                            //Alm_rep_AlmArt_Stock.recdat_ALM_REP_AlmArt_Stock_Acc_Empleado(
                            // this.dg.CurrentRow.Cells[0].Value.ToString(),
                            // this.dg.CurrentRow.Cells[1].Value.ToString());

                            //}
                            break;
                        case "Area":
                            //Alm_rep_AlmArt_Stock.recdat_ALM_REP_AlmArt_Stock_Acc_Area(
                            //      this.dg.CurrentRow.Cells[0].Value.ToString(),
                            //      this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Almacen": //recuperar datos
                            //Alm_rep_AlmArt_Stock.recdat_ALM_REP_AlmArt_Stock_Acc_Almacen(
                            //      this.dg.CurrentRow.Cells[0].Value.ToString(),
                            //      this.dg.CurrentRow.Cells[1].Value.ToString());
                            //varglo.Elegi = true;
                            break;
                    }
                    break;

                case 25: //frmVEN_RQ_info                    
                    switch (this.Vista)
                    {                        
                        case "RQ":
                             f.recdat_frmVEN_RQ_info(
                                                    this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                    this.dg.CurrentRow.Cells[1].Value.ToString()
                                                    );                                                      
                            break;
                        default:
                            break;
                    }
                    break;
                case 27:
                    switch (this.Vista)
                    {
                        case "RQ_DetPed":
                            LOG_InfRS_Rec.recdat_RqPed(
                            this.dg.CurrentRow.Cells[0].Value.ToString(),
                            this.dg.CurrentRow.Cells[1].Value.ToString());

                            varglo.Elegi = true;
                            break;
                        case "Articulo":
                            LOG_InfRS_Rec.recdat_Art(
                             this.dg.CurrentRow.Cells[0].Value.ToString(),
                             this.dg.CurrentRow.Cells[2].Value.ToString(),
                             this.dg.CurrentRow.Cells[8].Value.ToString(),
                             this.dg.CurrentRow.Cells[3].Value.ToString());

                            varglo.Elegi = true;
                            break;
                        case "ArticuloOc":
                            LOG_InfRS_Rec.recdat_ArtOC(
                             this.dg.CurrentRow.Cells[0].Value.ToString(),
                             this.dg.CurrentRow.Cells[2].Value.ToString(),
                             this.dg.CurrentRow.Cells[8].Value.ToString());

                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 30:
                    switch (this.Vista)
                    {
                        case "Corte":
                            Ruta_Corte_Rec.recdat_Ruta_Corte_Cor(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 34://frmLog_Imp
                    switch (this.Vista)
                    {
                        case "Proveedor":
                            LOG_Imp_Rec.recdat_Pro(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;

                        case "Envio":
                            LOG_Imp_Rec.recdat_Env(
                              this.dg.CurrentRow.Cells[0].Value.ToString(),
                              this.dg.CurrentRow.Cells[1].Value.ToString(),
                              this.dg.CurrentRow.Cells[2].Value.ToString());
                            varglo.Elegi = true;
                            break;

                        case "Estado Pago":
                            LOG_Imp_Rec.recdat_EstPag(
                              this.dg.CurrentRow.Cells[0].Value.ToString(),
                              this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;

                        case "Moneda":
                            LOG_Imp_Rec.recdat_Mon(
                              this.dg.CurrentRow.Cells[0].Value.ToString(),
                              this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;

                        case "Articulo":
                            LOG_Imp_Rec.recdat_Art(
                              this.dg.CurrentRow.Cells[0].Value.ToString(),
                              this.dg.CurrentRow.Cells[2].Value.ToString(),
                              this.dg.CurrentRow.Cells[3].Value.ToString(),
                              this.dg.CurrentRow.Cells[8].Value.ToString(),
                              this.dg.CurrentRow.Cells[9].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;
                case 36: //frmMan_Usuarios
                    switch (this.Vista)
                    {
                        case "NombreEmpleado":
                            frm_Man_Usuarios_Rec.recdat_frm_Man_Usuario(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            break;
                        default:
                            break;
                    }
                    break;
                case 39: //frmOPE_Pro_ingact 
                    switch (this.Vista)
                    {
                        case "Tipo":
                            OPE_Pro.recdat_OPE_Pro_Tipo(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Diseño":
                            OPE_Pro.recdat_OPE_Pro_Diseño(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Ing. Operaciones":
                            OPE_Pro.recdat_OPE_Pro_IngOpe(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Supervisor":
                            OPE_Pro.recdat_OPE_Pro_Supervisor(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Adm. Pedidos":
                            OPE_Pro.recdat_OPE_Pro_AdmPed(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Complejidad":
                            OPE_Pro.recdat_OPE_Pro_Complejidad(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tipo Predio":
                            OPE_Pro.recdat_OPE_Pro_TipoPredio(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "RQ":
                            OPE_Pro.recdat_OPE_Pro_RQ(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString(),
                                this.dg.CurrentRow.Cells[2].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        default:
                            break;
                    }
                    break;
               

                case 40: //frmOPE_Pro
                    switch (this.Vista)
                    {
                        case "Cargo":
                            OPE_Pro_Act.recdat_OPE_Pro_Cargo(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Estado Obra":
                            OPE_Pro_Act.recdat_OPE_Pro_EstadoObra(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        default:
                            break;
                    }
                    break;

                case 41: //frmLOG_OFC
                    switch (this.Vista)
                    {
                        case "Tipo OFC":
                            LOG_OFC.recdat_LOG_OFC_TipOFC(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Tipo de Servicio":
                            LOG_OFC.recdat_LOG_OFC_TipSer(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Servicio":
                            LOG_OFC.recdat_LOG_OFC_Ser(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[2].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[3].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[4].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[5].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[6].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[7].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[8].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Categoria":
                            LOG_OFC.recdat_LOG_OFC_CatGas(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Area":
                            LOG_OFC.recdat_LOG_OFC_Are(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "SubArea":
                            LOG_OFC.recdat_LOG_OFC_SubAre(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Unidad de Negocio":
                            LOG_OFC.recdat_LOG_OFC_UniNeg(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Proveedor":
                            LOG_OFC.recdat_LOG_OFC_Pro(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        case "Moneda":
                            LOG_OFC.recdat_LOG_OFC_Mon(
                                                   this.dg.CurrentRow.Cells[0].Value.ToString(),
                                                   this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                        default:
                            break;
                    }
                    break;

                case 43:
                    switch (Vista)
                    {
                        case "Articulos":

                            //LOG_MaeArt_ActDat.recdat_LOG_MaeArt_ActDat(this.dg.CurrentRow.Cells[0].Value.ToString(), //Codigo
                            //                                            this.dg.CurrentRow.Cells[1].Value.ToString(), //Descripcion
                            //                                            this.dg.CurrentRow.Cells[2].Value.ToString(), //Longitud
                            //                                            this.dg.CurrentRow.Cells[3].Value.ToString(), //Ancho
                            //                                            this.dg.CurrentRow.Cells[4].Value.ToString(), //Altura
                            //                                            this.dg.CurrentRow.Cells[5].Value.ToString(), //Volumnen
                            //                                            this.dg.CurrentRow.Cells[6].Value.ToString(), //Peso
                            //                                            this.dg.CurrentRow.Cells[7].Value.ToString(), //Clas. General
                            //                                            this.dg.CurrentRow.Cells[8].Value.ToString(), //Nombre Unico
                            //                                            this.dg.CurrentRow.Cells[9].Value.ToString()); //Caract. Adi.

                            break;
                    }
                    break;

                case 45: //ultimo filtro - //frmAccFrm
                    switch (Vista)
                    {
                        case "Usuario":
                            AccFrm_Rec.recdat_Usu(
                                 this.dg.CurrentRow.Cells[0].Value.ToString(),
                                 this.dg.CurrentRow.Cells[1].Value.ToString());
                                 varglo.Elegi = true;
                            break;
                        case "Documento":
                            AccFrm_Rec.recdat_Doc(
                                this.dg.CurrentRow.Cells[0].Value.ToString(),
                                this.dg.CurrentRow.Cells[1].Value.ToString());
                            varglo.Elegi = true;
                            break;
                    }
                    break;

                default:
                    break;
            }
            this.Dispose();
        }

        private void dg_DoubleClick(object sender, EventArgs e)
        {
            DevolverDatos();
        }

        void TamañoColumnas()
        {
            switch (this.Formulario)
            {
                case 1: //frmMenus_Accesos
                    switch (Vista)
                    {
                        case "Empleado/Usuario":
                            this.dg.Columns[0].Width = 50;
                            this.dg.Columns[1].Width = 300;
                            this.dg.Columns[2].Width = 70;
                            break;


                        case "Area":
                            this.dg.Columns[0].Width = 50;
                            this.dg.Columns[1].Width = 100;
                            break;
                    }
                    break;

                case 19://frmVEN_Cot
                    switch (Vista)
                    {
                        case "Cliente":
                            this.dg.Columns[0].Width = 100;
                            this.dg.Columns[1].Width = 300;
                            this.dg.Columns[2].Width = 100;
                            this.dg.Columns[3].Width = 100;
                            this.dg.Columns[4].Width = 100;
                            this.dg.Columns[5].Width = 100;
                            this.dg.Columns[6].Width = 200;
                            break;
                        case "EmpleadoVentas":
                            this.dg.Columns[0].Width = 100;
                            this.dg.Columns[1].Width = 300;
                            this.dg.Columns[2].Width = 100;
                            break;
                        case "Centro de Venta":
                        case "Tipo de Venta":
                        case "Recomendador":
                            this.dg.Columns[0].Width = 100;
                            this.dg.Columns[1].Width = 300;
                            break;
                        case "Tipo de Venta Relativo":
                        case "Rubro":
                        case "Tipo de Obra":
                        case "Dimension":
                            this.dg.Columns[0].Width = 300;
                            break;
                        case "ArticuloCompuesto":
                            dg.Columns[0].Width = 50;
                            dg.Columns[1].Width = 400;
                            dg.Columns[2].Width = 100;
                            dg.Columns[3].Width = 400;
                            dg.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            break;
                        case "Ambiente":
                        case "ArtAmb":
                            dg.Columns[0].Width = 50;
                            dg.Columns[1].Width = 300;
                            break;
                        case "Articulo":
                            dg.Columns[0].Width = 60;
                            dg.Columns[1].Width = 580;
                            dg.Columns[2].Width = 60;
                            dg.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            break;
                        default:
                            break;
                    }
                    break;
                case 38: //frmOPE_Pro_ingact 
                    switch (this.Vista)
                    {
                        case "RQ":
                            dg.Columns[0].Width = 50;
                            dg.Columns[1].Width = 400;
                            dg.Columns[2].Width = 100;
                            break;
                        case "Tipo":
                        case "Complejidad":
                        case "Tipo Predio":
                        case "Diseño":
                        case "Ing. Operaciones":
                        case "Supervisor":
                        case "Adm. Pedidos":
                            dg.Columns[0].Width = 50;
                            dg.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                            dg.Columns[1].Width = 200;
                            break;
                        default:
                            break;
                    }
                    break;

                case 44: //frmRutaDocRel
                    dg.Columns[0].Width = 60;
                    dg.Columns[1].Width = 80;
                    dg.Columns[2].Width = 100;
                    dg.Columns[3].Width = 250;
                    dg.Columns[4].Width = 70;
                    dg.Columns[5].Width = 250;
                    break;

                case 45: //frmAccFrm
                    switch (this.Vista)
                    {
                        case "Usuario":
                            dg.Columns[0].Width = 50;
                            dg.Columns[1].Width = 300;
                            dg.Columns[2].Width = 50;
                            dg.Columns[3].Width = 90;
                            break;
                        case "Documento":
                            dg.Columns[0].Width = 50;
                            dg.Columns[1].Width = 300;
                            break;
                    }
                    break;

                default:
                    break;
            }            
        }

        private void dg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DevolverDatos();
                e.SuppressKeyPress = true;

            }
        }

        private void frmConsulta_Varios_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape) 
            {
                this.Close();
            }
        }
    }
}
