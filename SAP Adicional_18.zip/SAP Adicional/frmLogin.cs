﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CapaNegocio;
using System.Configuration;

namespace SAP_Adicional
{
    public partial class frmLogin : Form
    {
        private VarGlo varglo = VarGlo.Instance();
        private NConsultas nc = new NConsultas();
        private NLogin nl = new NLogin();

        private int _posY = 0;
        private int _posX = 0;

        public frmLogin()
        {
            InitializeComponent();
            MetGlo.BackColorText(this);
            MetGlo.SeleccionTexto(this);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Login_MosBasDeDat();
            this.Login_MostrarLogoBase();

            //recupera el nombre desde el appconfig
            this.cboBases.Text = Properties.Settings.Default.DataBase;
            this.chbRecUsu.Checked = Properties.Settings.Default.Check;

            if (this.chbRecUsu.Checked)
            {
                this.txtUsu.Text = Properties.Settings.Default.RecordarUsu;
                this.chbRecUsu.Checked = true;
            }
            else
            {
                Properties.Settings.Default.Check = false;
                Properties.Settings.Default.RecordarUsu = "";
            }
        }
        private void btnAce_Click(object sender, EventArgs e)
        {
            NLogin valUsu = new NLogin();
            valUsu.CreateConnectionString(this.cboBases.SelectedValue.ToString());

            // Asigno valores
            string User = this.txtUsu.Text;
            string Password = this.txtCon.Text;

            if (User == "" || Password == "") //si no tiene usuario o password aparece mensaje de error
            {
                MessageBox.Show("Usuario y/o password incorrecto", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtUsu.Focus();
                return;
            }
            else
            {
                if (valUsu.ValidarUsuario(this.txtUsu.Text, this.txtCon.Text) == 0)
                {
                    MessageBox.Show("Usuario y/o password incorrecto", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    varglo.CodUsuAct = valUsu.ValidarUsuario(this.txtUsu.Text, this.txtCon.Text);
                    varglo.Base = this.cboBases.SelectedValue.ToString();
                    varglo.Empresa = this.cboBases.Text;
                    varglo.BaseSAP = nl.RecuperaBaseSAP();
                    varglo.ValFormClose = false;

                    frmPri f = new frmPri(this);
                    f.Text = "SAP Adicional - " + this.cboBases.Text;

                    //codigo para guardar el nombre en el appconfig
                    Properties.Settings.Default.DataBase = this.cboBases.Text;
                    Properties.Settings.Default.RecordarUsu = this.txtUsu.Text;
                    Properties.Settings.Default.Check = this.chbRecUsu.Checked;
                    Properties.Settings.Default.Save();

                    f.Show();
                    this.Hide();
                }
            }
        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtUsu_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.txtCon.Focus();
            }
        }

        private void txtCon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.btnAce.Focus();
            }
        }

        private void Login_MosBasDeDat() //mostrar bases de datos
        {
            string nomBas = "";
            string nomEmp = "";

            DataTable dt = new DataTable();
            dt = nl.RecuperoBases();

            DataTable dtCrear = new DataTable();

            DataColumn CNomBas = dtCrear.Columns.Add("NombreBase");
            DataColumn CNomEmp = dtCrear.Columns.Add("NomEmp");

            DataRow row;

            this.cboBases.ValueMember = "NombreBase";
            this.cboBases.DisplayMember = "NomEmp";

            foreach (DataRow rows in dt.Rows)
            {
                nomBas = nl.ConectarBases(rows[0].ToString());
                nomEmp = rows[0].ToString();

                if (nomBas != "")
                {
                    row = dtCrear.NewRow();

                    row["NombreBase"] = nomEmp;
                    row["NomEmp"] = nomBas;

                    dtCrear.Rows.Add(row);
                }
            }

            this.cboBases.DataSource = dtCrear;
        }

        private void cboBases_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                this.txtUsu.Focus();
            }
        }

        private void cboBases_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Login_MostrarLogoBase();
        }

        private void Login_MostrarLogoBase()
        {
            if (cboBases.Text.Contains("TRAZZO"))
            {
                this.lblHom.Visible = false;
                this.lblIlu.Visible = true;
            }
            else if (this.cboBases.Text.Contains("HOME"))
            {
                this.lblIlu.Visible = false;
                this.lblHom.Visible = true;
            }
            else
            {
                this.lblIlu.Visible = false;
                this.lblHom.Visible = false;
            }
        }

        private void pnlLogin_MouseMove(object sender, MouseEventArgs e)
        {
            this.LoginMoverFormulario(e);
        }
        
        private void frmLogin_MouseMove(object sender, MouseEventArgs e)
        {
            this.LoginMoverFormulario(e);
        }
        private void LoginMoverFormulario(MouseEventArgs e)
        {
            //codigo para mover el panel
            if (e.Button != MouseButtons.Left)
            {
                _posX = e.X;
                _posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - _posX);
                Top = Top + (e.Y - _posY);
            }
        }
    }
}
