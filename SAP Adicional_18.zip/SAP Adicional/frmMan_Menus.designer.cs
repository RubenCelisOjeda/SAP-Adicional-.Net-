﻿namespace SAP_Adicional
{
    partial class frmMan_Menus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMan_Menus));
            this.treVieMen = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabConVisNue = new System.Windows.Forms.TabControl();
            this.tabPagVis = new System.Windows.Forms.TabPage();
            this.btnEliMen = new System.Windows.Forms.Button();
            this.btnAct = new System.Windows.Forms.Button();
            this.txtOrdNiv = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtOrdJer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFor_Vis = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKeyRel_Vis = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtKeyNod_Vis = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNomMen_Vis = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodMen_Vis = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPagNue = new System.Windows.Forms.TabPage();
            this.chkPri = new System.Windows.Forms.CheckBox();
            this.btnAgrMen = new System.Windows.Forms.Button();
            this.txtFor_Nue = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNivSup = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtKeyRel_Nue = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtKeyNod_Nue = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNomMen_Nue = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCodMen_Nue = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tabConVisNue.SuspendLayout();
            this.tabPagVis.SuspendLayout();
            this.tabPagNue.SuspendLayout();
            this.SuspendLayout();
            // 
            // treVieMen
            // 
            this.treVieMen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.treVieMen.ImageIndex = 0;
            this.treVieMen.ImageList = this.imageList1;
            this.treVieMen.Location = new System.Drawing.Point(5, 12);
            this.treVieMen.Name = "treVieMen";
            this.treVieMen.SelectedImageIndex = 0;
            this.treVieMen.Size = new System.Drawing.Size(463, 446);
            this.treVieMen.StateImageList = this.imageList1;
            this.treVieMen.TabIndex = 0;
            this.treVieMen.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treVieMen_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "icono amarillo.ico");
            // 
            // tabConVisNue
            // 
            this.tabConVisNue.Controls.Add(this.tabPagVis);
            this.tabConVisNue.Controls.Add(this.tabPagNue);
            this.tabConVisNue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabConVisNue.Location = new System.Drawing.Point(488, 12);
            this.tabConVisNue.Name = "tabConVisNue";
            this.tabConVisNue.SelectedIndex = 0;
            this.tabConVisNue.Size = new System.Drawing.Size(270, 423);
            this.tabConVisNue.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabConVisNue.TabIndex = 0;
            // 
            // tabPagVis
            // 
            this.tabPagVis.Controls.Add(this.btnEliMen);
            this.tabPagVis.Controls.Add(this.btnAct);
            this.tabPagVis.Controls.Add(this.txtOrdNiv);
            this.tabPagVis.Controls.Add(this.label7);
            this.tabPagVis.Controls.Add(this.txtOrdJer);
            this.tabPagVis.Controls.Add(this.label6);
            this.tabPagVis.Controls.Add(this.txtFor_Vis);
            this.tabPagVis.Controls.Add(this.label5);
            this.tabPagVis.Controls.Add(this.txtKeyRel_Vis);
            this.tabPagVis.Controls.Add(this.label4);
            this.tabPagVis.Controls.Add(this.txtKeyNod_Vis);
            this.tabPagVis.Controls.Add(this.label3);
            this.tabPagVis.Controls.Add(this.txtNomMen_Vis);
            this.tabPagVis.Controls.Add(this.label2);
            this.tabPagVis.Controls.Add(this.txtCodMen_Vis);
            this.tabPagVis.Controls.Add(this.label1);
            this.tabPagVis.Location = new System.Drawing.Point(4, 22);
            this.tabPagVis.Name = "tabPagVis";
            this.tabPagVis.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagVis.Size = new System.Drawing.Size(262, 397);
            this.tabPagVis.TabIndex = 0;
            this.tabPagVis.Text = "Vista";
            this.tabPagVis.UseVisualStyleBackColor = true;
            // 
            // btnEliMen
            // 
            this.btnEliMen.BackColor = System.Drawing.SystemColors.Control;
            this.btnEliMen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliMen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEliMen.Location = new System.Drawing.Point(132, 353);
            this.btnEliMen.Name = "btnEliMen";
            this.btnEliMen.Size = new System.Drawing.Size(92, 31);
            this.btnEliMen.TabIndex = 9;
            this.btnEliMen.Text = "Eliminar Menu";
            this.btnEliMen.UseVisualStyleBackColor = false;
            this.btnEliMen.Click += new System.EventHandler(this.btnEliMen_Click);
            // 
            // btnAct
            // 
            this.btnAct.BackColor = System.Drawing.SystemColors.Control;
            this.btnAct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAct.Location = new System.Drawing.Point(42, 353);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(92, 31);
            this.btnAct.TabIndex = 8;
            this.btnAct.Text = "Actualizar";
            this.btnAct.UseVisualStyleBackColor = false;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            // 
            // txtOrdNiv
            // 
            this.txtOrdNiv.Location = new System.Drawing.Point(14, 317);
            this.txtOrdNiv.Name = "txtOrdNiv";
            this.txtOrdNiv.Size = new System.Drawing.Size(239, 21);
            this.txtOrdNiv.TabIndex = 7;
            this.txtOrdNiv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrdNiv_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Orden en su nivel.";
            // 
            // txtOrdJer
            // 
            this.txtOrdJer.Location = new System.Drawing.Point(14, 270);
            this.txtOrdJer.Name = "txtOrdJer";
            this.txtOrdJer.Size = new System.Drawing.Size(239, 21);
            this.txtOrdJer.TabIndex = 6;
            this.txtOrdJer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOrdJer_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Orden Jerarquico";
            // 
            // txtFor_Vis
            // 
            this.txtFor_Vis.Location = new System.Drawing.Point(14, 224);
            this.txtFor_Vis.Name = "txtFor_Vis";
            this.txtFor_Vis.Size = new System.Drawing.Size(239, 21);
            this.txtFor_Vis.TabIndex = 5;
            this.txtFor_Vis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFor_Vis_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Formulario:";
            // 
            // txtKeyRel_Vis
            // 
            this.txtKeyRel_Vis.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtKeyRel_Vis.Location = new System.Drawing.Point(14, 178);
            this.txtKeyRel_Vis.Name = "txtKeyRel_Vis";
            this.txtKeyRel_Vis.Size = new System.Drawing.Size(239, 21);
            this.txtKeyRel_Vis.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Key (Relation)";
            // 
            // txtKeyNod_Vis
            // 
            this.txtKeyNod_Vis.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtKeyNod_Vis.Location = new System.Drawing.Point(14, 131);
            this.txtKeyNod_Vis.Name = "txtKeyNod_Vis";
            this.txtKeyNod_Vis.Size = new System.Drawing.Size(239, 21);
            this.txtKeyNod_Vis.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Key (Nodo)";
            // 
            // txtNomMen_Vis
            // 
            this.txtNomMen_Vis.Location = new System.Drawing.Point(14, 83);
            this.txtNomMen_Vis.Name = "txtNomMen_Vis";
            this.txtNomMen_Vis.Size = new System.Drawing.Size(239, 21);
            this.txtNomMen_Vis.TabIndex = 2;
            this.txtNomMen_Vis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomMen_Vis_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre Menu:";
            // 
            // txtCodMen_Vis
            // 
            this.txtCodMen_Vis.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodMen_Vis.Location = new System.Drawing.Point(14, 33);
            this.txtCodMen_Vis.Name = "txtCodMen_Vis";
            this.txtCodMen_Vis.Size = new System.Drawing.Size(100, 21);
            this.txtCodMen_Vis.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codigo Menu:";
            // 
            // tabPagNue
            // 
            this.tabPagNue.Controls.Add(this.chkPri);
            this.tabPagNue.Controls.Add(this.btnAgrMen);
            this.tabPagNue.Controls.Add(this.txtFor_Nue);
            this.tabPagNue.Controls.Add(this.label8);
            this.tabPagNue.Controls.Add(this.txtNivSup);
            this.tabPagNue.Controls.Add(this.label9);
            this.tabPagNue.Controls.Add(this.txtKeyRel_Nue);
            this.tabPagNue.Controls.Add(this.label11);
            this.tabPagNue.Controls.Add(this.txtKeyNod_Nue);
            this.tabPagNue.Controls.Add(this.label12);
            this.tabPagNue.Controls.Add(this.txtNomMen_Nue);
            this.tabPagNue.Controls.Add(this.label13);
            this.tabPagNue.Controls.Add(this.txtCodMen_Nue);
            this.tabPagNue.Controls.Add(this.label14);
            this.tabPagNue.Location = new System.Drawing.Point(4, 22);
            this.tabPagNue.Name = "tabPagNue";
            this.tabPagNue.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagNue.Size = new System.Drawing.Size(262, 397);
            this.tabPagNue.TabIndex = 1;
            this.tabPagNue.Text = "Nuevo";
            this.tabPagNue.UseVisualStyleBackColor = true;
            // 
            // chkPri
            // 
            this.chkPri.AutoSize = true;
            this.chkPri.Location = new System.Drawing.Point(120, 34);
            this.chkPri.Name = "chkPri";
            this.chkPri.Size = new System.Drawing.Size(65, 17);
            this.chkPri.TabIndex = 16;
            this.chkPri.Text = "Principal";
            this.chkPri.UseVisualStyleBackColor = true;
            this.chkPri.CheckedChanged += new System.EventHandler(this.chkPri_CheckedChanged);
            // 
            // btnAgrMen
            // 
            this.btnAgrMen.BackColor = System.Drawing.SystemColors.Control;
            this.btnAgrMen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgrMen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAgrMen.Location = new System.Drawing.Point(12, 300);
            this.btnAgrMen.Name = "btnAgrMen";
            this.btnAgrMen.Size = new System.Drawing.Size(92, 35);
            this.btnAgrMen.TabIndex = 15;
            this.btnAgrMen.Text = "Agregar Menu";
            this.btnAgrMen.UseVisualStyleBackColor = false;
            this.btnAgrMen.Click += new System.EventHandler(this.btnAgrMen_Click);
            // 
            // txtFor_Nue
            // 
            this.txtFor_Nue.Location = new System.Drawing.Point(12, 273);
            this.txtFor_Nue.Name = "txtFor_Nue";
            this.txtFor_Nue.Size = new System.Drawing.Size(239, 21);
            this.txtFor_Nue.TabIndex = 14;
            this.txtFor_Nue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFor_Nue_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 257);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Formulario";
            // 
            // txtNivSup
            // 
            this.txtNivSup.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtNivSup.Location = new System.Drawing.Point(12, 226);
            this.txtNivSup.Name = "txtNivSup";
            this.txtNivSup.Size = new System.Drawing.Size(239, 21);
            this.txtNivSup.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Nivel Superior (Menu)";
            // 
            // txtKeyRel_Nue
            // 
            this.txtKeyRel_Nue.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtKeyRel_Nue.Location = new System.Drawing.Point(13, 176);
            this.txtKeyRel_Nue.Name = "txtKeyRel_Nue";
            this.txtKeyRel_Nue.Size = new System.Drawing.Size(239, 21);
            this.txtKeyRel_Nue.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 160);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Key (Relation)";
            // 
            // txtKeyNod_Nue
            // 
            this.txtKeyNod_Nue.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtKeyNod_Nue.Location = new System.Drawing.Point(13, 129);
            this.txtKeyNod_Nue.Name = "txtKeyNod_Nue";
            this.txtKeyNod_Nue.Size = new System.Drawing.Size(239, 21);
            this.txtKeyNod_Nue.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 113);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "Key (Nodo)";
            // 
            // txtNomMen_Nue
            // 
            this.txtNomMen_Nue.Location = new System.Drawing.Point(13, 81);
            this.txtNomMen_Nue.Name = "txtNomMen_Nue";
            this.txtNomMen_Nue.Size = new System.Drawing.Size(239, 21);
            this.txtNomMen_Nue.TabIndex = 10;
            this.txtNomMen_Nue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomMen_Nue_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Nombre Menu:";
            // 
            // txtCodMen_Nue
            // 
            this.txtCodMen_Nue.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodMen_Nue.Location = new System.Drawing.Point(13, 31);
            this.txtCodMen_Nue.Name = "txtCodMen_Nue";
            this.txtCodMen_Nue.Size = new System.Drawing.Size(100, 21);
            this.txtCodMen_Nue.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Codigo Menu:";
            // 
            // frmMan_Menus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 470);
            this.Controls.Add(this.tabConVisNue);
            this.Controls.Add(this.treVieMen);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMan_Menus";
            this.Text = "Menus";
            this.Load += new System.EventHandler(this.frmMan_Menus_Load);
            this.tabConVisNue.ResumeLayout(false);
            this.tabPagVis.ResumeLayout(false);
            this.tabPagVis.PerformLayout();
            this.tabPagNue.ResumeLayout(false);
            this.tabPagNue.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treVieMen;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TabControl tabConVisNue;
        private System.Windows.Forms.TabPage tabPagVis;
        private System.Windows.Forms.TabPage tabPagNue;
        private System.Windows.Forms.Button btnAct;
        private System.Windows.Forms.TextBox txtOrdNiv;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtOrdJer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFor_Vis;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKeyRel_Vis;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtKeyNod_Vis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNomMen_Vis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCodMen_Vis;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAgrMen;
        private System.Windows.Forms.TextBox txtFor_Nue;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtNivSup;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtKeyRel_Nue;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtKeyNod_Nue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNomMen_Nue;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCodMen_Nue;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chkPri;
        private System.Windows.Forms.Button btnEliMen;
        //private C1.C1Pdf.C1PdfDocument c1PdfDocument1;
    }
}