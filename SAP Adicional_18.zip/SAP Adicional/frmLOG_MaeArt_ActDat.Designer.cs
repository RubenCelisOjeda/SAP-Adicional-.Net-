﻿namespace SAP_Adicional
{
    partial class frmLOG_MaeArt_ActDat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCodArt = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtArtDes = new System.Windows.Forms.TextBox();
            this.grpDatBasEmb = new System.Windows.Forms.GroupBox();
            this.grpDatEti = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLon = new System.Windows.Forms.TextBox();
            this.txtAnc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAlt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtVol = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPes = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCarAdi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNomUni = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtClaGen = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAct = new System.Windows.Forms.Button();
            this.btnCer = new System.Windows.Forms.Button();
            this.grpDatBasEmb.SuspendLayout();
            this.grpDatEti.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCodArt
            // 
            this.txtCodArt.BackColor = System.Drawing.SystemColors.Window;
            this.txtCodArt.Location = new System.Drawing.Point(62, 21);
            this.txtCodArt.MaxLength = 9;
            this.txtCodArt.Name = "txtCodArt";
            this.txtCodArt.Size = new System.Drawing.Size(77, 21);
            this.txtCodArt.TabIndex = 34;
            this.txtCodArt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArt_KeyPress);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(16, 23);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(47, 13);
            this.label54.TabIndex = 33;
            this.label54.Text = "Articulo:";
            // 
            // txtArtDes
            // 
            this.txtArtDes.Location = new System.Drawing.Point(140, 21);
            this.txtArtDes.MaxLength = 100;
            this.txtArtDes.Name = "txtArtDes";
            this.txtArtDes.Size = new System.Drawing.Size(516, 21);
            this.txtArtDes.TabIndex = 35;
            this.txtArtDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArtDes_KeyPress);
            // 
            // grpDatBasEmb
            // 
            this.grpDatBasEmb.Controls.Add(this.txtPes);
            this.grpDatBasEmb.Controls.Add(this.label5);
            this.grpDatBasEmb.Controls.Add(this.txtVol);
            this.grpDatBasEmb.Controls.Add(this.label4);
            this.grpDatBasEmb.Controls.Add(this.txtAlt);
            this.grpDatBasEmb.Controls.Add(this.label3);
            this.grpDatBasEmb.Controls.Add(this.txtAnc);
            this.grpDatBasEmb.Controls.Add(this.label2);
            this.grpDatBasEmb.Controls.Add(this.txtLon);
            this.grpDatBasEmb.Controls.Add(this.label1);
            this.grpDatBasEmb.Location = new System.Drawing.Point(19, 67);
            this.grpDatBasEmb.Name = "grpDatBasEmb";
            this.grpDatBasEmb.Size = new System.Drawing.Size(620, 177);
            this.grpDatBasEmb.TabIndex = 36;
            this.grpDatBasEmb.TabStop = false;
            this.grpDatBasEmb.Text = "Datos basicos de embalaje:";
            // 
            // grpDatEti
            // 
            this.grpDatEti.Controls.Add(this.txtCarAdi);
            this.grpDatEti.Controls.Add(this.label6);
            this.grpDatEti.Controls.Add(this.txtNomUni);
            this.grpDatEti.Controls.Add(this.label7);
            this.grpDatEti.Controls.Add(this.txtClaGen);
            this.grpDatEti.Controls.Add(this.label8);
            this.grpDatEti.Location = new System.Drawing.Point(19, 264);
            this.grpDatEti.Name = "grpDatEti";
            this.grpDatEti.Size = new System.Drawing.Size(620, 142);
            this.grpDatEti.TabIndex = 37;
            this.grpDatEti.TabStop = false;
            this.grpDatEti.Text = "Datos de la etiqueta:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Longitud:";
            // 
            // txtLon
            // 
            this.txtLon.Location = new System.Drawing.Point(80, 34);
            this.txtLon.Name = "txtLon";
            this.txtLon.Size = new System.Drawing.Size(59, 21);
            this.txtLon.TabIndex = 1;
            this.txtLon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtLon.TextChanged += new System.EventHandler(this.txtLon_TextChanged);
            // 
            // txtAnc
            // 
            this.txtAnc.Location = new System.Drawing.Point(80, 61);
            this.txtAnc.Name = "txtAnc";
            this.txtAnc.Size = new System.Drawing.Size(59, 21);
            this.txtAnc.TabIndex = 3;
            this.txtAnc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAnc.TextChanged += new System.EventHandler(this.txtAnc_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ancho:";
            // 
            // txtAlt
            // 
            this.txtAlt.Location = new System.Drawing.Point(80, 88);
            this.txtAlt.Name = "txtAlt";
            this.txtAlt.Size = new System.Drawing.Size(59, 21);
            this.txtAlt.TabIndex = 5;
            this.txtAlt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAlt.TextChanged += new System.EventHandler(this.txtAlt_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Altura:";
            // 
            // txtVol
            // 
            this.txtVol.Location = new System.Drawing.Point(80, 115);
            this.txtVol.Name = "txtVol";
            this.txtVol.ReadOnly = true;
            this.txtVol.Size = new System.Drawing.Size(59, 21);
            this.txtVol.TabIndex = 7;
            this.txtVol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Volumen:";
            // 
            // txtPes
            // 
            this.txtPes.Location = new System.Drawing.Point(80, 142);
            this.txtPes.Name = "txtPes";
            this.txtPes.Size = new System.Drawing.Size(59, 21);
            this.txtPes.TabIndex = 9;
            this.txtPes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPes.TextChanged += new System.EventHandler(this.txtPes_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Peso:";
            // 
            // txtCarAdi
            // 
            this.txtCarAdi.Location = new System.Drawing.Point(163, 88);
            this.txtCarAdi.Name = "txtCarAdi";
            this.txtCarAdi.Size = new System.Drawing.Size(436, 21);
            this.txtCarAdi.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Caracteristicas Adicionales:";
            // 
            // txtNomUni
            // 
            this.txtNomUni.Location = new System.Drawing.Point(163, 58);
            this.txtNomUni.Name = "txtNomUni";
            this.txtNomUni.Size = new System.Drawing.Size(436, 21);
            this.txtNomUni.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Nombre Unico:";
            // 
            // txtClaGen
            // 
            this.txtClaGen.Location = new System.Drawing.Point(163, 26);
            this.txtClaGen.Name = "txtClaGen";
            this.txtClaGen.Size = new System.Drawing.Size(436, 21);
            this.txtClaGen.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Clasificacion General:";
            // 
            // btnAct
            // 
            this.btnAct.Location = new System.Drawing.Point(197, 432);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(75, 23);
            this.btnAct.TabIndex = 38;
            this.btnAct.Text = "Actualizar";
            this.btnAct.UseVisualStyleBackColor = true;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            // 
            // btnCer
            // 
            this.btnCer.Location = new System.Drawing.Point(296, 432);
            this.btnCer.Name = "btnCer";
            this.btnCer.Size = new System.Drawing.Size(75, 23);
            this.btnCer.TabIndex = 39;
            this.btnCer.Text = "Cerrar";
            this.btnCer.UseVisualStyleBackColor = true;
            this.btnCer.Click += new System.EventHandler(this.btnCer_Click);
            // 
            // frmLOG_MaeArt_ActDat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 487);
            this.Controls.Add(this.btnCer);
            this.Controls.Add(this.btnAct);
            this.Controls.Add(this.grpDatEti);
            this.Controls.Add(this.grpDatBasEmb);
            this.Controls.Add(this.txtCodArt);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.txtArtDes);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmLOG_MaeArt_ActDat";
            this.Text = "Maestro de Articulos - Actualizar datos";
            this.grpDatBasEmb.ResumeLayout(false);
            this.grpDatBasEmb.PerformLayout();
            this.grpDatEti.ResumeLayout(false);
            this.grpDatEti.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCodArt;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtArtDes;
        private System.Windows.Forms.GroupBox grpDatBasEmb;
        private System.Windows.Forms.GroupBox grpDatEti;
        private System.Windows.Forms.TextBox txtPes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtVol;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAlt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAnc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCarAdi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNomUni;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtClaGen;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAct;
        private System.Windows.Forms.Button btnCer;
    }
}