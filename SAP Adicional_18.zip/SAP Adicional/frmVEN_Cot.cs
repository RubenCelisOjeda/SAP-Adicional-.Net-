﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using Interfaces;
using C1.Win.C1FlexGrid;
using Microsoft.VisualBasic;
using Entidades.VEN_Cot;
using System.IO;
using SAP_Adicional.Reportes;


namespace SAP_Adicional
{
    public partial class frmVEN_Cot : Form, VEN_Cot_Filtros, SAP_Variables
    {
        NConsultas nc = new NConsultas();
        NVEN_Cot nvc = new NVEN_Cot();       
        VarGlo varglo = VarGlo.Instance();

        NGEN_SAPConexion sap = new NGEN_SAPConexion();

        public Int64 NumMov;

        string Moneda = "USD";
        byte EstDoc = 0;
        bool NueDes;
        bool ItemMod;
        bool ItemModAA;
        //bool IteAAPre;
        bool ArtItemMod;
        Int16 FilaAA = 0;
        Int64 NumMovCotOri;

        decimal PreMod;
        //bool CamPreMen;

        string Creado; string Modificado; string Aprobado; string Migrado;

        Int32 SAP_Conecta;
        bool SAP_UserBad;

        //Dim ItemMod As Boolean
        //Dim ItemModCodTip As Integer
        //Dim Fila As Integer
        //Dim PreMod As Currency
        //Dim CamPreMen As Boolean
        //Dim NumMovCro As Long

        public frmVEN_Cot()
        {
            InitializeComponent();

            MetGlo.SeleccionTexto(this);

            this.WindowState = FormWindowState.Maximized;
            this.WindowState = FormWindowState.Normal;

        }

        public void rec_SAP_Connection(int ErrorCode)
        {
            SAP_Conecta = ErrorCode;
        }

        public void rec_SAP_UserBad(bool UserBad)
        {
            SAP_UserBad = UserBad;
        }

        public void recdat_frmVEN_Cot_Cliente(string codcli, string cli, string rucdni, string codtipdoc, string tel, string email)
        {
            this.txtCodCli.Text = codcli;
            this.txtCli.Text = cli;
            txtRUCDNI.Text = rucdni;
            txtCodTipDoc.Text = codtipdoc;
            txtTel.Text = tel;
            txtEmail.Text = email;            
        }

        public void recdat_frmVEN_Cot_ArticuloCompuesto(string Codigo, string Art, string Precio, string Obs)
        {
            this.txtCodArtCom.Text = Codigo;
            this.txtDes.Text = Art;
            this.txtPrecio.Text = Precio;
            this.txtObs.Text = Obs;
            //
            btnAgrCom.Enabled = true; btnBorCom.Enabled = true; btnCanCom.Enabled = true;
            //
            VEN_Cot_ArtComMosCom();
            //
        }

        public void recdat_frmVEN_Cot_Tiempo(string Tiempo)
        {
            this.txtTie.Text = Tiempo;           
        }

        public void recdat_frmVEN_Cot_Ambiente(string CodAmb, string Amb)
        {
            this.txtCodAmb.Text = CodAmb;
            this.txtAmb.Text = Amb;
        }

        public void recdat_frmVEN_Cot_Motivo(string CodMot, string Mot)
        {
            this.txtCodMot.Text = CodMot;
            this.txtMot.Text = Mot;
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        void VEN_Cot_LimpiarTodo()
        {
            foreach (Control obj in this.Controls)
            {
                if (obj is TextBox) obj.Text = "";

                if (obj is GroupBox)
                {
                    foreach (Control objg in obj.Controls)
                    {
                        if (objg is TextBox) objg.Text = "";
                    }
                }

                if (obj is TabPage)
                {
                    foreach (Control objt in obj.Controls)
                    {
                        if (objt is TextBox) objt.Text = "";
                    }
                }
            }

            //Limipio el grid de detalle
            fgDet.Rows.Count = 1;

            //Limipio el grid de ambientes
            fgAmb.Rows.Count = 1;            

            //Limipio el grid de componentes
            fgCom.Rows.Count = 1;
            //
            this.btnCanItem.PerformClick();

            NumMovCotOri = 0;

        }

        private void VEN_Cot_HabilitarDeshabilitar(bool Estado)
        {
            ((Control)this.tbpEnc).Enabled = Estado;
            ((Control)this.tbpArtCom).Enabled = Estado;
            ((Control)this.tbpOtrArt).Enabled = Estado;
            ((Control)this.tbpArtSim).Enabled = Estado;
        }

        private void frmVEN_Cot_Load(object sender, EventArgs e)
        {
            VEN_Cot_TamañogpbCubre();
            VEN_Cot_Formatofg();

            VEN_Cot_EstBot("deshacer");

            if (NumMov != 0)
            {
                VEN_Cot_Buscar();
            }
            

        }

        private void btnCan_Click(object sender, EventArgs e)
        {
            this.gpbMoneda.Visible = false;
            NueDes = false;
            VEN_Cot_TamañogpbCubre();
        }

        private void frmVEN_Cot_Resize(object sender, EventArgs e)
        {
            VEN_Cot_TamañogpbCubre();
            //
            this.gpbMoneda.Top = (gpbCubre.Height / 2) - (this.gpbMoneda.Height / 2);
            this.gpbMoneda.Left = (gpbCubre.Width / 2) - (this.gpbMoneda.Width / 2);

            tbPri.Size = new System.Drawing.Size(this.Width, this.Height - 150);

            pnTot.Top = this.Height - 100;

            gbArtAAItem.Top = (gbItmArtComCubre.Height / 2) - (this.gbArtAAItem.Height / 2);
            gbArtAAItem.Left = (gbItmArtComCubre.Width / 2) - (gbArtAAItem.Width / 2);

            gbIteCat.Top = (this.Height / 2) - (this.gbIteCat.Height / 2);
            gbIteCat.Left = (this.Width / 2) - (gbIteCat.Width / 2);

        }

        void VEN_Cot_TamañogpbCubre()
        {
            gpbCubre.Left = 0;
            if (NueDes == true)
            {
                gpbCubre.Top = 0;
            }
            else
            {
                gpbCubre.Top = 40;
            }
               
            gpbCubre.Size = new System.Drawing.Size(this.Width - 10 , this.Height - 20);

            gbItmArtComCubre.Left = 0;
            gbItmArtComCubre.Top = 40;

            gbItmArtComCubre.Size = new System.Drawing.Size(this.Width - 10, this.Height - 20);

        }

        private void btnAce_Click(object sender, EventArgs e)
        {
            VEN_Cot_OpcionesNuevo();
           
            //'
            this.txtMot.Focus();            
        }

        private void VEN_Cot_OpcionesNuevo ()
        {
            VEN_Cot_LimpiarTodo();

            //Recuperamos la fecha actual
            DateTime Hoy = DateTime.Today;

            txtFecEmi.Text = Hoy.ToString("dd/MM/yyyy");

            if (!this.rdbDol.Checked && !this.rdbDol.Checked)
            {
                MessageBox.Show("Debe elegir una moneda", "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information); return;
            }

            varglo.TipCam = nc.TipoCambio_Recuperar(Convert.ToDateTime(txtFecEmi.Text));

            if (varglo.TipCam == 0)
            {
                MessageBox.Show("No se encontro Tipo de Cambio, para esta fecha, " +
                                "informe al personal de contabilidad", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            varglo.ValorIGV = nc.IGV_Recuperar(Convert.ToDateTime(txtFecEmi.Text));

            if (varglo.ValorIGV == 0)
            {
                MessageBox.Show("No se encontro IGV, para esta fecha, revisar la tabla de IGV", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                lblIGVUnit.Text = "IGV " + Convert.ToInt16(100 * varglo.ValorIGV).ToString() + "%:";
                lblIGVUnitAA.Text = "IGV " + Convert.ToInt16(100 * varglo.ValorIGV).ToString() + "%:";
                lblArtIGVUnit.Text = "IGV " + Convert.ToInt16(100 * varglo.ValorIGV).ToString() + "%:";

                lblIGVTotal.Text = "IGV " + Convert.ToInt16(100 * varglo.ValorIGV).ToString() + "%:";
            }

            this.gpbCubre.Visible = false;

            string MonedaTexto = (Moneda == "S/") ? "Soles" : "Dolares";

            this.Text = "Cotización " + " - " + this.txtNomCot.Text + " - " + MonedaTexto;
            
            NueDes = false;

            EstDoc = 1;
            NumMov = 0;
            ItemMod = false;
            ArtItemMod = false;
            //'
            btnCanItem.PerformClick();
            btnCanItemAA.PerformClick();
            btnArtCanItem.PerformClick();
            //'
            txtMot.Focus();
            //
            VEN_Cot_EstBot("nuevo");
            //
            tbPri.TabIndex = 0;

        }

        private void rdbDol_CheckedChanged(object sender, EventArgs e)
        {
            Moneda = "USD";
        }

        private void rdbSol_CheckedChanged(object sender, EventArgs e)
        {
            Moneda = "S/";
        }

        private void txtNomCot_TextChanged(object sender, EventArgs e)
        {
            string MonedaTexto = (Moneda == "S/") ? "Soles" : "Dolares";

            this.Text = "Cotización " + " - " + this.txtNomCot.Text + " - " + MonedaTexto;
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void VEN_Cot_Formatofg()
        {
            fgDet.Cols.Count = 16;
            fgDet.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Both;
            fgDet.Cols.Frozen = 3;           

            fgDet.Cols[0].Caption = "No.";
            fgDet.Cols[1].Caption = "Codigo";
            fgDet.Cols[2].Caption = "Descripción";
            fgDet.Cols[3].Caption = "Can";
            fgDet.Cols[4].Caption = "P.Unit";
            fgDet.Cols[5].Caption = "V.Bruta";
            fgDet.Cols[6].Caption = "%D";
            fgDet.Cols[7].Caption = "Desct";
            fgDet.Cols[8].Caption = "V. Neto";
            fgDet.Cols[9].Caption = "IGV";
            fgDet.Cols[10].Caption = "SubTotal";
            fgDet.Cols[11].Caption = "Observaciones";
            fgDet.Cols[12].Caption = "Simbolo";
            fgDet.Cols[13].Caption = "Costo Unt.";
            fgDet.Cols[14].Caption = "Costo Tot.";
            fgDet.Cols[15].Caption = "% Margen";

            fgDet.Cols[0].Width = 30; //N°
            fgDet.Cols[1].Width = 50;//Codigo
            fgDet.Cols[2].Width = 350;//Descripcion
            fgDet.Cols[3].Width = 50;//Can
            fgDet.Cols[4].Width = 70;//P. Unit
            fgDet.Cols[5].Width = 70;//V. Bruta
            fgDet.Cols[6].Width = 70;//%D
            fgDet.Cols[7].Width = 70;//Desct
            fgDet.Cols[8].Width = 70;//V.Neto
            fgDet.Cols[9].Width = 70;//IGV
            fgDet.Cols[10].Width = 70;//SubTotal
            fgDet.Cols[11].Width = 400;//Observaciones
            fgDet.Cols[12].Width = 70;//Simbolo.
            fgDet.Cols[13].Width = 70;//Costo Unt.
            fgDet.Cols[14].Width = 70;//Costo Tot.
            fgDet.Cols[15].Width = 70;//% Margen

            //fgDet.Cols[3].Format = "0";

            //fgDet.Cols[3].DataType = typeof(decimal);
            //fgDet.Cols[3].Format = "0.00";

            //Componentes 
            fgCom.Cols.Count = 10;
            fgCom.Cols[0].Caption = "Codigo";
            fgCom.Cols[1].Caption = "Descripcion";
            fgCom.Cols[2].Caption = "Cant";
            fgCom.Cols[3].Caption = "V.Venta";
            fgCom.Cols[4].Caption = "SIS";
            fgCom.Cols[5].Caption = "SHO";
            fgCom.Cols[6].Caption = "SQO";
            fgCom.Cols[7].Caption = "REM";
            fgCom.Cols[8].Caption = "Costo";
            fgCom.Cols[9].Caption = "% Margen";

            fgCom.Cols[0].Width = 70; //Codigo
            fgCom.Cols[1].Width = 500;//Descripcion
            fgCom.Cols[2].Width = 50;//Cant
            fgCom.Cols[3].Width = 60;//V. Venta
            fgCom.Cols[4].Width = 60;//SIS
            fgCom.Cols[5].Width = 60;//SHO
            fgCom.Cols[6].Width = 60;//SQO
            fgCom.Cols[7].Width = 60;//SQO
            fgCom.Cols[8].Width = 60;//Costo
            fgCom.Cols[9].Width = 60;//% Margen

            //Ambientes
            fgAmb.Cols.Count = 3;
            fgAmb.Cols[0].Caption = "Cod";
            fgAmb.Cols[1].Caption = "Ambiente";
            fgAmb.Cols[2].Caption = "Cant.";

            fgAmb.Cols[0].Visible = false; //Cod
            fgAmb.Cols[1].Width = 120;//Ambiente
            fgAmb.Cols[2].Width = 40;//Cant

            //Ambientes todos
            fgAmbTodos.Cols.Count = 4;
            fgAmbTodos.Cols[0].Caption = "CodigoKit";
            fgAmbTodos.Cols[1].Caption = "Cod";
            fgAmbTodos.Cols[2].Caption = "Ambiente";
            fgAmbTodos.Cols[3].Caption = "Cant.";

            //Componentes todos
            fgComTodos.Cols.Count = 5;
            fgComTodos.Cols[0].Caption = "CodigoKit";
            fgComTodos.Cols[1].Caption = "Codigo";
            fgComTodos.Cols[2].Caption = "Descripcion";
            fgComTodos.Cols[3].Caption = "Cant";
            fgComTodos.Cols[4].Caption = "V.Venta";

            //.FormatString = "No. |Descripción                                                                                                       |Can      |P.Unit        |V. Bruta       |%D       |Desct      |V. Neto         " & _
            //                        "|IGV           |SubTotal       |CodAmb|Ambiente                                   |Ruta Imagen              |Observaciones                                                                                           |Costo Unt.   |Costo Tot.    |% Margen    "
            //Articulos alternativos
            fgDetAA.Cols.Count = 19;
            fgDetAA.Cols.Frozen = 2;          
            fgDetAA.Cols[0].Caption = "No.";
            fgDetAA.Cols[1].Caption = "Descripción";
            fgDetAA.Cols[2].Caption = "Can";
            fgDetAA.Cols[3].Caption = "P.Unit";
            fgDetAA.Cols[4].Caption = "V.Bruta";
            fgDetAA.Cols[5].Caption = "% Desct";
            fgDetAA.Cols[6].Caption = "Desct";
            fgDetAA.Cols[7].Caption = "V. Neto";
            fgDetAA.Cols[8].Caption = "IGV";
            fgDetAA.Cols[9].Caption = "SubTotal";
            fgDetAA.Cols[10].Caption = "CodAmb";
            fgDetAA.Cols[11].Caption = "Ambiente";
            fgDetAA.Cols[12].Caption = "Ruta Imagen";
            fgDetAA.Cols[13].Caption = "Ruta Imagen2";
            fgDetAA.Cols[14].Caption = "Ruta Imagen Tecnica";
            fgDetAA.Cols[15].Caption = "Observaciones";
            fgDetAA.Cols[16].Caption = "Costo Unt.";
            fgDetAA.Cols[17].Caption = "Costo Tot.";
            fgDetAA.Cols[18].Caption = "% Margen";

            fgDetAA.Cols[0].Width = 30; //N°
            fgDetAA.Cols[1].Width = 400; //Descripcion
            fgDetAA.Cols[2].Width = 50; //Can
            fgDetAA.Cols[3].Width = 70; //P. Unit
            fgDetAA.Cols[4].Width = 70; //V. Bruta
            fgDetAA.Cols[5].Width = 70; //%D
            fgDetAA.Cols[6].Width = 70; //Desct
            fgDetAA.Cols[7].Width = 70; //V.Neto
            fgDetAA.Cols[8].Width = 70; //IGV
            fgDetAA.Cols[9].Width = 70; //SubTotal
            fgDetAA.Cols[10].Visible = false; //CodAmb
            fgDetAA.Cols[11].Width = 150; //Ambiente
            fgDetAA.Cols[12].Width = 150; //Ruta Imagen
            fgDetAA.Cols[13].Width = 150; //Ruta Imagen2
            fgDetAA.Cols[14].Width = 150; //Ruta Imagen Tecnico
            fgDetAA.Cols[15].Width = 300; //Observaciones
            fgDetAA.Cols[16].Width = 70; //Costo Unt.
            fgDetAA.Cols[17].Width = 70; //Costo Tot.
            fgDetAA.Cols[18].Width = 70; //% Margen

            //Detalle de articulos simples
            fgArtDet.Cols.Count = 15;
            fgArtDet.AllowFreezing = C1.Win.C1FlexGrid.AllowFreezingEnum.Both;
            fgArtDet.Cols.Frozen = 3;

            fgArtDet.Cols[0].Caption = "No.";
            fgArtDet.Cols[1].Caption = "Codigo";
            fgArtDet.Cols[2].Caption = "Descripción";
            fgArtDet.Cols[3].Caption = "Can";
            fgArtDet.Cols[4].Caption = "P.Unit";
            fgArtDet.Cols[5].Caption = "V.Bruta";
            fgArtDet.Cols[6].Caption = "%D";
            fgArtDet.Cols[7].Caption = "Desct";
            fgArtDet.Cols[8].Caption = "V. Neto";
            fgArtDet.Cols[9].Caption = "IGV";
            fgArtDet.Cols[10].Caption = "SubTotal";
            fgArtDet.Cols[11].Caption = "Observaciones";
            fgArtDet.Cols[12].Caption = "Costo Unt.";
            fgArtDet.Cols[13].Caption = "Costo Tot.";
            fgArtDet.Cols[14].Caption = "% Margen";

            fgArtDet.Cols[0].Width = 40; //N°
            fgArtDet.Cols[1].Width = 60;//Codigo
            fgArtDet.Cols[2].Width = 500;//Descripcion
            fgArtDet.Cols[3].Width = 50;//Can
            fgArtDet.Cols[4].Width = 70;//P. Unit
            fgArtDet.Cols[5].Width = 70;//V. Bruta
            fgArtDet.Cols[6].Width = 70;//%D
            fgArtDet.Cols[7].Width = 70;//Desct
            fgArtDet.Cols[8].Width = 70;//V.Neto
            fgArtDet.Cols[9].Width = 70;//IGV
            fgArtDet.Cols[10].Width = 70;//SubTotal
            fgArtDet.Cols[11].Width = 400;//Observaciones           
            fgArtDet.Cols[12].Width = 70;//Costo Unt.
            fgArtDet.Cols[13].Width = 70;//Costo Tot.
            fgArtDet.Cols[14].Width = 70;//% Margen

            //Ambiente de articulos simples
            //Ambientes
            fgArtAmb.Cols.Count = 3;
            fgArtAmb.Cols[0].Caption = "Cod";
            fgArtAmb.Cols[1].Caption = "Ambiente";
            fgArtAmb.Cols[2].Caption = "Cant.";

            fgArtAmb.Cols[0].Visible = false; //Cod
            fgArtAmb.Cols[1].Width = 120;//Ambiente
            fgArtAmb.Cols[2].Width = 40;//Cant

            //Ambientes todos
            fgArtAmbTodos.Cols.Count = 4;
            fgArtAmbTodos.Cols[0].Caption = "CodigoKit";
            fgArtAmbTodos.Cols[1].Caption = "Cod";
            fgArtAmbTodos.Cols[2].Caption = "Ambiente";
            fgArtAmbTodos.Cols[3].Caption = "Cant.";

            //Articulo Compuesto sin codigo - items
            fgDetArtAAItem.Styles.Normal.WordWrap = true;
            fgDetArtAAItem.Cols.Count = 43;

            fgDetArtAAItem.Rows[0].Height = 40;
            fgDetArtAAItem.Cols.Frozen = 2;

            fgDetArtAAItem.AllowMerging = AllowMergingEnum.FixedOnly;
            fgDetArtAAItem.Styles.Fixed.TextAlign = TextAlignEnum.CenterCenter;

            for (int i = 0; i < fgDetArtAAItem.Rows.Count; i++)
            {
                fgDetArtAAItem.Rows[i].AllowMerging = true;
            }

            for (int i = 0; i < fgDetArtAAItem.Cols.Count; i++)
            {
                fgDetArtAAItem.Cols[i].AllowMerging = true;
            }

            //fgDetArtAAItem.Cols[0].Caption = "Item Padre";
            //fgDetArtAAItem.Cols[1].Caption = "Item";
            fgDetArtAAItem.Cols[0].Caption = "CodLin";
            fgDetArtAAItem.Cols[1].Caption = "Linea";
            fgDetArtAAItem.Cols[2].Caption = "CodSubLin";
            fgDetArtAAItem.Cols[3].Caption = "SubLinea";
            fgDetArtAAItem.Cols[4].Caption = "CodFam";
            fgDetArtAAItem.Cols[5].Caption = "Familia";
            fgDetArtAAItem.Cols[6].Caption = "CodSubFam";
            fgDetArtAAItem.Cols[7].Caption = "SubFamilia";
            fgDetArtAAItem.Cols[8].Caption = "CodMar";
            fgDetArtAAItem.Cols[9].Caption = "Marca";
            fgDetArtAAItem.Cols[10].Caption = "Medidas";
            fgDetArtAAItem.Cols[11].Caption = "CodPro";
            fgDetArtAAItem.Cols[12].Caption = "Proveedor";            
            fgDetArtAAItem.Cols[13].Caption = "Color Producto";
            fgDetArtAAItem.Cols[14].Caption = "Cod Proveedor / Catalogo";
            fgDetArtAAItem.Cols[15].Caption = "Cod. Mat. de la base del mueble";
            fgDetArtAAItem.Cols[16].Caption = "Material de la base del Mueble";
            fgDetArtAAItem.Cols[17].Caption = "Medidas";
            fgDetArtAAItem.Cols[18].Caption = "Can";
            fgDetArtAAItem.Cols[19].Caption = "COST FOB";
            fgDetArtAAItem.Cols[20].Caption = "COST FOB US$";
            fgDetArtAAItem.Cols[21].Caption = "COST FOB Final US$";
            fgDetArtAAItem.Cols[22].Caption = "Descripción";
            fgDetArtAAItem.Cols[23].Caption = "%Dscto para FOB";
            fgDetArtAAItem.Cols[24].Caption = "Factor Import";
            fgDetArtAAItem.Cols[25].Caption = "COST. INT.";
            fgDetArtAAItem.Cols[26].Caption = "COST. ADIC. NAC.";
            fgDetArtAAItem.Cols[27].Caption = "COST. INTERN. TOTAL";
            fgDetArtAAItem.Cols[28].Caption = "Compra total dolares FOB";
            fgDetArtAAItem.Cols[29].Caption = "Compra total dolares internado";
            fgDetArtAAItem.Cols[30].Caption = "Calculo Px VTA o VV";
            fgDetArtAAItem.Cols[31].Caption = "VV";
            fgDetArtAAItem.Cols[32].Caption = "Px / VV";
            fgDetArtAAItem.Cols[33].Caption = "GM (%)";
            fgDetArtAAItem.Cols[34].Caption = "Dscto. Cliente";
            fgDetArtAAItem.Cols[35].Caption = "Px / VV Con DSCTO.";
            fgDetArtAAItem.Cols[36].Caption = "GM Px / VV DSCTO (%)";
            fgDetArtAAItem.Cols[37].Caption = "Com. Rec.";
            fgDetArtAAItem.Cols[38].Caption = "Px / VV C/RECOM";
            fgDetArtAAItem.Cols[39].Caption = "GM RECOM (%)";
            fgDetArtAAItem.Cols[40].Caption = "VV TOTAL VV TOTAL";
            fgDetArtAAItem.Cols[41].Caption = "VV TOTAL CON DSCTO Y COM. RECOM";
            fgDetArtAAItem.Cols[42].Caption = "Obs";

            for (int i = 18; i < fgDetArtAAItem.Cols.Count; i++)
            {
                fgDetArtAAItem.Cols[i].Width = 90;
            }

            fgDetArtAAItem.Cols[0].Visible = false; //CodLin
            fgDetArtAAItem.Cols[2].Visible = false; //CodSubLin
            fgDetArtAAItem.Cols[4].Visible = false; //CodFam
            fgDetArtAAItem.Cols[6].Visible = false; //CodSubFam
            fgDetArtAAItem.Cols[8].Visible = false; //CodMar 
            fgDetArtAAItem.Cols[11].Visible = false; //CodPro

            fgDetArtAAItem.Cols[22].Width = 400;
            fgDetArtAAItem.Cols[22].Width = 400;

            //
            //Articulo Compuesto sin codigo - items TODOS
            fgDetArtAAItemTodos.Cols.Count = 45;

            fgDetArtAAItemTodos.Cols[0].Caption = "Item Padre";
            fgDetArtAAItemTodos.Cols[1].Caption = "Item";
            fgDetArtAAItemTodos.Cols[2].Caption = "CodLin";
            fgDetArtAAItemTodos.Cols[3].Caption = "Linea";
            fgDetArtAAItemTodos.Cols[4].Caption = "CodSubLin";
            fgDetArtAAItemTodos.Cols[5].Caption = "SubLinea";
            fgDetArtAAItemTodos.Cols[6].Caption = "CodFam";
            fgDetArtAAItemTodos.Cols[7].Caption = "Familia";
            fgDetArtAAItemTodos.Cols[8].Caption = "CodSubFam";
            fgDetArtAAItemTodos.Cols[9].Caption = "SubFamilia";
            fgDetArtAAItemTodos.Cols[10].Caption = "CodMar";
            fgDetArtAAItemTodos.Cols[11].Caption = "Marca";
            fgDetArtAAItemTodos.Cols[12].Caption = "Medidas";
            fgDetArtAAItemTodos.Cols[13].Caption = "CodPro";
            fgDetArtAAItemTodos.Cols[14].Caption = "Proveedor";
            fgDetArtAAItemTodos.Cols[15].Caption = "Color Producto";
            fgDetArtAAItemTodos.Cols[16].Caption = "Cod Proveedor / Catalogo";
            fgDetArtAAItemTodos.Cols[17].Caption = "Cod. Mat. de la base del mueble";
            fgDetArtAAItemTodos.Cols[18].Caption = "Material de al base del Mueble";
            fgDetArtAAItemTodos.Cols[19].Caption = "Medidas";
            fgDetArtAAItemTodos.Cols[20].Caption = "Can";
            fgDetArtAAItemTodos.Cols[21].Caption = "COST FOB";
            fgDetArtAAItemTodos.Cols[22].Caption = "COST FOB US$";
            fgDetArtAAItemTodos.Cols[23].Caption = "COST FOB Final US$";
            fgDetArtAAItemTodos.Cols[24].Caption = "Descripción";
            fgDetArtAAItemTodos.Cols[25].Caption = "%Dscto para FOB";
            fgDetArtAAItemTodos.Cols[26].Caption = "Factor Import";
            fgDetArtAAItemTodos.Cols[27].Caption = "COST. INT.";
            fgDetArtAAItemTodos.Cols[28].Caption = "COST. ADIC. NAC.";
            fgDetArtAAItemTodos.Cols[29].Caption = "COST. INTERN. TOTAL";
            fgDetArtAAItemTodos.Cols[30].Caption = "Compra total dolares FOB";
            fgDetArtAAItemTodos.Cols[31].Caption = "Compra total dolares internado";
            fgDetArtAAItemTodos.Cols[32].Caption = "Calculo Px VTA o VV";
            fgDetArtAAItemTodos.Cols[33].Caption = "VV";
            fgDetArtAAItemTodos.Cols[34].Caption = "Px / VV";
            fgDetArtAAItemTodos.Cols[35].Caption = "GM (%)";
            fgDetArtAAItemTodos.Cols[36].Caption = "Dscto. Cliente";
            fgDetArtAAItemTodos.Cols[37].Caption = "Px / VV Con DSCTO.";
            fgDetArtAAItemTodos.Cols[38].Caption = "GM Px / VV DSCTO (%)";
            fgDetArtAAItemTodos.Cols[39].Caption = "Com. Rec.";
            fgDetArtAAItemTodos.Cols[40].Caption = "Px / VV C/RECOM";
            fgDetArtAAItemTodos.Cols[41].Caption = "GM RECOM (%)";
            fgDetArtAAItemTodos.Cols[42].Caption = "VV TOTAL VV TOTAL";
            fgDetArtAAItemTodos.Cols[43].Caption = "VV TOTAL CON DSCTO Y COM. RECOM";
            fgDetArtAAItemTodos.Cols[44].Caption = "Obs";

            //fgAACatIte
            fgAACatIte.Cols[0].Caption = "Catalogo";
            fgAACatIte.Cols[1].Caption = "Cantidad";
            fgAACatIte.Cols[2].Caption = "";

            fgAACatIte.Cols[0].Width = 200;
            fgAACatIte.Cols[1].Width = 50;
            fgAACatIte.Cols[2].Width = 20;



            if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 2, "otracc", 0) == 0)
            {
                fgDet.Cols[13].Visible = false; //Costo Unt.
                fgDet.Cols[14].Visible = false; //Costo Tot.
                fgDet.Cols[15].Visible = false; //% Margen

                fgCom.Cols[8].Visible = false; //Costo
                fgCom.Cols[9].Visible = false; //% Margen

                fgDetAA.Cols[16].Visible = false; //Costo Unt.
                fgDetAA.Cols[17].Visible = false; //Costo Tot.
                fgDetAA.Cols[18].Visible = false; //% Margen

                fgArtDet.Cols[12].Visible = false; //Costo Unt.
                fgArtDet.Cols[13].Visible = false; //Costo Tot.
                fgArtDet.Cols[14].Visible = false; //% Margen
            }

        }

        private void VEN_Cot_EstBot(string BotonEstado)
        {
            bool[] EstadoM =  { true };

            //nuevo, abrir, guardar, deshacer, modificar, opc. ipm., aprobar, migrar sap, duplicar, procesar, atendida

            switch (BotonEstado)
            {
                case "nuevo":
                case "modificar":
                case "duplicar":
                    EstadoM = matriz( false, false, true, true, false, false, false, false, false, true);

                    VEN_Cot_HabilitarDeshabilitar(true);

                    break;
                case "abrir":
                case "guardar":
                    switch(EstDoc)
                    {
                        case 1:
                            EstadoM = matriz(true, true, false, false, true, true, true, false, true, false);
                            break;
                        case 2: //Aprobado
                            EstadoM = matriz(true, true, false, false, true, true, false, true, true, false);
                            break;
                        case 8: //Migrado
                            EstadoM = matriz(true, true, false, false, true, true, false, false, true, false);
                            break;
                    }

                    VEN_Cot_HabilitarDeshabilitar(false);

                    break;
                case "deshacer":
                    EstadoM = matriz(true, true, false, true, false, false, false, false, false, false);

                    VEN_Cot_HabilitarDeshabilitar(true);

                    break;
            }

            this.btnNuevo.Enabled = EstadoM[0];
            this.btnAbrir.Enabled = EstadoM[1];
            this.btnGuardar.Enabled = EstadoM[2];
            this.btnDeshacer.Enabled = EstadoM[3];
            this.btnModificar.Enabled = EstadoM[4];
            this.btnOpcImp.Enabled = EstadoM[5];
            this.btnAprobar.Enabled = EstadoM[6];
            this.btnMigrarSAP.Enabled = EstadoM[7];
            this.btnDuplicar.Enabled = EstadoM[8];
            this.btnOpc.Enabled = EstadoM[9];

        }

        private bool[] matriz(params bool[] numeros)
        {
            return numeros;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnNuevo);
        }

        private void txtCli_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Cliente", "Filtro_Clientes",this.txtCli.Text,"","", "", "");

                if (varglo.Elegi == true)
                {
                    txtCliCon.Focus();
                }
                
            }
        }

        public void ConsultaDatos(string vista, string procedimiento, string param1, string param2, 
                                string param3, string param4, string param5)
        {
            DataTable dt = new DataTable();

            dt = nc.VEN_Cot_Filtros(vista, procedimiento, param1, param2, param3, param4, param5);


            if (dt.Rows.Count > 1)
            {

                frmConsulta_Varios frm = new frmConsulta_Varios();
                frm.Formulario = 19;
                frm.Text = vista;
                frm.Vista = vista;
                frm.dg.DataSource = dt;
                frm.Ven_Cot = this;
                frm.ShowDialog();               
                
            }
            else if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];

                switch (vista)
                {
                    case "Cliente":
                        txtCodCli.Text = row["Codigo"].ToString();
                        txtCli.Text = row["Cliente"].ToString();
                        txtRUCDNI.Text = row["Ruc/Dni o N° Doc"].ToString();
                        txtCodTipDoc.Text = row["CodTipDoc"].ToString();
                        txtTel.Text = row["telefono1"].ToString();
                        txtEmail.Text = row["email"].ToString();
                        txtCliCon.Focus();
                        break;
                    case "EmpleadoVentas":
                        txtCodVen.Text = row["Codigo"].ToString();
                        txtVen.Text = row["Vendedor"].ToString();
                        txtCenVen.Focus();
                        break;
                    case "Centro de Venta":
                        txtCodCenVen.Text = row["Codigo"].ToString();
                        txtCenVen.Text = row["CentroVenta"].ToString();
                        this.txtTipVen.Focus();
                        break;
                    case "Tipo de Venta":
                        txtCodTipVen.Text = row["Codigo"].ToString();
                        txtTipVen.Text = row["TipoVenta"].ToString();
                        this.txtTipVenRel.Focus();
                        break;
                    case "Tipo de Venta Relativo":
                        txtTipVenRel.Text = row["TipoVentaRelativo"].ToString();
                        this.txtRub.Focus();
                        break;
                    case "Rubro":
                        txtRub.Text = row["Rubro"].ToString();
                        this.txtTipObr.Focus();
                        break;
                    case "Tipo de Obra":
                        txtTipObr.Text = row["Tipo Obra"].ToString();
                        this.txtTipObr.Focus();
                        break;
                    case "Dimension":
                        txtDim.Text = row["Dimension"].ToString();
                        this.txtTipObr.Focus();
                        break;
                    case "Recomendador":
                        txtCodRec.Text = row["Codigo"].ToString();
                        txtRec.Text = row["Recomendador"].ToString();
                        btnSigPag.Focus();
                        break;
                    case "Articulo Compuesto":
                        txtCodArtCom.Text = row["Codigo"].ToString();
                        txtDes.Text = row["Articulo"].ToString();
                        txtPrecio.Text = row["Precio"].ToString();
                        txtObs.Text = row["Obs"].ToString();
                        VEN_Cot_ArtComMosCom();
                        txtCan.Focus();
                        break;
                    case "Ambientes (Articulo Compuesto)":
                        txtCodAmb.Text = row["Codigo"].ToString();
                        txtAmb.Text = row["Ambiente"].ToString();
                        txtCanAmb.Focus();
                        break;
                    case "Motivo":
                        txtCodMot.Text = row["Codigo"].ToString();
                        txtMot.Text = row["Motivo"].ToString();
                        break;
                    case "AdmRQ":
                        txtCodAdmRQ.Text = row["Codigo"].ToString();
                        txtAdmRQ.Text = row["AdmRQ"].ToString();
                        break;
                    case "Tiempo":
                        this.txtTie.Text = row["Tiempo"].ToString();
                        this.txtPag.Focus();
                        break;
                    case "Ambientes (Otros Articulos)":
                        txtCodAmbAA.Text = row["Codigo"].ToString();
                        txtAmbAA.Text = row["Ambiente"].ToString();
                        txtCanAA.Focus();
                        break;
                    case "Articulo Simple":
                        txtCodArt.Text = row["Codigo"].ToString();
                        txtArtDes.Text = row["Articulo"].ToString();
                        txtArtPrecio.Text = row["Precio"].ToString();                                               
                        txtArtCan.Focus();
                        break;
                    case "Ambientes (Articulo Simple)":
                        txtArtCodAmb.Text = row["Codigo"].ToString();
                        txtArtAmb.Text = row["Ambiente"].ToString();
                        txtArtCanAmb.Focus();
                        break;
                    case "Falla En":
                        txtCodFalEn.Text = row["Cod"].ToString();
                        txtFalEn.Text = row["Falla En"].ToString();
                        txtLinPro.Focus();
                        break;
                    case "Linea Producto/Servicio":
                        txtCodLinPro.Text = row["Cod"].ToString();
                        txtLinPro.Text = row["Linea Pro/Ser"].ToString();
                        txtTip.Focus();
                        break;
                    case "Tipo":
                        txtCodTip.Text = row["Cod"].ToString();
                        txtTip.Text = row["Tipo"].ToString();
                        txtSubLin.Focus();
                        break;
                    case "SubLinea":
                        txtCodSubLin.Text = row["Cod"].ToString();
                        txtSubLin.Text = row["SubLinea"].ToString();
                        txtFam.Focus();
                        break;
                    case "Familia":
                        txtCodFam.Text = row["Cod"].ToString();
                        txtFam.Text = row["Familia"].ToString();
                        txtTipVen.Focus();
                        break;
                    case "Contacto Cliente":
                        txtCodCliCon.Text = row["Codigo"].ToString();
                        txtCliCon.Text = row["Contacto"].ToString();
                        txtVen.Focus();
                        break;
                    case "Negocio":
                        txtCodNeg.Text = row["Codigo"].ToString();
                        txtNeg.Text = row["Negocio"].ToString();
                        txtEnv.Focus();
                        break;
                    case "Envio":
                        txtCodEnv.Text = row["Codigo"].ToString();
                        txtEnv.Text = row["Forma Envio"].ToString();
                        txtRutIma.Focus();
                        break;
                    case "Linea":
                        txtCodLin.Text = row["Codigo"].ToString();
                        txtLin.Text = row["Linea"].ToString();
                        break;
                    case "SubLineaAA":
                        txtCodSubLin.Text = row["Codigo"].ToString();
                        txtSubLin.Text = row["SubLinea"].ToString();
                        break;
                    case "FamiliaAA":
                        txtCodFamAA.Text = row["Codigo"].ToString();
                        txtFamAA.Text = row["Familia"].ToString();
                        break;
                    case "SubFamilia":
                        txtCodSubFam.Text = row["Codigo"].ToString();
                        txtSubFam.Text = row["SubFamilia"].ToString();
                        break;
                    case "Marca":
                        txtCodMarAA.Text = row["Codigo"].ToString();
                        txtMarAA.Text = row["Marca"].ToString();
                        break;
                    case "Proveedor":
                        txtCodPro.Text = row["Codigo"].ToString();
                        txtPro.Text = row["Proveedor"].ToString();
                        break;
                    //case "Color Mueble":
                    //    txtCodColMue.Text = row["Codigo"].ToString();
                    //    txtColMue.Text = row["Color"].ToString();
                    //    break;
                    case "Material Base Mueble":
                        txtCodMatBasMue.Text = row["Codigo"].ToString();
                        txtMatBasMue.Text = row["Material"].ToString();
                        break;
                    case "Seleccionar RQ":
                        txtRQ.Text = row["N° RQ"].ToString();
                        break;
                    default:
                        break;
                }

                varglo.Elegi = true;

            }
            else if (dt.Rows.Count == 0)
            {
                varglo.Elegi = false;
                MessageBox.Show ("No se encontraron registros","SAP Adicional");                
            }
        }

        private void txtVen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("EmpleadoVentas", "Filtro_EmpleadoVentas", this.txtVen.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtCenVen.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_EmpleadoVentas(string codemp, string emp)
        {
            this.txtCodVen.Text = codemp;
            this.txtVen.Text = emp;
            this.txtCenVen.Focus();
        }

        public void recdat_frmVEN_Cot_CentroVenta(string codcenven, string cenven)
        {
            this.txtCodCenVen.Text = codcenven;
            this.txtCenVen.Text = cenven;
            this.txtTipVen.Focus();
        }

        public void recdat_frmVEN_Cot_TipoVenta(string codtipven, string tipven)
        {
            this.txtCodTipVen.Text = codtipven;
            this.txtTipVen.Text = tipven;
            this.txtTipVenRel.Focus();
        }

        public void recdat_frmVEN_Cot_TipoVentaRelativo(string tipvenrel)
        {
            this.txtTipVenRel.Text = tipvenrel;
            this.txtRub.Focus();
        }

        public void recdat_frmVEN_Cot_Rubro(string rubro)
        {
            this.txtRub.Text = rubro;
            this.txtDim.Focus();
        }

        private void txtCenVen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Centro de Venta", "Filtro_CentroVenta", this.txtCenVen.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    if (txtCodCenVen.Text == "RECLAM")
                    {
                        txtFalEn.Focus();
                    }
                    else
                    {
                        txtTipVen.Focus();
                    }
                    
                }

            }
        }

        private void txtTipVen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo de Venta", "Filtro_TipoVenta", this.txtTipVen.Text.Trim(), this.txtCodCenVen.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    txtTipVenRel.Focus();
                }
            }
        }

        private void txtTipVenRel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo de Venta Relativo", "Filtro_TipoVentaRelativo", this.txtTipVenRel.Text, this.txtCodTipVen.Text, this.txtCodCenVen.Text, "", "");

                if (varglo.Elegi == true)
                {
                    txtRub.Focus();
                }
            }
        }

        private void txtRub_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Rubro", "Filtro_Rubro", this.txtRub.Text, this.txtTipVenRel.Text, this.txtCodTipVen.Text, "", "");

                if (varglo.Elegi == true)
                {
                    txtTipObr.Focus();
                }
            }
        }

        private void txtTipObr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo de Obra", "Filtro_TipoObra", this.txtTipObr.Text.Trim(), this.txtRub.Text, this.txtCodCenVen.Text, 
                                                                                            this.txtTipVenRel.Text, this.txtCodTipVen.Text);

                if (varglo.Elegi == true)
                {
                    txtDim.Focus();
                }
            }
        }

        private void txtTipVenRel_TextChanged(object sender, EventArgs e)
        {
            this.txtRub.Text = "";
        }

        private void txtRub_TextChanged(object sender, EventArgs e)
        {
            this.txtTipObr.Text = "";
        }

        private void txtTipObr_TextChanged(object sender, EventArgs e)
        {
            this.txtDim.Text = "";
        }

        public void recdat_frmVEN_Cot_TipoObra(string tipoobra)
        {
            this.txtTipObr.Text = tipoobra;
        }

        private void txtDim_Click(object sender, EventArgs e)
        {
         
        }

        private void txtDim_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Dimension", "Filtro_Dimension", this.txtDim.Text.Trim(), this.txtTipObr.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    txtRec.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_Dimension(string dimension)
        {
            this.txtDim.Text = dimension;
        }

        private void txtRec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Recomendador", "Filtro_Recomendador", txtRec.Text.Trim(),"","", "", "");

                if (varglo.Elegi == true)
                {
                    txtNomAdi.Focus();
                }
            }
        }

        private void txtRec_Click(object sender, EventArgs e)
        {
            this.txtRec.SelectAll();
        }

        public void recdat_frmVEN_Cot_Recomendador(string codrec, string rec)
        {
            this.txtCodRec.Text = codrec;
            this.txtRec.Text = rec;
        }

        private void btnAgrItem_Click(object sender, EventArgs e)
        {
            Int32 CodArtCom = 0;
            //Valido que se elija un articulo compuesto
            Int32.TryParse(txtCodArtCom.Text, out CodArtCom);

            if (CodArtCom == 0)
            {
                MessageBox.Show("Debe elegir un Kit", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCodArtCom.Focus(); return;
            }

            if (nc.Validar_CodArtCom(CodArtCom) == false)
            {
                MessageBox.Show("Codigo de Kit invalido", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCodArtCom.Focus(); return;
            }

            decimal PreUni = 0;
            //Valido agreguen un precio
            decimal.TryParse(txtPrecio.Text, out PreUni);

            if (PreUni == 0)
            {
                MessageBox.Show("Debe agregar un precio unitario", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPrecio.Focus(); return;
            }

            //-------------------------------------------------------
            int Can = 0;
            //Valido que se ingrese una cantidad
            Int32.TryParse(txtCan.Text, out Can);

            if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(txtCodArtCom.Text)) == 1)
            {
                if (Can < 1)
                {
                    MessageBox.Show("Debe ingresar una cantidad entera mayor a cero", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCan.Focus(); return;
                }            
            }
            else
            {
                if (Can > 1)
                {
                    MessageBox.Show("La cantidad de un artículo servicio no puede ser mayor a 1", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtCan.Focus(); return;
                }
            }

            int PorDes = 0;
            //Valido que se ingrese una cantidad
            Int32.TryParse(txtPorDes.Text, out PorDes);

            decimal TotProdAmb = 0;

            //Para comparar la cantidad de items y la suma de la cantidad puesta en los Ambientes
            for (int i = 1; i < fgAmb.Rows.Count; i++)
            {                
                TotProdAmb = TotProdAmb + Convert.ToDecimal(fgAmb.Rows[i][2]);
            }

            if (TotProdAmb != Can)
            {
                MessageBox.Show("El total de articulos por ambiente no coincide con la cantidad total de articulos","SAP ADICIONAL",MessageBoxButtons.OK,MessageBoxIcon.Information);
                txtCan.Focus(); return;
            }

            //Para revisar si el producto ya fue agregado
            foreach (Row dr in fgDet.Rows)
            {
                if (dr[1] != null) 
                {
                    if (String.Compare(txtCodArtCom.Text, dr[1].ToString()) == 0)
                    {
                        MessageBox.Show("El Codigo de Producto ya fue Seleccionado");
                        txtDes.Focus(); return;
                    }
                }
            }

            //Costo
            decimal CosUni = 0;

            for (int i = 1; i < fgCom.Rows.Count; i++)
            {
                CosUni = CosUni + Convert.ToDecimal(fgCom.Rows[i][8]);
            }

            //Margen %
            decimal Margen = 0;
            Margen = Math.Round(((Convert.ToDecimal(txtValNet.Text) - CosUni) / Convert.ToDecimal(txtValNet.Text)) * 100,2);            

            //Agregamos la fila al fgDet
            string[] rowDet = new string[] 
            {Convert.ToString(fgDet.Rows.Count),
                    txtCodArtCom.Text,
                    txtDes.Text,
                    txtCan.Text,
                    txtPrecio.Text,
                    txtVenBru.Text,
                    PorDes.ToString(),
                    txtDesc.Text == ""? "0" : txtDesc.Text,
                    txtValNet.Text,
                    txtIGV.Text,
                    txtSubTot.Text,
                    txtObs.Text,
                    txtSim.Text,
                    CosUni.ToString("#,###.##"),
                    (CosUni * Convert.ToInt32(txtCan.Text)).ToString("#,###.##"),
                    Margen.ToString("#,###.##")};

            fgDet.AddItem(rowDet);

            //Agregamos la fila del fgAmbTodos          
            foreach (Row row in fgAmb.Rows)
            {   
                if (row.Index > 0)
                {
                    fgAmbTodos.AddItem(new object[] { txtCodArtCom.Text, row[0], row[1].ToString(), row[2] });
                }
            }

            fgAmb.Rows.Count = 1;

            //Agregamos la fila del fgComTodos       
            foreach (Row row in fgCom.Rows)
            {
                if (row.Index > 0)
                {
                    fgComTodos.AddItem(new object[] { txtCodArtCom.Text, row[0].ToString(),
                                                row[1].ToString(), row[2].ToString(), row[3].ToString()});
                }

            }

            fgCom.Rows.Count = 1;            

            btnCanItem.PerformClick();

            //
            ItemMod = false;
            lblInfoItem.Text = "";
            //
            NumerarItems();
            ModCon_ArtComSer(false);
            //    '
            VEN_Cot_CalcularTotales();
            //    '
            btnBorItem.Enabled = true;

            txtDes.Focus();
        }

        private void txtCli_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCli_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtCli);
        }

        private void txtNomCot_Enter(object sender, EventArgs e)
        {
            NProVar.SelTex(txtNomCot);
        }

        private void txtNomCot_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) { txtCli.Focus(); }
        }

        private void txtVen_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Articulo Compuesto", "VEN_Cot_ArtCom", txtDes.Text.Trim(), Moneda, "0", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    txtCan.Focus();
                }
                else
                {
                    return;
                }



                if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(txtCodArtCom.Text)) == 2)
                {
                    ModCon_ArtComSer(true);
                }
                else
                {
                    ModCon_ArtComSer(false);
                }
                
            }
        }

        private void txtCan_TextChanged(object sender, EventArgs e)
        {

            decimal number = 0;
            decimal.TryParse(txtCan.Text, out number);

            if (number != 0)                    
            {                    
                ActualizarMontosArticuloCompuesto();
            }
            else
            {
                
                txtPorDes.Text = ""; txtDesc.Text = ""; txtValNet.Text = "";
                txtIGV.Text = ""; txtSubTot.Text = "";
            }
                
        }

        private void ActualizarMontosArticuloCompuesto()
        {
            decimal Can = 0;
            decimal.TryParse(txtCan.Text, out Can);

            decimal PorDes = 0;
            decimal.TryParse(txtPorDes.Text, out PorDes);


            //if (Can == 0 || PorDes == 0)
            //{
            //    txtVenBru.Text = ""; txtPorDes.Text = "";
            //    txtDes.Text = ""; txtValNet.Text = ""; txtIGV.Text = "";
            //    txtSubTot.Text = "";
            //}
            //else
            //{
                
                decimal Pre = Convert.ToDecimal(string.IsNullOrEmpty(txtPrecio.Text) ? "0" : txtPrecio.Text);               

                txtVenBru.Text = Convert.ToDecimal(Can * Pre ).ToString("N2");
                txtDesc.Text = Convert.ToDecimal(Can * Pre * PorDes / 100).ToString("N2");
                txtValNet.Text = Convert.ToDecimal(Can * Pre * (1 - PorDes / 100)).ToString("N2");
                txtIGV.Text = Convert.ToDecimal(varglo.ValorIGV * Can * Pre * (1 - PorDes / 100)).ToString("N2");
                txtSubTot.Text = Convert.ToDecimal((varglo.ValorIGV + 1) * Can * Pre * (1 - PorDes / 100)).ToString("N2");
                //Me.txtSubTotal.Text = Format(Round((ValorIGV + 1) * val(Me.txtCan.Text) * val(Me.txtPrecio.Text) * (1 - val(txtPorcentajeDescuento.Text) / 100), 2), "###,##0.00")
            //}
        }

        private void ActualizarMontosArticulo()
        {
            decimal ArtCan = 0;
            decimal.TryParse(txtArtCan.Text, out ArtCan);

            decimal Pre = 0;
            decimal.TryParse(txtArtPrecio.Text, out Pre);


            decimal PorDes = 0;
            decimal.TryParse(txtArtPorDes.Text, out PorDes);

            if (ArtCan == 0)
            {
                txtArtVenBru.Text = ""; txtArtPorDes.Text = "";
                txtArtValNet.Text = ""; txtArtIGV.Text = ""; txtArtSubTot.Text = "";
            }
            else
            {                                                
                txtArtVenBru.Text = Convert.ToDecimal(ArtCan * Pre).ToString("N2");
                txtArtDesc.Text = Convert.ToDecimal(ArtCan * Pre * PorDes / 100).ToString("N2");
                txtArtValNet.Text = Convert.ToDecimal(ArtCan * Pre * (1 - PorDes / 100)).ToString("N2");
                txtArtIGV.Text = Convert.ToDecimal(varglo.ValorIGV * ArtCan * Pre * (1 - PorDes / 100)).ToString("N2");
                txtArtSubTot.Text = Convert.ToDecimal((varglo.ValorIGV + 1) * ArtCan * Pre * (1 - PorDes / 100)).ToString("N2");
                
            }
        }

        private void VEN_Cot_ArtComMosCom()
        {
            int i = 1;
            DataTable dt = new DataTable();

            dt = nvc.VEN_Cot_ArtComMosCom(Convert.ToInt16(txtCodArtCom.Text),Moneda,txtCodTipVen.Text);

            //Preguntamos si el dataset esta vacio
            if (dt != null && dt.Rows.Count > 0)
            {
                fgCom.Rows.Count = 1;
                fgCom.Rows.Add(dt.Rows.Count);

                foreach (DataRow dr in dt.Rows)
                {
                    //fgCom.Rows.Add();
                    fgCom.Rows[i][0] = dr["CodArt"].ToString();
                    fgCom.Rows[i][1] = dr["Articulo"].ToString();
                    fgCom.Rows[i][2] = dr["Can"].ToString();
                    fgCom.Rows[i][3] = dr["ValorVenta"].ToString();
                    fgCom.Rows[i][4] = dr["SIS"].ToString();
                    fgCom.Rows[i][5] = dr["SHO"].ToString();
                    fgCom.Rows[i][6] = dr["SQO"].ToString();
                    fgCom.Rows[i][7] = dr["SQO"].ToString();
                    fgCom.Rows[i][8] = dr["Costo"].ToString();
                    fgCom.Rows[i][9] = dr["Margen"].ToString();
                    i = i + 1;
                }
            }

            //Limpiamos el grid de ambiente solo si no se esta modificando
            if (ItemMod == false)
            {
                fgAmb.Rows.Count = 1;
            }

        }

        private void txtDes_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAmb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Ambientes (Articulo Compuesto)", "Filtro_Ambientes", this.txtAmb.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtCanAmb.Focus();
                }
            }
        }

        private void txtCanAmb_TextChanged(object sender, EventArgs e)
        {
            Int32 number = 0;
            Int32.TryParse(txtCanAmb.Text, out number);

            if (number == 0) txtCanAmb.Text = "";
        }

        private void txtCanAmb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                if (txtCanAmb.Text == "")
                {
                    MessageBox.Show("Debe agregar una cantidad valida", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                btnAgrAmb.Focus();
            }
        }

        private void btnAgrAmb_Click(object sender, EventArgs e)
        {
            Int32 CodAmb = 0;

            Int32.TryParse(txtCodAmb.Text, out CodAmb);
            //Validamos que se haya seleccionado un ambiente
            if (CodAmb == 0)
            {
                MessageBox.Show("Debe elegir un ambiente", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAmb.Focus();
                return;
            }                

            //Para revisar si el ambiente ya fue agregado
            foreach (Row dr in fgAmb.Rows)
            {
                if (dr[1] != null)
                {
                    if (String.Compare(txtCodAmb.Text, dr[0].ToString()) == 0)
                    {
                        MessageBox.Show("El Ambiente ya fue Seleccionado","SAP ADICIONAL",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        txtAmb.Focus(); return;
                    }
                }
            }

            int CanAmb = 0 ;

            Int32.TryParse(txtCanAmb.Text, out CanAmb);
            //La cantidad a agregar debe ser mayor a cero
            if (CanAmb < 1)
            {
                MessageBox.Show("Debe ingresar una cantidad entera mayor a cero", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCanAmb.Focus(); return;
            }

            //Agregamos la linea
            string[] rowAmb = new string[]
            {txtCodAmb.Text, txtAmb.Text, txtCanAmb.Text};

            fgAmb.AddItem(rowAmb);

            //Limpiamos controles
            txtCodAmb.Text = ""; txtAmb.Text = ""; txtCanAmb.Text = "";

            int TotProAmb = 0;

            for (int i = 1; i < fgAmb.Rows.Count; i++)
            {
                TotProAmb = TotProAmb + Convert.ToInt16(fgAmb.Rows[i][2]);
            }

            lblAmbTot.Text = TotProAmb.ToString();

            //Validamos TotProAmb contra la cantidad del kit
            Int32 Can = 0;

            Int32.TryParse(txtCan.Text, out Can);

            if (TotProAmb == Can)
            {
                btnAgrItem.Enabled = true; btnAgrItem.Focus(); return;
            }
            else
            {
                txtAmb.Focus();
            }
        }

        private void txtCan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPorDes.Focus();
            }
        }

        private void txtPorDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                decimal TotProdAmb = 0;

                //Para comparar la cantidad de items y la suma de la cantidad puesta en los Ambientes
                for (int i = 1; i < fgAmb.Rows.Count; i++)
                {
                    TotProdAmb = TotProdAmb + Convert.ToDecimal(fgAmb.Rows[i][2]);
                }

                int Can = 0;
                //Valido que se ingrese una cantidad
                Int32.TryParse(txtCan.Text, out Can);

                if (TotProdAmb != Can)
                {
                    txtAmb.Focus();
                }
                else
                {
                    btnAgrItem.Focus();
                }                
            }
        }

        private void txtPorDes_TextChanged(object sender, EventArgs e)
        {
            decimal Can = 0;
            decimal.TryParse(txtCan.Text, out Can);

            //decimal Can = Convert.ToDecimal(string.IsNullOrEmpty(txtCan.Text) ? "0" : txtCan.Text);
            decimal Pre = Convert.ToDecimal(string.IsNullOrEmpty(txtPrecio.Text) ? "0" : txtPrecio.Text);

            decimal PorDes = 0;
            decimal.TryParse(txtPorDes.Text, out PorDes);

            txtDesc.Text = Convert.ToDecimal(Can * Pre * PorDes / 100).ToString("N2");
            txtValNet.Text = Convert.ToDecimal(Can * Pre * (1 - PorDes / 100)).ToString("N2");
            txtIGV.Text = Convert.ToDecimal(varglo.ValorIGV * Can * Pre * (1 - PorDes / 100)).ToString("N2");
            txtSubTot.Text = Convert.ToDecimal((varglo.ValorIGV + 1) * Can * Pre * (1 - PorDes / 100)).ToString("N2");
        }

        private void btnCanItem_Click(object sender, EventArgs e)
        {
            fgDet.Enabled = true;

            txtCodArtCom.Text = ""; txtDes.Text = ""; txtPrecio.Text = ""; txtSim.Text = ""; txtCan.Text = "";
            txtVenBru.Text = ""; txtPorDes.Text = ""; txtDesc.Text = ""; txtValNet.Text = ""; txtIGV.Text = ""; txtSubTot.Text = "";
            txtObs.Text = ""; txtAmb.Text = ""; txtCanAmb.Text = "";

            //'Limpiamos los grid componente y ambientes
            fgAmb.Rows.Count = 1;
            fgCom.Rows.Count = 1;

            ItemMod = false;
            lblInfoItem.Text = "";

            fgDet.Enabled = true;

            btnAgrCom.Enabled = false;
            btnCanCom.Enabled = false;
            btnBorCom.Enabled = false;

            btnBorItem.Enabled = true;
            
        }

        private void btnModItem_Click(object sender, EventArgs e)
        {

            //Pongo la variable itemod en true
            ItemMod = true;
            lblInfoItem.Text = "MODIFICANDO";

            Int16 Fila = 0;

            Fila = Convert.ToInt16(fgDet.Row);

            txtCodArtCom.Text = fgDet.Rows[Fila][1].ToString();
            txtDes.Text = fgDet.Rows[Fila][2].ToString();

            if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(txtCodArtCom.Text)) == 2)
            {
                ModCon_ArtComSer(true);
            }
            else
            {
                ModCon_ArtComSer(false);
            }

            txtCan.Text = fgDet.Rows[Fila][3].ToString();
            txtPrecio.Text = fgDet.Rows[Fila][4].ToString();
            txtVenBru.Text = fgDet.Rows[Fila][5].ToString();
            txtPorDes.Text = fgDet.Rows[Fila][6].ToString();
            txtDesc.Text = fgDet.Rows[Fila][7].ToString();
            txtValNet.Text = fgDet.Rows[Fila][8].ToString();
            txtIGV.Text = fgDet.Rows[Fila][9].ToString();
            txtSubTot.Text  = fgDet.Rows[Fila][10].ToString();
            txtObs.Text = fgDet.Rows[Fila][11].ToString();
            txtSim.Text = fgDet.Rows[Fila][12].ToString();

            //Retiro el kit de los grid todos (ambiente y componente), 
            bool Encuentra = false;

            while (Encuentra == false)
            {
                Encuentra = true;

                for (int i = 1; i < fgAmbTodos.Rows.Count; i++)
                {
                    if (fgAmbTodos.Rows[i][0].ToString() == txtCodArtCom.Text)
                    {
                        fgAmbTodos.RemoveItem(i);
                        Encuentra = false;
                        break;
                    }
                }

                for (int i = 1; i < fgComTodos.Rows.Count; i++)
                {
                    if (fgComTodos.Rows[i][0].ToString() == txtCodArtCom.Text)
                    {
                        fgComTodos.RemoveItem(i);
                        Encuentra = false;
                        break;
                    }
                }
            }            

            //Eliminamos la linea del grid detalle
            fgDet.RemoveItem(Fila);
            txtDes.Focus();

            fgDet.Enabled = false;

            btnAgrCom.Enabled = true;
            btnCanCom.Enabled = true;
            btnBorCom.Enabled = true;

            btnBorItem.Enabled = false;

            NumerarItems();

            VEN_Cot_CalcularTotales();


        }

        private void NumerarItems()
        {
            for (int i = 1; i < fgDet.Rows.Count ; i++)
            {
                fgDet.Rows[i][0] = i;
            }

            for (int i = 1; i < fgDetAA.Rows.Count; i++)
            {
                fgDetAA.Rows[i][0] = i;
            }

            for (int i = 1; i < fgArtDet.Rows.Count; i++)
            {
                fgArtDet.Rows[i][0] = i;
            }
        }

        private void VEN_Cot_Botones(ToolStripButton boton)
        {
            switch (boton.Text)
            {
                case "&Nuevo":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 2, "nue", 0) == 1)
                    {
                        this.gpbCubre.Visible = true;
                        this.gpbCubre.Enabled = true;
                        this.gpbCubre.Top = 0;

                        this.gpbMoneda.Visible = true;
                        this.gpbMoneda.Enabled = true;

                        this.rdbDol.Enabled = true;
                        this.rdbDol.AutoCheck = true;
                        this.rdbDol.Focus();

                        //
                        //this.tlsBot.Enabled = false;                                               
                        //
                        this.btnAce.Enabled = true;
                        this.btnCan.Enabled = true;
                        this.btnAce.Focus();
                        //'
                    }
                    else
                    {
                        MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    break;

                case "&Abrir":

                    bool Existe;

                    Existe = false;

                    Form frm = this.MdiParent.MdiChildren.FirstOrDefault(x => x is frmGEN_AbrDoc && Convert.ToInt16(x.Tag) == 11);

                    if (frm != null)
                    {
                        frm.BringToFront();
                        frm.Show();

                        Existe = true;
                    }

                    if (Existe == false)
                    {
                        frmGEN_AbrDoc f = new frmGEN_AbrDoc();
                        f.Text = "Cotizacion - Abrir";
                        f.Tag = 11;
                        f.MdiParent = this.MdiParent;
                        f.BringToFront();
                        f.Show();
                    }
               
                    this.Dispose();

                    break;

                case "&Guardar":


                    if (txtCodMot.Text == "") { MessageBox.Show("Debe elegir un motivo", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Information); txtMot.Focus(); return;}
                    //
                    //Validamos si tiene permitido crear una cotizacion con este centro de venta

                    if (nvc.VEN_Cot_ValCenVen(varglo.CodUsuAct, txtCodCenVen.Text) != 2)
                    {
                        MessageBox.Show("No puede crear y/o actualizar una oferta con el centro de venta seleccionado",
                                        "SAP ADICIONAL",MessageBoxButtons.OK, MessageBoxIcon.Information); return;
                    }

                    //Validando codigos
                    //Si la cotizacion esta aprobada valida que siempre tenga estos datos.
                    if (EstDoc == 2)
                    {
                        if (txtCodCli.Text == "") { MessageBox.Show("Codigo de Cliente invalido","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information); txtCli.Focus(); return; }

                        if (txtCodCenVen.Text == "") { MessageBox.Show("Debe elegir un Centro de Venta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCenVen.Focus(); return; }
                        if (txtCodTipVen.Text == "") {MessageBox.Show("Debe elegir un Tipo de Venta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtTipVen.Focus(); return; } 
                        if (txtCodTipDoc.Text == "6" && (txtCodCliCon.Text == "" || txtCodCliCon.Text == "0"))
                        {
                            { MessageBox.Show("Debe elegir una persona de contacto cuando el cliente es una razón social", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCliCon.Focus(); return; }
                        }

                        if (VEN_Cot_ValidaTipoVentayOtros(1) == true) return;

                        if (txtCenVen.Text != "RECLAM" && txtCenVen.Text != "POSVTA")
                        {
                            if (VEN_Cot_ValidaTipoVentayOtros(2) == true) return;
                            if (VEN_Cot_ValidaTipoVentayOtros(3) == true) return;
                            if (VEN_Cot_ValidaTipoVentayOtros(4) == true) return;
                        }

                    }

                    //    'Validamos que se seleccione toda la informacion si el centro de venta es reclamo
                    if (nvc.VEN_Cot_ValInfRec(txtCodCenVen.Text, 1, string.IsNullOrEmpty(txtCodFalEn.Text)?(Int16)0:Convert.ToInt16(txtCodFalEn.Text) ,0) != 0 && txtCodFalEn.Text == "")
                    { MessageBox.Show("Debe elegir la Falla.","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Exclamation); txtFalEn.Focus(); return;}

                    if (nvc.VEN_Cot_ValInfRec(txtCodCenVen.Text, 2, string.IsNullOrEmpty(txtCodFalEn.Text) ? (Int16)0 : Convert.ToInt16(txtCodFalEn.Text), 0) != 0 && txtCodLinPro.Text == "")
                    { MessageBox.Show("Debe elegir la linea de producto/servicio.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); txtLinPro.Focus(); return;}

                    if (nvc.VEN_Cot_ValInfRec(txtCodCenVen.Text, 3, string.IsNullOrEmpty(txtCodLinPro.Text) ? (Int16)0 : Convert.ToInt16(txtCodLinPro.Text), 0) != 0 && txtCodTip.Text == "")
                    { MessageBox.Show("Debe elegir el Tipo.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); txtTip.Focus(); return;}

                    if (nvc.VEN_Cot_ValInfRec(txtCodCenVen.Text, 4, string.IsNullOrEmpty(txtCodTip.Text) ? (Int16)0 : Convert.ToInt16(txtCodTip.Text), 0) != 0 && txtCodSubLin.Text == "")
                    { MessageBox.Show("Debe elegir la SubLinea", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); txtSubLin.Focus(); return;}

                    if (nvc.VEN_Cot_ValInfRec(txtCodCenVen.Text, 5, string.IsNullOrEmpty(txtCodSubLin.Text) ? (Int16)0 : Convert.ToInt16(txtCodSubLin.Text), 0) != 0 && txtCodFam.Text == "")
                    { MessageBox.Show("Debe elegir la Familia", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); txtFam.Focus(); return; }
                    //    '

                    //Validamos que haya un texto escrito en el campo cliente
                    if (txtCli.Text == "") { MessageBox.Show("Debe ingresar un nombre de cliente","SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information); txtCli.Focus(); return; }

                    //Validamos que escogan un vendedor
                    if (txtCodVen.Text == "") { MessageBox.Show("Codigo de vendedor invalido.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtVen.Focus(); return; }

                    //Validamos que escogan un recomendador
                    if (txtCodRec.Text == "") { MessageBox.Show("Debe seleccionar un recomendador.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtRec.Focus(); return; }
                    
                    //    Validamos si se esta vendiendo por debajo del costo
                    if (VEN_Cot_ValCosMar() == true)
                    {
                        return;
                    }

                    //Validamos que por lo menos hayan agregado una linea en cualquiera de los grid
                    if (fgDet.Rows.Count == 1 && fgDetAA.Rows.Count == 1 && fgArtDet.Rows.Count == 1)
                    {
                        MessageBox.Show("Debe ingresar al menos un producto","SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtDes.Focus(); return;
                    }

                    VEN_Cot_CalcularTotales();

                    //Encabezado de cotizacion
                    VEN_Cot Enc = new VEN_Cot();

                    Enc.NumMov = NumMov;
                    Enc.NumCot = txtNum.Text;
                    Enc.EstDoc = EstDoc;
                    Enc.CardCode = txtCodCli.Text;
                    Enc.NomCli = txtCli.Text;
                    Enc.DirCli = txtDirCli.Text;
                    Enc.DirObr = txtDirObr.Text;
                    Enc.CntctCode = string.IsNullOrEmpty(txtCodCliCon.Text) ? (Int16)0 : Convert.ToInt16(txtCodCliCon.Text);
                    Enc.SlpCode = Convert.ToInt16(txtCodVen.Text);
                    Enc.U_SYP_C_VENTA = txtCodCenVen.Text;
                    Enc.U_SYP_TIVENTA = txtCodTipVen.Text;
                    Enc.U_SYP_RQ = txtRQ.Text;
                    Enc.U_SYP_TVENTA_REL = txtTipVenRel.Text;
                    Enc.U_SYP_RUBRO = txtRub.Text;
                    Enc.U_SYP_TIPO_OBRA = txtTipObr.Text;
                    Enc.U_SYP_DIMENSION = txtDim.Text;
                    Enc.U_SYP_NOM_VENTA = txtNomCot.Text;
                    Enc.CodCon = Convert.ToInt16(txtCodRec.Text);
                    Enc.DocCur = Moneda;
                    Enc.DocRate = varglo.TipCam;
                    Enc.PorIGV = varglo.ValorIGV;
                    Enc.CodUsu = varglo.CodUsuAct;
                    Enc.Tel = txtTel.Text;
                    Enc.Email = txtEmail.Text;
                    Enc.U_TRZ_TIE = txtTie.Text;
                    Enc.U_TRZ_OPCPAG = txtPag.Text;
                    Enc.NomAdi = txtNomAdi.Text;
                    Enc.CodMot = Convert.ToInt16(txtCodMot.Text);  
                    Enc.CodAdmRQ = string.IsNullOrEmpty(txtCodAdmRQ.Text) ? (Int16)0 : Convert.ToInt16(txtCodAdmRQ.Text);
                    Enc.CodRecFalEn = string.IsNullOrEmpty(txtCodFalEn.Text) ? (Int16)0 : Convert.ToInt16(txtCodFalEn.Text);
                    Enc.CodRecLinPro = string.IsNullOrEmpty(txtCodLinPro.Text) ? (Int16)0 : Convert.ToInt16(txtCodLinPro.Text);
                    Enc.CodRecTip = string.IsNullOrEmpty(txtCodTip.Text) ? (Int16)0 : Convert.ToInt16(txtCodTip.Text);
                    Enc.CodRecSubLin = string.IsNullOrEmpty(txtCodSubLin.Text) ? (Int16)0 : Convert.ToInt16(txtCodSubLin.Text);
                    Enc.CodRecFam = string.IsNullOrEmpty(txtCodFam.Text) ? (Int16)0 : Convert.ToInt16(txtCodFam.Text);

                    //Recorremos el grid detalle 
                    for (int i = 1; i < fgDet.Rows.Count; i++)
                    {
                        VEN_Cot_Det Det = new VEN_Cot_Det();

                        Det.CodArtCom = Convert.ToInt32(fgDet.Rows[i][1]);
                        Det.Can = Convert.ToDecimal(fgDet.Rows[i][3]);
                        Det.PreUni = Convert.ToDecimal(fgDet.Rows[i][4]);
                        Det.VenBru = Convert.ToDecimal(fgDet.Rows[i][5]);
                        Det.PorDes = Convert.ToDecimal(fgDet.Rows[i][6]);
                        Det.Desct = Convert.ToDecimal(fgDet.Rows[i][7]);
                        Det.ValNet = Convert.ToDecimal(fgDet.Rows[i][8]);
                        Det.IGV = Convert.ToDecimal(fgDet.Rows[i][9]);
                        Det.SubTot = Convert.ToDecimal(fgDet.Rows[i][10]);
                        Det.Obs = fgDet.Rows[i][11].ToString();
                        Det.Sim = fgDet.Rows[i][12].ToString();

                        Enc.Det.Add(Det);

                    }

                    //Recorremos el grid detalle componente 
                    for (int i = 1; i < fgComTodos.Rows.Count; i++)
                    {
                        VEN_Cot_DetCom DetCom = new VEN_Cot_DetCom();

                        DetCom.CodArtCom = Convert.ToInt32(fgComTodos.Rows[i][0]);
                        DetCom.CodArt = fgComTodos.Rows[i][1].ToString();
                        DetCom.Can  = Convert.ToDecimal(fgComTodos.Rows[i][3]);
                        DetCom.PreUni = Convert.ToDecimal(fgComTodos.Rows[i][4]);

                        Enc.DetCom.Add(DetCom);

                    }

                    //Recorremos el grid detalle ambiente 
                    for (int i = 1; i < fgAmbTodos.Rows.Count; i++)
                    {
                        VEN_Cot_DetAmb DetAmb = new VEN_Cot_DetAmb();

                        DetAmb.CodArtCom = Convert.ToInt32(fgAmbTodos.Rows[i][0]);
                        DetAmb.CodAmb = Convert.ToInt32(fgAmbTodos.Rows[i][1]);
                        DetAmb.Can = Convert.ToDecimal(fgAmbTodos.Rows[i][3]);

                        Enc.DetAmb.Add(DetAmb);

                    }

                    //Recorremos el grid detalle articulos alternativos
                    for (int i = 1; i < fgDetAA.Rows.Count; i++)
                    {
                        VEN_Cot_DetAA DetAA = new VEN_Cot_DetAA();

                        DetAA.DesAA = fgDetAA.Rows[i][1].ToString();
                        DetAA.Can = Convert.ToDecimal(fgDetAA.Rows[i][2]);
                        DetAA.PreUni = Convert.ToDecimal(fgDetAA.Rows[i][3]);
                        DetAA.VenBru = Convert.ToDecimal(fgDetAA.Rows[i][4]);
                        DetAA.PorDes = Convert.ToDecimal(fgDetAA.Rows[i][5]);
                        DetAA.Desct = Convert.ToDecimal(fgDetAA.Rows[i][6]);
                        DetAA.ValNet = Convert.ToDecimal(fgDetAA.Rows[i][7]);
                        DetAA.IGV = Convert.ToDecimal(fgDetAA.Rows[i][8]);
                        DetAA.SubTot = Convert.ToDecimal(fgDetAA.Rows[i][9]);
                        DetAA.CodAmb = Convert.ToInt32(fgDetAA.Rows[i][10]);
                        DetAA.RutIma = fgDetAA.Rows[i][12].ToString();
                        DetAA.RutIma2 = fgDetAA.Rows[i][13].ToString();
                        DetAA.RutImaTec = fgDetAA.Rows[i][14].ToString();
                        DetAA.Obs = fgDetAA.Rows[i][15].ToString();
                        DetAA.CosUni = Convert.ToDecimal(fgDetAA.Rows[i][16]);

                        Enc.DetAA.Add(DetAA);

                    }

                    //Recorremos el grid detalle articulo simple
                    for (int i = 1; i < fgArtDet.Rows.Count; i++)
                    {
                        VEN_Cot_DetAS DetAS = new VEN_Cot_DetAS();

                        DetAS.CodArt = fgArtDet.Rows[i][1].ToString();
                        DetAS.Can = Convert.ToDecimal(fgArtDet.Rows[i][3]);
                        DetAS.PreUni = Convert.ToDecimal(fgArtDet.Rows[i][4]);
                        DetAS.VenBru = Convert.ToDecimal(fgArtDet.Rows[i][5]);
                        DetAS.PorDes = Convert.ToDecimal(fgArtDet.Rows[i][6]);
                        DetAS.Desct = Convert.ToDecimal(fgArtDet.Rows[i][7]);
                        DetAS.ValNet = Convert.ToDecimal(fgArtDet.Rows[i][8]);
                        DetAS.IGV = Convert.ToDecimal(fgArtDet.Rows[i][9]);
                        DetAS.SubTot = Convert.ToDecimal(fgArtDet.Rows[i][10]);
                        DetAS.Obs = fgArtDet.Rows[i][11].ToString();

                        Enc.DetAS.Add(DetAS);

                    }

                    //Recorremos el grid ambiente de articulo simple
                    for (int i = 1; i < fgArtAmbTodos.Rows.Count; i++)
                    {
                        VEN_Cot_DetAmbAS DetAmbAS = new VEN_Cot_DetAmbAS();

                        DetAmbAS.CodArt = fgArtAmbTodos.Rows[i][0].ToString();
                        DetAmbAS.CodAmb = Convert.ToInt32(fgArtAmbTodos.Rows[i][1]);
                        DetAmbAS.Can = Convert.ToDecimal(fgArtAmbTodos.Rows[i][3]);

                        Enc.DetAmbAS.Add(DetAmbAS);

                    }

                    //Pasamos la entidadd para guardar
                    nvc.VEN_Cot_ingact(Enc, NumMovCotOri);

                    NumMovCotOri = 0;

                    //Recuperamos el numero de movimiento y numero de cotizacion
                    NumMov = Enc.NumMov;
                    txtNum.Text = Enc.NumCot.ToString();

                    txtNomAdi.Text = nvc.VEN_Cot_RecNomAdi(NumMov);

                    VEN_Cot_EstBot("abrir");
                    //    '
                    btnCanItem.PerformClick();
                    //    '
                  //Call BloquearControles(False)

                    break;
                case "&Deshacer":

                    DialogResult res;
                    res = MessageBox.Show("Esto cancelara cualquier modificación. ¿Esta seguro de deshacer?.", "SAP Adicional", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (res == DialogResult.Yes)
                    {
                        VEN_Cot_Botones(btnAbrir);
                    }

                    break;

                case "&Modificar":

                    if (MetGlo.GEN_AccByDoc(varglo.CodUsuAct, 2, "mod", 0) == 1)
                    {
                        VEN_Cot_EstBot("modificar");
                    }
                    else
                    {
                        MessageBox.Show("No cuenta con acceso para realizar esta operación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    break;

                case "A&probar":

                    if (txtNum.Text == "")
                    { MessageBox.Show("La cotización no esta guardada", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

                    if (nvc.VEN_Cot_Validar_UsuApr(varglo.CodUsuAct) == false)
                    {
                        MessageBox.Show("El usuario actual no puede aprobar la cotización", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }

                    if (txtCodCli.Text == "")
                    { MessageBox.Show("Codigo de Cliente invalido", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCli.Focus(); return; }

                    if (txtCodCenVen.Text == "")
                    { MessageBox.Show("Debe elegir un Centro de Venta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCenVen.Focus(); return; }

                    if (txtCodTipVen.Text == "")
                    { MessageBox.Show("Debe elegir un Tipo de Venta", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtTipVen.Focus(); return; }

                    if (txtCodTipDoc.Text == "6" && (txtCodCliCon.Text == "" || txtCodCliCon.Text == "0"))
                    {
                        MessageBox.Show("Debe elegir una persona de contacto cuando el cliente es una razón social", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtCliCon.Focus();
                        return;
                    }

                    //Validamos los valores en el tipo de venta y otros
                    if (VEN_Cot_ValidaTipoVentayOtros(1) == true) return;

                    if (txtCenVen.Text != "RECLAM" && txtCenVen.Text != "POSVTA")
                    {
                        if (VEN_Cot_ValidaTipoVentayOtros(2) == true) return;
                        if (VEN_Cot_ValidaTipoVentayOtros(3) == true) return;
                        if (VEN_Cot_ValidaTipoVentayOtros(4) == true) return;
                    }

                    nvc.VEN_Cot_ActCotApr(NumMov, varglo.CodUsuAct);
                    EstDoc = 2;

                    VEN_Cot_EstBot("abrir");

                    break;

                case "D&uplicar":

                    NumMovCotOri = NumMov;
                    NumMov = 0;
                    txtNum.Text = "";
                    txtFecEmi.Text = /*DateAndTime.Now.ToString("dd/MM/yyyy");*/
                    //EstDoc = 1;
                    txtRQ.Text = "";
                    txtDocNum.Text = "";
                    txtDocEntry.Text = "";

                    VEN_Cot_EstBot("modificar");

                    break;

                case "Migrar &SAP":

                    //Primero solicitamos que seleccionen un Adm RQ.
                    MessageBox.Show("Indique quien sera el Adminsitrador del RQ.", "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtAdmRQ_KeyPress(this, new KeyPressEventArgs((char)(Keys.Enter)));

                    if (txtCodAdmRQ.Text == "")
                    {
                        MessageBox.Show("Se cancelo la operación.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); return;
                    }

                    string errorSAP = "" ;
                    string docentry = "";

                    if (sap.SAP_ValidarUsuario(varglo.UsuSAP, varglo.PasSAP) != 0)
                    {//La primera vez las variables van a estar vacias y devolvera error por lo que
                     //mostrara el formulario de inicio de sesion
                        frmGEN_SAP_IniSes f = new frmGEN_SAP_IniSes();

                        f.SAP_Var = this;
                        f.ShowDialog();

                        if (SAP_UserBad == true) return;
                    }
                    else
                    {
                        SAP_Conecta = sap.SAP_ConectarCompañia(varglo.UsuSAP, varglo.PasSAP);
                    }

                    if (SAP_Conecta != 0)
                    {
                        MessageBox.Show("Se ha producido el error " + SAP_Conecta.ToString(), "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        Int64 docnum = 0;
                        Int64.TryParse(txtDocNum.Text,out docnum);

                        //sap.VEN_Cot_MigSAP(out docentry, out errorSAP, NumMov, varglo.Empresa);

                        if (errorSAP != "")
                        {
                            MessageBox.Show(errorSAP); return;
                        }
                        else
                        {
                            txtDocEntry.Text = docentry;

                            DataTable dtRecVal = new DataTable();

                            dtRecVal = nvc.VEN_Cot_RecValCotMig(Convert.ToInt64(docentry));

                            txtRQ.Text = dtRecVal.Rows[0]["u_syp_rq"].ToString();
                            txtDocNum.Text = dtRecVal.Rows[0]["DocNum"].ToString();

                            nvc.VEN_Cot_ActCotMig(Convert.ToInt32(txtCodAdmRQ.Text),
                                                  varglo.CodUsuAct,
                                                  (txtRQ.Text == "" ? Convert.ToInt32("0") : Convert.ToInt32(txtRQ.Text)),                                                   
                                                  Convert.ToInt64(txtDocEntry.Text),
                                                  Convert.ToInt64(txtDocNum.Text),
                                                  NumMov);

                            MessageBox.Show("Se migro correctamente","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information);

                        }                           
                    }

                    break;

                case "Opc. &Imp...":

                    frmVEN_CotImp fImp = new frmVEN_CotImp();

                    fImp.tipven = txtCodTipVen.Text;
                    fImp.nummov = NumMov;
                    fImp.ShowDialog();

                    break;

            }
        }

        private void txtMot_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Motivo", "Filtro_Cot_Mot", this.txtMot.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtNomCot.Focus();
                }
            }
        }

        private void txtAdmRQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("AdmRQ", "Filtro_AdmRQ", this.txtAdmRQ.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    btnSigPag.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_AdmRQ(string CodAdmRQ, string AdmRQ)
        {
            txtCodAdmRQ.Text = CodAdmRQ;
            txtAdmRQ.Text = AdmRQ;
        }

        private void fgDet_Click(object sender, EventArgs e)
        {
            if (fgDet.Rows.Count == 1) { return;}

            int CodArtCom = Convert.ToInt32(fgDet.Rows[fgDet.Row][1]);

            fgAmb.Rows.Count = 1;
            fgCom.Rows.Count = 1;          
            
            //Busco el ambiente en el grid ambientes todos segun el codigo de articulo compuesto y lo recupero en el grid de ambientes
            foreach (Row row in fgAmbTodos.Rows)
            {
                if (row.Index > 0)
                {
                    if (Convert.ToInt32(row[0]) == CodArtCom)
                    {
                        fgAmb.AddItem(new object[] { row[1], row[2].ToString(), row[3] });
                    }
                }

            }

            DataTable dt = new DataTable();

            foreach (Row row in fgComTodos.Rows)
            {
                if (row.Index > 0)
                {
                    if (Convert.ToInt32(row[0]) == CodArtCom)
                    {
                        //recuperamos datos de stock para el codigo de articulo
                        dt = nvc.VEN_Cot_Stock(Convert.ToString(row[1]));

                        //Preguntamos si el dataset esta vacio
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            DataRow dr = dt.Rows[0];

                            fgCom.AddItem(new object[] {row[1], row[2].ToString(), row[3], row[4],
                                                    dr["SIS"].ToString(),
                                                    dr["SHO"].ToString(),
                                                    dr["SQO"].ToString(),
                                                    dr["REM"].ToString(),
                                                    dr["Costo"].ToString(),
                                                    Convert.ToDecimal(row[4]) - Convert.ToDecimal(dr["Costo"].ToString())});
                        }
                        else
                        {
                            fgCom.AddItem(new object[] { row[1], row[2].ToString(), row[3], row[4], 0, 0, 0, 0 ,0});
                        }

                    }
                }

            }
        }

        private void txtMot_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTie_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tiempo", "Filtro_Cot_Tie", this.txtTie.Text.Trim(), this.txtCodTipVen.ToString(), "", "", "");

                if (varglo.Elegi == true)
                {
                    txtPag.Focus();
                }
            }
        }

        private void btnSigPag_Click(object sender, EventArgs e)
        {
            this.tbPri.SelectedIndex = 1;
        }

        private void txtRec_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNomAdi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnSigPag.Focus();
            }
        }

        private void txtCodArtCom_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Articulo Compuesto", "VEN_Cot_ArtCom", txtCodArtCom.Text.Trim(), Moneda, "1", "", "");

                if (varglo.Elegi == true)
                {
                    txtCan.Focus();
                }

                if (txtCodArtCom.Text == "") return;

                if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(txtCodArtCom.Text)) == 2)
                {
                    ModCon_ArtComSer(true);
                }
                else
                {
                    ModCon_ArtComSer(false);
                }
            }
        }

        private void rdbDol_CheckedChanged_1(object sender, EventArgs e)
        {
            Moneda = "USD";
        }

        private void rdbSol_CheckedChanged_1(object sender, EventArgs e)
        {
            Moneda = "S/";
        }

        private void ModCon_ArtComSer(bool Val)
        {
            if (Val == true)
            {

                txtCan.Text = "1";
                txtCan.BackColor = SystemColors.InactiveCaption;
                txtCan.ReadOnly = true;

                txtPorDes.Text = "";
                txtPorDes.BackColor = SystemColors.InactiveCaption;
                txtPorDes.ReadOnly = true;

                txtAmb.Text = "";
                txtAmb.BackColor = SystemColors.InactiveCaption;
                txtAmb.ReadOnly = true;

                txtCanAmb.Text = "";
                txtCanAmb.BackColor = SystemColors.InactiveCaption;
                txtCanAmb.ReadOnly = true;

                if (ItemMod == false || nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(txtCodArtCom.Text)) ==2 )
                {
                    txtCodAmb.Text = "3126";
                    txtAmb.Text = "Servicio";
                    txtCanAmb.Text = "1";
                    btnAgrAmb.Enabled = true; btnAgrAmb.Focus();
                }
            }
            else
            {

                txtCan.Text = "";
                txtCan.BackColor = SystemColors.Window;
                txtCan.ReadOnly = false;

                txtPorDes.Text = "";
                txtPorDes.BackColor = SystemColors.Window;
                txtPorDes.ReadOnly = false;

                txtAmb.Text = "";
                txtAmb.BackColor = SystemColors.Window;
                txtAmb.ReadOnly = false;

                txtCanAmb.Text = "";
                txtCanAmb.BackColor = SystemColors.Window;
                txtCanAmb.ReadOnly = false;

                if (ItemMod == false)
                {
                    txtCodAmb.Text = "";
                    txtAmb.Text = "";
                    txtCanAmb.Text = "";                  
                }

                txtCan.Focus();
            }
        }

        private void txtCodArtCom_TextChanged(object sender, EventArgs e)
        {
            Int32 number = 0;
            Int32.TryParse(txtCodArtCom.Text, out number);

            if (number == 0) txtCodArtCom.Text = "";
        }

        private void btnEliAmb_Click(object sender, EventArgs e)
        {            
            Int32 TotProAmb = 0;

            if (fgAmb.Row > 0 )
            {
                fgAmb.Rows.Remove(fgAmb.Row);
            }

            for (int i = 1; i < fgAmb.Rows.Count; i++)
            {
                TotProAmb = TotProAmb + Convert.ToInt32(fgAmb.Rows[i][2]);
            }

            lblAmbTot.Text = TotProAmb.ToString();

        }

        private void fgAmb_AfterAddRow(object sender, RowColEventArgs e)
        {

        }

        private void VEN_Cot_CalcularTotales()
        {

            decimal VenBru = 0; decimal MonDes = 0; decimal ValVen = 0; decimal MonIGV = 0; decimal TotGen = 0; decimal TotSer = 0;

            txtTotPorDes.Text = "";

            //    Solo si hay algun dato en el grid Detalles
            if (fgDet.Rows.Count > 1)
            {
                for (int i = 1; i < fgDet.Rows.Count; i++)
                {
                    //Solo articulos
                    if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1)
                    {

                        VenBru = VenBru + (Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]));
                        MonDes = MonDes + (Convert.ToDecimal(fgDet.Rows[i][7]));

                        //decimal TotPorDes;
                        //decimal.TryParse(txtPorDes.Text, out TotPorDes);

                        //txtTotPorDes.Text = (TotPorDes + Convert.ToDecimal(fgDet.Rows[i][6])).ToString();
                    }

                    //Solo servicios
                    if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 2)
                    {
                        TotSer = TotSer + (Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]));
                    }

                    MonIGV = MonIGV + Convert.ToDecimal(fgDet.Rows[i][9]);
                }

                if (txtCodTipVen.Text == "SS")
                {
                    VenBru = TotSer;
                    ValVen = VenBru - MonDes;
                }
                else
                {
                    ValVen = (VenBru - MonDes) + TotSer;
                }

                TotGen = MonIGV + ValVen;

                if (fgDetAA.Rows.Count < 2 && txtCodTipVen.Text == "SS" && VenBru != 0)
                {
                    txtTotPorDes.Text = (100 * (MonDes / VenBru)).ToString();
                }

            }

            decimal VenBruAA = 0; decimal MonDesAA = 0; decimal ValVenAA = 0; decimal MonIGVAA = 0; decimal TotGenAA = 0;// double TotSerAA = 0;

            if (fgDetAA.Rows.Count > 1)
            {
                decimal CanAA = 0;
                decimal PreUniAA = 0;                

                for (int i = 1; i < fgDetAA.Rows.Count; i++)
                {                   

                    decimal.TryParse(fgDetAA.Rows[i][2].ToString(), out CanAA);
                    decimal.TryParse(fgDetAA.Rows[i][3].ToString(), out PreUniAA);

                    //MessageBox.Show(fgDetAA.Rows[i][2].ToString());

                    VenBruAA = VenBruAA + (CanAA * PreUniAA);
                    MonDesAA = MonDesAA + (Convert.ToDecimal(fgDetAA.Rows[i][6]));

                    MonIGVAA = MonIGVAA + Convert.ToDecimal(fgDetAA.Rows[i][8]);
                }

                ValVenAA = VenBruAA - MonDesAA;
                TotGenAA = MonIGVAA + ValVenAA;

            }

            decimal ArtVenBru = 0; decimal ArtMonDes = 0; decimal ArtValVen = 0; decimal ArtMonIGV = 0; decimal ArtTotGen = 0;// double TotSerAA = 0;

            if (fgArtDet.Rows.Count > 1)
            {
                decimal ArtCan = 0;
                decimal ArtPreUni = 0;

                for (int i = 1; i < fgArtDet.Rows.Count; i++)
                {
                    decimal.TryParse(fgArtDet.Rows[i][3].ToString(), out ArtCan);
                    decimal.TryParse(fgArtDet.Rows[i][4].ToString(), out ArtPreUni);

                    ArtVenBru = ArtVenBru + (ArtCan * ArtPreUni);
                    ArtMonDes = ArtMonDes + (Convert.ToDecimal(fgArtDet.Rows[i][7]));

                    ArtMonIGV = ArtMonIGV + Convert.ToDecimal(fgArtDet.Rows[i][9]);
                }

                ArtValVen = ArtVenBru - ArtMonDes;
                ArtTotGen = ArtMonIGV + ArtValVen;

            }

            txtTotPorDes.Text = "";

            if ((VenBru + VenBruAA + ArtVenBru) != 0)
            {
                txtTotPorDes.Text = (100 * ((MonDes + MonDesAA + ArtMonDes) / (VenBru + VenBruAA + ArtVenBru))).ToString("#,###,###.00");
            }
            
            //*********************EXCLUSIVO PARA SACAR LOS COSTOS************************************
            decimal CosTot = 0; decimal ValVenMer = 0;

            for (int i = 1; i < fgDet.Rows.Count; i++)
            {
                if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1)
                {
                    CosTot = CosTot + Convert.ToDecimal(fgDet.Rows[i][14]);
                    ValVenMer = ValVenMer + Convert.ToDecimal(fgDet.Rows[i][8]);
                }
            }

            for (int i = 1; i < fgDetAA.Rows.Count; i++)
            {
                CosTot = CosTot + Convert.ToDecimal(fgDetAA.Rows[i][17]);
                ValVenMer = ValVenMer + Convert.ToDecimal(fgDetAA.Rows[i][7]);
            }

            //********************************************************************************************

            if (ValVenMer != 0)
            {
                txtCosTot.Text = CosTot.ToString("#,###,###.00"); txtMar.Text = Math.Round((((ValVenMer - CosTot) / ValVenMer) * 100),2).ToString();
            }

            //Asigna valores a los texts
            txtTotVenBru.Text = (VenBru + VenBruAA + ArtVenBru).ToString("#,###,###.00");
            txtTotDes.Text = (MonDes + MonDesAA + ArtMonDes).ToString("#,###,###.00");
            txtTotValVen.Text = (ValVen + ValVenAA + ArtValVen).ToString("#,###,###.00");
            txtTotIGV.Text = (MonIGV + MonIGVAA + ArtMonIGV).ToString("#,###,###.00");
            txtTotGen.Text = (TotGen + TotGenAA + ArtTotGen).ToString("#,###,###.00");
        }

        private void btnBorItem_Click(object sender, EventArgs e)
        {
            if (fgDet.Row < 1) return;

            bool Encuentra = false;

            while (Encuentra == false)
            {
                Encuentra = true;

                for (int i = 1; i < fgAmbTodos.Rows.Count; i++)
                {
                    if (fgAmbTodos.Rows[i][0].ToString() == fgDet.Rows[fgDet.Row][1].ToString())
                    {
                        fgAmbTodos.RemoveItem(i);
                        Encuentra = false;
                        break;
                    }
                }

                for (int i = 1; i < fgComTodos.Rows.Count; i++)
                {
                    if (fgComTodos.Rows[i][0].ToString() == fgDet.Rows[fgDet.Row][1].ToString())
                    {
                        fgComTodos.RemoveItem(i);
                        Encuentra = false;
                        break;
                    }
                }
            }

            //Eliminamos la linea del grid detalle
            fgDet.RemoveItem(fgDet.Row);            

            NumerarItems();

            VEN_Cot_CalcularTotales();

            btnCanItem.PerformClick();

            ModCon_ArtComSer(false);

            txtDes.Focus();

        }

        private void btnAgrCom_Click(object sender, EventArgs e)
        {

            frmVEN_Cot_SelArtCom f = new frmVEN_Cot_SelArtCom();

            f.fvencont = this;
            f.moneda = Moneda;
            f.tipoventa = txtCodTipVen.Text;
            f.TipoColumna = 2;
            f.Ven_Cot = this;
            f.ShowDialog(this);


            VEN_Cot_ActPreUni();

        }

        private void VEN_Cot_ActPreUni()
        {

            decimal Tot = 0;

            for (int i = 1; i < fgCom.Rows.Count; i++)
            {               
                Tot = Tot + (Convert.ToDecimal(fgCom.Rows[i][2]) * Convert.ToDecimal(fgCom.Rows[i][3]));
            }

            txtPrecio.Text = Math.Round(Tot,2).ToString();
        }

        public void recdat_frmVEN_Cot_ArtCom(string Codigo, string Des, string Can, string ValVen)
        {

            string[] RowDet = new string[] {Codigo, Des, Can, Math.Round(Convert.ToDecimal(ValVen),2).ToString()};
            fgCom.AddItem(RowDet);
        }

        private void btnBorCom_Click(object sender, EventArgs e)
        {
            if (ItemMod == false)
            {
                MessageBox.Show("El Kit debe estar esta de modificación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); return;
            }

            if (fgCom.Row > 0)
            {
                fgCom.RemoveItem(fgCom.Row);
            }

            VEN_Cot_ActPreUni();
        }

        private void btnCanCom_Click(object sender, EventArgs e)
        {

            if (ItemMod == false)
            {
                MessageBox.Show("El Kit debe estar esta de modificación", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); return;
            }

            //if (string.IsNullOrEmpty(Cantidad))
            //{
            //    MessageBox.Show("Ingrese una cantidad valida","SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            decimal Cant = 0;

            //decimal.TryParse(Interaction.InputBox("Ingrese una cantidad valida", "Cambiar cantidad"), out Cant);

            if (Cant <= 0)
            {
                MessageBox.Show("Ingrese una cantidad valida", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (fgCom.Row > 0)
            {
                fgCom.Rows[fgCom.Row][2] = Cant;
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila de componente para actualizar la cantidad", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }            

            VEN_Cot_ActPreUni();

        }

        private void VEN_Cot_ActMonAA()
        {
            Int32 CanAA = 0; decimal PreUniAA = 0;

            Int32.TryParse(txtCanAA.Text, out CanAA);
            decimal.TryParse(txtPreUniAA.Text, out PreUniAA);

            if (CanAA == 0 || PreUniAA == 0)
            {
                txtVenBruAA.Text = ""; txtPorDesAA.Text = "";
                txtDescAA.Text = ""; txtValNetAA.Text = ""; txtIGVAA.Text = ""; txtSubTotAA.Text = "";
                return;
            }
            else
            {
                decimal PorDes = 0;

                decimal.TryParse(txtPorDesAA.Text, out PorDes);

                txtVenBruAA.Text = Math.Round(Convert.ToInt32(txtCanAA.Text) * Convert.ToDecimal(txtPreUniAA.Text)).ToString();
                txtDescAA.Text = Math.Round(Convert.ToInt32(txtCanAA.Text) * Convert.ToDecimal(txtPreUniAA.Text) * PorDes / 100).ToString();
                txtValNetAA.Text = Math.Round(Convert.ToInt32(txtCanAA.Text) * Convert.ToDecimal(txtPreUniAA.Text) * (1 - (PorDes / 100))).ToString();
                txtIGVAA.Text = Math.Round(varglo.ValorIGV * Convert.ToInt32(txtCanAA.Text) * Convert.ToDecimal(txtPreUniAA.Text) * (1 - (PorDes / 100))).ToString();
                txtSubTotAA.Text = Math.Round((varglo.ValorIGV + 1) * Convert.ToInt32(txtCanAA.Text) * Convert.ToDecimal(txtPreUniAA.Text) * (1 - (PorDes / 100))).ToString();
            }
        }

        private void txtCanAA_TextChanged(object sender, EventArgs e)
        {
            Int32 CanAA = 0;

            Int32.TryParse(txtCanAA.Text, out CanAA);

            if (CanAA == 0) txtCanAA.Text = "";

            VEN_Cot_ActMonAA();
        }

        private void txtPreUniAA_TextChanged(object sender, EventArgs e)
        {
            decimal PreUniAA = 0;

            decimal.TryParse(txtPreUniAA.Text, out PreUniAA);

            if (PreUniAA == 0) txtPreUniAA.Text = "";

            VEN_Cot_ActMonAA();
        }

        private void txtPorDesAA_TextChanged(object sender, EventArgs e)
        {
            decimal PorDes = 0;

            decimal.TryParse(txtPorDes.Text, out PorDes);

            if (PorDes == 0) txtPorDes.Text = "";

            VEN_Cot_ActMonAA();
        }

        private void txtDesAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtAmbAA.Focus();             
            }
        }

        private void txtAmbAA_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAmbAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Ambientes (Otros Articulos)", "Filtro_Ambientes", this.txtAmbAA.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtCanAA.Focus();
                }
            }
        }

        private void txtCanAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPreUniAA.Focus();
            }
        }

        private void txtVenBruAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPorDesAA.Focus();
            }
        }

        private void txtPreUniAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtPorDesAA.Focus();
            }
        }

        private void txtPorDesAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtRutIma.Focus();
            }
        }

        private void txtDescAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (e.KeyChar == 13)
            //{
            //    txtValNetAA.Focus();
            //}
        }

        private void txtIGVAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtSubTotAA.Focus();
            }
        }

        private void txtSubTotAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtRutIma.Focus();
            }
        }

        private void txtRutIma_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtRutIma2.Focus();
            }
        }

        private void txtObsAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                btnAgrAA.Focus();
            }
        }

        private void btnAgrAA_Click(object sender, EventArgs e)
        {
            Int32 CanAA = 0;
            decimal PreUniAA = 0;

            Int32.TryParse(txtCanAA.Text, out CanAA);
            decimal.TryParse(txtPreUniAA.Text, out PreUniAA);

            if (CanAA <= 0 || PreUniAA <= 0)
            {
                MessageBox.Show("Cantidad o Precio invalido","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information);
                txtCanAA.Focus(); return;
            }

            //Validamos que el porcentaje de descuento no sea negativo
            decimal PorDesAA = 0;
            decimal.TryParse(txtPorDesAA.Text,out PorDesAA);

            if (PorDesAA < 0)
            {
                MessageBox.Show("El porcentaje de descuento no puede ser negativo.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPorDesAA.Focus();
            }

            if (txtCodAmbAA.Text == "")
            {
                MessageBox.Show("Debe seleccionar un ambiente","SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAmbAA.Focus();
            }

            //No Borrar terminar codigo para el cotizador de Home
            #region           

            //Buscamos en el grid de AA Items Total para saber si ya se agrego los valores.
            //bool EncIte = false;

            //for (int i = 1; i < fgDetArtAAItemTodos.Rows.Count; i++)
            //{
            //    if (Convert.ToInt16(fgDetArtAAItemTodos.Rows[i][0]) == FilaAA)
            //    {
            //        EncIte = true;
            //        break;
            //    }
            //}


            //if (IteAAPre == false && EncIte == false) //
            //{
            //    DialogResult result = MessageBox.Show("¿Desea agregar los codigos de catalogos que componen este Kit?", "SAP Adicional", MessageBoxButtons.YesNo);

            //    if (result == DialogResult.Yes)
            //    {
            //        VEN_Cot_fgAACatIte_Limpiar();

            //        gbIteCat.Visible = true;
            //        fgAACatIte.Focus();

            //        tlsBot.Enabled = false;
            //        tbPri.Enabled = false;

            //        return;

            //    }
            //}
            #endregion

            //IteAAPre = false;

            string RutIma = txtRutIma.Text;
            string RutIma2 = txtRutIma2.Text;
            string RutImaTec = txtRutImaTec.Text;

            if (ItemModAA == false)
            {
                FilaAA = (Int16)(fgDetAA.Rows.Count);
                fgDetAA.Rows.Add();
            }

            fgDetAA.Rows[FilaAA][0] = FilaAA;
            fgDetAA.Rows[FilaAA][1] = txtDesAA.Text;
            fgDetAA.Rows[FilaAA][2] = txtCanAA.Text;
            fgDetAA.Rows[FilaAA][3] = this.txtPreUniAA.Text;
            fgDetAA.Rows[FilaAA][4] = txtVenBruAA.Text;
            fgDetAA.Rows[FilaAA][5] = string.IsNullOrEmpty(txtPorDesAA.Text) ? "0" : txtPorDesAA.Text;
            fgDetAA.Rows[FilaAA][6] = txtDescAA.Text;
            fgDetAA.Rows[FilaAA][7] = txtValNetAA.Text;
            fgDetAA.Rows[FilaAA][8] = txtIGVAA.Text;
            fgDetAA.Rows[FilaAA][9] = txtSubTotAA.Text;
            fgDetAA.Rows[FilaAA][10] = txtCodAmbAA.Text;
            fgDetAA.Rows[FilaAA][11] = txtAmbAA.Text;
            fgDetAA.Rows[FilaAA][12] = txtRutIma.Text;
            fgDetAA.Rows[FilaAA][13] = txtRutIma2.Text;
            fgDetAA.Rows[FilaAA][14] = txtRutImaTec.Text;
            fgDetAA.Rows[FilaAA][15] = txtObsAA.Text;

            btnCanItemAA.PerformClick();

            VEN_Cot_CalcularTotales();

            txtDesAA.Focus();

        }

        public void recdat_frmVEN_Cot_AmbienteAA(string CodAmb, string Amb)
        {
            txtCodAmbAA.Text = CodAmb;
            txtAmbAA.Text = Amb;
        }

        private void txtVenBruAA_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRutIma_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCodArt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Articulo Simple", "VEN_Cot_Art", txtCodArt.Text.Trim(), Moneda, "1", "", "");

                if (varglo.Elegi == true)
                {
                    txtArtCan.Focus();
                }

                if (txtCodArt.Text == "") return;

                if (nvc.VEN_Cot_CodGruArt(txtCodArt.Text) == 124)
                {
                    ModCon_ArtSer(true);
                }
                else
                {
                    ModCon_ArtSer(false);
                }
            }
        }

        public void recdat_frmVEN_Cot_Articulo(string Codigo, string Art, string Precio)
        {
            this.txtCodArt.Text = Codigo;
            this.txtArtDes.Text = Art;
            this.txtArtPrecio.Text = Precio;            
        }

        private void txtArtDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Articulo Simple", "VEN_Cot_Art", txtArtDes.Text.Trim(), Moneda, "0", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    txtArtCan.Focus();
                }
                else
                {
                    return;
                }

                if (txtCodArt.Text == "") return;

                //Limpiamos el grid de ambiente solo si no se esta modificando
                if (ArtItemMod == false)
                {
                    fgArtAmb.Rows.Count = 1;
                }

                if (nvc.VEN_Cot_CodGruArt(txtCodArt.Text) == 124)
                {
                    ModCon_ArtSer(true);
                }
                else
                {
                    ModCon_ArtSer(false);
                }

            }
        }

        private void txtArtCan_TextChanged(object sender, EventArgs e)
        {
            decimal number = 0;
            decimal.TryParse(txtArtCan.Text, out number);

            if (number != 0)
            {
                ActualizarMontosArticulo();
            }
            else
            {
                txtArtCan.Text = "";
                txtArtPorDes.Text = ""; txtArtValNet.Text = "";
                txtArtIGV.Text = ""; txtArtSubTot.Text = "";
            }
        }

        private void txtArtCan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtArtPorDes.Focus();
            }
        }

        private void txtArtPorDes_TextChanged(object sender, EventArgs e)
        {
            decimal number = 0;
            decimal.TryParse(txtArtPorDes.Text, out number);

            if (number >= 0)
            {
                if (number == 0 && txtArtPorDes.Text != "0") txtArtPorDes.Text = "";
                ActualizarMontosArticulo();           
            }
            else
            {
                txtArtPorDes.Text = "";
            }
        }

        private void txtArtPorDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtArtAmb.Focus();
            }
        }

        private void txtArtAmb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Ambientes (Articulo Simple)", "Filtro_Ambientes", this.txtArtAmb.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false; txtArtCanAmb.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_ArtAmb(string CodAmb, string Amb)
        {
            txtArtCodAmb.Text = CodAmb;
            txtArtAmb.Text = Amb;
        }

        private void txtArtCanAmb_TextChanged(object sender, EventArgs e)
        {
            Int32 number = 0;
            Int32.TryParse(txtArtCanAmb.Text, out number);

            if (number == 0) txtArtCanAmb.Text = "";
        }

        private void txtArtCanAmb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                if (txtArtCanAmb.Text == "")
                {
                    MessageBox.Show("Debe agregar una cantidad valida", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                btnArtAgrAmb.Focus();
            }
        }

        private void btnArtAgrAmb_Click(object sender, EventArgs e)
        {
            Int32 CodAmb = 0;

            Int32.TryParse(txtArtCodAmb.Text, out CodAmb);
            //Validamos que se haya seleccionado un ambiente
            if (CodAmb == 0)
            {
                MessageBox.Show("Debe elegir un ambiente", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtArtAmb.Focus();
                return;
            }

            //Para revisar si el ambiente ya fue agregado
            foreach (Row dr in fgArtAmb.Rows)
            {
                if (dr[1] != null)
                {
                    if (String.Compare(txtArtCodAmb.Text, dr[0].ToString()) == 0)
                    {
                        MessageBox.Show("El Ambiente ya fue Seleccionado", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtArtAmb.Focus(); return;
                    }
                }
            }

            int CanAmb = 0;

            Int32.TryParse(txtArtCanAmb.Text, out CanAmb);
            //La cantidad a agregar debe ser mayor a cero
            if (CanAmb < 1)
            {
                MessageBox.Show("Debe ingresar una cantidad entera mayor a cero", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtArtCanAmb.Focus(); return;
            }

            //Agregamos la linea
            string[] rowAmb = new string[]
            {txtArtCodAmb.Text, txtArtAmb.Text, txtArtCanAmb.Text};

            fgArtAmb.AddItem(rowAmb);

            //Limpiamos controles
            txtArtCodAmb.Text = ""; txtArtAmb.Text = ""; txtArtCanAmb.Text = "";

            int TotProAmb = 0;

            for (int i = 1; i < fgArtAmb.Rows.Count; i++)
            {
                TotProAmb = TotProAmb + Convert.ToInt16(fgArtAmb.Rows[i][2]);
            }

            lblArtAmbTot.Text = TotProAmb.ToString();

            //Validamos TotProAmb contra la cantidad del kit
            Int32 Can = 0;

            Int32.TryParse(txtArtCan.Text, out Can);

            if (TotProAmb == Can)
            {
                btnArtAgrItem.Enabled = true; btnArtAgrItem.Focus(); return;
            }
            else
            {
                txtArtAmb.Focus();
            }
        }

        private void btnArtEliAmb_Click(object sender, EventArgs e)
        {
            Int32 TotProAmb = 0;

            if (fgArtAmb.Row > 0)
            {
                fgArtAmb.Rows.Remove(fgArtAmb.Row);
            }

            for (int i = 1; i < fgArtAmb.Rows.Count; i++)
            {
                TotProAmb = TotProAmb + Convert.ToInt32(fgArtAmb.Rows[i][2]);
            }

            lblArtAmbTot.Text = TotProAmb.ToString();
        }

        private void fgAmb_DoubleClick(object sender, EventArgs e)
        {
            if(btnModificar.Enabled == false)
            {
                txtCodAmb.Text = fgAmb.Rows[fgAmb.Row][0].ToString();
                txtAmb.Text = fgAmb.Rows[fgAmb.Row][1].ToString();
                txtCanAmb.Text = fgAmb.Rows[fgAmb.Row][2].ToString();

                btnEliAmb.PerformClick();
                txtCanAmb.Focus();

                Int32 TotProAmb = 0 ;

                for (int i = 1; i < fgAmb.Rows.Count; i++)
                {
                    TotProAmb = TotProAmb + Convert.ToInt32(fgAmb.Rows[i][2]);
                }

                lblAmbTot.Text = TotProAmb.ToString();
            }
        }

        private void fgArtAmb_Click(object sender, EventArgs e)
        {

        }

        private void btnArtAgrItem_Click(object sender, EventArgs e)
        {
            //if (txtCodArt.Text == "")
            //{

            //}

            //Revisamos que el codigo de articulo exista
            if(nc.Validar_CodArt(txtCodArt.Text, varglo.BaseSAP) == false)
            {
                MessageBox.Show("Codigo de artículo incorrecto", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCodArt.Focus(); return;
            }

            decimal PreUni = 0;
            //Valido agreguen un precio
            decimal.TryParse(txtArtPrecio.Text, out PreUni);

            if (PreUni == 0)
            {
                MessageBox.Show("Debe agregar un precio unitario", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtArtPrecio.Focus(); return;
            }

            //-------------------------------------------------------
            int Can = 0;
            //Valido que se ingrese una cantidad
            Int32.TryParse(txtArtCan.Text, out Can);

            if (nvc.VEN_Cot_CodGruArt(txtCodArt.Text) != 124)
            {
                if (Can < 1)
                {
                    MessageBox.Show("Debe ingresar una cantidad entera mayor a cero", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtArtCan.Focus(); return;
                }
            }
            else
            {
                if (Can > 1)
                {
                    MessageBox.Show("La cantidad de un artículo servicio no puede ser mayor a 1", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtArtCan.Focus(); return;
                }
            }

            decimal TotProdAmb = 0;

            //Para comparar la cantidad de items y la suma de la cantidad puesta en los Ambientes
            for (int i = 1; i < fgArtAmb.Rows.Count; i++)
            {
                TotProdAmb = TotProdAmb + Convert.ToDecimal(fgArtAmb.Rows[i][2]);
            }

            if (TotProdAmb != Can)
            {
                MessageBox.Show("El total de articulos por ambiente no coincide con la cantidad total de articulos", "SAP ADICIONAL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtArtCan.Focus(); return;
            }

            //Para revisar si el producto ya fue agregado
            foreach (Row dr in fgArtDet.Rows)
            {
                if (dr[1] != null)
                {
                    if (String.Compare(txtCodArt.Text, dr[1].ToString()) == 0)
                    {
                        MessageBox.Show("El Codigo de Articulo ya fue Seleccionado");
                        txtArtDes.Focus(); return;
                    }
                }
            }

            //Costo
            decimal CosUni = 0;

            CosUni = nvc.VEN_CotDetAS_Cos(txtCodArt.Text, Moneda);

            //Margen %
            decimal Margen = 0;
            Margen = Math.Round(((Convert.ToDecimal(txtArtValNet.Text) - CosUni) / Convert.ToDecimal(txtArtValNet.Text)) * 100, 2);

            //Agregamos la fila al fgDet
            string[] rowDet = new string[]
            {Convert.ToString(fgArtDet.Rows.Count),
                    txtCodArt.Text,
                    txtArtDes.Text,
                    txtArtCan.Text,
                    txtArtPrecio.Text,
                    txtArtVenBru.Text,
                    txtArtPorDes.Text == ""?"0":txtArtPorDes.Text,
                    txtArtDesc.Text == ""? "0" : txtArtDesc.Text,
                    txtArtValNet.Text,
                    txtArtIGV.Text,
                    txtArtSubTot.Text,
                    txtArtObs.Text,
                    CosUni.ToString("#,###.##"),
                    (CosUni * Convert.ToInt32(txtArtCan.Text)).ToString("#,###.##"),
                    Margen.ToString("#,###.##")};

            fgArtDet.AddItem(rowDet);


            //Agregamos la fila del fgAmbTodos          
            foreach (Row row in fgArtAmb.Rows)
            {
                if (row.Index > 0)
                {
                    fgArtAmbTodos.AddItem(new object[] {txtCodArt.Text, row[0], row[1].ToString(), row[2] });
                }
            }
            //Limpiamos el fgArtAmb
            fgArtAmb.Rows.Count = 1;

            btnArtCanItem.PerformClick();

            //
            ArtItemMod = false;
            lblArtInfoItem.Text = "";
            //
            NumerarItems();
            ModCon_ArtSer(false);
            //    '
            VEN_Cot_CalcularTotales();
            //    '
            txtArtDes.Focus();
        }

        private void ModCon_ArtSer(bool Val)
        {
            if (Val == true)
            {

                txtArtCan.Text = "1";
                txtArtCan.BackColor = SystemColors.InactiveCaption;
                txtArtCan.ReadOnly = true;

                txtArtPorDes.Text = "";
                txtArtPorDes.BackColor = SystemColors.InactiveCaption;
                txtArtPorDes.ReadOnly = true;

                txtArtAmb.Text = "";
                txtArtAmb.BackColor = SystemColors.InactiveCaption;
                txtArtAmb.ReadOnly = true;

                txtArtCanAmb.Text = "";
                txtArtCanAmb.BackColor = SystemColors.InactiveCaption;
                txtArtCanAmb.ReadOnly = true;

                if (ArtItemMod == false || nvc.VEN_Cot_CodGruArt(txtCodArt.Text) == 124)
                {
                    txtArtCodAmb.Text = "3126";
                    txtArtAmb.Text = "Servicio";
                    txtArtCanAmb.Text = "1";
                    btnArtAgrAmb.Enabled = true; btnArtAgrAmb.Focus();
                }
            }
            else
            {
                txtArtCan.Text = "";
                txtArtCan.BackColor = SystemColors.Window;
                txtArtCan.ReadOnly = false;

                txtArtPorDes.Text = "";
                txtArtPorDes.BackColor = SystemColors.Window;
                txtArtPorDes.ReadOnly = false;

                txtArtAmb.Text = "";
                txtArtAmb.BackColor = SystemColors.Window;
                txtArtAmb.ReadOnly = false;

                txtArtCanAmb.Text = "";
                txtArtCanAmb.BackColor = SystemColors.Window;
                txtArtCanAmb.ReadOnly = false;

                if (ArtItemMod == false)
                {
                    txtArtCodAmb.Text = "";
                    txtArtAmb.Text = "";
                    txtArtCanAmb.Text = "";
                }

                txtArtCan.Focus();
            }
        }

        private void btnArtCanItem_Click(object sender, EventArgs e)
        {
            fgArtDet.Enabled = true;

            txtCodArt.Text = ""; txtArtDes.Text = ""; txtArtPrecio.Text = ""; txtArtCan.Text = "";
            txtArtVenBru.Text = ""; txtArtPorDes.Text = ""; txtArtDesc.Text = ""; txtArtValNet.Text = ""; txtArtIGV.Text = ""; txtArtSubTot.Text = "";
            txtArtObs.Text = ""; txtArtAmb.Text = ""; txtArtCanAmb.Text = "";

            //'Limpiamos el grid ambientes
            fgArtAmb.Rows.Count = 1;            

            ArtItemMod = false;
            lblInfoItem.Text = "";

            fgArtDet.Enabled = true;
        }

        private void btnArtModItem_Click(object sender, EventArgs e)
        {

            //Pongo la variable itemod en true
            ArtItemMod = true;
            lblArtInfoItem.Text = "MODIFICANDO";

            Int16 Fila = 0;

            Fila = Convert.ToInt16(fgArtDet.Row);

            txtCodArt.Text = fgArtDet.Rows[Fila][1].ToString();
            txtArtDes.Text = fgArtDet.Rows[Fila][2].ToString();

            if (nvc.VEN_Cot_CodGruArt(txtCodArtCom.Text) == 124)
            {
                ModCon_ArtComSer(true);
            }
            else
            {
                ModCon_ArtComSer(false);
            }

            txtArtCan.Text = fgArtDet.Rows[Fila][3].ToString();
            txtArtPrecio.Text = fgArtDet.Rows[Fila][4].ToString();
            txtArtVenBru.Text = fgArtDet.Rows[Fila][5].ToString();
            txtArtPorDes.Text = fgArtDet.Rows[Fila][6].ToString();
            txtArtDesc.Text = fgArtDet.Rows[Fila][7].ToString();
            txtArtValNet.Text = fgArtDet.Rows[Fila][8].ToString();
            txtArtIGV.Text = fgArtDet.Rows[Fila][9].ToString();
            txtArtSubTot.Text = fgArtDet.Rows[Fila][10].ToString();
            txtArtObs.Text = fgArtDet.Rows[Fila][11].ToString();
            
            //    'Retiro el kit de los grid todos (ambiente), 
            bool Encuentra = false;

            while (Encuentra == false)
            {
                Encuentra = true;

                for (int i = 1; i < fgArtAmbTodos.Rows.Count; i++)
                {
                    if (fgArtAmbTodos.Rows[i][0].ToString() == txtCodArt.Text)
                    {
                        fgArtAmbTodos.RemoveItem(i);
                        Encuentra = false;
                        break;
                    }
                }

            }

            //Eliminamos la linea del grid detalle
            fgArtDet.RemoveItem(Fila);
            txtArtDes.Focus();

            fgArtDet.Enabled = false;

            NumerarItems();

            VEN_Cot_CalcularTotales();
        }

        private void btnArtBorItem_Click(object sender, EventArgs e)
        {
            if (fgArtDet.Row < 1) return;

            bool Encuentra = false;

            while (Encuentra == false)
            {
                Encuentra = true;

                for (int i = 1; i < fgArtAmbTodos.Rows.Count; i++)
                {
                    if (fgArtAmbTodos.Rows[i][0].ToString() == fgArtDet.Rows[fgArtDet.Row][1].ToString())
                    {
                        fgArtAmbTodos.RemoveItem(i);
                        Encuentra = false;
                        break;
                    }
                }
            }

            //Eliminamos la linea del grid detalle
            fgArtDet.RemoveItem(fgArtDet.Row);

            VEN_Cot_CalcularTotales();

            NumerarItems();

            btnArtCanItem.PerformClick();

            ModCon_ArtSer(false);

            txtArtDes.Focus();
        }

        private void btnCanItemAA_Click(object sender, EventArgs e)
        {
            fgDetAA.Enabled = true;
            txtDesAA.Text = "";
            txtCanAA.Text = "";
            txtPreUniAA.Text = "";
            txtVenBruAA.Text = "";
            txtPorDesAA.Text = "";
            txtDescAA.Text = "";
            txtValNetAA.Text = "";
            txtIGVAA.Text = "";
            txtSubTotAA.Text = "";
            txtCodAmbAA.Text = "";
            txtAmbAA.Text = "";
            txtRutIma.Text = "";
            txtRutIma2.Text = "";
            txtRutImaTec.Text = "";
            txtObsAA.Text = "";

            FilaAA = 0;
            ItemModAA = false;            

        }

        private void btnModItemAA_Click(object sender, EventArgs e)
        {
            FilaAA = (Int16)fgDetAA.Row;

            txtDesAA.Text = fgDetAA.Rows[FilaAA][1].ToString();
            txtCanAA.Text = fgDetAA.Rows[FilaAA][2].ToString();
            this.txtPreUniAA.Text = fgDetAA.Rows[FilaAA][3].ToString();
            txtVenBruAA.Text = fgDetAA.Rows[FilaAA][4].ToString();
            txtPorDesAA.Text = fgDetAA.Rows[FilaAA][5].ToString();
            txtDescAA.Text = fgDetAA.Rows[FilaAA][6].ToString();
            txtValNetAA.Text = fgDetAA.Rows[FilaAA][7].ToString();
            txtIGVAA.Text = fgDetAA.Rows[FilaAA][8].ToString();
            txtSubTotAA.Text = fgDetAA.Rows[FilaAA][9].ToString();
            txtCodAmbAA.Text = fgDetAA.Rows[FilaAA][10].ToString();
            txtAmbAA.Text = fgDetAA.Rows[FilaAA][11].ToString();
            txtRutIma.Text = fgDetAA.Rows[FilaAA][12].ToString();
            txtRutIma2.Text = fgDetAA.Rows[FilaAA][13].ToString();
            txtRutImaTec.Text = fgDetAA.Rows[FilaAA][14].ToString();
            txtObsAA.Text = fgDetAA.Rows[FilaAA][15].ToString();

            ItemModAA = true;

            btnModItemAA.Enabled = false;
            fgDetAA.Enabled = false;

            txtDesAA.Focus();

        }

        private void fgArtDet_Click(object sender, EventArgs e)
        {   
            
            if (fgArtDet.Rows.Count <= 1) { return; }
                    
            string CodArt = fgArtDet.Rows[fgArtDet.Row][1].ToString();

            fgArtAmb.Rows.Count = 1;            

            //Busco el ambiente en el grid ambientes todos segun el codigo de articulo compuesto y lo recupero en el grid de ambientes
            foreach (Row row in fgArtAmbTodos.Rows)
            {
                if (row.Index > 0)
                {
                    if (row[0].ToString() == CodArt)
                    {
                        fgArtAmb.AddItem(new object[] { row[1], row[2].ToString(), row[3] });
                    }
                }

             }
                       
         }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnGuardar);
        }

        private void txtFalEn_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFalEn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Falla En", "Filtro_Rec_FalEn", this.txtFalEn.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtLinPro.Focus();
                }
            }
        }

        private void txtLinPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Linea Producto/Servicio", "Filtro_Rec_LinProSer", this.txtLinPro.Text.Trim(), txtCodFalEn.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    txtTip.Focus();
                }
            }
        }

        private void txtTip_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Tipo", "Filtro_Rec_Tip", this.txtTip.Text.Trim(), txtCodLinPro.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    txtSubLin.Focus();
                }
            }
        }

        private void txtSubLin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("SubLinea", "Filtro_Rec_SubLin", this.txtSubLin.Text.Trim(), txtCodTip.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    txtFam.Focus();
                }
            }
        }

        private void txtFam_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Familia", "Filtro_Rec_Fam", this.txtFam.Text.Trim(), txtCodSubLin.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    varglo.Elegi = false;
                    txtTipVen.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_FalEn(string CodFalEn, string FalEn)
        {
            txtCodFalEn.Text = CodFalEn;
            txtFalEn.Text = FalEn;
        }

        public void recdat_frmVEN_Cot_LinPro(string CodLinPro, string LinPro)
        {
            txtCodLinPro.Text = CodLinPro;
            txtLinPro.Text = LinPro;
        }

        public void recdat_frmVEN_Cot_Tip(string CodTip, string Tip)
        {
            txtCodTip.Text = CodTip;
            txtTip.Text = Tip;
        }

        public void recdat_frmVEN_Cot_SubLin(string CodSubLin, string SubLin)
        {
            txtCodSubLin.Text = CodSubLin;
            txtSubLin.Text = SubLin;
        }

        public void recdat_frmVEN_Cot_Fam(string CodFam, string Fam)
        {
            txtCodFam.Text = CodFam;
            txtFam.Text = Fam;
        }

        private void txtCenVen_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCodFalEn_TextChanged(object sender, EventArgs e)
        {
            txtCodLinPro.Text = ""; txtLinPro.Text = "";
        }

        private void txtCodLinPro_TextChanged(object sender, EventArgs e)
        {
            txtCodTip.Text = ""; txtTip.Text = "";
        }

        private void txtCodTip_TextChanged(object sender, EventArgs e)
        {
            txtCodSubLin.Text = ""; txtSubLin.Text = "";
        }

        private void txtCodSubLin_TextChanged(object sender, EventArgs e)
        {
            txtCodFam.Text = ""; txtFam.Text = "";
        }

        private void txtCodCenVen_TextChanged(object sender, EventArgs e)
        {
            if (txtCodCenVen.Text == "RECLAM")
            {
                grbInfRec.Visible = true;
                grpFacTipVen.Visible = false;            
            }
            else
            {
                grbInfRec.Visible = false;
                txtCodFalEn.Text = ""; txtFalEn.Text = "";

                grpFacTipVen.Visible = false;
            }

            if (txtCodCenVen.Text == "RECLAM" || txtCodCenVen.Text == "POSVTA")
            {
                grpObs.Visible = true;

                txtRub.Visible = false;
                txtTipObr.Visible = false;
                txtDim.Visible = false;

                txtCodRec.Visible = false;
                txtRec.Visible = false;
            }
            else
            {
                grpObs.Visible = false;

                txtRub.Visible = true;
                txtTipObr.Visible = true;
                txtDim.Visible = true;

                txtCodRec.Visible = true;
                txtRec.Visible = true;
            }

            txtCodTipVen.Text = ""; txtTipVen.Text = "";

        }

        private bool VEN_Cot_ValCosMar()
        {
            bool Val = false;

            for (int i = 1; i < fgDet.Rows.Count; i++)
            {
                //Unicamente revisamos mercaderia no servicios
                if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1 && Convert.ToDecimal(fgDet.Rows[i][8]) <= Convert.ToDecimal(fgDet.Rows[i][14]))
                {
                    MessageBox.Show("El Valor Neto del articulo " + fgDet.Rows[i][2].ToString() + " es menor al costo. Se cancela la operación",
                                    "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Val = true;
                    break;                    
                }
            }

            for (int i = 1; i < fgArtDet.Rows.Count; i++)
            {
                //Unicamente revisamos mercaderia no servicios
                if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1 && Convert.ToDecimal(fgDet.Rows[i][8]) <= Convert.ToDecimal(fgDet.Rows[i][14]))
                {
                    MessageBox.Show("El Valor Neto del articulo " + fgDet.Rows[i][2].ToString() + " es menor al costo. Se cancela la operación",
                                    "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Val = true;
                    break;
                }
            }

            return Val;
        }

        private void txtCliCon_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Contacto Cliente", "Filtro_ClientesContacto", this.txtCliCon.Text.Trim(), txtCodCli.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    txtVen.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_CliCon(string CodCon, string Con)
        {
            txtCodCliCon.Text = CodCon;
            txtCliCon.Text = Con;
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnAbrir);
        }

        private void label76_Click(object sender, EventArgs e)
        {        
        }

        private void txtTipVen_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtNeg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Negocio", "Filtro_Negocio", this.txtNeg.Text.Trim(),"","", "", "");

                if (varglo.Elegi == true)
                {
                    txtEnv.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_Neg(string Cod, string Des)
        {
            txtCodNeg.Text = Cod;
            txtNeg.Text = Des;
        }

        public void recdat_frmVEN_Cot_Env(string Cod, string Des)
        {
            txtCodEnv.Text = Cod;
            txtEnv.Text = Des;
        }

        private void txtEnv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Envio", "Filtro_FormaEnvio", this.txtEnv.Text.Trim(), "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtRutIma.Focus();
                }
            }
        }

        private void btnRuta_Click(object sender, EventArgs e)
        {
            if (ofdRutIma.ShowDialog(this) == DialogResult.OK)
            {
                //Recupera ruta de directorio y archivo 
                txtRutIma.Text = ofdRutIma.InitialDirectory + ofdRutIma.FileName;
            }
        }

        private void btnRutIma2_Click(object sender, EventArgs e)
        {
            if (ofdRutIma.ShowDialog(this) == DialogResult.OK)
            {
                //Recupera ruta de directorio y archivo 
                txtRutIma2.Text = ofdRutIma.InitialDirectory + ofdRutIma.FileName;
            }
        }

        private void btnRutImaTec_Click(object sender, EventArgs e)
        {
            if (ofdRutIma.ShowDialog(this) == DialogResult.OK)
            {
                //Recupera ruta de directorio y archivo 
                txtRutImaTec.Text = ofdRutIma.InitialDirectory + ofdRutIma.FileName;
            }
        }

        public void VEN_Cot_Buscar()
        {
            VEN_Cot_LimpiarTodo();

            DataSet ds = new DataSet();

            ds = nvc.VEN_Cot_rec(NumMov);

            DataTable dtEnc = ds.Tables["Cot_Enc"];

            NumMov = Convert.ToInt64(dtEnc.Rows[0]["NumMov"]);
            txtNum.Text = dtEnc.Rows[0]["NumCot"].ToString();            
            txtFecEmi.Text = Convert.ToDateTime(dtEnc.Rows[0]["FecEmi"]).ToString("dd/MM/yyyy");
            EstDoc = Convert.ToByte(dtEnc.Rows[0]["EstDoc"]);
            txtCodCli.Text = dtEnc.Rows[0]["CardCode"].ToString();
            txtCli.Text = dtEnc.Rows[0]["NomCli"].ToString();
            txtTel.Text = dtEnc.Rows[0]["Telefono"].ToString();
            txtEmail.Text = dtEnc.Rows[0]["Email"].ToString();
            txtDirCli.Text = dtEnc.Rows[0]["DirCli"].ToString();
            txtDirObr.Text = dtEnc.Rows[0]["DirObr"].ToString();
            txtCodTipDoc.Text = dtEnc.Rows[0]["CodTipDoc"].ToString();
            txtCodCliCon.Text = dtEnc.Rows[0]["CodCliCon"].ToString();
            txtCliCon.Text = dtEnc.Rows[0]["CliCon"].ToString();
            txtCodVen.Text = dtEnc.Rows[0]["CodVen"].ToString();
            txtVen.Text = dtEnc.Rows[0]["Ven"].ToString();
            txtCodCenVen.Text = dtEnc.Rows[0]["CodCenVen"].ToString();
            txtCenVen.Text = dtEnc.Rows[0]["CenVen"].ToString();
            txtCodTipVen.Text = dtEnc.Rows[0]["CodTipVen"].ToString();
            txtTipVen.Text = dtEnc.Rows[0]["TipVen"].ToString();
            txtRQ.Text = dtEnc.Rows[0]["u_syp_rq"].ToString();
            txtTipVenRel.Text = dtEnc.Rows[0]["TipVenRel"].ToString();
            txtRub.Text = dtEnc.Rows[0]["Rub"].ToString();
            txtTipObr.Text = dtEnc.Rows[0]["TipObr"].ToString();
            txtDim.Text = dtEnc.Rows[0]["Dim"].ToString();
            txtTie.Text = dtEnc.Rows[0]["Tiempo"].ToString();
            txtPag.Text = dtEnc.Rows[0]["Opcion de Pago"].ToString();
            txtNomCot.Text = dtEnc.Rows[0]["NomCot"].ToString();
            txtCodRec.Text = dtEnc.Rows[0]["CodRec"].ToString();
            txtRec.Text = dtEnc.Rows[0]["Rec"].ToString();
            Moneda = dtEnc.Rows[0]["DocCur"].ToString();
            varglo.TipCam = Convert.ToDecimal(dtEnc.Rows[0]["DocRate"].ToString());
            varglo.ValorIGV = Convert.ToDecimal(dtEnc.Rows[0]["PorIGV"].ToString());
            txtDocEntry.Text = dtEnc.Rows[0]["DocEntrySAP"].ToString();
            txtDocNum.Text = dtEnc.Rows[0]["DocNumSAP"].ToString();
            lblIGVUnit.Text = "IGV " + (Convert.ToDecimal(dtEnc.Rows[0]["PorIGV"]) * 100).ToString("0") + "%:";
            lblIGVTotal.Text = lblIGVUnit.Text;
            lblIGVUnitAA.Text = lblIGVUnit.Text;
            lblArtIGVUnit.Text = lblIGVUnit.Text;
            txtNomAdi.Text = dtEnc.Rows[0]["NomAdi"].ToString();
            Creado = dtEnc.Rows[0]["Creado"].ToString();
            Modificado = dtEnc.Rows[0]["Modificado"].ToString();
            Aprobado = dtEnc.Rows[0]["Aprobado"].ToString();
            Migrado = dtEnc.Rows[0]["Migrado"].ToString();
            txtCodMot.Text = dtEnc.Rows[0]["CodMot"].ToString();
            txtMot.Text = dtEnc.Rows[0]["Motivo"].ToString(); 
             

            if (txtDocNum.Text != "" && txtDocNum.Text != "0")
            {
                grbAdmRQ.Visible = true;
                txtCodAdmRQ.Text = dtEnc.Rows[0]["CodAdmRQ"].ToString();
                txtAdmRQ.Text = dtEnc.Rows[0]["AdmRQ"].ToString();
            }
            else
            {
                grbAdmRQ.Visible = false;
            }

            txtCodFalEn.Text = dtEnc.Rows[0]["CodRecFalEn"].ToString();
            txtFalEn.Text = dtEnc.Rows[0]["RecFalEn"].ToString();
            txtCodLinPro.Text = dtEnc.Rows[0]["CodRecLinPro"].ToString();
            txtLinPro.Text = dtEnc.Rows[0]["RecLinPro"].ToString();
            txtCodTip.Text = dtEnc.Rows[0]["CodRecTip"].ToString();
            txtTip.Text = dtEnc.Rows[0]["RecTip"].ToString();
            txtCodSubLin.Text = dtEnc.Rows[0]["CodRecSubLin"].ToString();
            txtSubLin.Text = dtEnc.Rows[0]["RecSubLin"].ToString();
            txtCodFam.Text = dtEnc.Rows[0]["CodRecFam"].ToString();
            txtFam.Text = dtEnc.Rows[0]["RecFam"].ToString();
            txtObsExt.Text = dtEnc.Rows[0]["SolRecPos"].ToString();

            //Recuperar Detalle
            DataTable dtDet = ds.Tables["Cot_Det"];

            foreach (DataRow dr in dtDet.Rows)
            {

                string[] rowDet = new string[] {fgDet.Rows.Count.ToString(),
                                                dr["CodArtCom"].ToString(),
                                                dr["ArtCom"].ToString(),
                                                Convert.ToDecimal(dr["Can"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["PreUni"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["VenBru"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["PorDes"]).ToString("##0.####"),                                                
                                                Convert.ToDecimal(dr["Desct"]).ToString("#,##0.##"),
                                                Convert.ToDecimal(dr["ValNet"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["IGV"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["SubTot"]).ToString("#,###.##"),
                                                dr["Obs"].ToString(),
                                                dr["Sim"].ToString(),
                                                dr["Costo"].ToString(),
                                                dr["CostoTotal"].ToString(),
                                                dr["Margen"].ToString()};

                fgDet.AddItem(rowDet);

            }

            //Recuperar Ambientes
            DataTable dtAmb = ds.Tables["Cot_DetAmb"];

            foreach (DataRow dr in dtAmb.Rows)
            {

                string[] rowDet = new string[] {dr["CodArtCom"].ToString(),
                                                dr["CodAmb"].ToString(),
                                                dr["Des"].ToString(),
                                                Convert.ToDecimal(dr["Can"]).ToString("#.##")};

                fgAmbTodos.AddItem(rowDet);

            }


            //Recuperar Componentes
            DataTable dtCom = ds.Tables["Cot_DetCom"];

            foreach (DataRow dr in dtCom.Rows)
            {

                string[] rowDet = new string[] {dr["CodArtCom"].ToString(),
                                                dr["CodArt"].ToString(),
                                                dr["Des"].ToString(),
                                                Convert.ToDecimal(dr["Can"]).ToString("#.##"),
                                                Convert.ToDecimal(dr["PreUni"]).ToString("0.##")};

                fgComTodos.AddItem(rowDet);

            }

            //Recuperar Detalle Articulos Alternativos
            DataTable dtDetAA = ds.Tables["Cot_DetAA"];

            foreach (DataRow dr in dtDetAA.Rows)
            {

                string[] rowDet = new string[] {fgDetAA.Rows.Count.ToString(),
                                                dr["DesAA"].ToString(),
                                                Convert.ToDecimal(dr["Can"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["PreUni"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["VenBru"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["PorDes"]).ToString("##0.####"),
                                                Convert.ToDecimal(dr["Desct"]).ToString("#,##0.##"),
                                                Convert.ToDecimal(dr["ValNet"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["IGV"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["SubTot"]).ToString("#,###.##"),
                                                dr["CodAmb"].ToString(),
                                                dr["Amb"].ToString(),
                                                dr["RutIma"].ToString(),
                                                dr["RutIma2"].ToString(),
                                                dr["RutImaTec"].ToString(),
                                                dr["Obs"].ToString(),
                                                dr["CosUni"].ToString(),
                                                dr["CosTot"].ToString(),
                                                dr["Margen"].ToString()};

                fgDetAA.AddItem(rowDet);

            }

            //Recuperar Detalle Articulos simples
            DataTable dtDetAS = ds.Tables["Cot_DetAS"];

            foreach (DataRow dr in dtDetAS.Rows)
            {

                string[] rowDet = new string[] {fgArtDet.Rows.Count.ToString(),
                                                dr["CodArt"].ToString(),
                                                dr["Art"].ToString(),
                                                Convert.ToDecimal(dr["Can"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["PreUni"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["VenBru"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["PorDes"]).ToString("##0.####"),
                                                Convert.ToDecimal(dr["Desct"]).ToString("#,##0.##"),
                                                Convert.ToDecimal(dr["ValNet"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["IGV"]).ToString("#,###.##"),
                                                Convert.ToDecimal(dr["SubTot"]).ToString("#,###.##"),
                                                dr["Obs"].ToString(),
                                                dr["Costo"].ToString(),
                                                dr["CostoTotal"].ToString(),
                                                dr["Margen"].ToString()};

                fgArtDet.AddItem(rowDet);

            }

            //Recuperar Ambientes
            DataTable dtAmbAS = ds.Tables["Cot_DetAmbAS"];

            foreach (DataRow dr in dtAmbAS.Rows)
            {

                string[] rowDet = new string[] {dr["CodArt"].ToString(),
                                                dr["CodAmb"].ToString(),
                                                dr["Des"].ToString(),
                                                dr["Can"].ToString()};

                fgArtAmbTodos.AddItem(rowDet);

            }

            VEN_Cot_CalcularTotales();

            VEN_Cot_EstBot("abrir");

            gpbCubre.Visible = false;

        }

        private void txtRutIma2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtRutImaTec.Focus();
            }
        }

        private void txtRutImaTec_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtObsAA.Focus();
            }
        }

        private void txtLin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Linea", "Filtro_Linea", this.txtLin.Text, "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtSubLinAA.Focus();
                }

            }
        }

        public void recdat_frmVEN_Cot_Lin(string Codigo, string Linea)
        {
            txtCodLin.Text = Codigo;
            txtLin.Text = Linea;
        }

        private void txtSubLinAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("SubLineaAA", "Filtro_SubLinea", this.txtSubLinAA.Text, txtCodLin.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    txtFamAA.Focus();
                }

            }
        }

        public void recdat_frmVEN_Cot_SubLinAA(string Codigo, string SubLinea)
        {
            txtCodSubLinAA.Text = Codigo;
            txtSubLinAA.Text = SubLinea;
        }

        private void txtSubLin_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFamAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("FamiliaAA", "Filtro_Familia", this.txtFamAA.Text, txtCodSubLinAA.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    txtSubFam.Focus();
                }

            }
        }

        public void recdat_frmVEN_Cot_FamAA(string Codigo, string Familia)
        {
            txtCodFamAA.Text = Codigo;
            txtFamAA.Text = Familia;
        }

        private void txtSubFam_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("SubFamilia", "Filtro_SubFamilia", this.txtSubFam.Text, txtCodFamAA.Text, "", "", "");

                if (varglo.Elegi == true)
                {
                    txtMarAA.Focus();
                }

            }
        }

        public void recdat_frmVEN_Cot_SubFam(string Codigo, string SubFamilia)
        {
            txtCodSubFam.Text = Codigo;
            txtSubFam.Text = SubFamilia;
        }

        private void txtMarAA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Marca", "Filtro_Marca", this.txtMarAA.Text, "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtPro.Focus();
                }

            }
        }

        public void recdat_frmVEN_Cot_Marca(string Codigo, string Marca)
        {
            txtCodMarAA.Text = Codigo;
            txtMarAA.Text = Marca;
        }

        private void txtPro_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (e.KeyChar == 13)
            //{
            //    //if (Strings.InStr(varglo.Empresa, "TRAZZO", CompareMethod.Text) != 0)
            //        { ConsultaDatos("Proveedor", "Filtro_Proveedor", this.txtPro.Text, "", "", "", ""); }
            //    else
            //        { ConsultaDatos("ProveedorHome", "Filtro_VEN_Cot_Pro", this.txtPro.Text, "", "", "", ""); }

            //    if (varglo.Elegi == true)
            //    {
            //        if (txtColPro.Visible == true)
            //        {
            //            txtColPro.Focus();
            //        }
            //        else
            //        {
            //            txtMed.Focus();
            //        }
            //    }
            //}
        }

        public void recdat_frmVEN_Cot_Pro(string Codigo, string Proveedor)
        {
            txtCodPro.Text = Codigo;
            txtPro.Text = Proveedor;
        }

        //public void recdat_frmVEN_Cot_ColMue(string Codigo, string Color)
        //{
        //    txtCodColMue.Text = Codigo;
        //    txtColMue.Text = Color;
        //}

        private void txtMatBasMue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                ConsultaDatos("Material Base Mueble", "Filtro_VEN_Cot_MatBasMue", this.txtMatBasMue.Text, "", "", "", "");

                if (varglo.Elegi == true)
                {
                    txtMed.Focus();
                }
            }
        }

        public void recdat_frmVEN_Cot_MatBasMue(string Codigo, string Material)
        {
            txtCodMatBasMue.Text = Codigo;
            txtMatBasMue.Text = Material;
        }

        private void fgDetAA_DoubleClick(object sender, EventArgs e)
        {            
            //if (ItemModAA == false) //Solo permite el doble click si no se esta modificando el item.
            //{
            //    txtTC.Text = nvc.VEN_Cot_RecTipCam().ToString();

            //    gbItmArtComCubre.Visible = true;

            //    txtIteArtComAA.Text = fgDetAA.Rows[fgDetAA.Row][0].ToString();
            //    txtDesArtComAA.Text = fgDetAA.Rows[fgDetAA.Row][1].ToString();
            //    txtCodNegIte.Text = fgDetAA.Rows[fgDetAA.Row][12].ToString();
            //    txtNegIte.Text = fgDetAA.Rows[fgDetAA.Row][13].ToString();

            //    //Recuperamos del total para mostrar en el grid por item con la variable de fila
            //    for (int i = 1; i < fgDetArtAAItemTodos.Rows.Count; i++)
            //    {
            //        if (Convert.ToInt16(fgDetArtAAItemTodos.Rows[i][0]) == Convert.ToInt16(txtIteArtComAA.Text))
            //        {
            //            fgDetArtAAItem.Rows.Add();

            //            Int16 fila = Convert.ToInt16(fgDetArtAAItem.Rows.Count - 1);

            //            for (int j = 2; j < fgDetArtAAItemTodos.Cols.Count - 2; j++)
            //            {
            //                fgDetArtAAItem.Rows[fila][j-2] = fgDetArtAAItemTodos.Rows[i][j]; 
            //            }

            //        }

            //    }
            //}            
        }

        private void btnAgrIteAA_Click(object sender, EventArgs e)
        {
            decimal Valor = 0;

            if (decimal.TryParse(txtTC.Text,out Valor) == false || Valor == 0)
            { MessageBox.Show("No hay tipo de cambio asignado, se la cancela la operacion", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information);  return; }

            if (decimal.TryParse(txtCanAAItem.Text, out Valor) == false || Valor == 0)
            { MessageBox.Show("Valor incorrecto en el campo Can por favor corrijalo", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCanAAItem.Text = ""; return; }

            //if (decimal.TryParse(txtCosAdiNac.Text, out Valor) == false || Valor == 0)
            //{ MessageBox.Show("Valor incorrecto en el campo COST. ADIC. NAC. por favor corrijalo", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtCosAdiNac.Text = ""; return; }

            //if (decimal.TryParse(txtValVen.Text, out Valor) == false || Valor == 0)
            //{ MessageBox.Show("Valor incorrecto en el campo Px / VV. por favor corrijalo", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtValVen.Text = ""; return; }

            //if (decimal.TryParse(txtComRec.Text, out Valor) == false)
            //{ MessageBox.Show("Valor incorrecto en el campo Com. Rec. por favor corrijalo", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtComRec.Text = ""; return; }

            fgDetArtAAItem.Rows.Add();

            Int16 fila = Convert.ToInt16(fgDetArtAAItem.Rows.Count - 1);

            fgDetArtAAItem.Rows[fila][0] = txtCodLin.Text; //CodLin
            fgDetArtAAItem.Rows[fila][1] = txtLin.Text; //Linea
            fgDetArtAAItem.Rows[fila][2] = txtCodSubLinAA.Text; //CodSubLin
            fgDetArtAAItem.Rows[fila][3] = txtSubLinAA.Text; //SubLinea
            fgDetArtAAItem.Rows[fila][4] = txtCodFamAA.Text; //CodFam
            fgDetArtAAItem.Rows[fila][5] = txtFamAA.Text; //Familia
            fgDetArtAAItem.Rows[fila][6] = txtCodSubFam.Text; //CodSubFam
            fgDetArtAAItem.Rows[fila][7] = txtSubFam.Text; //SubFamilia
            fgDetArtAAItem.Rows[fila][8] = txtCodMarAA.Text; //CodMar
            fgDetArtAAItem.Rows[fila][9] = txtMarAA.Text; //Marca
            fgDetArtAAItem.Rows[fila][10] = txtMedAA.Text; //Medidas
            fgDetArtAAItem.Rows[fila][11] = txtCodPro.Text; //CodPro
            fgDetArtAAItem.Rows[fila][12] = txtPro.Text; //Proveedor
            fgDetArtAAItem.Rows[fila][13] = txtColPro.Text; //Color Producto
            fgDetArtAAItem.Rows[fila][14] = txtCodProCat.Text; // Cod Proveedor / Catalogo
            fgDetArtAAItem.Rows[fila][15] = txtCodMatBasMue.Text; //Cod. Mat. de la base del mueble
            fgDetArtAAItem.Rows[fila][16] = txtMatBasMue.Text; //Material de la base del Mueble
            fgDetArtAAItem.Rows[fila][17] = txtMed.Text; //Medidas
            fgDetArtAAItem.Rows[fila][18] = txtCanAAItem.Text; //Can
            fgDetArtAAItem.Rows[fila][19] = txtCosFob.Text; //COST FOB
            fgDetArtAAItem.Rows[fila][20] = txtCosFobUS.Text; //COST FOB US$
            fgDetArtAAItem.Rows[fila][21] = txtCosFobFinUS.Text; //COST FOB Final US$
            fgDetArtAAItem.Rows[fila][22] = txtDesIteAA.Text; //Descripción
            fgDetArtAAItem.Rows[fila][23] = txtPorDesFOB.Text; //%Dscto para FOB
            fgDetArtAAItem.Rows[fila][24] = txtFacImp.Text; //Factor Import
            fgDetArtAAItem.Rows[fila][25] = txtCosInt.Text; //COST. INT.
            fgDetArtAAItem.Rows[fila][26] = txtCosAdiNac.Text; //COST. ADIC. NAC.
            fgDetArtAAItem.Rows[fila][27] = txtCosIntTot.Text; //COST. INTERN. TOTAL
            fgDetArtAAItem.Rows[fila][28] = txtComTotDolFOB.Text; //Compra total dolares FOB
            fgDetArtAAItem.Rows[fila][29] = txtComTotDolInt.Text; //Compra total dolares internado
            fgDetArtAAItem.Rows[fila][30] = txtCalPreVen.Text; //Calculo Px VTA o VV
            fgDetArtAAItem.Rows[fila][31] = txtValVenSinIGV.Text; //VV
            fgDetArtAAItem.Rows[fila][32] = txtValVen.Text; //Px / VV

            decimal ValVen = 0;
            decimal CosIntTot = 0;

            decimal.TryParse(txtValVen.Text, out ValVen);
            decimal.TryParse(txtCosIntTot.Text, out CosIntTot);

            if (ValVen == 0) { fgDetArtAAItem.Rows[fila][33] = "0"; }
            else if (txtCodNegIte.Text == "4" || txtCodNegIte.Text == "3"){ fgDetArtAAItem.Rows[fila][33] = decimal.Round(((ValVen - CosIntTot) / ValVen) * 100).ToString(); }
            else if (txtCodNegIte.Text == "2" || txtCodNegIte.Text == "1") { fgDetArtAAItem.Rows[fila][33] = decimal.Round((((ValVen / (1 + varglo.ValorIGV)) - CosIntTot) / (ValVen / (1 + varglo.ValorIGV))) * 100).ToString(); } //GM (%)

            decimal PorDes = 0;

            decimal.TryParse(txtPorDesAAIte.Text, out PorDes);

            fgDetArtAAItem.Rows[fila][34] = PorDes.ToString(); //Dscto. Cliente
            if (PorDes != 0) { fgDetArtAAItem.Rows[fila][35] = decimal.Round(ValVen * (1 - PorDes / 100), 2).ToString(); } else { fgDetArtAAItem.Rows[fila][35] = ValVen; } //Px / VV CON DSCTO

            if ( Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) == 0) { fgDetArtAAItem.Rows[fila][36] = "0"; }
            else if (txtCodNegIte.Text == "4" || txtCodNegIte.Text == "3")
                { fgDetArtAAItem.Rows[fila][36] = decimal.Round(((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) - CosIntTot) / Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]))  * 100).ToString(); }
            else if (txtCodNegIte.Text == "2" || txtCodNegIte.Text == "1")
                { fgDetArtAAItem.Rows[fila][36] = decimal.Round((((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) / (1 + varglo.ValorIGV)) - CosIntTot) / (Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) / (1 + varglo.ValorIGV))) * 100).ToString(); } //GM Px / VV DSCTO (%)

            decimal ComRec = 0;

            decimal.TryParse(txtComRecAAIte.Text, out ComRec);

            fgDetArtAAItem.Rows[fila][37] = ComRec.ToString(); //Com. Rec.
            fgDetArtAAItem.Rows[fila][38] = decimal.Round(Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) * (1 - ComRec / 100),2).ToString() ; //Px / VV C/RECOM

            if (Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) == 0) { fgDetArtAAItem.Rows[fila][39] = "0"; }
            else if (txtCodNegIte.Text == "4" || txtCodNegIte.Text == "3")
            { fgDetArtAAItem.Rows[fila][39] = decimal.Round(((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) - CosIntTot) / Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38])) * 100).ToString(); }
            else if (txtCodNegIte.Text == "2" || txtCodNegIte.Text == "1")
            { fgDetArtAAItem.Rows[fila][39] = decimal.Round((((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) / (1 + varglo.ValorIGV)) - CosIntTot) / (Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) / (1 + varglo.ValorIGV))) * 100).ToString(); } //GM RECOM (%)


            if (Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) == 0) { fgDetArtAAItem.Rows[fila][39] = "0"; }
            else if (txtCodNegIte.Text == "4" || txtCodNegIte.Text == "3")
            { fgDetArtAAItem.Rows[fila][40] = decimal.Round((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) * Convert.ToDecimal(fgDetArtAAItem.Rows[fila][18])),2).ToString(); }
            else if (txtCodNegIte.Text == "2" || txtCodNegIte.Text == "1")
            { fgDetArtAAItem.Rows[fila][40] = decimal.Round((((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][35]) * Convert.ToDecimal(fgDetArtAAItem.Rows[fila][18]) / (1 + varglo.ValorIGV)))),2).ToString(); } //VV TOTAL VV TOTAL

            if (Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) == 0) { fgDetArtAAItem.Rows[fila][40] = "0"; }
            else if (txtCodNegIte.Text == "4" || txtCodNegIte.Text == "3")
            { fgDetArtAAItem.Rows[fila][41] = decimal.Round((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) * Convert.ToDecimal(fgDetArtAAItem.Rows[fila][18])),2).ToString(); }
            else if (txtCodNegIte.Text == "2" || txtCodNegIte.Text == "1")
            { fgDetArtAAItem.Rows[fila][41] = decimal.Round((((Convert.ToDecimal(fgDetArtAAItem.Rows[fila][38]) * Convert.ToDecimal(fgDetArtAAItem.Rows[fila][18]) / (1 + varglo.ValorIGV)))),2).ToString(); } //VV TOTAL CON DSCTO Y COM. RECOM

            fgDetArtAAItem.Rows[fila][42] = txtObsAAItem.Text; //Item Padre

        }

        private void txtCanAAItem_TextChanged(object sender, EventArgs e)
        {

            decimal Can = 0; 
            decimal CosFobFinUS = 0;
            decimal CosIntTot = 0;

            decimal.TryParse(txtCanAAItem.Text, out Can);
            decimal.TryParse(txtCosFobFinUS.Text, out CosFobFinUS);
            decimal.TryParse(txtCosIntTot.Text, out CosIntTot);

            txtComTotDolFOB.Text = (Can * CosFobFinUS).ToString();
            txtComTotDolInt.Text = (Can * CosIntTot).ToString();
        
        }

        private void txtCanAAItem_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtCosFob_TextChanged(object sender, EventArgs e)
        {
            //try
            //{
                decimal CosFob = 0;

                decimal CosIntTot = 0;
                decimal.TryParse(txtCosIntTot.Text, out CosIntTot);

                //if (Strings.InStr(varglo.Empresa, "HOME", CompareMethod.Text) != 0)
                //{
                //    if (txtCodNegIte.Text == "1") //INDOOR
                //    { txtCalPreVen.Text = decimal.Round((CosIntTot / Convert.ToDecimal(0.6)) * (1 + varglo.ValorIGV)).ToString(); }
                //    else if (txtCodNegIte.Text == "2") //OUTDOOR
                //    { txtCalPreVen.Text = decimal.Round((CosIntTot / Convert.ToDecimal(0.4)) * (1 + varglo.ValorIGV)).ToString(); }
                //    else if (txtCodNegIte.Text == "3") //PROY RESID
                //    { txtCalPreVen.Text = decimal.Round((CosIntTot / Convert.ToDecimal(0.4))).ToString(); }
                //    else if (txtCodNegIte.Text == "4") //PROY CONTRACT
                //    { txtCalPreVen.Text = decimal.Round((CosIntTot / Convert.ToDecimal(0.75))).ToString(); }

                //};

                if (decimal.TryParse(txtCosFob.Text, out CosFob) == false || CosFob == 0) { txtCosFobUS.Text = ""; }

                if (Moneda == "USD")
                { txtCosFobUS.Text = decimal.Round(CosFob * Convert.ToDecimal(txtTC.Text)).ToString(); }
                else
                { txtCosFobUS.Text = CosFob.ToString(); }
            //}
            //catch (Exception ex)
            //{

            //    MessageBox.Show(ex.Message);
            //}
        }

        public void recdat_frmVEN_Cot_ProHom(string Codigo, string Proveedor, string CodMon, string Mon, string PorDesFOB, string FacImp)
        {
            txtCodPro.Text = Codigo;
            txtPro.Text = Proveedor;
            txtPorDesFOB.Text = PorDesFOB;
            txtFacImp.Text = FacImp;
        }

        private void txtCosAdiNac_TextChanged(object sender, EventArgs e)
        {
            decimal CosAdiNac = 0;
            decimal CosInt = 0;

            decimal.TryParse(txtCosAdiNac.Text, out CosAdiNac);
            decimal.TryParse(txtCosInt.Text, out CosInt);

            txtCosIntTot.Text = (CosInt + CosAdiNac).ToString();
        }

        private void txtValVen_TextChanged(object sender, EventArgs e)
        {
            decimal ValVen = 0;

            if (decimal.TryParse(txtValVen.Text, out ValVen) == true)
            {
                if (txtCodNegIte.Text == "1" || txtCodNegIte.Text == "2")
                {
                    txtValVenSinIGV.Text = decimal.Round(ValVen / (1 + varglo.ValorIGV),2).ToString();
                }
                else
                {
                    txtValVenSinIGV.Text = ValVen.ToString();
                }
            }
        }

        private void txtCosFobUS_TextChanged(object sender, EventArgs e)
        {
            decimal CosFobUS = 0;

            if (decimal.TryParse(txtCosFobUS.Text, out CosFobUS) == false || CosFobUS == 0) 
            {
                txtCosFobFinUS.Text = ""; return;
            }

            if (txtPorDesFOB.Text != "")
            {
                txtCosFobFinUS.Text = decimal.Round(CosFobUS * Convert.ToDecimal(txtPorDesFOB.Text)).ToString();
            }

        }

        private void txtCosFobFinUS_TextChanged(object sender, EventArgs e)
        {
            decimal CosFobFinUS = 0;

            if (decimal.TryParse(txtCosFobFinUS.Text, out CosFobFinUS) == false || CosFobFinUS == 0)
            {
                txtCosInt.Text = ""; return;
            }

            txtCosInt.Text = decimal.Ceiling(CosFobFinUS * Convert.ToDecimal(txtFacImp.Text)).ToString();
            txtComTotDolFOB.Text = (Convert.ToDecimal(txtCanAAItem.Text) * CosFobFinUS).ToString();

        }

        private void txtCosInt_TextChanged(object sender, EventArgs e)
        {
            decimal CosInt = 0;
            decimal CosAdiNac = 0;

            decimal.TryParse(txtCosInt.Text, out CosInt);
            decimal.TryParse(txtCosAdiNac.Text, out CosAdiNac);

            txtCosIntTot.Text = (CosInt + CosAdiNac).ToString();

        }

        private void txtCosIntTot_TextChanged(object sender, EventArgs e)
        {

            decimal Can = 0;
            decimal CosIntTot = 0;

            decimal.TryParse(txtCanAAItem.Text, out Can);
            decimal.TryParse(txtCosIntTot.Text, out CosIntTot);

            txtComTotDolInt.Text = (Can * CosIntTot).ToString();

            if (txtCodNegIte.Text == "1") //INDOOR
            {   txtCalPreVen.Text = decimal.Round((CosIntTot / Convert.ToDecimal(0.6)) * (1 + varglo.ValorIGV)).ToString(); }
            else if (txtCodNegIte.Text == "2") //OUTDOOR
            {   txtCalPreVen.Text = decimal.Round((CosIntTot / Convert.ToDecimal(0.4)) * (1 + varglo.ValorIGV)).ToString(); }
            else if (txtCodNegIte.Text == "3") //PROY RESID
            {   txtCalPreVen.Text = decimal.Round(CosIntTot / Convert.ToDecimal(0.4)).ToString(); }
            else if (txtCodNegIte.Text == "4") //PROY CONTRACT
            {   txtCalPreVen.Text = decimal.Round(CosIntTot / Convert.ToDecimal(0.75)).ToString(); }
        }

        private void btnCanAACat_Click(object sender, EventArgs e)
        {
            gbIteCat.Visible = false;

            tlsBot.Enabled = true;
            tbPri.Enabled = true;

            VEN_Cot_fgAACatIte_Limpiar();

            //IteAAPre = true;
            btnAgrAA.PerformClick();
        }

        private void btnAceAACat_Click(object sender, EventArgs e)
        {

            //Verificamos que la columna cantidad tenga datos
            foreach (Row fila in fgAACatIte.Rows)
            {
                if (fila.Index > 0)
                {
                    decimal can = 0;
                    decimal.TryParse(Convert.ToString(fila[1]), out can);

                    if (fila[0].ToString() != "" && can == 0)
                    {
                        MessageBox.Show("Debe agregar una cantidad", "SAP Adicional"); return;
                    }
                }

            }

            //agregamos los valores al grid todos de items de articulos sin stock
            for (int i = 1; i < fgAACatIte.Rows.Count; i++)
            {                
                Int16 Fila = Convert.ToInt16(fgDetArtAAItemTodos.Rows.Count);

                if (Convert.ToString(fgAACatIte.Rows[i][0]) != "")                    
                {
                    fgDetArtAAItemTodos.Rows.Add();
                    fgDetArtAAItemTodos.Rows[Fila][0] = FilaAA;
                    fgDetArtAAItemTodos.Rows[Fila][1] = 0;                   
                    fgDetArtAAItemTodos.Rows[Fila][16] = fgAACatIte.Rows[i][0].ToString(); //Cod Proveedor / Catalogo
                    fgDetArtAAItemTodos.Rows[Fila][20] = fgAACatIte.Rows[i][1].ToString(); //Can
                }
                else
                {
                    break;
                }
            }            

            //IteAAPre = true;

            gbIteCat.Visible = false;

            tlsBot.Enabled = true;
            tbPri.Enabled = true;

            VEN_Cot_fgAACatIte_Limpiar();        

            btnAgrAA.PerformClick();

            //Actualizamos el correlativo por item padre
            AAIteActCorr();

        }

        private void VEN_Cot_fgAACatIte_Limpiar()
        {
            fgAACatIte.Rows.Count = 1;
            fgAACatIte.Rows.Count = 10;

            for (int i = 1; i < fgAACatIte.Rows.Count; i++)
            {
                fgAACatIte.Rows[i][0] = "";
                fgAACatIte.Rows[i][1] = "";
                fgAACatIte.Rows[i][2] = "";
            }

            fgAACatIte.Cols[0].DataType = typeof(string);
            fgAACatIte.Cols[1].DataType = typeof(decimal);
        }

        private void fgAACatIte_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            //Revisa que no se pueda escribir en una flia si la anterior esta vacia       

            if (fgAACatIte.Rows[fgAACatIte.Row - 1][0].ToString() == "")
            {
                e.Handled = true;
            }          

        }

        private void fgAACatIte_AfterEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 0)
            {
                fgAACatIte.Rows[e.Row][0] = fgAACatIte.Rows[e.Row][0].ToString().ToUpper();
            }
        }

        private void fgDetAA_Click(object sender, EventArgs e)
        {
            if (btnModificar.Enabled == true) return;

            btnModItemAA.Enabled = true;           
        }

        private void btnCanAAIte_Click(object sender, EventArgs e)
        {
            foreach (Control x in gbArtAAItem.Controls)
            {
                if (x is TextBox) { x.Text = ""; }
            }

            fgDetArtAAItem.Rows.Count = 1;

            gbItmArtComCubre.Visible = false;
        }

        private void AAIteActCorr()
        {
            Int16 CorItePad = 0;

            //Recorremos toda la lista y actualizamos los valores de correlativo de item
            for (int i = 1; i < fgDetAA.Rows.Count; i++)
            {
                CorItePad = Convert.ToInt16(fgDetAA.Rows[i][0]);
                Int16 CorIteHij = 1;

                for (int j = 1; j < fgDetArtAAItemTodos.Rows.Count; j++)
                {
                    if (Convert.ToInt16(fgDetArtAAItemTodos.Rows[j][0]) == CorItePad) { fgDetArtAAItemTodos.Rows[j][1] = CorIteHij; CorIteHij++; }
                }
                
            }
        }

        private void btnAceAAIte_Click(object sender, EventArgs e)
        {
            //Primero eliminamos todo lo de la lista para volver a agregarlo.
            bool NoEncontro = true;

            while (NoEncontro == true)
            {
                NoEncontro = false;
                for (int i = 1; i < fgDetArtAAItemTodos.Rows.Count; i++)
                {
                    if (Convert.ToInt16(fgDetArtAAItemTodos.Rows[i][0]) == Convert.ToInt16(txtIteArtComAA.Text))
                    {
                        fgDetArtAAItemTodos.RemoveItem(i);
                        NoEncontro = true;
                        break;
                    }
                }
            }

            for (int i = 1; i < fgDetArtAAItem.Rows.Count; i++)
            {
                fgDetArtAAItemTodos.Rows.Add();

                Int16 fila = Convert.ToInt16(fgDetArtAAItemTodos.Rows.Count - 1);

                for (int j = 0; j < fgDetArtAAItem.Cols.Count - 1; j++)
                {
                    fgDetArtAAItemTodos.Rows[fila][0] = txtIteArtComAA.Text;
                    fgDetArtAAItemTodos.Rows[fila][j + 2] = fgDetArtAAItem.Rows[i][j];
                }

            }

            //Actualizo la columna de correlativo para los items
            AAIteActCorr();

            btnCanAAIte.PerformClick();
        }

        private void btnModIteAA_Click(object sender, EventArgs e)
        {
            Int16 fila = Convert.ToInt16(fgDetArtAAItem.Row) ;

            txtCodLin.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][0]);
            txtLin.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][1]);
            txtCodSubLinAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][2]);
            txtSubLinAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][3]);
            txtCodFamAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][4]);
            txtFamAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][5]); //Familia
            txtCodSubFam.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][6]); //CodSubFam
            txtSubFam.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][7]); //SubFamilia
            txtCodMarAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][8]); //CodMar
            txtMarAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][9]); //Marca
            txtMedAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][10]); //Medidas
            txtCodPro.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][11]); //CodPro
            txtPro.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][12]); //Proveedor
            txtColPro.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][13]); //Color Producto
            txtCodProCat.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][14]);// Cod Proveedor / Catalogo
            txtCodMatBasMue.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][15]); //Cod. Mat. de la base del mueble
            txtMatBasMue.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][16]); //Material de la base del Mueble
            txtMed.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][17]); //Medidas
            txtCanAAItem.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][18]); //Can
            txtCosFob.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][19]); //COST FOB
            txtCosFobUS.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][20]); //COST FOB US$
            txtCosFobFinUS.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][21]); //COST FOB Final US$
            txtDesIteAA.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][22]); //Descripción
            txtPorDesFOB.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][23]); //%Dscto para FOB
            txtFacImp.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][24]); //Factor Import
            txtCosInt.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][25]); //COST. INT.
            txtCosAdiNac.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][26]); //COST. ADIC. NAC.
            txtCosIntTot.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][27]); //COST. INTERN. TOTAL
            txtComTotDolFOB.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][28]); //Compra total dolares FOB
            txtComTotDolInt.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][29]); //Compra total dolares internado
            txtCalPreVen.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][30]); //Calculo Px VTA o VV
            txtValVenSinIGV.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][31]);//VV
            txtValVen.Text = Convert.ToString(fgDetArtAAItem.Rows[fila][32]); //Px / VV

            fgDetArtAAItem.RemoveItem(fila);

        }

        private void fgDetAA_Enter(object sender, EventArgs e)
        {
            btnModIteAA.Enabled = true;
        }

        private void fgDetAA_Leave(object sender, EventArgs e)
        {
            btnModIteAA.Enabled = false;
        }

        private void btnExp_Click(object sender, EventArgs e)
        {

            if (btnExp.Text == "&Expandir")
            {
                btnExp.Text = "&Contraer";

                grpObs.Top = 0;
                grpObs.Height = tbpEnc.Height - 50;
                grpObs.Width = tbpEnc.Width - 50;
                grpObs.Left = 0;

                txtObsExt.Top = grpObs.Top + 25;
                txtObsExt.Height = grpObs.Height - 100;
                txtObsExt.Width = grpObs.Width - 50;
                txtObsExt.Left = 20;

                btnExp.Left = (grpObs.Width / 2) - (btnExp.Width / 2);
                btnExp.Top = grpObs.Height - 50;
            }
            else
            {
                btnExp.Text = "&Expandir";

                grpObs.Top = 292;
                grpObs.Height = 130;
                grpObs.Width = 274;
                grpObs.Left = 445;                

                txtObsExt.Top = 17;
                txtObsExt.Height = 79;
                txtObsExt.Width = 252;
                txtObsExt.Left = 9;

                btnExp.Left = 82;
                btnExp.Top = 102;
            }
        }

        private bool VEN_Cot_ValidaTipoVentayOtros(byte Tipo)
        {
            DataTable dt;

            switch (Tipo)
            {
                case 1: //Valida tipo de venta relativo

                    dt = nvc.VEN_Cot_ValTipVenyOtr(Tipo, txtCodTipVen.Text, txtTipVenRel.Text, txtRub.Text, txtTipObr.Text, txtDim.Text);

                    if (dt.Rows.Count != 0 && dt.Rows[0][0].ToString() != "" && txtTipVenRel.Text == "")
                    {
                        MessageBox.Show("Debe elegir un tipo de venta relativo.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtTipVenRel.Focus(); return true;
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("El tipo de venta relativo elegido es incorrecto.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtTipVenRel.Focus(); return true;
                    }

                    break;

                case 2: //Valida Rubro

                    dt = nvc.VEN_Cot_ValTipVenyOtr(Tipo, txtCodTipVen.Text, txtTipVenRel.Text, txtRub.Text, txtTipObr.Text, txtDim.Text);
                    if (dt.Rows.Count != 0 && dt.Rows[0][0].ToString() != "" && txtRub.Text == "")
                    {
                        MessageBox.Show("Debe elegir un rubro.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtRub.Focus(); return true;
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("El rubro elegido es incorrecto.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtRub.Focus(); return true;
                    }

                    break;

                case 3: //Valida Tipo de Obra

                    dt = nvc.VEN_Cot_ValTipVenyOtr(Tipo, txtCodTipVen.Text, txtTipVenRel.Text, txtRub.Text, txtTipObr.Text, txtDim.Text);
                    if (dt.Rows.Count != 0 && dt.Rows[0][0].ToString() != "" && txtTipObr.Text == "")
                    {
                        MessageBox.Show("Debe elegir un tipo de obra.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtTipObr.Focus(); return true;
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("El tipo de obra elegido es incorrecto.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtTipObr.Focus(); return true;
                    }

                    break;

                case 4: //Valida Dimension

                    dt = nvc.VEN_Cot_ValTipVenyOtr(Tipo, txtCodTipVen.Text, txtTipVenRel.Text, txtRub.Text, txtTipObr.Text, txtDim.Text);

                    if (dt.Rows.Count != 0 && dt.Rows[0][0].ToString() != "" && txtDim.Text == "")
                    {
                        MessageBox.Show("Debe elegir una dimension.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtDim.Focus(); return true;
                    }
                    else if (dt.Rows.Count == 0 && dt.Rows[0][0].ToString() != "")
                    {
                        MessageBox.Show("El tipo de dimension elegido es incorrecto.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); txtDim.Focus(); return true;
                    }

                    break;                                                                 
            }

            return false;
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnModificar);
        }

        private void txtCodTipVen_TextChanged(object sender, EventArgs e)
        {
            this.txtTipVenRel.Text = "";
        }

        private void fgDet_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void fgCom_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.Col != 3)
            {
                if (e.KeyChar != 3 && e.KeyChar != 27)
                {
                    e.Handled = true;
                }
            }
        }

        private void fgAmb_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void fgDetAA_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void fgArtDet_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void fgArtAmb_KeyPressEdit(object sender, KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnDeshacer_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnDeshacer);
        }

        private void fgCom_AfterEdit(object sender, RowColEventArgs e)//Aqui validare que el precio no baje del Valor Venta que hay en SAP. 
        {
            //MessageBox.Show(PreMod.ToString());
            //Si no esta habilitada la modificacion no puede modificar el precio de los componentes del kit.
            if (btnModificar.Enabled == true) return;

            //Si estan modificando el kit no permito la modificacion de los componentes.
            if (ItemMod == true) return;

            decimal ValVen = nvc.VEN_Cot_ConPreVen(NumMov,fgCom.Cols[0][e.Row].ToString(), Moneda);
            decimal ValVenNue = 0;

            decimal.TryParse(fgCom.Cols[3][e.Row].ToString(), out ValVenNue);

            if (ValVenNue < ValVen && txtCodCenVen.Text != "DIST_MAY")
            {
                MessageBox.Show("Precio introducido menor al precio venta actual, se cancela la operación","SAP Adicional",MessageBoxButtons.OK,MessageBoxIcon.Information);
                fgCom.Rows[e.Row][3] = PreMod; return;
            }
            else if (ValVenNue < ValVen && txtCodCenVen.Text != "DIST_MAY")
            {
                //CamPreMen = true;
            }

            short numitem = 0;

            //Tambien revisare si existe el articulo en otros kits
            for (int i = 1; i < fgComTodos.Rows.Count; i++)
            {
                if (fgComTodos.Rows[i][1].ToString() == fgCom.Rows[e.Row][0].ToString())
                {
                    numitem = numitem++;
                    if (numitem > 1) return;
                }
            }

            //Solo si la variable NumItem es mayor a 1 preguntara si se quiere modificar los articulos encontrados en otros kits
            if (numitem > 1)
            {
                DialogResult res = MessageBox.Show("El Articulo existe en otros kits los cuales tambien seran modificados. ¿Esta seguro de realizar esta operación?",
                                                "SAP Adicional", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (res == DialogResult.Yes)
                {
                    //Recorro el grid componentes todos buscando el articulo y actualizando el precio
                    for (int i = 1; i < fgComTodos.Rows.Count; i++)
                    {
                        if (fgComTodos.Rows[i][1].ToString() == fgCom.Rows[e.Row][0].ToString())
                        {
                            fgComTodos.Rows[i][4] = fgCom.Rows[e.Row][e.Col];
                        }
                    }            
                }
                else
                {
                    fgCom.Rows[e.Row][3] = PreMod; return;
                }
            }
            else
            {
                for (int i = 1; i < fgComTodos.Rows.Count; i++)
                {
                    if (fgComTodos.Rows[i][1].ToString() == fgCom.Rows[e.Row][0].ToString())
                    {
                        fgComTodos.Rows[i][4] = fgCom.Rows[e.Row][e.Col];
                    }
                }
            }

            //Recorremos ambos grids detalle y componentes todos para actualizar los valores del grid detalle y sacar los totales.
            decimal NuevoPrecio = 0;

            for (int i = 1; i < fgDet.Rows.Count; i++)
            {                
                for (int j = 1; j < fgComTodos.Rows.Count; j++)
                {
                    //Si el codigo de kit es el mismo que en componentes todos va a sumando el valor de los componentes
                    if (fgDet.Rows[i][1].ToString() == fgComTodos.Rows[j][0].ToString())
                    {
                        NuevoPrecio = NuevoPrecio + (Convert.ToDecimal(fgComTodos.Rows[j][3]) * Convert.ToDecimal(fgComTodos.Rows[j][4]));
                    }
                }

                fgDet.Rows[i][4] = NuevoPrecio;
                fgDet.Rows[i][5] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]), 2).ToString("###,##0.00"); //V. Bruta
                fgDet.Rows[i][7] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) *
                                                     Convert.ToDecimal(fgDet.Rows[i][4]) *
                                                     Convert.ToDecimal(fgDet.Rows[i][6]) / 100, 2).ToString("###,##0.00"); //Desct
                fgDet.Rows[i][8] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) *
                                                     Convert.ToDecimal(fgDet.Rows[i][4]) *
                                                     (1 - Convert.ToDecimal(fgDet.Rows[i][6]) / 100), 2).ToString("###,##0.00"); //V.Neto
                fgDet.Rows[i][9] = decimal.Round(varglo.ValorIGV * Convert.ToDecimal(fgDet.Rows[i][3]) *
                                                     Convert.ToDecimal(fgDet.Rows[i][4]) *
                                                     (1 - Convert.ToDecimal(fgDet.Rows[i][6]) / 100), 2).ToString("###,##0.00"); //IGV
                fgDet.Rows[i][10] = decimal.Round((varglo.ValorIGV + 1) * Convert.ToDecimal(fgDet.Rows[i][3]) *
                                                     Convert.ToDecimal(fgDet.Rows[i][4]) *
                                                     (1 - Convert.ToDecimal(fgDet.Rows[i][6]) / 100), 2).ToString("###,##0.00"); //IGV

                NuevoPrecio = 0;

            }

            PreMod = 0;

            VEN_Cot_CalcularTotales();
        }

        private void fgCom_StartEdit(object sender, RowColEventArgs e)
        {
            if (e.Col == 3)
            {
                decimal valven = 0;

                decimal.TryParse(this.fgCom.Rows[e.Row][3].ToString(), out valven);

                PreMod = valven;
            }
        }        

        private void btnBorItemAA_Click(object sender, EventArgs e)
        {
            int Fila = fgDetAA.Row;
            Int16 Id = Convert.ToInt16(fgDetAA.Rows[Fila][0]);

            //Revisamos si tiene componentes, preguntamos y segun la respuesta borramos
            bool encontro = false;

            for (int i = 1; i < fgDetArtAAItemTodos.Rows.Count; i++)
            {
                if (Id == Convert.ToInt16(fgDetArtAAItemTodos.Rows[i][0])) { encontro = true; break; }
            }

            if (encontro == true)
            {
                DialogResult res = MessageBox.Show("¿Este item contiene componenetes, esta seguro que desea eliminarlo?", "SAP Adicional", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (res == DialogResult.No) { return; }
            }

            //Primero eliminamos todo lo de la lista de componentes
            bool NoEncontro = true;

            while (NoEncontro == true)
            {
                NoEncontro = false;
                for (int i = 1; i < fgDetArtAAItemTodos.Rows.Count; i++)
                {
                    if (Convert.ToInt16(fgDetArtAAItemTodos.Rows[i][0]) == Id)
                    {
                        fgDetArtAAItemTodos.RemoveItem(i);
                        NoEncontro = true;
                        break;
                    }
                }
            }

            //Eliminamos la linea seleccionada.
            fgDetAA.RemoveItem(Fila);

            VEN_Cot_CalcularTotales();

            txtDesAA.Focus();
        }

        private void frmVEN_Cot_Activated(object sender, EventArgs e)
        {
        }

        private void fgArtAmb_DoubleClick(object sender, EventArgs e)
        {
            if (fgArtAmb.Rows.Count <= 1) { return; }

            txtArtCodAmb.Text = fgArtAmb.Rows[fgArtAmb.Row][0].ToString();
            txtArtAmb.Text = fgArtAmb.Rows[fgArtAmb.Row][1].ToString();
            txtArtCanAmb.Text = fgArtAmb.Rows[fgArtAmb.Row][2].ToString();

            btnArtEliAmb.PerformClick();
            txtArtCanAmb.Focus();

            Int32 TotProAmb = 0;

            for (int i = 1; i < fgArtAmb.Rows.Count; i++)
            {
                TotProAmb = TotProAmb + Convert.ToInt32(fgArtAmb.Rows[i][2]);
            }

            lblArtAmbTot.Text = TotProAmb.ToString();
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnAprobar);
        }

        private void btnDuplicar_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnDuplicar);
        }

        private void btnMigrarSAP_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnMigrarSAP);
        }

        private void btnOpcImp_Click(object sender, EventArgs e)
        {
            VEN_Cot_Botones(btnOpcImp);
        }

        private void tsmiDesTot_Click(object sender, EventArgs e)
        {
            decimal Desc = 0;

            //decimal.TryParse(Interaction.InputBox("Ingrese una descuento.", "Descuento Total"), out Desc);

            if (Desc < 0 || Desc > 100)
            {
                MessageBox.Show("Debe agregar un valor entre 0 y 100.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            VEN_Cot_AplDesTot(1,Desc);
        }

        private void VEN_Cot_AplDesTot(short Ind, decimal Desc)
        {
            //Primero saco el nivel de descuento que tiene el usuario.
            decimal DescUsu = nvc.VEN_Cot_NivDes(varglo.CodUsuAct);

            if (Ind == 1) //Si el descuento viene desde descuento total
            {                
                if (DescUsu == 100) //Si nivel de descuento es 100% no se valida nada, pueden poner desde 0 a 100
                {
                    for (int i = 1; i < fgDet.Rows.Count; i++)
                    {
                        if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1)
                        {
                            fgDet.Rows[i][6] = Desc;
                            fgDet.Rows[i][7] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * Desc / 100, 2).ToString("###,###.00"); //Desct
                            fgDet.Rows[i][8] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //V. Neto
                            fgDet.Rows[i][9] = decimal.Round(varglo.ValorIGV * Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //IGV
                            fgDet.Rows[i][10] = decimal.Round((varglo.ValorIGV + 1) * Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //SubTotal
                        }
                    }

                }
                else //De lo contrario pasa por validacion
                {
                    if (Desc > 0) //Si el descuento ingresado es mayor a cero se valida el ingreso.
                    {
                        for (int i = 1; i < fgDet.Rows.Count; i++)
                        {
                            decimal DesFin = Desc;                            

                            if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1)
                            {
                                decimal DesKit = nvc.VEN_Cot_NivDesArtCom(Convert.ToInt32(fgDet.Rows[i][1]));

                                if (DesKit < Desc) { DesFin = DesKit; }

                                fgDet.Rows[i][6] = DesFin;
                                fgDet.Rows[i][7] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * DesFin / 100, 2).ToString("###,###.00"); //Desct
                                fgDet.Rows[i][8] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - DesFin / 100), 2).ToString("###,###.00"); //V. Neto
                                fgDet.Rows[i][9] = decimal.Round(varglo.ValorIGV * Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - DesFin / 100), 2).ToString("###,###.00"); //IGV
                                fgDet.Rows[i][10] = decimal.Round((varglo.ValorIGV + 1) * Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - DesFin / 100), 2).ToString("###,###.00"); //SubTotal
                            }
                        }
                    }
                    else
                    {
                        for (int i = 1; i < fgDet.Rows.Count; i++)
                        {
                            if (nvc.VEN_Cot_CodTipArtCom(Convert.ToInt32(fgDet.Rows[i][1])) == 1)
                            {
                                fgDet.Rows[i][6] = Desc;
                                fgDet.Rows[i][7] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * Desc / 100, 2).ToString("###,###.00"); //Desct
                                fgDet.Rows[i][8] = decimal.Round(Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //V. Neto
                                fgDet.Rows[i][9] = decimal.Round(varglo.ValorIGV * Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //IGV
                                fgDet.Rows[i][10] = decimal.Round((varglo.ValorIGV + 1) * Convert.ToDecimal(fgDet.Rows[i][3]) * Convert.ToDecimal(fgDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //SubTotal
                            }
                        }
                    }

                }

                if (Desc > DescUsu)
                {
                    Desc = DescUsu;
                }

                for (int i = 1; i < fgDetAA.Rows.Count; i++)
                {
                    fgDetAA.Rows[i][5] = Desc;
                    fgDetAA.Rows[i][6] = decimal.Round(Convert.ToDecimal(fgDetAA.Rows[i][2]) * Convert.ToDecimal(fgDetAA.Rows[i][3]) * Desc / 100, 2).ToString("###,###.00"); //Desct
                    fgDetAA.Rows[i][7] = decimal.Round(Convert.ToDecimal(fgDetAA.Rows[i][2]) * Convert.ToDecimal(fgDetAA.Rows[i][3]) * (1 - Desc / 100), 2).ToString("###,###.00"); //V. Neto
                    fgDetAA.Rows[i][8] = decimal.Round(varglo.ValorIGV * Convert.ToDecimal(fgDetAA.Rows[i][2]) * Convert.ToDecimal(fgDetAA.Rows[i][3]) * (1 - Desc / 100), 2).ToString("###,###.00"); //IGV
                    fgDetAA.Rows[i][9] = decimal.Round((varglo.ValorIGV + 1) * Convert.ToDecimal(fgDetAA.Rows[i][2]) * Convert.ToDecimal(fgDetAA.Rows[i][3]) * (1 - Desc / 100), 2).ToString("###,###.00"); //SubTotal
                }

                for (int i = 1; i < fgArtDet.Rows.Count; i++)
                {

                    fgArtDet.Rows[i][6] = Desc;
                    fgArtDet.Rows[i][7] = decimal.Round(Convert.ToDecimal(fgArtDet.Rows[i][3]) * Convert.ToDecimal(fgArtDet.Rows[i][4]) * Desc / 100, 2).ToString("###,###.00"); //Desct
                    fgArtDet.Rows[i][8] = decimal.Round(Convert.ToDecimal(fgArtDet.Rows[i][3]) * Convert.ToDecimal(fgArtDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //V. Neto
                    fgArtDet.Rows[i][9] = decimal.Round(varglo.ValorIGV * Convert.ToDecimal(fgArtDet.Rows[i][3]) * Convert.ToDecimal(fgArtDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //IGV
                    fgArtDet.Rows[i][10] = decimal.Round((varglo.ValorIGV + 1) * Convert.ToDecimal(fgArtDet.Rows[i][3]) * Convert.ToDecimal(fgArtDet.Rows[i][4]) * (1 - Desc / 100), 2).ToString("###,###.00"); //SubTotal
                }
            }
            else if (Ind == 2) //Si la forma de modificar el descuento es por item, articulo compuesto con codigo
            {
                if (DescUsu != 100)
                {
                    decimal DesKit = nvc.VEN_Cot_NivDesArtCom(Convert.ToInt32(txtCodArtCom.Text));

                    if (Desc > DesKit)
                    {
                        txtPorDes.Text = DesKit.ToString();
                    }
                }
            }
            else if (Ind == 3) //Si la forma de modificar el descuento es por item, articulos compuesto sin codigo
            {
                if (DescUsu != 100)
                {                   
                    if (Desc > DescUsu)
                    {
                        txtPorDesAA.Text = DescUsu.ToString();
                    }
                }
            }
            else if (Ind == 4) //Si la forma de modificar el descuento es por item, articulos simples
            {
                if (DescUsu != 100)
                {
                    if (Desc > DescUsu)
                    {
                        txtArtPorDes.Text = DescUsu.ToString();
                    }
                }
            }

            VEN_Cot_CalcularTotales();

        }

        private void txtPorDes_Leave(object sender, EventArgs e)
        {
            decimal Desc = 0;
            decimal.TryParse(txtPorDes.Text, out Desc);

            VEN_Cot_AplDesTot(2,Desc);
        }

        private void txtPorDesAA_Leave(object sender, EventArgs e)
        {
            decimal Desc = 0;
            decimal.TryParse(txtPorDesAA.Text, out Desc);

            VEN_Cot_AplDesTot(3, Desc);
        }

        private void txtArtPorDes_Leave(object sender, EventArgs e)
        {
            decimal Desc = 0;
            decimal.TryParse(txtArtPorDes.Text, out Desc);

            VEN_Cot_AplDesTot(4, Desc);
        }

        private void fgCom_Click(object sender, EventArgs e)
        {

        }

        private void txtArtPrecio_DoubleClick(object sender, EventArgs e)
        {
            decimal PreUniAct = 0;
            decimal.TryParse(txtArtPrecio.Text, out PreUniAct);

            decimal PreUniNue = 0;
            //decimal.TryParse(Interaction.InputBox("Ingrese un precio.", "Precio Unitario"), out PreUniNue);

            //Si no es servicio recupero el precio original asi que el codigo debe estar bien digitado
            if ((nvc.VEN_Cot_CodGruArt(txtCodArt.Text) != 124 && nvc.VEN_Cot_CodGruArt(txtCodArt.Text) != 0 && varglo.Empresa.Contains("TRAZZO")) ||
                    (nvc.VEN_Cot_CodGruArt(txtCodArt.Text) != 117 && nvc.VEN_Cot_CodGruArt(txtCodArt.Text) != 0 && varglo.Empresa.Contains("HOME"))) 
            {
                if (PreUniNue < PreUniAct)
                {
                    MessageBox.Show(@"El nuevo precio no puede ser menor al actual. Si desea el precio unitario original recupere el artículo nuevamente.", 
                                    "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                }
                else
                {
                    txtArtPrecio.Text = PreUniNue.ToString();
                }
            }
            else
            {
                MessageBox.Show(@"No se puede establecer si el artículo es del tipo mercadería o servicio. Revise el código seleccionado.",
                                 "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void txtCodArt_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVinRQ_Click(object sender, EventArgs e)
        {
            if (EstDoc == 1 )
            { MessageBox.Show("Esta cotización no esta aprobada, no puede vincular a un RQ existente.", "SAP Adicional",MessageBoxButtons.OK, MessageBoxIcon.Stop); return; }

            if (txtDocEntry.Text != "" && txtDocEntry.Text != "0")
            { MessageBox.Show("Esta cotización ya fue migrada, no puede vincular a un RQ existente.", "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Stop); return; }

            //'Si no esta aprobada
            //If EstDoc = 1 Then MsgBox "Esta cotización no esta aprobada, no puede vincular a un RQ existente.", vbInformation, "Mensaje del sistema": Exit Sub
            //'
            //If val(Me.txtDocEntry) <> 0 Then MsgBox "Esta cotización ya fue migrada, no puede vincular a un RQ existente.", vbInformation, "Mensaje del sistema": Exit Sub
            //'

            ConsultaDatos("Seleccionar RQ", "VEN_Cot_CliRQ", this.txtCodCli.Text.Trim(), "", "1", "", "");

            if (varglo.Elegi == true)
            {
                txtRQ.Focus();
            }

            //With frmAbrir_Doc
            //    If.CodDoc <> 13 Then
            //       Unload frmAbrir_Doc
            //       .CodDoc = 13
            //       .VariableString = Me.txtCodCli.Text
            //        Set.f = Me
            //        .TipoAcc = 0
            //        .Show 1
            //    Else
            //        .CodDoc = 13
            //        .VariableString = Me.txtCodCli.Text
            //        Set.f = Me
            //        .TipoAcc = 0
            //        .Show 1
            //    End If
            //End With
        }

        public void recdat_frmVEN_Cot_RQ(string rq)
        {
            txtRQ.Text = rq;
        }
    }
}
