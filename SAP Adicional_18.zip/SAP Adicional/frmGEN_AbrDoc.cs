﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaNegocio;
using System.Reflection;
using Interfaces;

namespace SAP_Adicional
{
    public partial class frmGEN_AbrDoc : Form
    {
        public Int16 CodDoc;
        public int Rq;
        public Int16 Columna;
        public Int16 colMem;
        NConsultas nc = new NConsultas();
        VarGlo varglo = VarGlo.Instance();
      
        public int SubCod = 0;
        public bool Panel = false;
        public string FecDoc;

        //public Ruta_Item_ListarRq Ruta_Item_ListarRq_Rec { get; set; }

        public frmGEN_AbrDoc()
        {
            InitializeComponent();
            MetGlo.SeleccionTexto(this);
        }
    
        private void frmGEN_AbrDoc_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            DataTable dtRecGen = new DataTable();

            switch (Convert.ToInt64(this.Tag)) //el valor del tag se le da en le otro formulario
            {
                case 4: //Listar RQ

                    dtRecGen = nc.Ruta_Item_ListarRQ(Columna, txtFiltro.Text);

                    if (dtRecGen.Rows.Count > 0) fgAbr.DataSource = dtRecGen;
                    else return;

                    break;
                case 7: //abrir item
                    dtRecGen = nc.Ruta_Item_VisGen(Columna, txtFiltro.Text); //consulta las rutas del boton abrir

                    if (dtRecGen.Rows.Count > 0) fgAbr.DataSource = dtRecGen;
                    else return;

                    break;
                case 8: //abrir inventario
                    dtRecGen = nc.ALM_Inventario_AbrirRec(Columna, txtFiltro.Text);

                    if (dtRecGen.Rows.Count > 0) fgAbr.DataSource = dtRecGen;
                    else return;

                    break;
                case 11:
                    dtRecGen = nc.VEN_Cot_visgen(0, "");

                    if (dtRecGen.Rows.Count > 0) fgAbr.DataSource = dtRecGen;
                    else return;

                    break;
                case 15: //frmLOG_Imp
                    dtRecGen = nc.LOG_Imp_AbrRec(Columna,txtFiltro.Text);

                    if (dtRecGen.Rows.Count > 0) fgAbr.DataSource = dtRecGen;
                    else return;
                   
                    break;
                default:
                    break;
            }

            Cursor.Current = Cursors.Default;
        }
        private void fg_TamañoColumnas()
        {
            switch (Convert.ToInt64(this.Tag))
            {
                case 4:
                    //tamaño
                    fgAbr.Cols["N° RQ"].Width = 70;
                    fgAbr.Cols["Codigo"].Width = 80;
                    fgAbr.Cols["Cliente"].Width = 220;
                    fgAbr.Cols["Nombre de Venta"].Width = 230;
                    fgAbr.Cols["DireccionObra"].Width = 550;
                    fgAbr.Cols["NumORV"].Width = 50;
                    //nombre y visible
                    fgAbr.Cols["Vendedor(a)"].Visible = false;
                    break;

                case 7:
                    //nombre y visible
                    fgAbr.Cols[0].Caption = "Movimiento";
                    fgAbr.Cols["Hora"].Visible = false;

                    //tamaño
                    fgAbr.Cols[0].Width = 70;
                    fgAbr.Cols["NumRQ"].Width = 70;
                    fgAbr.Cols["Cliente"].Width = 150;
                    fgAbr.Cols["Fecha/Ruta"].Width = 70;
                    fgAbr.Cols["Ruta"].Width = 50;
                    break;

                case 8:
                    fgAbr.Cols[0].Width = 80; //numero de movimiento
                    fgAbr.Cols[1].Width = 70; //movimiento 
                    fgAbr.Cols[2].Width = 40; //origen 
                    fgAbr.Cols[3].Width = 50; //destino 
                    fgAbr.Cols[4].Width = 80; //N° Documento 
                    break;

                case 11:
                    fgAbr.Cols[0].Visible = false; //N° Mov
                    fgAbr.Cols[1].Width = 60; //N° Cot            
                    fgAbr.Cols[2].Width = 60; //RQ
                    fgAbr.Cols[3].Width = 70; //Emision
                    fgAbr.Cols[4].Width = 250; //Cliente
                    fgAbr.Cols[5].Width = 300; //Nombre Cotizacion
                    fgAbr.Cols[6].Width = 60; //Moneda
                    fgAbr.Cols[7].Width = 80; //Total
                    fgAbr.Cols[8].Width = 140; //Vendedor(a)
                    fgAbr.Cols[9].Width = 140; //AdmRQ
                    fgAbr.Cols[10].Width = 110; //CentroVenta
                    fgAbr.Cols[11].Width = 100; //TipoVenta                    
                    break;

                case 15: //frmLOG_Imp

                    fgAbr.Cols[0].Width = 60; //N° Num         
                    fgAbr.Cols[1].Width = 60; //N° Imp
                    fgAbr.Cols[2].Width = 300; //Proveedor
                    fgAbr.Cols[3].Width = 60; //ETD
                    fgAbr.Cols[4].Width = 60; //ETA
                    fgAbr.Cols[5].Width = 70; //Forma envio
                    fgAbr.Cols[6].Width = 70; //Estado Pago
                    fgAbr.Cols[7].Width = 80; //Fecha emision
                    fgAbr.Cols[8].Width = 70; //Estado

                    break;

                default:
                    break;
            }

        }

        private void fg_AfterDataRefresh(object sender, ListChangedEventArgs e)
        {
            fg_TamañoColumnas();
        }

        private void fg_BeforeSort(object sender, C1.Win.C1FlexGrid.SortColEventArgs e)
        {
            int Col = e.Col + 1 ;
            Columna = (Int16)Col;
            colMem = Columna;


            this.lblFiltro.Text = fgAbr.Cols[e.Col].Name;
            this.txtFiltro.Focus();
        }
        private void txtFiltro_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (this.lblFiltro.Text == "" && txtFiltro.Text != "" )
            {
                MessageBox.Show("Seleccione una columna", "Mensaje del sistema", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtFiltro.Focus();
                return;
            }

            if (e.KeyChar == 13)
            {                
                try
                {
                    if (txtFiltro.Text == "") Columna = 99;
                    DataTable dtRecGen = new DataTable();


                    switch (Convert.ToInt64(this.Tag))
                    {
                        case 4: //Listar RQ
                            dtRecGen = nc.Ruta_Item_ListarRQ(Columna, txtFiltro.Text);

                            if (dtRecGen.Rows.Count > 0)
                            {
                                fgAbr.DataSource = dtRecGen;
                                Columna = colMem;
                            }
                            else
                                return;

                            break;
                        case 7:
                            dtRecGen = nc.Ruta_Item_VisGen(Columna, txtFiltro.Text); //consulta las rutas del boton abrir

                            if (dtRecGen.Rows.Count > 0)
                            {
                                fgAbr.DataSource = dtRecGen;
                            }
                            else return;

                            break;
                        case 8://inventario
                            dtRecGen = nc.ALM_Inventario_AbrirRec(Columna, txtFiltro.Text); //consulta las rutas del boton abrir

                            if (dtRecGen.Rows.Count > 0)
                            {
                                fgAbr.DataSource = dtRecGen;
                               
                            }
                            else return;

                            break;
                        case 11:
                            dtRecGen  = nc.VEN_Cot_visgen(Columna, txtFiltro.Text);

                            if (dtRecGen.Rows.Count > 0)
                            {
                                fgAbr.DataSource = dtRecGen;
                                Columna = colMem;
                            }
                            else return;

                            break;
                        case 15:
                            dtRecGen = nc.LOG_Imp_AbrRec(Columna, txtFiltro.Text);

                            if (dtRecGen.Rows.Count > 0)
                            {
                                fgAbr.DataSource = dtRecGen; Columna = colMem;
                            }
                            else
                                return;

                            break;

                        default:
                            break;
                    }
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "SAP Adicional", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void fg_DoubleClick(object sender, EventArgs e)
        {
            switch (Convert.ToInt64(this.Tag))
            {
                case 4: //frmRutaItem - Vincular Rq
                    frmRuta_Item frmRutIte = new frmRuta_Item();
                    frmRutIte.pnlRutIte.Visible = true;
                    varglo.RqRutIte = Convert.ToInt32(fgAbr.Rows[fgAbr.Row][0]);
                    break;

                case 7: //BotonAbrir
                    frmRuta_Item frmRutIteNumMov = new frmRuta_Item();
                    frmRutIteNumMov.MdiParent = this.MdiParent;
                    frmRutIteNumMov.NumMov = Convert.ToInt32(fgAbr.Rows[fgAbr.Row][0]);
                    frmRutIteNumMov._estReg = 1;
                    frmRutIteNumMov.Show();
                    break;

                case 11:
                    frmVEN_Cot frmCot = new frmVEN_Cot();
                    frmCot.MdiParent = this.MdiParent;
                    frmCot.NumMov = Convert.ToInt64(fgAbr.Rows[fgAbr.Row][0]);
                    frmCot.Show();                                                                                                
                    break;

                case 15:
                    frmLOG_Imp frmImp = new frmLOG_Imp();
                    frmImp.MdiParent = this.MdiParent;
                    frmImp.NumMov = Convert.ToInt32(fgAbr.Rows[fgAbr.Row][0]);
                    frmImp.Show();
                    break;

                default:
                    break;
            }
            this.Hide();
        }
        private void txtFiltro_GotFocus(object sender, EventArgs e)
        {
            //txtFiltro.SelectAll();
        }

        private void fg_KeyPressEdit(object sender, C1.Win.C1FlexGrid.KeyPressEditEventArgs e)
        {
            if (e.KeyChar != 3 && e.KeyChar != 27)
            {
                e.Handled = true;
            }
        }

        private void btnExp_Click(object sender, EventArgs e)
        {
            MetGlo.ExportarExcel(fgAbr,this.Text);
        }
    }
}
