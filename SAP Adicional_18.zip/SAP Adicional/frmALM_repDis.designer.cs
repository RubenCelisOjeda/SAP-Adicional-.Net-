﻿namespace SAP_Adicional
{
    partial class frmALM_repDis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnMos5 = new System.Windows.Forms.Button();
            this.btnMos4 = new System.Windows.Forms.Button();
            this.btnMos3 = new System.Windows.Forms.Button();
            this.btnMos2 = new System.Windows.Forms.Button();
            this.btnMos1 = new System.Windows.Forms.Button();
            this.dtpSegTipR5_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR4_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR5 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR3_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR4 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR2_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR3 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR1_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR2 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipR1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpSegTipV7_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV6_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV7 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV6 = new System.Windows.Forms.DateTimePicker();
            this.btnMos12 = new System.Windows.Forms.Button();
            this.btnMos11 = new System.Windows.Forms.Button();
            this.btnMos10 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btnMos9 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.btnMos8 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btnMos7 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnMos6 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpSegTipV5_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV1 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV4_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV2 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV5 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV1_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV3_ = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV3 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV4 = new System.Windows.Forms.DateTimePicker();
            this.dtpSegTipV2_ = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMos5);
            this.groupBox1.Controls.Add(this.btnMos4);
            this.groupBox1.Controls.Add(this.btnMos3);
            this.groupBox1.Controls.Add(this.btnMos2);
            this.groupBox1.Controls.Add(this.btnMos1);
            this.groupBox1.Controls.Add(this.dtpSegTipR5_);
            this.groupBox1.Controls.Add(this.dtpSegTipR4_);
            this.groupBox1.Controls.Add(this.dtpSegTipR5);
            this.groupBox1.Controls.Add(this.dtpSegTipR3_);
            this.groupBox1.Controls.Add(this.dtpSegTipR4);
            this.groupBox1.Controls.Add(this.dtpSegTipR2_);
            this.groupBox1.Controls.Add(this.dtpSegTipR3);
            this.groupBox1.Controls.Add(this.dtpSegTipR1_);
            this.groupBox1.Controls.Add(this.dtpSegTipR2);
            this.groupBox1.Controls.Add(this.dtpSegTipR1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(3, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(737, 255);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Según Tipo de Ruta";
            // 
            // btnMos5
            // 
            this.btnMos5.Location = new System.Drawing.Point(434, 210);
            this.btnMos5.Name = "btnMos5";
            this.btnMos5.Size = new System.Drawing.Size(81, 33);
            this.btnMos5.TabIndex = 15;
            this.btnMos5.Text = "Mostrar";
            this.btnMos5.UseVisualStyleBackColor = true;
            this.btnMos5.Click += new System.EventHandler(this.btnMos5_Click);
            // 
            // btnMos4
            // 
            this.btnMos4.Location = new System.Drawing.Point(434, 162);
            this.btnMos4.Name = "btnMos4";
            this.btnMos4.Size = new System.Drawing.Size(81, 33);
            this.btnMos4.TabIndex = 12;
            this.btnMos4.Text = "Mostrar";
            this.btnMos4.UseVisualStyleBackColor = true;
            this.btnMos4.Click += new System.EventHandler(this.btnMos4_Click);
            // 
            // btnMos3
            // 
            this.btnMos3.Location = new System.Drawing.Point(434, 115);
            this.btnMos3.Name = "btnMos3";
            this.btnMos3.Size = new System.Drawing.Size(81, 33);
            this.btnMos3.TabIndex = 9;
            this.btnMos3.Text = "Mostrar";
            this.btnMos3.UseVisualStyleBackColor = true;
            this.btnMos3.Click += new System.EventHandler(this.btnMos3_Click);
            // 
            // btnMos2
            // 
            this.btnMos2.Location = new System.Drawing.Point(434, 67);
            this.btnMos2.Name = "btnMos2";
            this.btnMos2.Size = new System.Drawing.Size(81, 33);
            this.btnMos2.TabIndex = 6;
            this.btnMos2.Text = "Mostrar";
            this.btnMos2.UseVisualStyleBackColor = true;
            this.btnMos2.Click += new System.EventHandler(this.btnMos2_Click);
            // 
            // btnMos1
            // 
            this.btnMos1.Location = new System.Drawing.Point(434, 18);
            this.btnMos1.Name = "btnMos1";
            this.btnMos1.Size = new System.Drawing.Size(81, 33);
            this.btnMos1.TabIndex = 3;
            this.btnMos1.Text = "Mostrar";
            this.btnMos1.UseVisualStyleBackColor = true;
            this.btnMos1.Click += new System.EventHandler(this.btnMos1_Click);
            // 
            // dtpSegTipR5_
            // 
            this.dtpSegTipR5_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR5_.Location = new System.Drawing.Point(287, 218);
            this.dtpSegTipR5_.Name = "dtpSegTipR5_";
            this.dtpSegTipR5_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR5_.TabIndex = 14;
            this.dtpSegTipR5_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR5__KeyPress);
            // 
            // dtpSegTipR4_
            // 
            this.dtpSegTipR4_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR4_.Location = new System.Drawing.Point(287, 171);
            this.dtpSegTipR4_.Name = "dtpSegTipR4_";
            this.dtpSegTipR4_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR4_.TabIndex = 11;
            this.dtpSegTipR4_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR4__KeyPress);
            // 
            // dtpSegTipR5
            // 
            this.dtpSegTipR5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR5.Location = new System.Drawing.Point(167, 218);
            this.dtpSegTipR5.Name = "dtpSegTipR5";
            this.dtpSegTipR5.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR5.TabIndex = 13;
            this.dtpSegTipR5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR5_KeyPress);
            // 
            // dtpSegTipR3_
            // 
            this.dtpSegTipR3_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR3_.Location = new System.Drawing.Point(287, 124);
            this.dtpSegTipR3_.Name = "dtpSegTipR3_";
            this.dtpSegTipR3_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR3_.TabIndex = 8;
            this.dtpSegTipR3_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR3__KeyPress);
            // 
            // dtpSegTipR4
            // 
            this.dtpSegTipR4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR4.Location = new System.Drawing.Point(167, 171);
            this.dtpSegTipR4.Name = "dtpSegTipR4";
            this.dtpSegTipR4.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR4.TabIndex = 10;
            this.dtpSegTipR4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR4_KeyPress);
            // 
            // dtpSegTipR2_
            // 
            this.dtpSegTipR2_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR2_.Location = new System.Drawing.Point(287, 76);
            this.dtpSegTipR2_.Name = "dtpSegTipR2_";
            this.dtpSegTipR2_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR2_.TabIndex = 5;
            this.dtpSegTipR2_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR2__KeyPress);
            // 
            // dtpSegTipR3
            // 
            this.dtpSegTipR3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR3.Location = new System.Drawing.Point(167, 124);
            this.dtpSegTipR3.Name = "dtpSegTipR3";
            this.dtpSegTipR3.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR3.TabIndex = 7;
            this.dtpSegTipR3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR3_KeyPress);
            // 
            // dtpSegTipR1_
            // 
            this.dtpSegTipR1_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR1_.Location = new System.Drawing.Point(287, 28);
            this.dtpSegTipR1_.Name = "dtpSegTipR1_";
            this.dtpSegTipR1_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR1_.TabIndex = 2;
            this.dtpSegTipR1_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR1__KeyPress);
            // 
            // dtpSegTipR2
            // 
            this.dtpSegTipR2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR2.Location = new System.Drawing.Point(167, 76);
            this.dtpSegTipR2.Name = "dtpSegTipR2";
            this.dtpSegTipR2.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR2.TabIndex = 4;
            this.dtpSegTipR2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR2_KeyPress);
            // 
            // dtpSegTipR1
            // 
            this.dtpSegTipR1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipR1.Location = new System.Drawing.Point(167, 28);
            this.dtpSegTipR1.Name = "dtpSegTipR1";
            this.dtpSegTipR1.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipR1.TabIndex = 0;
            this.dtpSegTipR1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipR1_KeyPress);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(23, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Comparativo(TECTOR)";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(23, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Rutas atendidas(TECTOR)";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(23, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Rutas atendidas (Personal trazzo Vs Transportista)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Comparativo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rutas atendidas";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpSegTipV7_);
            this.groupBox2.Controls.Add(this.dtpSegTipV6_);
            this.groupBox2.Controls.Add(this.dtpSegTipV7);
            this.groupBox2.Controls.Add(this.dtpSegTipV6);
            this.groupBox2.Controls.Add(this.btnMos12);
            this.groupBox2.Controls.Add(this.btnMos11);
            this.groupBox2.Controls.Add(this.btnMos10);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnMos9);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.btnMos8);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.btnMos7);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.btnMos6);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.dtpSegTipV5_);
            this.groupBox2.Controls.Add(this.dtpSegTipV1);
            this.groupBox2.Controls.Add(this.dtpSegTipV4_);
            this.groupBox2.Controls.Add(this.dtpSegTipV2);
            this.groupBox2.Controls.Add(this.dtpSegTipV5);
            this.groupBox2.Controls.Add(this.dtpSegTipV1_);
            this.groupBox2.Controls.Add(this.dtpSegTipV3_);
            this.groupBox2.Controls.Add(this.dtpSegTipV3);
            this.groupBox2.Controls.Add(this.dtpSegTipV4);
            this.groupBox2.Controls.Add(this.dtpSegTipV2_);
            this.groupBox2.Location = new System.Drawing.Point(3, 273);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(737, 356);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Según Tipo de Venta";
            // 
            // dtpSegTipV7_
            // 
            this.dtpSegTipV7_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV7_.Location = new System.Drawing.Point(287, 310);
            this.dtpSegTipV7_.Name = "dtpSegTipV7_";
            this.dtpSegTipV7_.Size = new System.Drawing.Size(90, 21);
            this.dtpSegTipV7_.TabIndex = 35;
            this.dtpSegTipV7_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV7__KeyPress);
            // 
            // dtpSegTipV6_
            // 
            this.dtpSegTipV6_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV6_.Location = new System.Drawing.Point(288, 266);
            this.dtpSegTipV6_.Name = "dtpSegTipV6_";
            this.dtpSegTipV6_.Size = new System.Drawing.Size(90, 21);
            this.dtpSegTipV6_.TabIndex = 32;
            this.dtpSegTipV6_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV6__KeyPress);
            // 
            // dtpSegTipV7
            // 
            this.dtpSegTipV7.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV7.Location = new System.Drawing.Point(167, 310);
            this.dtpSegTipV7.Name = "dtpSegTipV7";
            this.dtpSegTipV7.Size = new System.Drawing.Size(90, 21);
            this.dtpSegTipV7.TabIndex = 34;
            this.dtpSegTipV7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV7_KeyPress);
            // 
            // dtpSegTipV6
            // 
            this.dtpSegTipV6.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV6.Location = new System.Drawing.Point(168, 266);
            this.dtpSegTipV6.Name = "dtpSegTipV6";
            this.dtpSegTipV6.Size = new System.Drawing.Size(90, 21);
            this.dtpSegTipV6.TabIndex = 31;
            this.dtpSegTipV6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV6_KeyPress);
            // 
            // btnMos12
            // 
            this.btnMos12.Location = new System.Drawing.Point(434, 302);
            this.btnMos12.Name = "btnMos12";
            this.btnMos12.Size = new System.Drawing.Size(81, 33);
            this.btnMos12.TabIndex = 36;
            this.btnMos12.Text = "Mostrar";
            this.btnMos12.UseVisualStyleBackColor = true;
            this.btnMos12.Click += new System.EventHandler(this.btnMos12_Click);
            // 
            // btnMos11
            // 
            this.btnMos11.Location = new System.Drawing.Point(434, 255);
            this.btnMos11.Name = "btnMos11";
            this.btnMos11.Size = new System.Drawing.Size(81, 33);
            this.btnMos11.TabIndex = 33;
            this.btnMos11.Text = "Mostrar";
            this.btnMos11.UseVisualStyleBackColor = true;
            this.btnMos11.Click += new System.EventHandler(this.btnMos11_Click);
            // 
            // btnMos10
            // 
            this.btnMos10.Location = new System.Drawing.Point(434, 212);
            this.btnMos10.Name = "btnMos10";
            this.btnMos10.Size = new System.Drawing.Size(81, 33);
            this.btnMos10.TabIndex = 30;
            this.btnMos10.Text = "Mostrar";
            this.btnMos10.UseVisualStyleBackColor = true;
            this.btnMos10.Click += new System.EventHandler(this.btnMos10_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Rutas atendidas";
            // 
            // btnMos9
            // 
            this.btnMos9.Location = new System.Drawing.Point(434, 165);
            this.btnMos9.Name = "btnMos9";
            this.btnMos9.Size = new System.Drawing.Size(81, 33);
            this.btnMos9.TabIndex = 27;
            this.btnMos9.Text = "Mostrar";
            this.btnMos9.UseVisualStyleBackColor = true;
            this.btnMos9.Click += new System.EventHandler(this.btnMos9_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Comparativo";
            // 
            // btnMos8
            // 
            this.btnMos8.Location = new System.Drawing.Point(434, 119);
            this.btnMos8.Name = "btnMos8";
            this.btnMos8.Size = new System.Drawing.Size(81, 33);
            this.btnMos8.TabIndex = 24;
            this.btnMos8.Text = "Mostrar";
            this.btnMos8.UseVisualStyleBackColor = true;
            this.btnMos8.Click += new System.EventHandler(this.btnMos8_Click);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(23, 127);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 29);
            this.label8.TabIndex = 0;
            this.label8.Text = "Rutas atendidas (Personal trazzo Vs Transportista)";
            // 
            // btnMos7
            // 
            this.btnMos7.Location = new System.Drawing.Point(434, 73);
            this.btnMos7.Name = "btnMos7";
            this.btnMos7.Size = new System.Drawing.Size(81, 33);
            this.btnMos7.TabIndex = 21;
            this.btnMos7.Text = "Mostrar";
            this.btnMos7.UseVisualStyleBackColor = true;
            this.btnMos7.Click += new System.EventHandler(this.btnMos7_Click);
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(23, 272);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(138, 15);
            this.label12.TabIndex = 0;
            this.label12.Text = "Rutas atendidas(TRAZZO)";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(23, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "Rutas atendidas(TECTOR)";
            // 
            // btnMos6
            // 
            this.btnMos6.Location = new System.Drawing.Point(434, 25);
            this.btnMos6.Name = "btnMos6";
            this.btnMos6.Size = new System.Drawing.Size(81, 33);
            this.btnMos6.TabIndex = 18;
            this.btnMos6.Text = "Mostrar";
            this.btnMos6.UseVisualStyleBackColor = true;
            this.btnMos6.Click += new System.EventHandler(this.btnMos6_Click);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(23, 316);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(138, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "Comparativo(TRAZZO)";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(23, 225);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 15);
            this.label10.TabIndex = 0;
            this.label10.Text = "Comparativo(TECTOR)";
            // 
            // dtpSegTipV5_
            // 
            this.dtpSegTipV5_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV5_.Location = new System.Drawing.Point(287, 219);
            this.dtpSegTipV5_.Name = "dtpSegTipV5_";
            this.dtpSegTipV5_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV5_.TabIndex = 29;
            this.dtpSegTipV5_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV5__KeyPress);
            // 
            // dtpSegTipV1
            // 
            this.dtpSegTipV1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV1.Location = new System.Drawing.Point(167, 36);
            this.dtpSegTipV1.Name = "dtpSegTipV1";
            this.dtpSegTipV1.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV1.TabIndex = 16;
            this.dtpSegTipV1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV1_KeyPress);
            // 
            // dtpSegTipV4_
            // 
            this.dtpSegTipV4_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV4_.Location = new System.Drawing.Point(287, 174);
            this.dtpSegTipV4_.Name = "dtpSegTipV4_";
            this.dtpSegTipV4_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV4_.TabIndex = 26;
            this.dtpSegTipV4_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV4__KeyPress);
            // 
            // dtpSegTipV2
            // 
            this.dtpSegTipV2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV2.Location = new System.Drawing.Point(167, 81);
            this.dtpSegTipV2.Name = "dtpSegTipV2";
            this.dtpSegTipV2.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV2.TabIndex = 19;
            this.dtpSegTipV2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV2_KeyPress);
            // 
            // dtpSegTipV5
            // 
            this.dtpSegTipV5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV5.Location = new System.Drawing.Point(167, 219);
            this.dtpSegTipV5.Name = "dtpSegTipV5";
            this.dtpSegTipV5.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV5.TabIndex = 28;
            this.dtpSegTipV5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV5_KeyPress);
            // 
            // dtpSegTipV1_
            // 
            this.dtpSegTipV1_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV1_.Location = new System.Drawing.Point(287, 36);
            this.dtpSegTipV1_.Name = "dtpSegTipV1_";
            this.dtpSegTipV1_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV1_.TabIndex = 17;
            this.dtpSegTipV1_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV1__KeyPress);
            // 
            // dtpSegTipV3_
            // 
            this.dtpSegTipV3_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV3_.Location = new System.Drawing.Point(287, 129);
            this.dtpSegTipV3_.Name = "dtpSegTipV3_";
            this.dtpSegTipV3_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV3_.TabIndex = 23;
            this.dtpSegTipV3_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV3__KeyPress);
            // 
            // dtpSegTipV3
            // 
            this.dtpSegTipV3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV3.Location = new System.Drawing.Point(167, 129);
            this.dtpSegTipV3.Name = "dtpSegTipV3";
            this.dtpSegTipV3.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV3.TabIndex = 22;
            this.dtpSegTipV3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV3_KeyPress);
            // 
            // dtpSegTipV4
            // 
            this.dtpSegTipV4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV4.Location = new System.Drawing.Point(167, 174);
            this.dtpSegTipV4.Name = "dtpSegTipV4";
            this.dtpSegTipV4.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV4.TabIndex = 25;
            this.dtpSegTipV4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV4_KeyPress);
            // 
            // dtpSegTipV2_
            // 
            this.dtpSegTipV2_.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSegTipV2_.Location = new System.Drawing.Point(287, 81);
            this.dtpSegTipV2_.Name = "dtpSegTipV2_";
            this.dtpSegTipV2_.Size = new System.Drawing.Size(91, 21);
            this.dtpSegTipV2_.TabIndex = 20;
            this.dtpSegTipV2_.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dtpSegTipV2__KeyPress);
            // 
            // frmALM_repDis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 634);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmALM_repDis";
            this.Text = "Reportes de Distribución";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtpSegTipR5_;
        private System.Windows.Forms.DateTimePicker dtpSegTipR4_;
        private System.Windows.Forms.DateTimePicker dtpSegTipR5;
        private System.Windows.Forms.DateTimePicker dtpSegTipR3_;
        private System.Windows.Forms.DateTimePicker dtpSegTipR4;
        private System.Windows.Forms.DateTimePicker dtpSegTipR2_;
        private System.Windows.Forms.DateTimePicker dtpSegTipR3;
        private System.Windows.Forms.DateTimePicker dtpSegTipR1_;
        private System.Windows.Forms.DateTimePicker dtpSegTipR2;
        private System.Windows.Forms.DateTimePicker dtpSegTipR1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMos2;
        private System.Windows.Forms.Button btnMos1;
        private System.Windows.Forms.Button btnMos5;
        private System.Windows.Forms.Button btnMos4;
        private System.Windows.Forms.Button btnMos3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnMos10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnMos9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnMos8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnMos7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnMos6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpSegTipV5_;
        private System.Windows.Forms.DateTimePicker dtpSegTipV1;
        private System.Windows.Forms.DateTimePicker dtpSegTipV4_;
        private System.Windows.Forms.DateTimePicker dtpSegTipV2;
        private System.Windows.Forms.DateTimePicker dtpSegTipV5;
        private System.Windows.Forms.DateTimePicker dtpSegTipV1_;
        private System.Windows.Forms.DateTimePicker dtpSegTipV3_;
        private System.Windows.Forms.DateTimePicker dtpSegTipV3;
        private System.Windows.Forms.DateTimePicker dtpSegTipV4;
        private System.Windows.Forms.DateTimePicker dtpSegTipV2_;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnMos12;
        private System.Windows.Forms.Button btnMos11;
        private System.Windows.Forms.DateTimePicker dtpSegTipV7_;
        private System.Windows.Forms.DateTimePicker dtpSegTipV6_;
        private System.Windows.Forms.DateTimePicker dtpSegTipV7;
        private System.Windows.Forms.DateTimePicker dtpSegTipV6;
    }
}