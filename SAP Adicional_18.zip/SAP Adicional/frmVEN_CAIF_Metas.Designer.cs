﻿namespace SAP_Adicional
{
    partial class frmVEN_CAIF_Metas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMos = new System.Windows.Forms.Button();
            this.cbAño = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.cbTipMet = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMos
            // 
            this.btnMos.Location = new System.Drawing.Point(558, 22);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(124, 21);
            this.btnMos.TabIndex = 1;
            this.btnMos.Text = "Mostrar / Actualizar";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // cbAño
            // 
            this.cbAño.FormattingEnabled = true;
            this.cbAño.Location = new System.Drawing.Point(69, 22);
            this.cbAño.Name = "cbAño";
            this.cbAño.Size = new System.Drawing.Size(96, 21);
            this.cbAño.TabIndex = 3;
            this.cbAño.SelectedIndexChanged += new System.EventHandler(this.cbAño_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Elija año:";
            // 
            // fg
            // 
            this.fg.AllowSorting = C1.Win.C1FlexGrid.AllowSortingEnum.None;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(9, 57);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.Size = new System.Drawing.Size(1268, 607);
            this.fg.TabIndex = 5;
            this.fg.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fg_AfterEdit);
            this.fg.LeaveEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fg_LeaveEdit);
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            this.fg.Click += new System.EventHandler(this.fg_Click);
            // 
            // cbTipMet
            // 
            this.cbTipMet.FormattingEnabled = true;
            this.cbTipMet.Location = new System.Drawing.Point(247, 22);
            this.cbTipMet.Name = "cbTipMet";
            this.cbTipMet.Size = new System.Drawing.Size(305, 21);
            this.cbTipMet.TabIndex = 8;
            this.cbTipMet.SelectedIndexChanged += new System.EventHandler(this.cbTipMet_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Elija el tipo:";
            // 
            // frmVEN_CAIF_Metas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1292, 676);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbTipMet);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbAño);
            this.Controls.Add(this.btnMos);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_CAIF_Metas";
            this.Text = "CAIF - Metas";
            this.Load += new System.EventHandler(this.frmVEN_CAIF_Metas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.ComboBox cbAño;
        private System.Windows.Forms.Label label1;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
        private System.Windows.Forms.ComboBox cbTipMet;
        private System.Windows.Forms.Label label2;
    }
}