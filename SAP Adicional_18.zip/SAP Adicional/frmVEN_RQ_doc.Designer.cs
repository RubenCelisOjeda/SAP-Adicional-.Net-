﻿namespace SAP_Adicional
{
    partial class frmVEN_RQ_Doc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExp = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRQ = new System.Windows.Forms.TextBox();
            this.txtCli = new System.Windows.Forms.TextBox();
            this.btnMost = new System.Windows.Forms.Button();
            this.rdbCon = new System.Windows.Forms.RadioButton();
            this.rdbDet = new System.Windows.Forms.RadioButton();
            this.sfdGuardar = new System.Windows.Forms.SaveFileDialog();
            this.fg = new C1.Win.C1FlexGrid.C1FlexGrid();
            ((System.ComponentModel.ISupportInitialize)(this.fg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExp
            // 
            this.btnExp.Location = new System.Drawing.Point(762, 53);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(101, 20);
            this.btnExp.TabIndex = 5;
            this.btnExp.Text = "Exportar Excel";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Cliente:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "N° RQ:";
            // 
            // txtRQ
            // 
            this.txtRQ.Location = new System.Drawing.Point(95, 27);
            this.txtRQ.Name = "txtRQ";
            this.txtRQ.Size = new System.Drawing.Size(96, 21);
            this.txtRQ.TabIndex = 0;
            this.txtRQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRQ_KeyPress);
            // 
            // txtCli
            // 
            this.txtCli.Location = new System.Drawing.Point(95, 53);
            this.txtCli.Name = "txtCli";
            this.txtCli.Size = new System.Drawing.Size(538, 21);
            this.txtCli.TabIndex = 3;
            this.txtCli.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCli_KeyPress);
            // 
            // btnMost
            // 
            this.btnMost.Location = new System.Drawing.Point(660, 53);
            this.btnMost.Name = "btnMost";
            this.btnMost.Size = new System.Drawing.Size(104, 20);
            this.btnMost.TabIndex = 4;
            this.btnMost.Text = "Mostrar/Actualizar";
            this.btnMost.UseVisualStyleBackColor = true;
            this.btnMost.Click += new System.EventHandler(this.btnMost_Click);
            // 
            // rdbCon
            // 
            this.rdbCon.AutoSize = true;
            this.rdbCon.Checked = true;
            this.rdbCon.Location = new System.Drawing.Point(261, 30);
            this.rdbCon.Name = "rdbCon";
            this.rdbCon.Size = new System.Drawing.Size(83, 17);
            this.rdbCon.TabIndex = 1;
            this.rdbCon.TabStop = true;
            this.rdbCon.Text = "Consolidado";
            this.rdbCon.UseVisualStyleBackColor = true;
            // 
            // rdbDet
            // 
            this.rdbDet.AutoSize = true;
            this.rdbDet.Location = new System.Drawing.Point(355, 30);
            this.rdbDet.Name = "rdbDet";
            this.rdbDet.Size = new System.Drawing.Size(58, 17);
            this.rdbDet.TabIndex = 2;
            this.rdbDet.Text = "Detalle";
            this.rdbDet.UseVisualStyleBackColor = true;
            // 
            // fg
            // 
            this.fg.AllowFiltering = true;
            this.fg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fg.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fg.Location = new System.Drawing.Point(13, 86);
            this.fg.Name = "fg";
            this.fg.Rows.DefaultSize = 19;
            this.fg.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fg.Size = new System.Drawing.Size(978, 436);
            this.fg.TabIndex = 6;
            this.fg.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fg_KeyPressEdit);
            this.fg.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fg_AfterDataRefresh);
            // 
            // frmVEN_RQ_Doc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 534);
            this.Controls.Add(this.fg);
            this.Controls.Add(this.rdbDet);
            this.Controls.Add(this.rdbCon);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRQ);
            this.Controls.Add(this.txtCli);
            this.Controls.Add(this.btnMost);
            this.Controls.Add(this.btnExp);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmVEN_RQ_Doc";
            this.Text = "Documentos de RQ";
            this.Load += new System.EventHandler(this.frmVEN_RQ_doc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRQ;
        private System.Windows.Forms.TextBox txtCli;
        private System.Windows.Forms.Button btnMost;
        private System.Windows.Forms.RadioButton rdbCon;
        private System.Windows.Forms.RadioButton rdbDet;
        private System.Windows.Forms.SaveFileDialog sfdGuardar;
        private C1.Win.C1FlexGrid.C1FlexGrid fg;
    }
}