﻿namespace SAP_Adicional
{
    partial class frmMan_ArticuloCompuesto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMan_ArticuloCompuesto));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.fgMae = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.gpbBtnMae = new System.Windows.Forms.GroupBox();
            this.btnRutImgApl = new System.Windows.Forms.Button();
            this.btnLimRut = new System.Windows.Forms.Button();
            this.btnRutImgCot = new System.Windows.Forms.Button();
            this.btnExp = new System.Windows.Forms.Button();
            this.gpbBot = new System.Windows.Forms.GroupBox();
            this.btnPri = new System.Windows.Forms.Button();
            this.btnUlt = new System.Windows.Forms.Button();
            this.btnAva = new System.Windows.Forms.Button();
            this.btnRet = new System.Windows.Forms.Button();
            this.chkInac = new System.Windows.Forms.CheckBox();
            this.chkPri = new System.Windows.Forms.CheckBox();
            this.txtCodTipArt = new System.Windows.Forms.TextBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.txtDes = new System.Windows.Forms.TextBox();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCer = new System.Windows.Forms.Button();
            this.btnDeshacer = new System.Windows.Forms.Button();
            this.btnBor = new System.Windows.Forms.Button();
            this.btnGua = new System.Windows.Forms.Button();
            this.btnNue = new System.Windows.Forms.Button();
            this.btnMod = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.fgCom = new C1.Win.C1FlexGrid.C1FlexGrid();
            this.gpbCom = new System.Windows.Forms.GroupBox();
            this.txtDescon = new System.Windows.Forms.TextBox();
            this.txtMon = new System.Windows.Forms.TextBox();
            this.txtPre = new System.Windows.Forms.TextBox();
            this.btnCanCom = new System.Windows.Forms.Button();
            this.btnEliCom = new System.Windows.Forms.Button();
            this.btnModCom = new System.Windows.Forms.Button();
            this.btnAgr = new System.Windows.Forms.Button();
            this.txtCat = new System.Windows.Forms.TextBox();
            this.txtDesArt = new System.Windows.Forms.TextBox();
            this.txtCan = new System.Windows.Forms.TextBox();
            this.txtCodArt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTipoArt = new System.Windows.Forms.TextBox();
            this.tabMae = new System.Windows.Forms.TabControl();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgMae)).BeginInit();
            this.gpbBtnMae.SuspendLayout();
            this.gpbBot.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCom)).BeginInit();
            this.gpbCom.SuspendLayout();
            this.tabMae.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.fgMae);
            this.tabPage2.Controls.Add(this.gpbBtnMae);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1141, 641);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Maestro";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // fgMae
            // 
            this.fgMae.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fgMae.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgMae.Location = new System.Drawing.Point(-1, 6);
            this.fgMae.Name = "fgMae";
            this.fgMae.Rows.DefaultSize = 19;
            this.fgMae.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgMae.Size = new System.Drawing.Size(1129, 569);
            this.fgMae.TabIndex = 0;
            this.fgMae.StartEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgMae_StartEdit);
            this.fgMae.AfterEdit += new C1.Win.C1FlexGrid.RowColEventHandler(this.fgMae_AfterEdit);
            this.fgMae.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgMae_KeyPressEdit);
            this.fgMae.AfterDataRefresh += new System.ComponentModel.ListChangedEventHandler(this.fgMae_AfterDataRefresh);
            this.fgMae.DoubleClick += new System.EventHandler(this.fgMae_DoubleClick);
            // 
            // gpbBtnMae
            // 
            this.gpbBtnMae.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gpbBtnMae.Controls.Add(this.btnRutImgApl);
            this.gpbBtnMae.Controls.Add(this.btnLimRut);
            this.gpbBtnMae.Controls.Add(this.btnRutImgCot);
            this.gpbBtnMae.Controls.Add(this.btnExp);
            this.gpbBtnMae.Location = new System.Drawing.Point(379, 580);
            this.gpbBtnMae.Name = "gpbBtnMae";
            this.gpbBtnMae.Size = new System.Drawing.Size(491, 44);
            this.gpbBtnMae.TabIndex = 1;
            this.gpbBtnMae.TabStop = false;
            // 
            // btnRutImgApl
            // 
            this.btnRutImgApl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnRutImgApl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRutImgApl.Location = new System.Drawing.Point(323, 13);
            this.btnRutImgApl.Name = "btnRutImgApl";
            this.btnRutImgApl.Size = new System.Drawing.Size(148, 23);
            this.btnRutImgApl.TabIndex = 5;
            this.btnRutImgApl.Text = "Ruta Imagen - Aplicación\r\n";
            this.btnRutImgApl.UseVisualStyleBackColor = true;
            this.btnRutImgApl.Click += new System.EventHandler(this.btnRutImgApl_Click);
            // 
            // btnLimRut
            // 
            this.btnLimRut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLimRut.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLimRut.Location = new System.Drawing.Point(236, 13);
            this.btnLimRut.Name = "btnLimRut";
            this.btnLimRut.Size = new System.Drawing.Size(91, 23);
            this.btnLimRut.TabIndex = 4;
            this.btnLimRut.Text = "Limpiar Ruta";
            this.btnLimRut.UseVisualStyleBackColor = true;
            this.btnLimRut.Click += new System.EventHandler(this.btnLimRut_Click);
            // 
            // btnRutImgCot
            // 
            this.btnRutImgCot.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnRutImgCot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRutImgCot.Location = new System.Drawing.Point(99, 13);
            this.btnRutImgCot.Name = "btnRutImgCot";
            this.btnRutImgCot.Size = new System.Drawing.Size(139, 23);
            this.btnRutImgCot.TabIndex = 3;
            this.btnRutImgCot.Text = "Ruta Imagen - Cotización";
            this.btnRutImgCot.UseVisualStyleBackColor = true;
            this.btnRutImgCot.Click += new System.EventHandler(this.btnRutImgCot_Click);
            // 
            // btnExp
            // 
            this.btnExp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExp.Location = new System.Drawing.Point(19, 13);
            this.btnExp.Name = "btnExp";
            this.btnExp.Size = new System.Drawing.Size(81, 23);
            this.btnExp.TabIndex = 2;
            this.btnExp.Text = "&Exportar";
            this.btnExp.UseVisualStyleBackColor = true;
            this.btnExp.Click += new System.EventHandler(this.btnExp_Click);
            // 
            // gpbBot
            // 
            this.gpbBot.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.gpbBot.Controls.Add(this.btnPri);
            this.gpbBot.Controls.Add(this.btnUlt);
            this.gpbBot.Controls.Add(this.btnAva);
            this.gpbBot.Controls.Add(this.btnRet);
            this.gpbBot.Location = new System.Drawing.Point(295, 523);
            this.gpbBot.Name = "gpbBot";
            this.gpbBot.Size = new System.Drawing.Size(322, 72);
            this.gpbBot.TabIndex = 26;
            this.gpbBot.TabStop = false;
            // 
            // btnPri
            // 
            this.btnPri.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPri.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPri.Image = ((System.Drawing.Image)(resources.GetObject("btnPri.Image")));
            this.btnPri.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPri.Location = new System.Drawing.Point(22, 15);
            this.btnPri.Name = "btnPri";
            this.btnPri.Size = new System.Drawing.Size(71, 49);
            this.btnPri.TabIndex = 27;
            this.btnPri.Tag = "0";
            this.btnPri.Text = "Primero";
            this.btnPri.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPri.UseVisualStyleBackColor = true;
            this.btnPri.Click += new System.EventHandler(this.btnPri_Click);
            // 
            // btnUlt
            // 
            this.btnUlt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUlt.Image = ((System.Drawing.Image)(resources.GetObject("btnUlt.Image")));
            this.btnUlt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUlt.Location = new System.Drawing.Point(230, 15);
            this.btnUlt.Name = "btnUlt";
            this.btnUlt.Size = new System.Drawing.Size(71, 49);
            this.btnUlt.TabIndex = 30;
            this.btnUlt.Tag = "3";
            this.btnUlt.Text = "Ultimo";
            this.btnUlt.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnUlt.UseVisualStyleBackColor = true;
            this.btnUlt.Click += new System.EventHandler(this.btnUlt_Click);
            // 
            // btnAva
            // 
            this.btnAva.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAva.Image = ((System.Drawing.Image)(resources.GetObject("btnAva.Image")));
            this.btnAva.Location = new System.Drawing.Point(160, 15);
            this.btnAva.Name = "btnAva";
            this.btnAva.Size = new System.Drawing.Size(71, 49);
            this.btnAva.TabIndex = 29;
            this.btnAva.Tag = "2";
            this.btnAva.Text = "Avanzar";
            this.btnAva.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAva.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAva.UseVisualStyleBackColor = true;
            this.btnAva.Click += new System.EventHandler(this.btnAva_Click);
            // 
            // btnRet
            // 
            this.btnRet.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRet.Image = ((System.Drawing.Image)(resources.GetObject("btnRet.Image")));
            this.btnRet.Location = new System.Drawing.Point(91, 15);
            this.btnRet.Name = "btnRet";
            this.btnRet.Size = new System.Drawing.Size(71, 49);
            this.btnRet.TabIndex = 28;
            this.btnRet.Tag = "1";
            this.btnRet.Text = "Retroceder";
            this.btnRet.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRet.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnRet.UseVisualStyleBackColor = true;
            this.btnRet.Click += new System.EventHandler(this.btnRet_Click);
            // 
            // chkInac
            // 
            this.chkInac.AutoSize = true;
            this.chkInac.Enabled = false;
            this.chkInac.Location = new System.Drawing.Point(693, 159);
            this.chkInac.Name = "chkInac";
            this.chkInac.Size = new System.Drawing.Size(65, 17);
            this.chkInac.TabIndex = 12;
            this.chkInac.Text = "Inactivo";
            this.chkInac.UseVisualStyleBackColor = true;
            // 
            // chkPri
            // 
            this.chkPri.AutoSize = true;
            this.chkPri.Location = new System.Drawing.Point(193, 68);
            this.chkPri.Name = "chkPri";
            this.chkPri.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkPri.Size = new System.Drawing.Size(65, 17);
            this.chkPri.TabIndex = 21;
            this.chkPri.Text = "Principal";
            this.chkPri.UseVisualStyleBackColor = true;
            // 
            // txtCodTipArt
            // 
            this.txtCodTipArt.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCodTipArt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodTipArt.ForeColor = System.Drawing.Color.Blue;
            this.txtCodTipArt.Location = new System.Drawing.Point(272, 150);
            this.txtCodTipArt.Name = "txtCodTipArt";
            this.txtCodTipArt.Size = new System.Drawing.Size(64, 21);
            this.txtCodTipArt.TabIndex = 10;
            this.txtCodTipArt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtObs
            // 
            this.txtObs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtObs.ForeColor = System.Drawing.Color.Blue;
            this.txtObs.Location = new System.Drawing.Point(272, 116);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(524, 30);
            this.txtObs.TabIndex = 9;
            this.txtObs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtObs_KeyPress);
            // 
            // txtDes
            // 
            this.txtDes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDes.ForeColor = System.Drawing.Color.Blue;
            this.txtDes.Location = new System.Drawing.Point(272, 83);
            this.txtDes.Multiline = true;
            this.txtDes.Name = "txtDes";
            this.txtDes.Size = new System.Drawing.Size(524, 30);
            this.txtDes.TabIndex = 8;
            this.txtDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDes_KeyPress);
            // 
            // txtCod
            // 
            this.txtCod.BackColor = System.Drawing.Color.PaleTurquoise;
            this.txtCod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCod.ForeColor = System.Drawing.Color.Blue;
            this.txtCod.Location = new System.Drawing.Point(272, 60);
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(64, 21);
            this.txtCod.TabIndex = 7;
            this.txtCod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCod.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCod_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(235, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tipo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(237, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Obs:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(222, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(226, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Codigo:";
            // 
            // btnCer
            // 
            this.btnCer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCer.Image = ((System.Drawing.Image)(resources.GetObject("btnCer.Image")));
            this.btnCer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnCer.Location = new System.Drawing.Point(61, 290);
            this.btnCer.Name = "btnCer";
            this.btnCer.Size = new System.Drawing.Size(67, 41);
            this.btnCer.TabIndex = 6;
            this.btnCer.Text = "Cerrar";
            this.btnCer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCer.UseVisualStyleBackColor = true;
            this.btnCer.Click += new System.EventHandler(this.btnCer_Click);
            // 
            // btnDeshacer
            // 
            this.btnDeshacer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDeshacer.Image = ((System.Drawing.Image)(resources.GetObject("btnDeshacer.Image")));
            this.btnDeshacer.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDeshacer.Location = new System.Drawing.Point(61, 250);
            this.btnDeshacer.Name = "btnDeshacer";
            this.btnDeshacer.Size = new System.Drawing.Size(67, 41);
            this.btnDeshacer.TabIndex = 5;
            this.btnDeshacer.Text = "&Deshacer";
            this.btnDeshacer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDeshacer.UseVisualStyleBackColor = true;
            this.btnDeshacer.Click += new System.EventHandler(this.btnDeshacer_Click);
            // 
            // btnBor
            // 
            this.btnBor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBor.Image = ((System.Drawing.Image)(resources.GetObject("btnBor.Image")));
            this.btnBor.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBor.Location = new System.Drawing.Point(61, 210);
            this.btnBor.Name = "btnBor";
            this.btnBor.Size = new System.Drawing.Size(67, 41);
            this.btnBor.TabIndex = 4;
            this.btnBor.Text = "Borrar";
            this.btnBor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBor.UseVisualStyleBackColor = true;
            this.btnBor.Click += new System.EventHandler(this.btnBor_Click);
            // 
            // btnGua
            // 
            this.btnGua.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGua.Image = ((System.Drawing.Image)(resources.GetObject("btnGua.Image")));
            this.btnGua.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGua.Location = new System.Drawing.Point(61, 170);
            this.btnGua.Name = "btnGua";
            this.btnGua.Size = new System.Drawing.Size(67, 41);
            this.btnGua.TabIndex = 3;
            this.btnGua.Text = "Guardar";
            this.btnGua.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGua.UseVisualStyleBackColor = true;
            this.btnGua.Click += new System.EventHandler(this.btnGua_Click);
            // 
            // btnNue
            // 
            this.btnNue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNue.Image = ((System.Drawing.Image)(resources.GetObject("btnNue.Image")));
            this.btnNue.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNue.Location = new System.Drawing.Point(61, 90);
            this.btnNue.Name = "btnNue";
            this.btnNue.Size = new System.Drawing.Size(67, 41);
            this.btnNue.TabIndex = 1;
            this.btnNue.Text = "Nuevo";
            this.btnNue.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNue.UseVisualStyleBackColor = true;
            this.btnNue.Click += new System.EventHandler(this.btnNue_Click);
            // 
            // btnMod
            // 
            this.btnMod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMod.Image = ((System.Drawing.Image)(resources.GetObject("btnMod.Image")));
            this.btnMod.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMod.Location = new System.Drawing.Point(61, 130);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(67, 41);
            this.btnMod.TabIndex = 2;
            this.btnMod.Text = "Modificar";
            this.btnMod.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.fgCom);
            this.tabPage1.Controls.Add(this.gpbCom);
            this.tabPage1.Controls.Add(this.txtTipoArt);
            this.tabPage1.Controls.Add(this.gpbBot);
            this.tabPage1.Controls.Add(this.chkInac);
            this.tabPage1.Controls.Add(this.txtCodTipArt);
            this.tabPage1.Controls.Add(this.txtObs);
            this.tabPage1.Controls.Add(this.txtDes);
            this.tabPage1.Controls.Add(this.txtCod);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnCer);
            this.tabPage1.Controls.Add(this.btnDeshacer);
            this.tabPage1.Controls.Add(this.btnBor);
            this.tabPage1.Controls.Add(this.btnGua);
            this.tabPage1.Controls.Add(this.btnNue);
            this.tabPage1.Controls.Add(this.btnMod);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1141, 641);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mantenimiento";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // fgCom
            // 
            this.fgCom.ColumnInfo = "0,0,0,0,0,95,Columns:";
            this.fgCom.Location = new System.Drawing.Point(238, 286);
            this.fgCom.Name = "fgCom";
            this.fgCom.Rows.DefaultSize = 19;
            this.fgCom.SelectionMode = C1.Win.C1FlexGrid.SelectionModeEnum.Row;
            this.fgCom.Size = new System.Drawing.Size(843, 185);
            this.fgCom.TabIndex = 13;
            this.fgCom.KeyPressEdit += new C1.Win.C1FlexGrid.KeyPressEditEventHandler(this.fgCom_KeyPressEdit);
            // 
            // gpbCom
            // 
            this.gpbCom.Controls.Add(this.txtDescon);
            this.gpbCom.Controls.Add(this.txtMon);
            this.gpbCom.Controls.Add(this.txtPre);
            this.gpbCom.Controls.Add(this.btnCanCom);
            this.gpbCom.Controls.Add(this.btnEliCom);
            this.gpbCom.Controls.Add(this.btnModCom);
            this.gpbCom.Controls.Add(this.btnAgr);
            this.gpbCom.Controls.Add(this.txtCat);
            this.gpbCom.Controls.Add(this.txtDesArt);
            this.gpbCom.Controls.Add(this.txtCan);
            this.gpbCom.Controls.Add(this.txtCodArt);
            this.gpbCom.Controls.Add(this.chkPri);
            this.gpbCom.Controls.Add(this.label6);
            this.gpbCom.Controls.Add(this.label7);
            this.gpbCom.Controls.Add(this.label8);
            this.gpbCom.Controls.Add(this.label5);
            this.gpbCom.Enabled = false;
            this.gpbCom.Location = new System.Drawing.Point(238, 181);
            this.gpbCom.Name = "gpbCom";
            this.gpbCom.Size = new System.Drawing.Size(725, 99);
            this.gpbCom.TabIndex = 13;
            this.gpbCom.TabStop = false;
            this.gpbCom.Text = "Componentes";
            // 
            // txtDescon
            // 
            this.txtDescon.ForeColor = System.Drawing.Color.Blue;
            this.txtDescon.Location = new System.Drawing.Point(653, 19);
            this.txtDescon.Name = "txtDescon";
            this.txtDescon.Size = new System.Drawing.Size(58, 21);
            this.txtDescon.TabIndex = 27;
            this.txtDescon.Visible = false;
            // 
            // txtMon
            // 
            this.txtMon.ForeColor = System.Drawing.Color.Blue;
            this.txtMon.Location = new System.Drawing.Point(585, 19);
            this.txtMon.Name = "txtMon";
            this.txtMon.Size = new System.Drawing.Size(62, 21);
            this.txtMon.TabIndex = 27;
            this.txtMon.Visible = false;
            // 
            // txtPre
            // 
            this.txtPre.ForeColor = System.Drawing.Color.Blue;
            this.txtPre.Location = new System.Drawing.Point(513, 19);
            this.txtPre.Name = "txtPre";
            this.txtPre.Size = new System.Drawing.Size(64, 21);
            this.txtPre.TabIndex = 26;
            this.txtPre.Visible = false;
            // 
            // btnCanCom
            // 
            this.btnCanCom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCanCom.Location = new System.Drawing.Point(543, 64);
            this.btnCanCom.Name = "btnCanCom";
            this.btnCanCom.Size = new System.Drawing.Size(75, 23);
            this.btnCanCom.TabIndex = 25;
            this.btnCanCom.Text = "&Cancelar";
            this.btnCanCom.UseVisualStyleBackColor = true;
            this.btnCanCom.Click += new System.EventHandler(this.btnCanCom_Click);
            // 
            // btnEliCom
            // 
            this.btnEliCom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEliCom.Location = new System.Drawing.Point(469, 64);
            this.btnEliCom.Name = "btnEliCom";
            this.btnEliCom.Size = new System.Drawing.Size(75, 23);
            this.btnEliCom.TabIndex = 24;
            this.btnEliCom.Text = "&Eliminar";
            this.btnEliCom.UseVisualStyleBackColor = true;
            this.btnEliCom.Click += new System.EventHandler(this.btnEliCom_Click);
            // 
            // btnModCom
            // 
            this.btnModCom.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnModCom.Location = new System.Drawing.Point(395, 64);
            this.btnModCom.Name = "btnModCom";
            this.btnModCom.Size = new System.Drawing.Size(75, 23);
            this.btnModCom.TabIndex = 23;
            this.btnModCom.Text = "&Modificar";
            this.btnModCom.UseVisualStyleBackColor = true;
            this.btnModCom.Click += new System.EventHandler(this.btnModCom_Click);
            // 
            // btnAgr
            // 
            this.btnAgr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAgr.Location = new System.Drawing.Point(322, 64);
            this.btnAgr.Name = "btnAgr";
            this.btnAgr.Size = new System.Drawing.Size(75, 23);
            this.btnAgr.TabIndex = 22;
            this.btnAgr.Text = "&Agregar";
            this.btnAgr.UseVisualStyleBackColor = true;
            this.btnAgr.Click += new System.EventHandler(this.btnAgr_Click);
            // 
            // txtCat
            // 
            this.txtCat.ForeColor = System.Drawing.Color.Blue;
            this.txtCat.Location = new System.Drawing.Point(241, 19);
            this.txtCat.Name = "txtCat";
            this.txtCat.Size = new System.Drawing.Size(215, 21);
            this.txtCat.TabIndex = 15;
            this.txtCat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCat_KeyPress);
            // 
            // txtDesArt
            // 
            this.txtDesArt.ForeColor = System.Drawing.Color.Blue;
            this.txtDesArt.Location = new System.Drawing.Point(83, 42);
            this.txtDesArt.Name = "txtDesArt";
            this.txtDesArt.Size = new System.Drawing.Size(535, 21);
            this.txtDesArt.TabIndex = 19;
            this.txtDesArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesArt_KeyPress);
            // 
            // txtCan
            // 
            this.txtCan.ForeColor = System.Drawing.Color.Blue;
            this.txtCan.Location = new System.Drawing.Point(83, 66);
            this.txtCan.Name = "txtCan";
            this.txtCan.Size = new System.Drawing.Size(100, 21);
            this.txtCan.TabIndex = 20;
            this.txtCan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCan_KeyPress);
            // 
            // txtCodArt
            // 
            this.txtCodArt.ForeColor = System.Drawing.Color.Blue;
            this.txtCodArt.Location = new System.Drawing.Point(83, 19);
            this.txtCodArt.Name = "txtCodArt";
            this.txtCodArt.Size = new System.Drawing.Size(100, 21);
            this.txtCodArt.TabIndex = 14;
            this.txtCodArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodArt_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Componentes:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Cantidad:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(189, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Catálogo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Codigo:";
            // 
            // txtTipoArt
            // 
            this.txtTipoArt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTipoArt.ForeColor = System.Drawing.Color.Blue;
            this.txtTipoArt.Location = new System.Drawing.Point(335, 150);
            this.txtTipoArt.Name = "txtTipoArt";
            this.txtTipoArt.Size = new System.Drawing.Size(249, 21);
            this.txtTipoArt.TabIndex = 11;
            this.txtTipoArt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTipoArt_KeyPress);
            // 
            // tabMae
            // 
            this.tabMae.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabMae.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabMae.Controls.Add(this.tabPage1);
            this.tabMae.Controls.Add(this.tabPage2);
            this.tabMae.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabMae.ItemSize = new System.Drawing.Size(100, 21);
            this.tabMae.Location = new System.Drawing.Point(2, 3);
            this.tabMae.Name = "tabMae";
            this.tabMae.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabMae.SelectedIndex = 0;
            this.tabMae.Size = new System.Drawing.Size(1149, 670);
            this.tabMae.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabMae.TabIndex = 0;
            this.tabMae.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabMae_Selecting);
            // 
            // frmMan_ArticuloCompuesto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1163, 672);
            this.Controls.Add(this.tabMae);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmMan_ArticuloCompuesto";
            this.Text = "Articulos Compuestos";
            this.Load += new System.EventHandler(this.frmMan_ArticuloCompuesto_Load);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fgMae)).EndInit();
            this.gpbBtnMae.ResumeLayout(false);
            this.gpbBot.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fgCom)).EndInit();
            this.gpbCom.ResumeLayout(false);
            this.gpbCom.PerformLayout();
            this.tabMae.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gpbBot;
        private System.Windows.Forms.Button btnPri;
        private System.Windows.Forms.Button btnUlt;
        private System.Windows.Forms.Button btnAva;
        private System.Windows.Forms.Button btnRet;
        private System.Windows.Forms.CheckBox chkInac;
        private System.Windows.Forms.CheckBox chkPri;
        private System.Windows.Forms.TextBox txtCodTipArt;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.TextBox txtDes;
        private System.Windows.Forms.TextBox txtCod;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCer;
        private System.Windows.Forms.Button btnDeshacer;
        private System.Windows.Forms.Button btnBor;
        private System.Windows.Forms.Button btnGua;
        private System.Windows.Forms.Button btnNue;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabMae;
        private System.Windows.Forms.TextBox txtTipoArt;
        private System.Windows.Forms.GroupBox gpbCom;
        private System.Windows.Forms.TextBox txtCat;
        private System.Windows.Forms.TextBox txtCodArt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDesArt;
        private System.Windows.Forms.TextBox txtCan;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnCanCom;
        private System.Windows.Forms.Button btnEliCom;
        private System.Windows.Forms.Button btnModCom;
        private System.Windows.Forms.Button btnAgr;
        private C1.Win.C1FlexGrid.C1FlexGrid fgCom;
        private C1.Win.C1FlexGrid.C1FlexGrid fgMae;
        private System.Windows.Forms.GroupBox gpbBtnMae;
        private System.Windows.Forms.Button btnRutImgApl;
        private System.Windows.Forms.Button btnLimRut;
        private System.Windows.Forms.Button btnRutImgCot;
        private System.Windows.Forms.Button btnExp;
        private System.Windows.Forms.TextBox txtDescon;
        private System.Windows.Forms.TextBox txtMon;
        private System.Windows.Forms.TextBox txtPre;
    }
}