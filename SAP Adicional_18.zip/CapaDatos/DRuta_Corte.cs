﻿using Entidades.Ruta_Corte;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DRuta_Corte
    {
        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);
        public DataTable Ruta_Corte_RecCorPed()
        {
            SqlDataAdapter daRecCorPed = new SqlDataAdapter("SELECT Fecha,Codigo,Corte FROM ALM_CorPed_Cortes ORDER BY Fecha Desc",cnx);
            daRecCorPed.SelectCommand.CommandType = CommandType.Text;
            DataTable dtRecCorPed = new DataTable();
            dtRecCorPed.Locale = CultureInfo.InvariantCulture;
            daRecCorPed.Fill(dtRecCorPed);
            return dtRecCorPed;   
        }

        public DataTable Ruta_Corte_Filtros(string vista, string procedimiento, string param1)
        {
            SqlDataAdapter daFiltro = new SqlDataAdapter(procedimiento, cnx);
            daFiltro.SelectCommand.CommandType = CommandType.StoredProcedure;

            switch (vista)
            {
                case "Corte":
                    daFiltro.SelectCommand.Parameters.Add("@Filtro",SqlDbType.NVarChar,60).Value = param1;
                    break;
            }

            DataTable dtFiltro = new DataTable();
            daFiltro.Fill(dtFiltro);
            return dtFiltro;
        }

        public void Ruta_Corte_InsCorPed(Ruta_Corte_Enc Enc)
        {
            string consulta = "INSERT INTO ALM_CorPed_Cor(CodCorPed,FecCor,CodUsuCre,FecCre)"+
                               "VALUES(@codCor,@Fec,@codUsu,getdate())";

            using (SqlCommand cmdInsCorPed = new SqlCommand(consulta,cnx))
            {
                cnx.Open();
                cmdInsCorPed.CommandType = CommandType.Text;
                cmdInsCorPed.Parameters.Add("@codCor",SqlDbType.TinyInt).Value =Enc.CodCorPed;
                cmdInsCorPed.Parameters.Add("@Fec", SqlDbType.SmallDateTime).Value = Enc.FecCor;
                cmdInsCorPed.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = Enc.CodUsuCre;
                cmdInsCorPed.ExecuteNonQuery();
                cnx.Close();
            }
        }
        public void Ruta_Corte_EliCorPed(Int16 CodCorPed,DateTime FecCor)
        {
            string consulta = "DELETE ALM_CorPed_Cor WHERE CodCorPed = @codCor and FecCor = @fecCor";

            using (SqlCommand cmdEliCorPed = new SqlCommand(consulta, cnx))
            {
                cnx.Open();
                cmdEliCorPed.CommandType = CommandType.Text;
                cmdEliCorPed.Parameters.Add("@codCor", SqlDbType.TinyInt).Value = CodCorPed;
                cmdEliCorPed.Parameters.Add("@fecCor", SqlDbType.SmallDateTime).Value = FecCor;
                cmdEliCorPed.ExecuteNonQuery();
                cnx.Close();
            }
        }
    }
}
