﻿using CapaDatos;
using Entidades.Man_Menus;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DMan_UsuMae
    {
        public DataTable RecUsuMae()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter recUsuMae = new SqlDataAdapter("SELECT * FROM MantenimientoUsuarios_Maestro", cn))
                {
                    recUsuMae.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    recUsuMae.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable RecManUsu(Int16 dir,int usu)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecUsu = new SqlDataAdapter("MantenimientoUsuarios_General",cn))
                {
                    daRecUsu.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecUsu.SelectCommand.Parameters.Add("@Direccion",SqlDbType.SmallInt).Value = dir;
                    daRecUsu.SelectCommand.Parameters.Add("@Usuario", SqlDbType.NVarChar,25).Value = usu;
                    daRecUsu.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar,200).Value = "";
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    daRecUsu.Fill(dt);
                    return dt;
                }
            }
        }
        public void ActGuaUsu(Man_UsuMae actGuar)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand actGuaUsu = new SqlCommand("MantenimientoUsuarios_ActualizaGuarda", cn))
                {
                    cn.Open();
                    actGuaUsu.CommandType = CommandType.StoredProcedure;
                    actGuaUsu.Parameters.Add("@Accion",SqlDbType.Bit).Value= actGuar.Acc;
                    actGuaUsu.Parameters.Add("@CodigoUsuario", SqlDbType.Int).Value = actGuar.CodUsu;
                    actGuaUsu.Parameters.Add("@Usuario", SqlDbType.NVarChar,25 ).Value = actGuar.Usu;
                    actGuaUsu.Parameters.Add("@Clave ", SqlDbType.NVarChar,20).Value = actGuar.Cla;
                    actGuaUsu.Parameters.Add("@UsuarioActivo", SqlDbType.SmallInt).Value = actGuar.UsuAct;
                    actGuaUsu.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }
        public void EliUsu(Int16 CodEmp)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand eliCodUsu = new SqlCommand("DELETE Usuario WHERE CodigoUsuario=@codEmp", cn))
                {
                    cn.Open();
                    eliCodUsu.CommandType = CommandType.Text;
                    eliCodUsu.Parameters.Add("@codEmp", SqlDbType.SmallInt).Value = CodEmp;
                    eliCodUsu.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public void ActUsuMae(string UsuClaAct,Int16 CodUsu,Int16 NumCol)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                if (NumCol == 0)
                {
                    using (SqlCommand actUsu = new SqlCommand("update Usuario set Usuario=@usu where CodigoUsuario=@codusu", cn))
                    {
                        cn.Open();
                        actUsu.CommandType = CommandType.Text;
                        actUsu.Parameters.Add("@usu", SqlDbType.NVarChar, 20).Value = UsuClaAct;
                        actUsu.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = CodUsu;
                        actUsu.ExecuteNonQuery();
                        cn.Close();
                    }
                }
                else if(NumCol == 1)
                {
                    using (SqlCommand actUsu = new SqlCommand("update Usuario set Clave=@clave where CodigoUsuario=@codusu", cn))
                    {
                        cn.Open();
                        actUsu.CommandType = CommandType.Text;
                        actUsu.Parameters.Add("@clave", SqlDbType.NVarChar, 15).Value = UsuClaAct;
                        actUsu.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = CodUsu;
                        actUsu.ExecuteNonQuery();
                        cn.Close();
                    }
                }
                else
                {
                    using (SqlCommand actUsu = new SqlCommand("update Usuario set UsuarioActivo=@usuact where CodigoUsuario=@codusu", cn))
                    {
                        cn.Open();
                        actUsu.CommandType = CommandType.Text;
                        actUsu.Parameters.Add("@usuact", SqlDbType.NVarChar, 15).Value = UsuClaAct;
                        actUsu.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = CodUsu;
                        actUsu.ExecuteNonQuery();
                        cn.Close();
                    }
                } 
            }
        }
    }
}
