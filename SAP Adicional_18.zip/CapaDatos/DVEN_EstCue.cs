﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades.VEN_EstCue;

namespace CapaDatos
{
    public class DVEN_EstCue
    {
        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

        public DataTable VEN_EstCue_OpcOri(Byte origen, int rq)
        {

            SqlDataAdapter da = new SqlDataAdapter("[VEN_EstCue_OpcOri]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@origen", SqlDbType.TinyInt).Value = origen;
            da.SelectCommand.Parameters.Add("@rq", SqlDbType.Int).Value = rq;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public void VEN_EstCue_Docs(VEN_EstCue EstCue, Int32 CodUsu)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_EstCue_Docs WHERE CodUsu = @codusu ", cnx))
                {
                    cnx.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = CodUsu;
                    cmd.ExecuteNonQuery();
                    cnx.Close();
                }

                string sqlDet = "INSERT INTO VEN_EstCue_Docs (RQ,NumDoc,CodUsu) VALUES (@rq,@NumDoc,@codusu)";

                using (SqlCommand cmd = new SqlCommand(sqlDet, cnx))
                {
                    foreach (VEN_EstCue item in EstCue.EstCueList)
                    {
                        cnx.Open();
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@rq", SqlDbType.Int).Value = item.RQ;
                        cmd.Parameters.Add("@NumDoc", SqlDbType.NVarChar, 10).Value = item.NumDoc;
                        cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = item.CodUsuActi;

                        cmd.ExecuteNonQuery();
                        cnx.Close();
                    }

                }
            }
        }
    }
}
