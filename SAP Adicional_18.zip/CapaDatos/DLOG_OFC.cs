﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades.LOG_OFC;

namespace CapaDatos
{
    public class DLOG_OFC
    {
        public DataSet LOG_OFC_rec(Int64 nummov)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter daEnc = new SqlDataAdapter("LOG_OFC_Enc_rec", cnx);
                daEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
                daEnc.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                SqlDataAdapter daDet = new SqlDataAdapter("LOG_OFC_Det_rec", cnx);
                daDet.SelectCommand.CommandType = CommandType.StoredProcedure;
                daDet.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;               

                DataSet ds = new DataSet();

                daEnc.Fill(ds, "LOG_OFC_Enc");
                daDet.Fill(ds, "LOG_OFC_Det");

                return (ds);
            }
        }
        
        public DataTable LOG_OFC_VisGen(Int16 val)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("LOG_OFC_visgen", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@val", SqlDbType.TinyInt).Value = val;

                //ejecutamos y llenamos el datatable
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public void LOG_OFC_ingact(LOG_OFC Enc)
        {
            //Ingresar o actualizar informacion de la tabla LOG_OFC_Enc
            using (SqlConnection cnx= new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using(SqlCommand cmd = new SqlCommand("LOG_OFC_Enc_ingact", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    //

                    SqlParameter paramNumMov = new SqlParameter("@nummov", SqlDbType.BigInt);
                    paramNumMov.Direction = ParameterDirection.InputOutput;
                    paramNumMov.Value = Enc.NumMov;

                    SqlParameter paramNumOFC = new SqlParameter("@numofc", SqlDbType.NVarChar,11);
                    paramNumOFC.Direction = ParameterDirection.InputOutput;
                    paramNumOFC.Value = Enc.NumOFC;

                    cmd.Parameters.Add(paramNumMov);
                    cmd.Parameters.Add(paramNumOFC);
                    cmd.Parameters.Add("@codtipofc", SqlDbType.SmallInt).Value = Enc.CodTipOFC;
                    cmd.Parameters.Add("@codtipser", SqlDbType.SmallInt).Value = Enc.CodTipSer;
                    cmd.Parameters.Add("@doccur", SqlDbType.NVarChar, 3).Value = Enc.DocCur;
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                    //
                    cnx.Open();
                    //
                    //cmd.Parameters.Clear();
                    cmd.ExecuteNonQuery();
                    Enc.NumMov = Convert.ToInt64(cmd.Parameters["@nummov"].Value);
                    Enc.NumOFC = (cmd.Parameters["@numofc"].Value).ToString();
                }

                //Eliminamos el detalle
                using (SqlCommand cmd = new SqlCommand("DELETE LOG_OFC_Det WHERE NumMov = @nummov", cnx))
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@nummov", Enc.NumMov);

                    cmd.ExecuteNonQuery();
                }

                string LOG_OFC_Det = @"INSERT INTO LOG_OFC_Det (nummov,item,codcatgas,codpro,
                                        codgas,cta,desser,canser,codart,can,preuni,tot,codare,codsubare,
                                        codunineg,rq,rutarc) VALUES
                                        (@nummov, @item, @codcatgas, @codpro, @codgas, @cta,
                                        @desser, @canser, @codart,@can, @preuni, @tot, @codare, @codsubare,
                                        @codunineg, @rq, @rutarc)";

                using(SqlCommand cmd = new SqlCommand(LOG_OFC_Det, cnx))
                {
                    foreach(LOG_OFC_Det Det in Enc.Det)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@nummov", Enc.NumMov);
                        cmd.Parameters.AddWithValue("@item", Det.Item);
                        cmd.Parameters.AddWithValue("@codcatgas", Det.CodCatGas);
                        cmd.Parameters.AddWithValue("@codpro", Det.CodPro);
                        cmd.Parameters.AddWithValue("@codgas", Det.CodGas);
                        cmd.Parameters.AddWithValue("@cta", Det.Cta);
                        cmd.Parameters.AddWithValue("@desser", Det.DesSer);
                        cmd.Parameters.AddWithValue("@canser", Det.CanSer);
                        cmd.Parameters.AddWithValue("@codart", Det.CodArt);
                        cmd.Parameters.AddWithValue("@can", Det.Can);
                        cmd.Parameters.AddWithValue("@preuni", Det.PreUni);
                        cmd.Parameters.AddWithValue("@tot", Det.Tot);
                        cmd.Parameters.AddWithValue("@codare", Det.CodAre);
                        cmd.Parameters.AddWithValue("@codsubare", Det.CodSubAre);
                        cmd.Parameters.AddWithValue("@codunineg", Det.CodUniNeg);
                        cmd.Parameters.AddWithValue("@rq", Det.RQ);
                        cmd.Parameters.AddWithValue("@rutarc", Det.RutArc);

                        cmd.ExecuteNonQuery();
                    }

                }
            }
        }
    }
}
