﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades.OPE_Pro;

namespace CapaDatos
{
    public class DOPE_Pro
    {
        public void OPE_Pro_ActFecAprIns(Int64 nummov, Int32 codusu, DateTime fecaprinst, Int64 rq)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {

                string cadena = "";

                cadena = @"UPDATE OPE_Pro_Det0 SET FecAprIns = @fecaprins,
                                                    FecModFecAprIns = getdate(),
                                                    CodUsuModFecAprIns = @codusu                                                       
                                              WHERE NumMov = @nummov and RQ = @rq";

                cnx.Open();

                using (SqlCommand cmd = new SqlCommand(cadena, cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;                    
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                    cmd.Parameters.Add("@fecaprins", SqlDbType.SmallDateTime).Value = fecaprinst;
                    cmd.Parameters.Add("@rq", SqlDbType.SmallInt).Value = rq;
                    
                    cmd.ExecuteNonQuery();
                }

                cadena = @"UPDATE OPE_Pro_Enc SET   FecMod = getdate(), 
                                                    CodUsuMod = @codusu                                                                
                                                    WHERE NumMov = @nummov";

                using (SqlCommand cmd = new SqlCommand(cadena, cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                    
                    cmd.ExecuteNonQuery();
                }

            }

        }

        public void OPE_Pro_Est(Int64 nummov, Int32 codusu, Int16 codest)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string cadena = "";

                switch (codest)
                {
                    case 1: //Terminado

                        cadena = @"UPDATE OPE_Pro_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu                                                                
                                                        WHERE NumMov = @nummov";

                        break;

                    case 2: //Terminado

                        cadena = @"UPDATE OPE_Pro_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecTer = getdate(),
                                                                CodUsuTer = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                    case 3: //Paralizado

                        cadena = @"UPDATE OPE_Pro_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecPar = getdate(),
                                                                CodUsuPar = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                    case 4: //Archivado

                        cadena = @"UPDATE OPE_Pro_Enc SET DocNumNotCre = @docnumnotcre,
                                                                CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecArc = getdate(),
                                                                CodUsuArc = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                }

                using (SqlCommand cmd = new SqlCommand(cadena, cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                    cmd.Parameters.Add("@codest", SqlDbType.SmallInt).Value = codest;                   

                    cnx.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public DataTable OPE_Pro_VisGen(bool VisDet)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {

                string query;
                
                if (VisDet == true)
                {
                    query = "SELECT TOP 50 * FROM OPE_Pro_VisGen_Det ORDER BY [N° Proyecto] DESC";
                }
                else
                {
                    query = "SELECT TOP 50 * FROM OPE_Pro_VisGen ORDER BY [N° Proyecto] DESC";
                }

                SqlDataAdapter da = new SqlDataAdapter(query, cnx);
                da.SelectCommand.CommandType = CommandType.Text;
                //
                DataTable dt = new DataTable();
                dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                da.Fill(dt);
                return dt;
            }

        }

        public Int64 OPE_Pro_InsertarEditar(OPE_Pro Enc)
        {

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                //Ingresar o actualizar informacion de la tabla OPE_Pro_Enc
                using (SqlCommand cmd = new SqlCommand("OPE_Pro_Enc_ingact", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    //
                    cmd.Parameters.Clear();
                    SqlParameter paramNumMov = new SqlParameter("@nummov", SqlDbType.BigInt);
                    paramNumMov.Direction = ParameterDirection.InputOutput;
                    paramNumMov.Value = Enc.NumMov;
                    //
                    cmd.Parameters.Add(paramNumMov);
                    cmd.Parameters.Add("@nompro", SqlDbType.NVarChar, 100).Value = Enc.NomPro;
                    cmd.Parameters.Add("@dirpro", SqlDbType.NVarChar, 150).Value = Enc.DirPro;
                    cmd.Parameters.Add("@dispro", SqlDbType.NVarChar, 50).Value = Enc.DisPro;
                    cmd.Parameters.Add("@fecaprins", SqlDbType.NVarChar,10).Value = Enc.FecAprIns;
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                    //
                    cnx.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    //
                    Enc.NumMov = Convert.ToInt64(cmd.Parameters["@nummov"].Value);

                }

                //Elimino todo el detalle cero (Det0)
                using (SqlCommand cmd = new SqlCommand("DELETE OPE_Pro_Det0 WHERE NumMov = @nummov", cnx))
                {

                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@nummov", Enc.NumMov);                    

                    cmd.ExecuteNonQuery();

                }

                string sqlDet = @"INSERT INTO OPE_Pro_Det0(nummov,rq,codtip,tipico,pendiente,socneg,
                                ven,codcom,codtippre,coddis,codingope,codsup,codadmped,cortippen) VALUES 
                                (@nummov, @rq, @codtip, @tipico, @pendiente, @socneg, @ven,
                                @codcom, @codtippre, @coddis, @codingope, @codsup, @codadmped,
                                @cortippen)";


                using (SqlCommand cmd = new SqlCommand(sqlDet, cnx))
                {

                    foreach (OPE_Pro_Det0 Det0 in Enc.Det0)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@nummov", Enc.NumMov);
                        cmd.Parameters.AddWithValue("@rq", Det0.RQ);
                        cmd.Parameters.AddWithValue("@codtip", Det0.CodTip);
                        cmd.Parameters.AddWithValue("@tipico", Det0.Tipico);
                        cmd.Parameters.AddWithValue("@pendiente", Det0.Pendiente);
                        cmd.Parameters.AddWithValue("@socneg", Det0.SocNeg);
                        cmd.Parameters.AddWithValue("@ven", Det0.Ven);
                        cmd.Parameters.AddWithValue("@codcom", Det0.CodCom);
                        cmd.Parameters.AddWithValue("@codtippre", Det0.CodTipPre);
                        cmd.Parameters.AddWithValue("@coddis", Det0.CodDis);
                        cmd.Parameters.AddWithValue("@codingope", Det0.CodIngOpe);
                        cmd.Parameters.AddWithValue("@codsup", Det0.CodSup);
                        cmd.Parameters.AddWithValue("@codadmped", Det0.CodAdmPed);
                        cmd.Parameters.AddWithValue("@cortippen", Det0.CorTipPen);
                        //cmd.Parameters.AddWithValue("@sup", Det0.Sup);

                        cmd.ExecuteNonQuery();
                    }

                }

                return Enc.NumMov;
            }

        }

        public DataTable OPE_Pro_VisGen_Filtro(string filtro, bool VisDet)
        {

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string query;

                if (VisDet == true)
                {
                    query = "SELECT * FROM OPE_Pro_VisGen_Det ";
                }
                else
                {
                    query = "SELECT * FROM OPE_Pro_VisGen ";
                }
      
                SqlDataAdapter da = new SqlDataAdapter(query + filtro + " ORDER BY [N° Proyecto] DESC", cnx);
                da.SelectCommand.CommandType = CommandType.Text;

                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataSet OPE_Pro_rec(int nummov)
        {
            //Este es para el formulario frmOPE_Pro_ingact
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {

                SqlDataAdapter daOPE_Pro_Enc = new SqlDataAdapter("OPE_Pro_Enc_rec", cnx);
                daOPE_Pro_Enc.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Enc.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                SqlDataAdapter daOPE_Pro_Det0 = new SqlDataAdapter("OPE_Pro_Det0_rec", cnx);
                daOPE_Pro_Det0.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det0.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                DataSet ds = new DataSet();

                daOPE_Pro_Enc.Fill(ds, "OPE_Pro_Enc");
                daOPE_Pro_Det0.Fill(ds, "OPE_Pro_Det0");

                return (ds);
            }
        }

        public DataSet OPE_Pro_rec2(int nummov, Int32 codusu)
        {
            //Este es para el formulario frmOPE_Pro
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {

                SqlDataAdapter daOPE_Pro_Enc = new SqlDataAdapter("OPE_Pro_Enc_rec", cnx);
                daOPE_Pro_Enc.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Enc.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                daOPE_Pro_Enc.SelectCommand.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                //Detalle de los  RQ
                SqlDataAdapter daOPE_Pro_Det0 = new SqlDataAdapter("OPE_Pro_Det0_rec", cnx);
                daOPE_Pro_Det0.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det0.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Acuerdos comerciales
                SqlDataAdapter daOPE_Pro_Det1 = new SqlDataAdapter("OPE_Pro_Det1_rec", cnx);
                daOPE_Pro_Det1.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det1.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Registro de visitas
                SqlDataAdapter daOPE_Pro_Det2 = new SqlDataAdapter("OPE_Pro_Det2_rec", cnx);
                daOPE_Pro_Det2.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det2.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Interesados del proyecto
                SqlDataAdapter daOPE_Pro_Det4 = new SqlDataAdapter("OPE_Pro_Det4_rec", cnx);
                daOPE_Pro_Det4.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det4.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //OTIS vinculadas
                SqlDataAdapter daOPE_Pro_Det5 = new SqlDataAdapter("OPE_Pro_Det5_rec", cnx);
                daOPE_Pro_Det5.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det5.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Rutas vinculadas
                SqlDataAdapter daOPE_Pro_Det6 = new SqlDataAdapter("OPE_Pro_Det6_rec", cnx);
                daOPE_Pro_Det6.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det6.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Fechas Apro. de Instalacion
                SqlDataAdapter daOPE_Pro_Det7 = new SqlDataAdapter("OPE_Pro_FecAprIns_rec", cnx);
                daOPE_Pro_Det7.SelectCommand.CommandType = CommandType.StoredProcedure;
                daOPE_Pro_Det7.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                DataSet ds = new DataSet();

                daOPE_Pro_Enc.Fill(ds, "OPE_Pro_Enc");
                daOPE_Pro_Det0.Fill(ds, "OPE_Pro_Det0");
                daOPE_Pro_Det1.Fill(ds, "OPE_Pro_Det1");
                daOPE_Pro_Det2.Fill(ds, "OPE_Pro_Det2");
                daOPE_Pro_Det4.Fill(ds, "OPE_Pro_Det4");
                daOPE_Pro_Det5.Fill(ds, "OPE_Pro_Det5");
                daOPE_Pro_Det6.Fill(ds, "OPE_Pro_Det6");
                daOPE_Pro_Det7.Fill(ds, "OPE_Pro_Det7");

                return (ds);
            }
        }

        public void OPE_Pro_Det1_ingact(OPE_Pro Enc)
        {

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                //Ingresar o actualizar informacion de la tabla OPE_Pro_Enc
                using (SqlCommand cmd = new SqlCommand("OPE_Pro_Enc_act", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    //
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.BigInt).Value = Enc.NumMov;
                    cmd.Parameters.Add("@codestobr", SqlDbType.Int).Value = Enc.CodEstObr;
                    cmd.Parameters.Add("@fecini", SqlDbType.NVarChar, 10).Value = Enc.FecIni;
                    cmd.Parameters.Add("@feccab", SqlDbType.NVarChar, 10).Value = Enc.FecCab;
                    cmd.Parameters.Add("@fecaprins", SqlDbType.NVarChar, 10).Value = Enc.FecAprIns;
                    cmd.Parameters.Add("@fecfin", SqlDbType.NVarChar, 10).Value = Enc.FecFin;
                    cmd.Parameters.Add("@alcpro", SqlDbType.VarChar, 8000).Value = Enc.AlcPro;
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                    //
                    cnx.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    //
                }

                //Elimino todo el detalle cero (Det0)
                using (SqlCommand cmd = new SqlCommand("DELETE OPE_Pro_Det1 WHERE NumMov = @nummov", cnx))
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@nummov", Enc.NumMov);

                    cmd.ExecuteNonQuery();

                }

                //Y lo vuelvo a agregar
                using (SqlCommand cmd = new SqlCommand("OPE_Pro_Det1_insact", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (OPE_Pro_Det1 Det1 in Enc.Det1)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@NumMov", Det1.NumMov);
                        cmd.Parameters.AddWithValue("@RQ", Det1.RQ);
                        cmd.Parameters.AddWithValue("@Dis_DurEst_Mes", Det1.Dis_DurEst_Mes);
                        cmd.Parameters.AddWithValue("@Dis_CanVis_Und", Det1.Dis_CanVis_Und);
                        cmd.Parameters.AddWithValue("@Dis_TraOfi_Hor", Det1.Dis_TraOfi_Hor);
                        cmd.Parameters.AddWithValue("@Dis_TraPla_Hor", Det1.Dis_TraPla_Hor);
                        cmd.Parameters.AddWithValue("@Dis_TraDia_Hor", Det1.Dis_TraDia_Hor);
                        cmd.Parameters.AddWithValue("@Dis_CosDir", Det1.Dis_CosDir);
                        cmd.Parameters.AddWithValue("@Dis_CosInd", Det1.Dis_CosInd);
                        cmd.Parameters.AddWithValue("@Dis_GasGen", Det1.Dis_GasGen);
                        cmd.Parameters.AddWithValue("@Dis_Uti", Det1.Dis_Uti);
                        cmd.Parameters.AddWithValue("@Sup_DurEst_Mes", Det1.Sup_DurEst_Mes);
                        cmd.Parameters.AddWithValue("@Sup_CanVisIngOpe_Und", Det1.Sup_CanVisIngOpe_Und);
                        cmd.Parameters.AddWithValue("@Sup_TraOfiOpe_Hor", Det1.Sup_TraOfiOpe_Hor);
                        cmd.Parameters.AddWithValue("@Sup_CanVisSup_Und", Det1.Sup_CanVisSup_Und);
                        cmd.Parameters.AddWithValue("@Sup_CanPruMue_Und", Det1.Sup_CanPruMue_Und);
                        cmd.Parameters.AddWithValue("@Sup_CanPruMueDobAlt_Und", Det1.Sup_CanPruMueDobAlt_Und);
                        cmd.Parameters.AddWithValue("@Sup_CanPrueMeg_Und", Det1.Sup_CanPrueMeg_Und);
                        cmd.Parameters.AddWithValue("@Sup_CosDir", Det1.Sup_CosDir);
                        cmd.Parameters.AddWithValue("@Sup_CosInd", Det1.Sup_CosInd);
                        cmd.Parameters.AddWithValue("@Sup_GasGen", Det1.Sup_GasGen);
                        cmd.Parameters.AddWithValue("@Sup_Uti", Det1.Sup_Uti);
                        cmd.Parameters.AddWithValue("@Ins_DurEst_Dia", Det1.Ins_DurEst_Dia);
                        cmd.Parameters.AddWithValue("@Ins_CanTecDia_Und", Det1.Ins_CanTecDia_Und);
                        cmd.Parameters.AddWithValue("@Ins_CanVisCoo_Und", Det1.Ins_CanVisCoo_Und);
                        cmd.Parameters.AddWithValue("@Ins_CanViaMov_Und", Det1.Ins_CanViaMov_Und);
                        cmd.Parameters.AddWithValue("@Ins_CanPruLuc_Und", Det1.Ins_CanPruLuc_Und);
                        cmd.Parameters.AddWithValue("@Ins_CosTraNoc_Sol", Det1.Ins_CosTraNoc_Sol);
                        cmd.Parameters.AddWithValue("@Ins_CosMat_Sol", Det1.Ins_CosMat_Sol);
                        cmd.Parameters.AddWithValue("@Ins_CosDir", Det1.Ins_CosDir);
                        cmd.Parameters.AddWithValue("@Ins_CosInd", Det1.Ins_CosInd);
                        cmd.Parameters.AddWithValue("@Ins_GasGen", Det1.Ins_GasGen);
                        cmd.Parameters.AddWithValue("@Ins_Uti", Det1.Ins_Uti);
                        cmd.Parameters.AddWithValue("@Pro_DurEst_Dia", Det1.Pro_DurEst_Dia);
                        cmd.Parameters.AddWithValue("@Pro_CanBotSenDri_Und", Det1.Pro_CanBotSenDri_Und);
                        cmd.Parameters.AddWithValue("@Pro_CanModRepAmp_Und", Det1.Pro_CanModRepAmp_Und);
                        cmd.Parameters.AddWithValue("@Pro_CanPanConLic_Und", Det1.Pro_CanPanConLic_Und);
                        cmd.Parameters.AddWithValue("@Pro_CosPro_Sol", Det1.Pro_CosPro_Sol);
                        cmd.Parameters.AddWithValue("@Pro_CosDir", Det1.Pro_CosDir);
                        cmd.Parameters.AddWithValue("@Pro_CosInd", Det1.Pro_CosInd);
                        cmd.Parameters.AddWithValue("@Pro_GasGen", Det1.Pro_GasGen);
                        cmd.Parameters.AddWithValue("@Pro_Uti", Det1.Pro_Uti);

                        cmd.ExecuteNonQuery();
                    }

                }

                //Elimino todo el detalle 4 (Det4)
                using (SqlCommand cmd = new SqlCommand("DELETE OPE_Pro_Det4 WHERE NumMov = @nummov", cnx))
                {

                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@nummov", Enc.NumMov);

                    cmd.ExecuteNonQuery();

                }

                //Y lo vuelvo a agregar
                using (SqlCommand cmd = new SqlCommand("OPE_Pro_Det4_InsAct", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (OPE_Pro_Det4 Det4 in Enc.Det4)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@nummov", Det4.NumMov);
                        cmd.Parameters.AddWithValue("@item", Det4.Item);
                        cmd.Parameters.AddWithValue("@codintpro", Det4.CodIntPro);
                        cmd.Parameters.AddWithValue("@nom", Det4.Nom);
                        cmd.Parameters.AddWithValue("@cel1", Det4.Cel1);
                        cmd.Parameters.AddWithValue("@cel2", Det4.Cel2);
                        cmd.Parameters.AddWithValue("@email", Det4.Email);
                        cmd.Parameters.AddWithValue("@resfirgui", Det4.ResFirGui);
                        cmd.Parameters.AddWithValue("@resactvis", Det4.ResActVis);

                        cmd.ExecuteNonQuery();
                    }

                }

            }

        }

    }
}
