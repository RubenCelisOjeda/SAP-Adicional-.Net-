﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos.Properties;
using Entidades.VEN_Cot;

namespace CapaDatos
{
    public class DVEN_Cot
    {

        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

        public DataTable VEN_Cot_ArtComMosCom(int codcom, string moneda, string tipoventa)
        {
            // Recuperar los componentes del articulo compuesto 
            SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_ArtCom_MosCom", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@codcom", SqlDbType.Int).Value = codcom;
            da.SelectCommand.Parameters.Add("@moneda", SqlDbType.NVarChar,3).Value = moneda;
            da.SelectCommand.Parameters.Add("@tipoventa", SqlDbType.NVarChar,2).Value = tipoventa;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_Cot_Stock(string codart)
        {
            //Recupera stock (SIS,SHO,SQO) y costo de los articulos que componen un kit
            SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_Stock", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@codart", SqlDbType.NChar,10).Value = codart;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_Cot_Art(string filtro, string moneda, string tipoventa )
        {
            //Recupera stock (SIS,SHO,SQO) y costo de los articulos que componen un kit
            SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_ArtSim", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NChar, 120).Value = filtro;
            da.SelectCommand.Parameters.Add("@moneda", SqlDbType.NChar, 3).Value = moneda;
            da.SelectCommand.Parameters.Add("@tipoventa", SqlDbType.NChar, 2).Value = tipoventa;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public byte VEN_Cot_CodTipArtCom(Int32 CodArtCom)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            byte CodTipArtCom = 0;

            using (SqlCommand cmd = new SqlCommand("select CodTipArtCom from ArtCom where CodArtCom = @codartcom", cnx))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@codartcom", SqlDbType.Int).Value = CodArtCom;
                cnx.Open();

                if (cmd.ExecuteScalar() != null)
                {
                    CodTipArtCom = (byte)cmd.ExecuteScalar();
                }

                return CodTipArtCom;

            }
        }

        public decimal VEN_Cot_RecTipCam()
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (SqlCommand cmd = new SqlCommand("SELECT TipCam FROM VEN_Cot_TipCam WHERE Valido = 1", cnx))
            {
                cmd.CommandType = CommandType.Text;
                cnx.Open();

                if (cmd.ExecuteScalar() != null)
                {
                    return (decimal)cmd.ExecuteScalar();                
                }
                else
                {
                    return 0;
                }

            }
        }

        public byte VEN_Cot_ValCodArtCom(Int32 CodArtCom)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (SqlCommand cmd = new SqlCommand("select CodArtCom from ArtCom where CodArtCom = @codartcom", cnx))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@codartcom", SqlDbType.Int).Value = CodArtCom;
                cnx.Open();

                return (byte)cmd.ExecuteScalar();
            }
        }

        public Int16 VEN_Cot_CodGruArt(string CodArt)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            Int16 CodGruArt = 0;

            using (SqlCommand cmd = new SqlCommand("VEN_Cot_CodTipArt", cnx))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@codart", SqlDbType.NVarChar,9).Value = CodArt;
                cnx.Open();

                if (cmd.ExecuteScalar() != null)
                {
                    CodGruArt = (Int16)cmd.ExecuteScalar();
                }

                return CodGruArt;
            }
        }

        public void VEN_Cot_ingact(VEN_Cot Enc, Int64 NumMovCotOri)
        {
            using(SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using(SqlCommand cmd = new SqlCommand("VEN_Cot_Enc_actgua", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Clear();
                    //
                    SqlParameter paramNumMov = new SqlParameter("@nummov", SqlDbType.Int);
                    paramNumMov.Direction = ParameterDirection.InputOutput;
                    paramNumMov.Value = Enc.NumMov;
                    //                    
                    SqlParameter paramNumCot = new SqlParameter("@numcot", SqlDbType.NVarChar,10);
                    paramNumCot.Direction = ParameterDirection.InputOutput;
                    paramNumCot.Value = Enc.NumCot;
                    //
                    cmd.Parameters.Add(paramNumMov);
                    cmd.Parameters.Add(paramNumCot);
                    cmd.Parameters.Add("@estdoc", SqlDbType.TinyInt).Value = Enc.EstDoc;
                    cmd.Parameters.Add("@CardCode", SqlDbType.NVarChar, 15).Value = Enc.CardCode;
                    cmd.Parameters.Add("@NomCli", SqlDbType.NVarChar, 100).Value = Enc.NomCli;
                    cmd.Parameters.Add("@DirCli", SqlDbType.NVarChar, 200).Value = Enc.DirCli;
                    cmd.Parameters.Add("@DirObr", SqlDbType.NVarChar, 200).Value = Enc.DirObr;
                    cmd.Parameters.Add("@CntctCode", SqlDbType.Int).Value = Enc.CntctCode;
                    cmd.Parameters.Add("@SlpCode", SqlDbType.Int).Value = Enc.SlpCode;
                    cmd.Parameters.Add("@u_syp_c_venta", SqlDbType.NVarChar, 10).Value = Enc.U_SYP_C_VENTA;
                    cmd.Parameters.Add("@u_syp_tiventa", SqlDbType.NVarChar, 10).Value = Enc.U_SYP_TIVENTA;
                    cmd.Parameters.Add("@u_syp_rq", SqlDbType.NVarChar, 12).Value = Enc.U_SYP_RQ;
                    cmd.Parameters.Add("@u_syp_tventa_rel", SqlDbType.NVarChar, 20).Value = Enc.U_SYP_TVENTA_REL;
                    cmd.Parameters.Add("@u_syp_rubro", SqlDbType.NVarChar, 20).Value = Enc.U_SYP_RUBRO;
                    cmd.Parameters.Add("@u_syp_tipo_obra", SqlDbType.NVarChar, 20).Value = Enc.U_SYP_TIPO_OBRA;
                    cmd.Parameters.Add("@u_syp_dimension", SqlDbType.NVarChar, 20).Value = Enc.U_SYP_DIMENSION;
                    cmd.Parameters.Add("@u_syp_nom_venta", SqlDbType.NVarChar, 400).Value = Enc.U_SYP_NOM_VENTA;
                    cmd.Parameters.Add("@codigocontacto", SqlDbType.Int).Value = Enc.CodCon;
                    cmd.Parameters.Add("@DocCur", SqlDbType.NVarChar, 3).Value = Enc.DocCur;
                    cmd.Parameters.Add("@DocRate", SqlDbType.Decimal).Value = Enc.DocRate;
                    cmd.Parameters.Add("@PorIGV", SqlDbType.Decimal).Value = Enc.PorIGV;
                    cmd.Parameters.Add("@CodUsu", SqlDbType.Int).Value = Enc.CodUsu;
                    cmd.Parameters.Add("@Tel", SqlDbType.NVarChar, 50).Value = Enc.Tel;
                    cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 50).Value = Enc.Email;
                    cmd.Parameters.Add("@u_trz_tie", SqlDbType.NVarChar, 50).Value = Enc.U_TRZ_TIE;
                    cmd.Parameters.Add("@u_trz_opcpag", SqlDbType.NVarChar, 50).Value = Enc.U_TRZ_OPCPAG;
                    cmd.Parameters.Add("@nomadi", SqlDbType.NVarChar, 150).Value = Enc.NomAdi;
                    cmd.Parameters.Add("@codmot", SqlDbType.SmallInt).Value = Enc.CodMot;
                    cmd.Parameters.Add("@codadmrq", SqlDbType.SmallInt).Value = Enc.CodAdmRQ;
                    cmd.Parameters.Add("@codrecfalen", SqlDbType.TinyInt).Value = Enc.CodRecFalEn;
                    cmd.Parameters.Add("@codreclinpro", SqlDbType.TinyInt).Value = Enc.CodRecLinPro;
                    cmd.Parameters.Add("@codrectip", SqlDbType.TinyInt).Value = Enc.CodRecTip;
                    cmd.Parameters.Add("@codrecsublin", SqlDbType.TinyInt).Value = Enc.CodRecSubLin;
                    cmd.Parameters.Add("@codrecfam", SqlDbType.TinyInt).Value = Enc.CodRecFam;
                    //
                    cnx.Open();
                    //
                    int rowsAffected = cmd.ExecuteNonQuery();
                    //
                    Enc.NumMov = Convert.ToInt64(cmd.Parameters["@nummov"].Value);
                    Enc.NumCot = cmd.Parameters["@numcot"].Value.ToString();

                }

                //Eliminamos los diferentes detalles para volver a agregarlos
                using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotAmb WHERE NumMov = @nummov", cnx))
                {
                    cmd.CommandType = CommandType.Text;   
                                     
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotCom WHERE NumMov = @nummov", cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotDet WHERE NumMov = @nummov",cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotDetAA WHERE NumMov = @nummov", cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotAmbAS WHERE NumMov = @nummov", cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotDetAS WHERE NumMov = @nummov", cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                //Insertamos detalle de kits
                using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotDet (NumMov,CodArtCom,Can,PreUni, VenBru,PorDes,Desct,ValNet,IGV,SubTot,Obs,Sim) VALUES 
                                                        (@nummov, @codartcom, @can, @preuni, @venbru, @pordes, @desct, @valnet, @igv, @subtot, @obs, @sim)", cnx))
                {
                    foreach (VEN_Cot_Det Det in Enc.Det)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@codartcom", SqlDbType.Int).Value = Det.CodArtCom;
                        cmd.Parameters.Add("@can", SqlDbType.Decimal).Value = Det.Can;
                        cmd.Parameters.Add("@preuni", SqlDbType.Decimal).Value = Det.PreUni;
                        cmd.Parameters.Add("@venbru", SqlDbType.Decimal).Value = Det.VenBru;
                        cmd.Parameters.Add("@pordes", SqlDbType.Decimal).Value = Det.PorDes;
                        cmd.Parameters.Add("@desct", SqlDbType.Decimal).Value = Det.Desct;
                        cmd.Parameters.Add("@valnet", SqlDbType.Decimal).Value = Det.ValNet;
                        cmd.Parameters.Add("@igv", SqlDbType.Decimal).Value = Det.IGV;
                        cmd.Parameters.Add("@subtot", SqlDbType.Decimal).Value = Det.SubTot;
                        cmd.Parameters.Add("@obs", SqlDbType.NVarChar, 200).Value = Det.Obs;
                        cmd.Parameters.Add("@sim", SqlDbType.NVarChar, 7).Value = Det.Sim;

                        cmd.ExecuteNonQuery();
                    }

                }

                //Ambientes de Detalles de kit
                using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotAmb (NumMov,CodArtCom,CodAmb,Can) Values 
                                                        (@nummov, @codartcom, @codamb, @can)", cnx))
                {
                    foreach (VEN_Cot_DetAmb DetAmb in Enc.DetAmb)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@codartcom", SqlDbType.Int).Value = DetAmb.CodArtCom;
                        cmd.Parameters.Add("@codamb", SqlDbType.Int).Value = DetAmb.CodAmb;
                        cmd.Parameters.Add("@can",SqlDbType.Decimal).Value = DetAmb.Can;

                        cmd.ExecuteNonQuery();
                    }
                                       
                }

                //Componentes de Detalles de kit
                using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotCom (NumMov,CodArtCom,CodArt,Can,PreUni) Values 
                                                        (@nummov, @codartcom, @codart, @can, @preuni)", cnx))
                {
                    foreach (VEN_Cot_DetCom DetCom in Enc.DetCom)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@codartcom", SqlDbType.Int).Value = DetCom.CodArtCom;
                        cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = DetCom.CodArt;
                        cmd.Parameters.Add("@can", SqlDbType.Decimal).Value = DetCom.Can;
                        cmd.Parameters.Add("@preuni", SqlDbType.Decimal).Value = DetCom.PreUni;

                        cmd.ExecuteNonQuery();
                    }

                }

                //Detalle de articulos alternativos AA
                using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotDetAA (NumMov,DesAA,Can,PreUni,VenBru,
                                                        PorDes,Desct,ValNet,IGV,SubTot,CodAmb,RutIma,RutIma2,
                                                        RutImaTec,Obs,CosUni) VALUES (@nummov, @desaa, @can,
                                                        @preuni, @venbru, @pordes, @desct, @valnet, @igv,
                                                        @subtot, @codamb, @rutima, @rutima2, @rutimatec, @obs,  
                                                        @cosuni)", cnx))
                {
                    foreach (VEN_Cot_DetAA DetAA in Enc.DetAA)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@desaa", SqlDbType.NVarChar, 100).Value = DetAA.DesAA;
                        cmd.Parameters.Add("@can", SqlDbType.Decimal).Value = DetAA.Can;
                        cmd.Parameters.Add("@preuni", SqlDbType.Decimal).Value = DetAA.PreUni;
                        cmd.Parameters.Add("@venbru", SqlDbType.Decimal).Value = DetAA.VenBru;
                        cmd.Parameters.Add("@pordes", SqlDbType.Decimal).Value = DetAA.PorDes;
                        cmd.Parameters.Add("@desct", SqlDbType.Decimal).Value = DetAA.Desct;
                        cmd.Parameters.Add("@valnet", SqlDbType.Decimal).Value = DetAA.ValNet;
                        cmd.Parameters.Add("@igv", SqlDbType.Decimal).Value = DetAA.IGV;
                        cmd.Parameters.Add("@subtot", SqlDbType.Decimal).Value = DetAA.SubTot;
                        cmd.Parameters.Add("@codamb", SqlDbType.Int).Value = DetAA.CodAmb;
                        cmd.Parameters.Add("@rutima", SqlDbType.NVarChar, 100).Value = DetAA.RutIma;
                        cmd.Parameters.Add("@rutima2", SqlDbType.NVarChar, 100).Value = DetAA.RutIma2;
                        cmd.Parameters.Add("@rutimatec", SqlDbType.NVarChar, 100).Value = DetAA.RutImaTec;
                        cmd.Parameters.Add("@obs", SqlDbType.NVarChar, 200).Value = DetAA.Obs;
                        cmd.Parameters.Add("@cosuni", SqlDbType.Decimal).Value = DetAA.CosUni;

                        cmd.ExecuteNonQuery();
                    }

                }

                //Detalle de articulos simples
                using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotDetAS (NumMov,CodArt,Can,PreUni, VenBru,PorDes,Desct,ValNet,IGV,SubTot,Obs) VALUES 
                                                        (@nummov, @codart, @can, @preuni, @venbru, @pordes, @desct, @valnet, @igv, @subtot, @obs)", cnx))
                {
                    foreach (VEN_Cot_DetAS DetAS in Enc.DetAS)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = DetAS.CodArt;
                        cmd.Parameters.Add("@can", SqlDbType.Decimal).Value = DetAS.Can;
                        cmd.Parameters.Add("@preuni", SqlDbType.Decimal).Value = DetAS.PreUni;
                        cmd.Parameters.Add("@venbru", SqlDbType.Decimal).Value = DetAS.VenBru;
                        cmd.Parameters.Add("@pordes", SqlDbType.Decimal).Value = DetAS.PorDes;
                        cmd.Parameters.Add("@desct", SqlDbType.Decimal).Value = DetAS.Desct;
                        cmd.Parameters.Add("@valnet", SqlDbType.Decimal).Value = DetAS.ValNet;
                        cmd.Parameters.Add("@igv", SqlDbType.Decimal).Value = DetAS.IGV;
                        cmd.Parameters.Add("@subtot", SqlDbType.Decimal).Value = DetAS.SubTot;
                        cmd.Parameters.Add("@obs", SqlDbType.NVarChar, 200).Value = DetAS.Obs;                      

                        cmd.ExecuteNonQuery();
                    }

                }

                //Ambientes de Detalles de articulo simple
                using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotAmbAS (NumMov,CodArt,CodAmb,Can) Values 
                                                        (@nummov, @codart, @codamb, @can)", cnx))
                {
                    foreach (VEN_Cot_DetAmbAS DetAmbAS in Enc.DetAmbAS)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = DetAmbAS.CodArt;
                        cmd.Parameters.Add("@codamb", SqlDbType.Int).Value = DetAmbAS.CodAmb;
                        cmd.Parameters.Add("@can", SqlDbType.Decimal).Value = DetAmbAS.Can;

                        cmd.ExecuteNonQuery();
                    }
                }

                if (NumMovCotOri != 0) //Copiar orden de ambientes de cotizacion original si se esta duplicando una.
                {                    
                    using (SqlCommand cmd = new SqlCommand("VEN_Cot_CopAmbCotOri", cnx))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummovcotori", SqlDbType.Int).Value = NumMovCotOri;
                        cmd.Parameters.Add("@nummovcotfin", SqlDbType.Int).Value = Enc.NumMov;

                        cmd.ExecuteNonQuery();
                        
                    }
                }
 

            }
        }

        public Int16 VEN_Cot_ValCenVen(Int32 codemp, string codcenven)
        {
            //Valida Centro de venta
            using(SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("VEN_Cot_EmpCenVen_rec", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@codemp", SqlDbType.SmallInt).Value = codemp;
                    cmd.Parameters.Add("@codcenven",SqlDbType.NVarChar, 10).Value = codcenven;
                    cmd.Parameters.Add("@valor", SqlDbType.TinyInt).Value = 0;
                    
                    cnx.Open();
         
                    return Convert.ToInt16(cmd.ExecuteScalar());
                }
            }            
        }

        public decimal VEN_Cot_ConPreVen(Int64 nummov, string codart, string codmon)
        {
            //Devuelve el precio de la lista de precios
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("VEN_Cot_ConPreVen", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                    cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = codart;
                    cmd.Parameters.Add("@moneda", SqlDbType.NVarChar,3).Value = codmon;

                    cnx.Open();

                    return Convert.ToDecimal(cmd.ExecuteScalar());
                }
            }
        }

        public Int16 VEN_Cot_ValInfRec(string codcenven, Int16 tip, Int16 cod, Int16 codret)
        {
            //Valida Info Reclamos
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("VEN_Cot_Rec_ValInf", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@codcenven", SqlDbType.NVarChar, 10).Value = codcenven;
                    cmd.Parameters.Add("@tip", SqlDbType.TinyInt).Value = tip;
                    cmd.Parameters.Add("@cod", SqlDbType.TinyInt).Value = cod;

                    SqlParameter paramCodRet = new SqlParameter("@codret", SqlDbType.TinyInt);
                    paramCodRet.Direction = ParameterDirection.InputOutput;
                    paramCodRet.Value = codret;

                    cmd.Parameters.Add(paramCodRet);

                    cnx.Open();
           
                    cmd.ExecuteNonQuery();

                    return Convert.ToInt16(paramCodRet.Value);

                }
            }
        }

        public DataTable VEN_Cot_ValTipVenyOtr(Int16 Tipo, string TipVen, string TipVenRel, string Rubro, string TipObr, string Dim)
        {
            //Validar Tipo Venta y Otros
            string Cadena = "";

            if(Tipo == 1)
            {
                if (TipVenRel == "")
                {
                    Cadena = @"SELECT DISTINCT U_SYP_TVTA_RELATIVO 
                                FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS] 
                                WHERE U_SYP_COD_TIPO = @tipven";
                }
                else
                {
                    Cadena = @"SELECT * 
                              FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS]
                              WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel";
                }

            }

            if (Tipo == 2)
            {
                if (Rubro == "")
                {
                    Cadena = @"SELECT DISTINCT U_SYP_RUBRO 
                                FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS] 
                                WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel";
                }
                else
                {
                    Cadena = @"SELECT * 
                              FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS]
                              WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel AND U_SYP_RUBRO = @rubro";
                }

            }

            if (Tipo == 3)
            {
                if (TipObr == "")
                {
                    Cadena = @"SELECT DISTINCT U_SYP_TIPO_OBRA 
                                FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS] 
                                WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel AND U_SYP_RUBRO = @rubro";
                }
                else
                {
                    Cadena = @"SELECT * 
                              FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS]
                              WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel AND U_SYP_RUBRO = @rubro AND U_SYP_TIPO_OBRA = @tipobr";
                }

            }

            if (Tipo == 4)
            {
                if (Dim == "")
                {
                    Cadena = @"SELECT DISTINCT U_SYP_DIMENSION 
                                FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS] 
                                WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel AND U_SYP_RUBRO = @rubro AND U_SYP_TIPO_OBRA = @tipobr";
                }
                else
                {
                    Cadena = @"SELECT * 
                              FROM SBO_TRAZ_PROD.dbo.[@SYP_TIPO_VENTAS]
                              WHERE U_SYP_COD_TIPO = @tipven AND U_SYP_TVTA_RELATIVO = @tipvenrel AND U_SYP_RUBRO = @rubro AND U_SYP_TIPO_OBRA = @tipobr and U_SYP_DIMENSION = @dim";
                }

            }


            SqlDataAdapter da = new SqlDataAdapter(Cadena, cnx);

            da.SelectCommand.CommandType = CommandType.Text;

            if (Tipo == 1)
            {
                if (TipVenRel == "")
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                }
                else
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                }
            }

            if (Tipo == 2)
            {
                if (Rubro == "")
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                }
                else
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                    da.SelectCommand.Parameters.Add("@rubro", SqlDbType.NVarChar, 50).Value = Rubro;
                }
            }

            if (Tipo == 3)
            {
                if (TipObr == "")
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                    da.SelectCommand.Parameters.Add("@rubro", SqlDbType.NVarChar, 50).Value = Rubro;
                }
                else
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                    da.SelectCommand.Parameters.Add("@rubro", SqlDbType.NVarChar, 50).Value = Rubro;
                    da.SelectCommand.Parameters.Add("@tipobr", SqlDbType.NVarChar, 50).Value = TipObr;
                }
            }

            if (Tipo == 4)
            {
                if (Dim == "")
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                    da.SelectCommand.Parameters.Add("@rubro", SqlDbType.NVarChar, 50).Value = Rubro;
                    da.SelectCommand.Parameters.Add("@tipobr", SqlDbType.NVarChar, 50).Value = TipObr;
                }
                else
                {
                    da.SelectCommand.Parameters.Add("@tipven", SqlDbType.NVarChar, 10).Value = TipVen;
                    da.SelectCommand.Parameters.Add("@tipvenrel", SqlDbType.NVarChar, 50).Value = TipVenRel;
                    da.SelectCommand.Parameters.Add("@rubro", SqlDbType.NVarChar, 50).Value = Rubro;
                    da.SelectCommand.Parameters.Add("@tipobr", SqlDbType.NVarChar, 50).Value = TipObr;
                    da.SelectCommand.Parameters.Add("@dim", SqlDbType.NVarChar, 50).Value = Dim;
                }
            }

            DataTable dt = new DataTable();

            da.Fill(dt);

            return dt;
            
        }

        public string VEN_Cot_RecNomAdi(Int64 nummov)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (SqlCommand cmd = new SqlCommand("SELECT NomAdi FROM VEN_Cot WHERE NumMov = @nummov", cnx))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                cnx.Open();

                return cmd.ExecuteScalar().ToString();
            }
        }

        public DataSet VEN_Cot_rec(Int64 nummov)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                //Encabezado de cotizacion
                SqlDataAdapter daVEN_Cot_Enc = new SqlDataAdapter("VEN_CotEnc_rec", cnx);
                daVEN_Cot_Enc.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_Enc.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Detalle de kits
                SqlDataAdapter daVEN_Cot_Det = new SqlDataAdapter("VEN_CotDet_rec", cnx);
                daVEN_Cot_Det.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_Det.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Componentes de kits
                SqlDataAdapter daVEN_Cot_DetCom = new SqlDataAdapter("VEN_CotCom_rec", cnx);
                daVEN_Cot_DetCom.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_DetCom.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Ambientes de kits
                SqlDataAdapter daVEN_Cot_DetAmb = new SqlDataAdapter("VEN_CotAmb_rec", cnx);
                daVEN_Cot_DetAmb.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_DetAmb.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Articulos Alternativos
                SqlDataAdapter daVEN_Cot_DetAA = new SqlDataAdapter("VEN_CotDetAA_rec", cnx);
                daVEN_Cot_DetAA.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_DetAA.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Encabezado de cotizacion
                SqlDataAdapter daVEN_Cot_ArtDet = new SqlDataAdapter("VEN_CotDetAS_rec", cnx);
                daVEN_Cot_ArtDet.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_ArtDet.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                //Ambientes de kits
                SqlDataAdapter daVEN_Cot_ArtAmb = new SqlDataAdapter("VEN_CotAmbAS_rec", cnx);
                daVEN_Cot_ArtAmb.SelectCommand.CommandType = CommandType.StoredProcedure;
                daVEN_Cot_ArtAmb.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                DataSet ds = new DataSet();

                daVEN_Cot_Enc.Fill(ds, "Cot_Enc");
                daVEN_Cot_Det.Fill(ds, "Cot_Det");
                daVEN_Cot_DetCom.Fill(ds, "Cot_DetCom");
                daVEN_Cot_DetAmb.Fill(ds, "Cot_DetAmb");
                daVEN_Cot_DetAA.Fill(ds, "Cot_DetAA");
                daVEN_Cot_ArtDet.Fill(ds, "Cot_DetAS");
                daVEN_Cot_ArtAmb.Fill(ds, "Cot_DetAmbAS");

                return (ds);

            }
        }

        public DataTable VEN_Cot_Amb_orden(Int64 nummov)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_CotAmb_paorden",cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;

            }
        }

        public bool VEN_Cot_Validar_UsuApr(Int32 codusu)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (cnx)
            {
                SqlCommand cmd = new SqlCommand("SELECT CodUsu FROM VEN_Cot_UsuApr WHERE CodUsu = @codusu", cnx);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                cnx.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }

        public void VEN_Cot_ActCotApr(Int64 nummov, Int32 codusu)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);
           
            using(SqlCommand cmd = new SqlCommand(@"update VEN_cOT set EstDoc = 2,
                                                                        EstApr = 1,
                                                                        FecApr = getdate(),
                                                                        CodUsuApr = @codusu
                                                    where nummov = @nummov", cnx))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                cnx.Open();

                cmd.ExecuteNonQuery();
            }            
        }

        public DataTable VEN_Cot_RecValCotMig(Int64 docentry)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_ActValSAP", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Clear();
                da.SelectCommand.Parameters.Add("@docentry", SqlDbType.Int).Value = docentry;

                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;
            }
        }

        public void VEN_Cot_ActCotMig(Int32 codadmrq, Int32 codusu, Int32 rq, Int64 docentry, Int64 docnum, Int64 nummov)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (SqlCommand cmd = new SqlCommand(@"update VEN_Cot set CodAdmRQ = @codadmrq,
                                                                        EstMigSAP = 1,
                                                                        CodUsuMigSAP = @codusu,
                                                                        FecMigSAP = getdate(),
                                                                        U_SYP_RQ = @rq,
                                                                        DocEntrySAP = @docentry,
                                                                        DocNumSAP = @docnum,                                                                            
                                                                        CodUsuMod = @codusu,
                                                                        FecMod = getdate()
                                                    where nummov = @nummov", cnx))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@codadmrq", SqlDbType.SmallInt).Value = codadmrq;
                cmd.Parameters.Add("@rq", SqlDbType.Int).Value = rq;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                cmd.Parameters.Add("@docentry", SqlDbType.Int).Value = docentry;
                cmd.Parameters.Add("@docnum", SqlDbType.Int).Value = docnum;
                cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                cnx.Open();

                cmd.ExecuteNonQuery();
            }
        }

        public DataTable VEN_Cot_ValImp(Int64 nummov)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_ValImp_rec", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Clear();
                da.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;
            }
        }

        public DataTable VEN_Cot_ValImpAmb(Int64 nummov)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_CotAmb_paorden", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Clear();
                da.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;
            }
        }

        public void VEN_Cot_AmbOrden(VEN_Cot_AmbOrd AmbOrd)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            cnx.Open();

            using (SqlCommand cmd = new SqlCommand("DELETE VEN_CotAmb_orden WHERE NumMov = @nummov", cnx))
            {
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.Clear();
                cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = AmbOrd.NumMov;

                cmd.ExecuteNonQuery();
            }

            using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_CotAmb_orden 
                                                                            (NumMov, 
                                                                            CodAmb, 
                                                                            Orden)  
                                                                            VALUES 
                                                                            (@nummov,
                                                                            @codamb,
                                                                            @orden)", cnx))
            {
                cmd.CommandType = CommandType.Text;

                foreach (VEN_Cot_AmbOrd Amb in AmbOrd.AmbOrd)
                {
                    
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Amb.NumMov;
                    cmd.Parameters.Add("@codamb", SqlDbType.Int).Value = Amb.CodAmb;
                    cmd.Parameters.Add("@orden", SqlDbType.TinyInt).Value = Amb.Orden;

                    cmd.ExecuteNonQuery();
                }                           
                
            }
        }

        public void VEN_Cot_ValImpCon(Int64 nummov, Int16 ade, Int16 conent, string con01, string con02, Int32 codusu)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            cnx.Open();

            using (SqlCommand cmd = new SqlCommand("DELETE VEN_Cot_ValImp WHERE NumMov = @nummov", cnx))
            {
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.Clear();
                cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                cmd.ExecuteNonQuery();
            }

            using (SqlCommand cmd = new SqlCommand(@"INSERT INTO VEN_Cot_ValImp 
                                                                        (NumMov,
                                                                        Adelanto,
                                                                        Contraentrega,
                                                                        Condicion01,
                                                                        Condicion02,
                                                                        CodUsu,
                                                                        Fec)
                                                                        VALUES
                                                                        (@nummov,
                                                                        @ade,
                                                                        @conent,
                                                                        @con01,
                                                                        @con02,                                                                        
                                                                        @codusu,
                                                                        getdate())", cnx))

            {
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                cmd.Parameters.Add("@ade", SqlDbType.SmallInt).Value = ade;
                cmd.Parameters.Add("@conent", SqlDbType.SmallInt).Value = conent;
                cmd.Parameters.Add("@con01", SqlDbType.NVarChar,800).Value = con01;
                cmd.Parameters.Add("@con02", SqlDbType.NVarChar,800).Value = con02;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                
                cmd.ExecuteNonQuery();
            }
        }

        public decimal VEN_Cot_NivDes(Int32 codusu)
        {
            //Nivel de descuento de los usuarios
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            decimal Des = 0;

            using (cnx)
            {
                SqlCommand cmd = new SqlCommand("SELECT PorDes FROM VEN_Cot_NivDes Where CodEmp = @codusu", cnx);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                cnx.Open();

                decimal.TryParse(cmd.ExecuteScalar().ToString(), out Des);

                return Des;

            }
        }

        public decimal VEN_Cot_NivDesArtCom(Int32 codartcom)
        {
            //Nivel de descuento de los usuarios
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            decimal Des = 0;

            using (cnx)
            {
                SqlCommand cmd = new SqlCommand("Select PorDes From ArtCom Where CodTipArtCom = 1 and CodArtCom = @codartcom", cnx);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@codartcom", SqlDbType.Int).Value = codartcom;

                cnx.Open();

                if (cmd.ExecuteScalar() != null)
                {
                    decimal.TryParse(cmd.ExecuteScalar().ToString(), out Des);
                }                

                return Des;

            }
        }

        public decimal VEN_CotDetAS_Cos(string codart, string moneda)
        {
            //Nivel de descuento de los usuarios
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            decimal Costo = 0;

            using (cnx)
            {
                SqlCommand cmd = new SqlCommand("VEN_CotDetAS_Cos", cnx);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = codart;
                cmd.Parameters.Add("@moneda", SqlDbType.NVarChar, 3).Value = moneda;

                cnx.Open();

                if (cmd.ExecuteScalar() != null)
                {
                    decimal.TryParse(cmd.ExecuteScalar().ToString(), out Costo);
                }

                return Costo;

            }
        }

    }
}
