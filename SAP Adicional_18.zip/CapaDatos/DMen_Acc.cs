﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades.Men_Acc;
using CapaDatos;
using System.Globalization;
using C1.Win.C1FlexGrid;

namespace CapaDatos
{
    public class DMen_Acc
    {
        public SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena);
        public DataTable Men_Acc_Filtros(string vista,string procedimiento,string param1)
        {
            using (SqlDataAdapter da = new SqlDataAdapter(procedimiento,cn)) //variable
            {
                da.SelectCommand.CommandType = CommandType.StoredProcedure;

                switch (vista)
                {
                    case "Empleado/Usuario":
                        da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param1;
                        break;
                    case "Empleado2/Usuario2":
                        da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param1;
                        break;
                    case "Area":
                        da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 50).Value = param1;
                        break;

                }

                DataTable dt = new DataTable();
                dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                da.Fill(dt);
                return dt;
            }
            
        }

        public DataTable RecMenUsu(Int16 CodUsu,Int16 valor)
        {
            using (SqlDataAdapter AccMen = new SqlDataAdapter("Menus_AccesoUsuario",cn))
            {
                AccMen.SelectCommand.CommandType = CommandType.StoredProcedure;
                AccMen.SelectCommand.Parameters.Add("@CodigoUsuario", SqlDbType.SmallInt).Value = CodUsu;
                AccMen.SelectCommand.Parameters.Add("@Valor", SqlDbType.Bit).Value = Convert.ToInt16(valor);
                DataTable dt = new DataTable();
                dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                AccMen.Fill(dt);
                return dt;
            }
        }

        public DataTable RecKeyNod(string KeyNod)
        {
            using (SqlDataAdapter daRecKeyNod = new SqlDataAdapter("SELECT Codigo, Menu, NivelSuperior, Notacion, Relacion," +
                                                                    "NotacionSuperior, Formulario from Menus where Notacion=@not", cn))
            {
                daRecKeyNod.SelectCommand.CommandType = CommandType.Text;
                daRecKeyNod.SelectCommand.Parameters.Add("@not",SqlDbType.NVarChar,50).Value = KeyNod;
                DataTable dt = new DataTable();
                dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                daRecKeyNod.Fill(dt);
                return dt;
            }
        }
        public void MenAccInsEli(MenuAcc_Enc MenAccIns, int NodChe)
        {
            if (NodChe == 1)
            {

                using (SqlCommand InsMen = new SqlCommand("insert into Menus_Accesos(CodigoUsuario,CodigoMenu,FechaIngreso,CodigoUsuarioResponsable,ValorPerfil)" +
                                                    "values(@codUsu,@CodMen,@FecIng,@CodUsuRes,@ValPer)", cn))
                {
                    cn.Open();
                    InsMen.CommandType = CommandType.Text;
                    InsMen.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = MenAccIns.CodUsu;
                    InsMen.Parameters.Add("@CodMen", SqlDbType.SmallInt).Value = MenAccIns.CodMen;
                    InsMen.Parameters.Add("@FecIng", SqlDbType.SmallDateTime).Value = MenAccIns.FecIng;
                    InsMen.Parameters.Add("@CodUsuRes", SqlDbType.SmallInt).Value = MenAccIns.CodUsu;
                    InsMen.Parameters.Add("@ValPer", SqlDbType.TinyInt).Value = Convert.ToInt16(MenAccIns.SelPer);
                    InsMen.ExecuteNonQuery();
                    cn.Close();
                }
            }
            else
            {

                using (SqlCommand EliMen = new SqlCommand("DELETE Menus_Accesos WHERE CodigoMenu = @codMenu and CodigoUsuario=@codUsu", cn))
                {
                    cn.Open();
                    EliMen.CommandType = CommandType.Text;
                    EliMen.Parameters.Add("@codMenu", SqlDbType.SmallInt).Value = MenAccIns.CodMen;
                    EliMen.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = MenAccIns.CodUsu;
                    EliMen.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }
        public void Men_Accesos_CopiarAccesos(MenuAcc_Enc Enc)
        {
            using (SqlCommand cmdAcc = new SqlCommand("Menus_Accesos_CopAcc", cn))
            {
                cn.Open();
                cmdAcc.CommandType = CommandType.StoredProcedure;
                cmdAcc.Parameters.Add("@CodUsuOri", SqlDbType.Int).Value = Enc.CodUsuOri;
                cmdAcc.Parameters.Add("@CodUsuDes", SqlDbType.Int).Value = Enc.CodUsuDes;
                cmdAcc.ExecuteNonQuery();
                cn.Close();
            }
        }
        public int Men_Accesos_ValNod(int CodUsu,string NotSup)
        {
            SqlDataAdapter daValNod = new SqlDataAdapter("Menus_Acceso_RecNod", cn);
            daValNod.SelectCommand .CommandType = CommandType.StoredProcedure;
            daValNod.SelectCommand.Parameters.Add("@CodUsu", SqlDbType.Int).Value = CodUsu;
            daValNod.SelectCommand.Parameters.Add("@NotSup", SqlDbType.NVarChar).Value = NotSup;

            DataTable dtValNod = new DataTable();
            dtValNod.Locale = CultureInfo.InvariantCulture;
            daValNod.Fill(dtValNod);
            return dtValNod.Rows.Count;
        }
    }
}
