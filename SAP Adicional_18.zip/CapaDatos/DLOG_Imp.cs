﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Entidades.LOG_Imp;

namespace CapaDatos
{
    public class DLOG_Imp
    {
        SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena);

        public byte GEN_For_ConAcc(Int16 CodUsu, Int16 CodDoc, string Cam, byte Acc)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdAcc = new SqlCommand("GEN_For_ConAcc", cnx))
                {
                    cmdAcc.Connection.Open();
                    cmdAcc.CommandType = CommandType.StoredProcedure;
                    cmdAcc.Parameters.Add("@CodEmp", SqlDbType.SmallInt).Value = CodUsu;
                    cmdAcc.Parameters.Add("@CodDoc", SqlDbType.SmallInt).Value = CodDoc;
                    cmdAcc.Parameters.Add("@Campo", SqlDbType.NVarChar, 10).Value = Cam;

                    var accParam = new SqlParameter();
                    accParam = cmdAcc.Parameters.Add("@Acc", SqlDbType.TinyInt);
                    accParam.Direction = ParameterDirection.InputOutput;
                    accParam.Value = Acc;
                    return (byte)cmdAcc.ExecuteScalar();
                }
            }
        }

        public DataSet LOG_Imp_DetImp(Int16 NumMov)
        {
            DataSet ds = new DataSet();
            DataTable dtRecDet = new DataTable();

            SqlDataAdapter daImpDetRec = new SqlDataAdapter("LOG_Imp_Enc_rec", cn);
            daImpDetRec.SelectCommand.CommandType = CommandType.StoredProcedure;
            daImpDetRec.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;

            daImpDetRec.Fill(ds, "Enc_Rec");

            SqlDataAdapter daImpDetComRec = new SqlDataAdapter("LOG_Imp_Det_rec", cn);
            daImpDetComRec.SelectCommand.CommandType = CommandType.StoredProcedure;
            daImpDetComRec.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;

            daImpDetComRec.Fill(ds, "Det_Rec");

            SqlDataAdapter daImpDetSinSto = new SqlDataAdapter("LOG_Imp_DetSinStock_rec", cn);
            daImpDetSinSto.SelectCommand.CommandType = CommandType.StoredProcedure;
            daImpDetSinSto.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;

            daImpDetSinSto.Fill(ds, "DetSinStock_Rec");
            
            return ds;
        }

        public void Log_Imp_AnuImp(Int16 CodUsu,int NumMov)
        {
            string consulta= "UPDATE LOG_Imp_Enc SET CodUsuMod = @codUsu,"+
                                             "EstDoc = 4,"+
                                             "FecMod = GETDATE() "+
                                             "WHERE NumMov = @numMov";

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdActImp = new SqlCommand(consulta, cnx))
                {
                    cmdActImp.Connection.Open();
                    cmdActImp.CommandType = CommandType.Text;
                    cmdActImp.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = CodUsu;
                    cmdActImp.Parameters.Add("@numMov",SqlDbType.Int).Value = NumMov;
                    cmdActImp.ExecuteNonQuery();
                    cmdActImp.Connection.Close();
                }
            }
        }

        public void Log_Imp_ProImp(Int16 CodUsu, int NumMov)
        {
            string consulta = "UPDATE LOG_Imp_Enc SET CodUsuMod = @codUsu," +
                                             "EstDoc = 8," +
                                             "FecMod = GETDATE() " +
                                             "WHERE NumMov = @numMov";

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdProImp = new SqlCommand(consulta, cnx))
                {
                    cmdProImp.Connection.Open();
                    cmdProImp.CommandType = CommandType.Text;
                    cmdProImp.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = CodUsu;
                    cmdProImp.Parameters.Add("@numMov", SqlDbType.Int).Value = NumMov;
                    cmdProImp.ExecuteNonQuery();
                    cmdProImp.Connection.Close();
                }
            }
        }

        public DataTable LOG_Imp_Filtros(string vista, string procedimiento, Int16 param2,string param)
        {
            SqlDataAdapter daImpRec = new SqlDataAdapter(procedimiento, cn);
            daImpRec.SelectCommand.CommandType = CommandType.StoredProcedure;

            switch (vista)
            {
                case "Proveedor":
                case "Envio":
                case "Estado Pago":
                case "Moneda":
                    daImpRec.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 50).Value = param;
                    break;
                case "Articulo":
                    daImpRec.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param;
                    daImpRec.SelectCommand.Parameters.Add("@Tipo", SqlDbType.SmallInt).Value = param2;
                    break;
                
                default:
                    break;
            }

            DataTable dtImpFiltro = new DataTable();
            daImpRec.Fill(dtImpFiltro);
            return dtImpFiltro;
        }

        public void LOG_Imp_Gua_EncDet(LOG_Imp_Enc Enc)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdEliDetsImp = new SqlCommand("LOG_Imp_Bor", cnx))
                {
                    cmdEliDetsImp.Connection.Open();
                    cmdEliDetsImp.CommandType = CommandType.StoredProcedure;
                    cmdEliDetsImp.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                    cmdEliDetsImp.ExecuteNonQuery();

                    SqlCommand cmdImpGuaEnc = new SqlCommand("LOG_Imp_Enc_ActGua", cnx);
                    cmdImpGuaEnc.CommandType = CommandType.StoredProcedure;

                    SqlParameter paraNumMov = new SqlParameter("@nummov", SqlDbType.Int);
                    paraNumMov.Direction = ParameterDirection.InputOutput;

                    SqlParameter paraImp = new SqlParameter("@numimp", SqlDbType.NVarChar, 9);
                    paraImp.Direction = ParameterDirection.InputOutput;

                    //encabezado
                    cmdImpGuaEnc.Parameters.Add(paraNumMov).Value = Enc.NumMov;
                    cmdImpGuaEnc.Parameters.Add(paraImp).Value = Enc.NumImp;
                    cmdImpGuaEnc.Parameters.Add("@fecemi", SqlDbType.SmallDateTime).Value = Enc.FecEmi;
                    cmdImpGuaEnc.Parameters.Add("@codpro", SqlDbType.NVarChar, 13).Value = Enc.CodPro;
                    cmdImpGuaEnc.Parameters.Add("@nompro", SqlDbType.NVarChar, 150).Value = Enc.Nompro;
                    cmdImpGuaEnc.Parameters.Add("@etd", SqlDbType.NVarChar, 10).Value = Enc.Etd;
                    cmdImpGuaEnc.Parameters.Add("@eta", SqlDbType.NVarChar, 10).Value = Enc.Eta;
                    cmdImpGuaEnc.Parameters.Add("@codforenv", SqlDbType.SmallInt).Value = Enc.CodForEnv;
                    cmdImpGuaEnc.Parameters.Add("@codestpag", SqlDbType.SmallInt).Value = Enc.CodEstPag;
                    cmdImpGuaEnc.Parameters.Add("@invoiceto", SqlDbType.NVarChar, 100).Value = Enc.InVoiTo;
                    cmdImpGuaEnc.Parameters.Add("@shipto", SqlDbType.NVarChar, 100).Value = Enc.Shipo;
                    cmdImpGuaEnc.Parameters.Add("@countryimport", SqlDbType.NVarChar, 100).Value = Enc.CouImp;
                    cmdImpGuaEnc.Parameters.Add("@ultimatedest", SqlDbType.NVarChar, 100).Value = Enc.UltDest;
                    cmdImpGuaEnc.Parameters.Add("@phone", SqlDbType.NVarChar, 50).Value = Enc.Pho;
                    cmdImpGuaEnc.Parameters.Add("@fax", SqlDbType.NVarChar, 50).Value = Enc.Fax;
                    cmdImpGuaEnc.Parameters.Add("@forwarder", SqlDbType.NVarChar, 100).Value = Enc.Fwd;
                    cmdImpGuaEnc.Parameters.Add("@address", SqlDbType.NVarChar, 100).Value = Enc.Adrs;
                    cmdImpGuaEnc.Parameters.Add("@forwarderphone", SqlDbType.NVarChar, 50).Value = Enc.FwdPho;
                    cmdImpGuaEnc.Parameters.Add("@forwarderfax", SqlDbType.NVarChar, 100).Value = Enc.FwdFax;
                    cmdImpGuaEnc.Parameters.Add("@email", SqlDbType.NVarChar, 50).Value = Enc.Ema;
                    cmdImpGuaEnc.Parameters.Add("@contactperson", SqlDbType.NVarChar, 50).Value = Enc.ConPer;
                    cmdImpGuaEnc.Parameters.Add("@paymentterms", SqlDbType.NVarChar, 200).Value = Enc.PayTer;
                    cmdImpGuaEnc.Parameters.Add("@labels", SqlDbType.NVarChar, 200).Value = Enc.Lbs;
                    cmdImpGuaEnc.Parameters.Add("@codmon", SqlDbType.SmallInt).Value = Enc.CodMon;
                    cmdImpGuaEnc.Parameters.Add("@fecest", SqlDbType.NVarChar, 10).Value = Enc.FecLleSqo;
                    cmdImpGuaEnc.Parameters.Add("@incoterm", SqlDbType.SmallInt).Value = Enc.IncTer;
                    cmdImpGuaEnc.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.IncTer;
                    cmdImpGuaEnc.Parameters.Add("@fecdisdes", SqlDbType.NVarChar, 10).Value = Enc.FecDisDes;
                    cmdImpGuaEnc.Parameters.Add("@nombarnumvue", SqlDbType.NVarChar, 50).Value = Enc.NomBar;
                    cmdImpGuaEnc.Parameters.Add("@awbbltra", SqlDbType.NVarChar, 50).Value = Enc.AwbTra;
                    cmdImpGuaEnc.Parameters.Add("@codconimpmar", SqlDbType.NVarChar, 50).Value = Enc.CodImp;
                    cmdImpGuaEnc.Parameters.Add("@numcarimp", SqlDbType.NVarChar,50).Value = Enc.OtrNumImp;
                    cmdImpGuaEnc.Parameters.Add("@fepe", SqlDbType.NVarChar, 10).Value = Enc.Fepe;
                    cmdImpGuaEnc.Parameters.Add("@envint", SqlDbType.Bit).Value = Enc.EnvInt;
                    cmdImpGuaEnc.Parameters.Add("@codley ", SqlDbType.TinyInt).Value = Enc.CodLey;
                    cmdImpGuaEnc.ExecuteNonQuery();

                    Enc.NumMov = Convert.ToInt32(cmdImpGuaEnc.Parameters["@nummov"].Value);
                    Enc.NumImp = Convert.ToString(cmdImpGuaEnc.Parameters["@numimp"].Value);


                    string consultaDet = "INSERT INTO LOG_Imp_Det (NumMov,CodArt,NumeroId,Can,Costo,Obs,Ocu,Ord,FecEntPro) values " +
                                                                        "(@numMov,@codArt,@numId,@can,@cos,@obs,@ocu,@ord,@fecEntPro)";

                    SqlCommand cmdImpGuaDet = new SqlCommand(consultaDet, cnx);

                    foreach (LOG_Imp_Det Det in Enc.Log_Imp_Det)
                    {
                        cmdImpGuaDet.Parameters.Clear();
                        cmdImpGuaDet.CommandType = CommandType.Text;

                        cmdImpGuaDet.Parameters.Add("@numMov", SqlDbType.NVarChar, 10).Value = Enc.NumMov;
                        cmdImpGuaDet.Parameters.Add("@codArt", SqlDbType.NVarChar, 50).Value = Det.CodArt;
                        cmdImpGuaDet.Parameters.Add("@numId", SqlDbType.NVarChar, 50).Value = Det.NumId;
                        cmdImpGuaDet.Parameters.Add("@can", SqlDbType.NVarChar, 50).Value = Det.Can;
                        cmdImpGuaDet.Parameters.Add("@cos", SqlDbType.Int).Value = Det.Cos;
                        cmdImpGuaDet.Parameters.Add("@obs", SqlDbType.NVarChar, 10).Value = Det.Obs;
                        cmdImpGuaDet.Parameters.Add("@ocu", SqlDbType.SmallInt).Value = Convert.ToInt16(Det.Ocu);
                        cmdImpGuaDet.Parameters.Add("@ord", SqlDbType.TinyInt).Value = Det.Ord;
                        cmdImpGuaDet.Parameters.Add("@fecEntPro", SqlDbType.NVarChar, 10).Value = Det.FecEnPro;
                        cmdImpGuaDet.ExecuteNonQuery();
                    }


                    string consultaSinStock = "INSERT INTO LOG_Imp_DetSinStock (NumMov,Item,Catalogo,DesPro,Traduccion,Can,Costo,Partida,Ord,FecEntPro) values" +
                                                                                "(@numMov,@ite,@cat,@desPro,@tra,@can,@cos,@par,@ord,@fecEntPro)";

                    SqlCommand cmdImpGuaDetSinStock = new SqlCommand(consultaSinStock, cnx);


                    foreach (LOG_Imp_DetSinSto DetStock in Enc.Log_Imp_DetSinStock)
                    {
                        cmdImpGuaDetSinStock.Parameters.Clear();
                        cmdImpGuaDetSinStock.CommandType = CommandType.Text;

                        cmdImpGuaDetSinStock.Parameters.Add("@numMov", SqlDbType.Int).Value = Enc.NumMov;
                        cmdImpGuaDetSinStock.Parameters.Add("@ite", SqlDbType.SmallInt).Value = DetStock.Ite;
                        cmdImpGuaDetSinStock.Parameters.Add("@cat", SqlDbType.NVarChar, 100).Value = DetStock.Cat;
                        cmdImpGuaDetSinStock.Parameters.Add("@desPro", SqlDbType.NVarChar, 500).Value = DetStock.DesPro;
                        cmdImpGuaDetSinStock.Parameters.Add("@tra", SqlDbType.NVarChar, 500).Value = DetStock.Tra;
                        cmdImpGuaDetSinStock.Parameters.Add("@can", SqlDbType.Decimal).Value = DetStock.Can;
                        cmdImpGuaDetSinStock.Parameters.Add("@cos", SqlDbType.Decimal).Value = DetStock.Cos;
                        cmdImpGuaDetSinStock.Parameters.Add("@par", SqlDbType.NVarChar, 100).Value = DetStock.Par;
                        cmdImpGuaDetSinStock.Parameters.Add("@ord", SqlDbType.TinyInt).Value = DetStock.Ord;
                        cmdImpGuaDetSinStock.Parameters.Add("@fecEntPro", SqlDbType.SmallDateTime).Value = DetStock.FecEntPro;
                        cmdImpGuaDetSinStock.ExecuteNonQuery();
                    }
                } 
            }
        }
    }
}
