﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using CapaDatos;

namespace CapaDatos
{
    public class DConsultas
    {

        private SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);
        private string _consulta = "";


        public bool Seguridad_ValPass(Int16 codUsu,string pass)
        {
            _consulta = @"SELECT Clave 
                          FROM Usuario 
                          WHERE CodigoUsuario = @codUsu";

            bool isVal = false;

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daValPass = new SqlDataAdapter(_consulta,cn))
                {
                    daValPass.SelectCommand.CommandType = CommandType.Text;
                    daValPass.SelectCommand.Parameters.Add("@codUsu",SqlDbType.SmallInt).Value = codUsu;

                    DataTable dtValPass = new DataTable();
                    dtValPass.Locale = CultureInfo.InvariantCulture;
                    daValPass.Fill(dtValPass);

                    //Obtiene el password del codigo de usuario
                    string clave = "";
                    clave = (string)dtValPass.Rows[0]["Clave"];

                    //Valida si la contraseña es igual
                    if (clave.Equals(pass))
                    {
                        isVal = true;
                    }
                    else
                    {
                        isVal = false;
                    }
                }
                return isVal;
            }
        }

        public DataTable LOG_rep_InfRSV_RecInfRes(Int16 val)
        {
            using (SqlDataAdapter daRecInfRes = new SqlDataAdapter("LOG_InfRSV_RepFin2",cnx))
            {
                daRecInfRes.SelectCommand.CommandType = CommandType.StoredProcedure;
                daRecInfRes.SelectCommand.Parameters.Add("@Val",SqlDbType.TinyInt).Value = val;

                DataTable dtInfRes = new DataTable();
                dtInfRes.Locale = CultureInfo.InstalledUICulture;
                daRecInfRes.Fill(dtInfRes);
                return dtInfRes;
            }
        }

        public DataTable RANKING_DE_RECOMENDADORES_POR_PERIODOS(DateTime fecIni, DateTime fecFin)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("[RANKING DE RECOMENDADORES POR PERIODOS]", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.Add("@FECHA_INI", SqlDbType.Date).Value = fecIni;
                    da.SelectCommand.Parameters.Add("@FECHA_FIN", SqlDbType.Date).Value = fecFin;
                    DataTable dt = new DataTable();
                    dt.Locale = CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }
        public bool ValRqGenSap(string rq,string baseSap)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdValRq = new SqlCommand("SELECT U_SYP_RQ FROM " + baseSap + ".dbo.OQUT WHERE U_SYP_RQ = @rq", cn))
                {
                    cmdValRq.Connection.Open();
                    cmdValRq.CommandType = CommandType.Text;
                    cmdValRq.Parameters.Add("@rq", SqlDbType.NVarChar, 12).Value = rq;
                    SqlDataReader drRq = cmdValRq.ExecuteReader();

                    bool est;
                    est = false;

                    if (drRq.Read())
                    {
                        est = true;
                    }
                    return est;
                }
            }
        }

        public bool ValCodArtGenSap(string codArtSap,string baseSAP)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdValCod = new SqlCommand("SELECT ItemCode FROM " + baseSAP + ".dbo.oitm WHERE ItemCode = @CodArt", cn))
                {
                    cmdValCod.Connection.Open();
                    cmdValCod.CommandType = CommandType.Text;
                    cmdValCod.Parameters.Add("@CodArt",SqlDbType.NVarChar, 50).Value = codArtSap;
                    SqlDataReader drIteCod = cmdValCod.ExecuteReader();
                    bool est;
                    est = false;

                    if (drIteCod.Read())
                    {
                        est = true;
                    }
                    return est;
                }
            }
        }

        public DataTable LOG_Imp_AbrRec(short Col, string Filtro)
        {
            SqlDataAdapter daImpAbrRec = new SqlDataAdapter("LOG_Imp_AbrirRec", cnx);
            daImpAbrRec.SelectCommand.CommandType = CommandType.StoredProcedure;
            daImpAbrRec.SelectCommand.Parameters.Add("@Col", SqlDbType.Int).Value = Col;
            daImpAbrRec.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = Filtro;

            DataTable dtImpAbrRec = new DataTable();
            dtImpAbrRec.Locale = CultureInfo.InvariantCulture;
            daImpAbrRec.Fill(dtImpAbrRec);
            return dtImpAbrRec;
        }
        public DataTable ALM_Inventario_AbrirRec(short Col, string Filtro)
        {
            SqlDataAdapter daInvAbrRec= new SqlDataAdapter("ALM_Inventario_AbrirRec", cnx);
            daInvAbrRec.SelectCommand.CommandType = CommandType.StoredProcedure;
            daInvAbrRec.SelectCommand.Parameters.Add("@Col", SqlDbType.Int).Value = Col;
            daInvAbrRec.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar,100).Value = Filtro;
            DataTable dtInvAbrRec = new DataTable();
            dtInvAbrRec.Locale = CultureInfo.InvariantCulture;
            daInvAbrRec.Fill(dtInvAbrRec);
            return dtInvAbrRec;
        }
        public DataTable Ruta_Item_RecRqInf(int Rq)
        {
            SqlDataAdapter daRecRqInf = new SqlDataAdapter("[GEN_RQ_info]", cnx);
            daRecRqInf.SelectCommand.CommandType = CommandType.StoredProcedure;
            daRecRqInf.SelectCommand.Parameters.Add("@RQ", SqlDbType.Int).Value = Rq;
            DataTable dtRecRqInf = new DataTable();
            dtRecRqInf.Locale = CultureInfo.InvariantCulture;
            daRecRqInf.Fill(dtRecRqInf);
            return dtRecRqInf;
        }

        public DataTable Ruta_Item_ListarRQ(short Col, string Filtro)
        {
            SqlDataAdapter daLisRq = new SqlDataAdapter("[VEN_ListaRQ]", cnx);
            daLisRq.SelectCommand.CommandType = CommandType.StoredProcedure;
            daLisRq.SelectCommand.Parameters.Add("@Col", SqlDbType.TinyInt).Value = Col;
            daLisRq.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar,100).Value = Filtro;
            DataTable dtLisRq = new DataTable();
            dtLisRq.Locale = CultureInfo.InvariantCulture;
            daLisRq.Fill(dtLisRq);
            return dtLisRq;
        }

        public DataTable DocumentoTipoRec(Int16 CodTip)
        {
            SqlDataAdapter daRecTipDoc = new SqlDataAdapter("[DocumentoTipo_Rec]", cnx);
            daRecTipDoc.SelectCommand.CommandType = CommandType.StoredProcedure;
            daRecTipDoc.SelectCommand.Parameters.Add("@CodTip", SqlDbType.SmallInt).Value = CodTip;
            DataTable dtRecTipDoc = new DataTable();
            dtRecTipDoc.Locale = CultureInfo.InvariantCulture;
            daRecTipDoc.Fill(dtRecTipDoc);
            return dtRecTipDoc;
        }
        
        public DataTable ven_cueporcob_cat()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("select CodCat, Des from CON_CuePorCob_Cat", cnx);
            da.SelectCommand.CommandType = CommandType.Text;

            //
            da.Fill(dt); //el data adapter llena al data adapter               
            return dt;
        }

        public DataTable ven_cueporcob(DateTime param1, DateTime param2)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("CON_CuePorCob", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@fdesde", SqlDbType.SmallDateTime).Value = param1;
            da.SelectCommand.Parameters.Add("@fhasta", SqlDbType.SmallDateTime).Value = param2;
            da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = 0;
            //
            da.Fill(dt); //el data adapter llena al data adapter               
            return dt;
        }

        public DataTable RecuperaInfoRQ(string vista, string procedimiento, int param1, string param2)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@Tipo", SqlDbType.Int).Value = param1;
            da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.VarChar,120).Value = param2;
            //
            da.Fill(dt); //el data adapter llena al data adapter               
            return dt;
        }

        public DataTable VEN_CuadreRQ(Int64 rq)
        {
            // Create a new data adapter based on the specified query.
            SqlDataAdapter da = new SqlDataAdapter("VEN_CuadreRQ", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@rq", SqlDbType.Int).Value = rq;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_RQ_info(int rq)
        {
            // Create a new data adapter based on the specified query.
            SqlDataAdapter da = new SqlDataAdapter("VNT_STATUS_RQ", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@numrq", SqlDbType.Int).Value = rq;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;           
        }

        public DataTable VEN_Cot_Filtros(string vista, string procedimiento, string param1, string param2, string param3, string param4, string param5)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            //
            switch (vista)
            {
                case "Cliente":
                case "EmpleadoVentas":
                case "Centro de Venta":
                case "Recomendador":
                case "Motivo":
                case "AdmRQ":
                case "Negocio":
                case "Material Base Mueble":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    break;
                case "Tipo de Venta":                
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar,100).Value = param1;
                    da.SelectCommand.Parameters.Add("@CenVen", SqlDbType.NVarChar, 100).Value = param2;
                    break;
                case "Tipo de Venta Relativo":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@TipVen", SqlDbType.NVarChar, 100).Value = param2;
                    da.SelectCommand.Parameters.Add("@CenVen", SqlDbType.NVarChar, 100).Value = param3;
                    break;
                case "Rubro": 
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@TipVenRel", SqlDbType.NVarChar, 100).Value = param2;
                    da.SelectCommand.Parameters.Add("@TipVen", SqlDbType.NVarChar, 100).Value = param3;
                    break;
                case "Tipo de Obra":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@Rub", SqlDbType.NVarChar, 100).Value = param2;
                    da.SelectCommand.Parameters.Add("@CenVen", SqlDbType.NVarChar, 100).Value = param3;
                    da.SelectCommand.Parameters.Add("@TipVenRel", SqlDbType.NVarChar, 100).Value = param4;
                    da.SelectCommand.Parameters.Add("@TipVen", SqlDbType.NVarChar, 100).Value = param5;
                    break;
                case "Dimension":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@TipObr", SqlDbType.NVarChar, 100).Value = param2;
                    break;
                case "Articulo Compuesto":
                case "Articulo Simple":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@moneda", SqlDbType.NVarChar, 100).Value = param2;
                    da.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = Convert.ToByte(param3);
                    break;
                case "Ambientes (Articulo Compuesto)":
                case "Ambientes (Otros Articulos)":
                case "Ambientes (Articulo Simple)":
                case "Falla En":
                case "Envio":
                case "Linea":
                case "Marca":
                case "Proveedor":
                case "ProveedorHome":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    break;
                case "Tiempo":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@TipVen", SqlDbType.NVarChar, 100).Value = param2;
                    break;
                case "Linea Producto/Servicio":
                case "Tipo":
                case "SubLinea":
                case "Familia":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@cod", SqlDbType.TinyInt).Value = Convert.ToInt16(param2);
                    break;
                case "Contacto Cliente":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@cardcode", SqlDbType.NVarChar, 15).Value = param2;
                    break;
                case "SubLineaAA":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@codlin", SqlDbType.NVarChar, 15).Value = param2;
                    break;
                case "FamiliaAA":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@codsublin", SqlDbType.NVarChar, 15).Value = param2;
                    break;
                case "SubFamilia":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@CodFam", SqlDbType.NVarChar, 15).Value = param2;
                    break;
                case "Seleccionar RQ":
                    da.SelectCommand.Parameters.Add("@codcli", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@rq", SqlDbType.NVarChar, 100).Value = param2;
                    da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = Convert.ToInt16(param3);
                    break;
                default:
                    break;
            }

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable OPE_Pro_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            //
            switch (vista)
            {
                case "Tipo":
                case "Diseño":
                case "Ing. Operaciones":
                case "Supervisor":
                case "Adm. Pedidos":
                case "Tipo Predio":
                case "Cargo":
                case "Estado Obra":       
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 50).Value = param1;
                    break;
                case "OPE_Pro_Det1":
                    da.SelectCommand.Parameters.Add("@rq", SqlDbType.NVarChar, 50).Value = param1;
                    break;
                case "Complejidad":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@Param2", SqlDbType.SmallInt).Value = param2;
                    break;
                case "RQ":
                    da.SelectCommand.Parameters.Add("@rq", SqlDbType.Int).Value = Convert.ToInt32(param1);
                    da.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = Convert.ToInt64(param2);
                    break;
                default:
                    break;
            }

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable ALM_MovIngxEnc_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            //
            switch (vista)
            {
                case "Encargado":
                    da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 150).Value = param1;
                    da.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = 3;
                    break;
                default:
                    break;
            }

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable ALM_MovIng_EncAlm(int CodEnc, DateTime FDesde, DateTime FHasta)
        {
            SqlDataAdapter da = new SqlDataAdapter("[ALM_MovIng_EncAlm]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@CodEnc", SqlDbType.SmallInt).Value = CodEnc;
            da.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = FDesde;
            da.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = FHasta;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_OFC_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            //
            switch (vista)
            {  
                case "Tipo OFC":
                case "Tipo de Servicio":
                case "Categoria":
                case "Area":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 50).Value = param1;
                    break;
                case "Servicio":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@Param2", SqlDbType.NVarChar, 2).Value = param2;
                    break;
                case "SubArea":
                case "Unidad de Negocio":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 50).Value = param1;
                    da.SelectCommand.Parameters.Add("@Param2", SqlDbType.NVarChar, 3).Value = param2;
                    break;
                case "Proveedor":
                case "Moneda":
                    da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 100).Value = param1;                    
                    break;
                default:
                    break;
            }

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable ALM_AlmArt_Stock_Filtros(string vista, string procedimiento, string param1)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;

            switch (vista)
            {
                case "Encargado":
                    da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 150).Value = param1;
                    da.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = 3;
                    break;

                case "Empleado":
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param1;
                    break;
                case "Area":
                    da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 50).Value = param1;
                    break;

                case "Almacen": //
                    da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 50).Value = param1;
                    break;
                default:
                    break;
            }

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;

        }

        public DataTable ALM_rep_AccAlm(byte tipo, Int16 CodUsuAre, string CodAlm)
        {
            SqlDataAdapter da = new SqlDataAdapter("[ALM_rep_AccAlm]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;

            da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = tipo;
            da.SelectCommand.Parameters.Add("@CodUsuAre", SqlDbType.SmallInt).Value = CodUsuAre;
            da.SelectCommand.Parameters.Add("@codalm", SqlDbType.NVarChar, 10).Value = CodAlm;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public decimal IGV_Recuperar(DateTime Fecha)
        {
            decimal ValorIGV;

            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (cnx)
            {
                SqlCommand command = new SqlCommand("IGV_Rec", cnx);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@Fecha", SqlDbType.DateTime).Value = Fecha;

                cnx.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    ValorIGV = reader.GetDecimal(0);
                    reader.Close();
                    return ValorIGV;                   
                }
                else
                {
                    ValorIGV = 0;
                    return ValorIGV;
                }
                
            }            
        }

        public decimal TipoCambio_Recuperar(DateTime Fecha)
        {
            decimal TipCam;

            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (cnx)
            {
                SqlCommand command = new SqlCommand("ven_tipcam", cnx);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add("@Fec", SqlDbType.DateTime).Value = Fecha;

                cnx.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    TipCam = reader.GetDecimal(0);
                    reader.Close();
                    return TipCam;
                }
                else
                {
                    TipCam = 0;
                    return TipCam;
                }                
            }
        }

        public string FechaServidor()
        {
            string FecSer;

            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (cnx)
            {
                SqlCommand command = new SqlCommand("GEN_FecSer", cnx);
                command.CommandType = CommandType.StoredProcedure;

                cnx.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    FecSer = reader[0].ToString();
                    reader.Close();
                    return FecSer;
                }
                else
                {
                    FecSer = "";
                    return FecSer;
                }

            }

        }

        public DataTable VEN_RQ_Doc(int rq, int tipo)
        {
            SqlDataAdapter da = new SqlDataAdapter("TRZ_VEN_DOCRQ", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@RQ", SqlDbType.Int).Value = rq;
            da.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = tipo;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_rep_Ing(DateTime fecini, DateTime fecfin)
        {
            SqlDataAdapter da = new SqlDataAdapter("[SYP_REPORTE DE INGRESOS]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@fechaini", SqlDbType.Date).Value = fecini;
            da.SelectCommand.Parameters.Add("@fechafin", SqlDbType.Date).Value = fecfin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_rep_CotApr(DateTime FDesde, DateTime FHasta)
        {
            SqlDataAdapter da = new SqlDataAdapter("[VEN_rep_CotApr]", cnx);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FDesde", SqlDbType.Date).Value = FDesde;
            da.SelectCommand.Parameters.Add("@FHasta", SqlDbType.Date).Value = FHasta;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_rep_CotAprCol()
        {
            SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_rep_CotApr_discol", cnx);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_rep_Fac(DateTime FDesde, DateTime FHasta)
        {
            SqlDataAdapter da = new SqlDataAdapter("VEN_rep_Fac", cnx);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FDesde", SqlDbType.Date).Value = FDesde;
            da.SelectCommand.Parameters.Add("@FHasta", SqlDbType.Date).Value = FHasta;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_Alm_ArtSto(int CodUsu, string filtro, Byte valor, bool tipo)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_Alm_ArtSto]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@CodUsu", SqlDbType.Int).Value = CodUsu;
            da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar).Value = filtro;
            da.SelectCommand.Parameters.Add("@valor", SqlDbType.TinyInt).Value = valor;
            da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = tipo;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable OPE_OFVAprSerInsPro(Int16 valor)
        {
            SqlDataAdapter da = new SqlDataAdapter("OPE_OFVAprSerInsPro_rep", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@val", SqlDbType.TinyInt).Value = valor;
                  
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public void OPE_OFVApr_dat_acting(Int16 codrep, Int64 numdoc, string codart, string est, string obs, Int32 codusu, bool sel)
        {

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlCommand cmd = new SqlCommand("OPE_OFVApr_dat_ingact", cnx);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@codrep", SqlDbType.TinyInt).Value = codrep;
                cmd.Parameters.Add("@numdoc", SqlDbType.Int).Value = numdoc;
                cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = codart;
                cmd.Parameters.Add("@est", SqlDbType.NVarChar, 50).Value = est;
                cmd.Parameters.Add("@obs", SqlDbType.NVarChar,400).Value = obs;
                cmd.Parameters.Add("@sel", SqlDbType.Bit).Value = sel;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                cnx.Open();

                cmd.ExecuteNonQuery();

            }

        }

        public DataTable OPE_ODVAprSerInsPro(Int16 valor)
        {
            SqlDataAdapter da = new SqlDataAdapter("OPE_ODVAprSerInsPro_rep", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@val", SqlDbType.TinyInt).Value = valor;

            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable OPE_OFVAprSerSupDis(Int16 valor)
        {
            SqlDataAdapter da = new SqlDataAdapter("OPE_OFVAprSerSupDis_rep", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@val", SqlDbType.TinyInt).Value = valor;

            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable OPE_ODVAprSerSupDis(Int16 valor)
        {
            SqlDataAdapter da = new SqlDataAdapter("OPE_ODVAprSerSupDis_rep", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@val", SqlDbType.TinyInt).Value = valor;

            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_rep_Ing(DateTime fIni, DateTime fFin)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_rep_Ing]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@fdesde", SqlDbType.SmallDateTime).Value = fIni;
            da.SelectCommand.Parameters.Add("@fhasta", SqlDbType.SmallDateTime).Value = fFin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable ALM_rep_SolTra_Stock(DateTime fIni, DateTime fFin)
        {
            SqlDataAdapter da = new SqlDataAdapter("[ALM_REP_SolTra_Stock]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = fIni;
            da.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = fFin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataSet VEN_rep_CroPag(DateTime fIni, DateTime fFin)
        {
            DataSet ds = new DataSet();

            SqlDataAdapter daEnc = new SqlDataAdapter("VEN_CroPag_RanFec", cnx);
            daEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
            daEnc.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = fIni;
            daEnc.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = fFin;

            SqlDataAdapter daDet = new SqlDataAdapter("VEN_CroPag_RanFec_det", cnx);
            daDet.SelectCommand.CommandType = CommandType.StoredProcedure;
            daDet.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = fIni;
            daDet.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = fFin;

            daEnc.Fill(ds,"Enc");
            daDet.Fill(ds,"Det");

            DataRelation dtr = new DataRelation("CroPagEncDet", ds.Tables[0].Columns[0], ds.Tables[1].Columns[0], true);
            ds.Relations.Add(dtr);

            return ds;
        }

        public DataTable ALM_rep_DocPenDes()
        {
            SqlDataAdapter da = new SqlDataAdapter("[ALM_rep_DocPenDes]", cnx);
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable TRZ_ALM_ConPro(DateTime fIni, DateTime fFin)
        {
            SqlDataAdapter da = new SqlDataAdapter("[TRZ_ALM_ConPro]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = fIni;
            da.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = fFin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_rep_AdmRQ(Int16 Valor)
        {
            SqlDataAdapter da = new SqlDataAdapter("[VEN_rep_AdmRQ]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;            
            da.SelectCommand.Parameters.Add("@valor", SqlDbType.SmallInt).Value = Valor;

            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public byte GEN_AccByDoc(Int32 codEmp, Int16 codDoc, string campo, byte acc)
        {
            //Documentos control de acceso            
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("GEN_For_ConAcc", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@codemp", SqlDbType.SmallInt).Value = codEmp;
                    cmd.Parameters.Add("@coddoc", SqlDbType.SmallInt).Value = codDoc;
                    cmd.Parameters.Add("@campo", SqlDbType.NVarChar, 10).Value = campo;

                    SqlParameter accParam = new SqlParameter();

                    accParam = cmd.Parameters.Add("@acc", SqlDbType.TinyInt);
                    accParam.Direction = ParameterDirection.InputOutput;
                    accParam.Value = acc;

                    cnx.Open();

                    return (byte)cmd.ExecuteScalar();
                }
            }
        }

        public DataTable VEN_rep_DesOtoxVen(DateTime fecini, DateTime fecfin)
        {
            SqlDataAdapter da = new SqlDataAdapter("VEN_rep_DesOtoxVen", cnx);

            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FecIni", SqlDbType.Date).Value = fecini;
            da.SelectCommand.Parameters.Add("@FecFin", SqlDbType.Date).Value = fecfin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable VEN_Cot_visgen(Int16 col, string filtro)
        {
            // Create a new data adapter based on the specified query.
            SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_visgen", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@col", SqlDbType.Int).Value = col;
            da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = filtro;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable Ruta_Item_VisGen(short Col,string Filtro)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                
                using (SqlDataAdapter daRecRut = new SqlDataAdapter("RutaItem_AbrirRec", cn))
                {
                    daRecRut.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecRut.SelectCommand.Parameters.Add("@Col",SqlDbType.TinyInt).Value = Col;
                    daRecRut.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar,100).Value = Filtro;
                    DataTable dtRutVisGen = new DataTable();
                    dtRutVisGen.Locale = CultureInfo.InvariantCulture;
                    daRecRut.Fill(dtRutVisGen);
                    return dtRutVisGen;
                }
            }
        }

        public bool Validar_CodArtCom(Int64 CodArtCom)
        {            
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (cnx)
            {
                SqlCommand cmd = new SqlCommand("SELECT CodArtCom FROM ArtCom WHERE CodArtCom = @CodArtCom", cnx);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@CodArtCom", SqlDbType.Int).Value = CodArtCom;

                cnx.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    return true;
                }
                else
                {                   
                    return false;
                }
            }
        }

        public bool Validar_CodArt(string CodArt, string BaseSAP)
        {
            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

            using (cnx)
            {
                SqlCommand cmd = new SqlCommand("SELECT ItemCode FROM " + BaseSAP + ".dbo.oitm WHERE ItemCode = @CodArt", cnx);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Add("@CodArt", SqlDbType.NVarChar,12).Value = CodArt;

                cnx.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }

        public DataTable ALM_repDis_TipRutVen(string procedimiento, DateTime fecini, DateTime fecfin)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@fecini", SqlDbType.SmallDateTime).Value = fecini;
            da.SelectCommand.Parameters.Add("@fecfin", SqlDbType.SmallDateTime).Value = fecfin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_SegDoc(DateTime FInicinal, DateTime FFinal)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_SegDoc]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FInicial", SqlDbType.SmallDateTime).Value = FInicinal;
            da.SelectCommand.Parameters.Add("@FFinal", SqlDbType.SmallDateTime).Value = FFinal;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable ALM_Ubi_PorCrear()
        {
            SqlDataAdapter da = new SqlDataAdapter("[ALM_Ubi_PorCrear]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_RQ_Rango(int RqInicial, int RqFinal)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_RQ_Rango]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@RQ_Inicial", SqlDbType.Int).Value = RqInicial;
            da.SelectCommand.Parameters.Add("@RQ_Final", SqlDbType.Int).Value = RqFinal;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_RQ_Rango_Detalle(int RqInicial, int RqFinal)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_RQ_Rango_Detalle]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@RQ_Inicial", SqlDbType.Int).Value = RqInicial;
            da.SelectCommand.Parameters.Add("@RQ_Final", SqlDbType.Int).Value = RqFinal;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public void ALM_rep_AlmArt_AccAlm_InsDel(string CodAlm, Int16 CodUsuAre, byte Ind, bool InsDel)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string sqlCadena = "";

                if (InsDel == true)
                {
                    sqlCadena = "insert into LOG_Area_AccAlm (CodAlm, CodUsuAre, Ind) values (@codalm, @codusuare, @ind)";
                }
                else
                {
                    sqlCadena = "delete LOG_Area_AccAlm where CodAlm = @codalm and CodUsuAre = @codusuare and Ind = @ind";
                }

                using (SqlCommand cmd = new SqlCommand(sqlCadena, cn))
                {
                    cn.Open();
                    cmd.Parameters.Add("@codalm", SqlDbType.NVarChar, 8).Value = CodAlm;
                    cmd.Parameters.Add("@codusuare", SqlDbType.SmallInt).Value = CodUsuAre;
                    cmd.Parameters.Add("@ind", SqlDbType.TinyInt).Value = Ind;
                    cmd.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public DataTable VEN_Cot_SeleccionarRQ(string codcli, Int64 rq, short tipo)
        {
            // Create a new data adapter based on the specified query.
            SqlDataAdapter da = new SqlDataAdapter("VEN_Cot_CliRQ", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@codcli", SqlDbType.NVarChar,12).Value = codcli;
            da.SelectCommand.Parameters.Add("@rq", SqlDbType.Int).Value = rq;
            da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = tipo;
            //
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_MaeArt_ActDat_Filtros(string vista, string procedimiento, string param1, string param2)
        {
            SqlDataAdapter da = new SqlDataAdapter(procedimiento, cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            //
            switch (vista)
            {
                case "Articulos":
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = param1;
                    da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = Convert.ToInt16(param2);
                    
                    break;
            }

            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
