﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;

namespace CapaDatos
{
    public class DALM_PreDoc_Con
    {
        public DataTable PreDoc_Con_Filtros(string vista,string procedimiento,string param)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daDocConRec = new SqlDataAdapter(procedimiento, cn))
                {
                    daDocConRec.SelectCommand.CommandType = CommandType.StoredProcedure;

                    switch (vista)
                    {
                        case "Rutas":
                            daDocConRec.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 60).Value = param;
                            break;
                        case "Almacen":
                            daDocConRec.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 50).Value = param;
                            break;
                        default:
                            break;
                    }

                    DataTable dtFiltro = new DataTable();
                    daDocConRec.Fill(dtFiltro);
                    return dtFiltro;
                }
            }
        }

        public DataTable PreDoc_Con_Rec(byte TipPro, Int16 TipCon,DateTime FecIni, DateTime FecFin, Int16 Ruta,string Alm,bool ConSto)
        {
            DataTable dtPro = new DataTable();

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                switch (TipPro)
                {
                    case 0:
                        {
                            SqlDataAdapter daDocConRec = new SqlDataAdapter("[ALM_PickingPacking_Con]", cn);
                            daDocConRec.SelectCommand.CommandType = CommandType.StoredProcedure;
                            daDocConRec.SelectCommand.Parameters.Add("@TipCon", SqlDbType.TinyInt).Value = TipCon;
                            daDocConRec.SelectCommand.Parameters.Add("@FInicial", SqlDbType.SmallDateTime).Value = FecIni;
                            daDocConRec.SelectCommand.Parameters.Add("@FFinal", SqlDbType.SmallDateTime).Value = FecFin;
                            daDocConRec.SelectCommand.Parameters.Add("@Ruta", SqlDbType.TinyInt).Value = Ruta;
                            daDocConRec.SelectCommand.Parameters.Add("@Almacen", SqlDbType.NVarChar, 3).Value = Alm;
                            daDocConRec.SelectCommand.Parameters.Add("@ConStock", SqlDbType.Bit).Value = Convert.ToInt32(ConSto);

                            dtPro.Locale = CultureInfo.InvariantCulture;
                            daDocConRec.Fill(dtPro);
                        }
                        break;

                    case 1:
                        {
                            SqlDataAdapter daDocConRec2 = new SqlDataAdapter("[ALM_PickingPacking_Con_Tra]", cn);
                            daDocConRec2.SelectCommand.CommandType = CommandType.StoredProcedure;
                            daDocConRec2.SelectCommand.Parameters.Add("@TipCon", SqlDbType.TinyInt).Value = TipCon;
                            daDocConRec2.SelectCommand.Parameters.Add("@FInicial", SqlDbType.SmallDateTime).Value = FecIni;
                            daDocConRec2.SelectCommand.Parameters.Add("@FFinal", SqlDbType.SmallDateTime).Value = FecFin;
                            daDocConRec2.SelectCommand.Parameters.Add("@Ruta", SqlDbType.TinyInt).Value = Ruta;
                            daDocConRec2.SelectCommand.Parameters.Add("@Almacen", SqlDbType.NVarChar, 3).Value = Alm;
                            daDocConRec2.SelectCommand.Parameters.Add("@ConStock", SqlDbType.Bit).Value = Convert.ToInt32(ConSto);

                            dtPro.Locale = CultureInfo.InvariantCulture;
                            daDocConRec2.Fill(dtPro);
                        }
                        break;

                    default:
                        break;

                }
            }

            return dtPro;
        }
    }
}
