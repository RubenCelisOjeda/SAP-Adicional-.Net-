﻿using System;
using System.Data;
using System.Data.SqlClient;
using Entidades.SolFac;
using CapaDatos;

namespace CapaDatos
{
    public class DSolFac
    {
      
        private static SAPbobsCOM.Company oCompany = new SAPbobsCOM.Company();
        DConsultas cf = new DConsultas();

        public void VEN_SolFac_Enc_IngAct(SolFac_Enc Enc)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("VEN_SolFac_Enc_actgua", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter paraNumMon = new SqlParameter("@nummov", SqlDbType.Int);
                    paraNumMon.Direction = ParameterDirection.InputOutput;

                    SqlParameter paraNumSol = new SqlParameter("@numsol", SqlDbType.NVarChar, 11);
                    paraNumSol.Direction = ParameterDirection.InputOutput;

                    da.SelectCommand.Parameters.Add(paraNumMon).Value = Enc.NumMov;
                    da.SelectCommand.Parameters.Add(paraNumSol).Value = Enc.NumSol;
                    da.SelectCommand.Parameters.Add("@rq", SqlDbType.Int).Value = Enc.Rq;
                    da.SelectCommand.Parameters.Add("@cli", SqlDbType.NVarChar, 12).Value = Enc.Cli;
                    da.SelectCommand.Parameters.Add("@codmon", SqlDbType.NVarChar, 3).Value = Enc.CodMon;
                    da.SelectCommand.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                    da.SelectCommand.Parameters.Add("@obs", SqlDbType.NVarChar, 800).Value = Enc.Obs;
                    da.SelectCommand.Parameters.Add("@docnumbf", SqlDbType.NVarChar, 20).Value = Enc.DocNumBf;
                    da.SelectCommand.Parameters.Add("@numoti", SqlDbType.NVarChar, 11).Value = Enc.NumOti;
                    da.SelectCommand.Parameters.Add("@igv", SqlDbType.Decimal).Value = Enc.IGV;//
                    da.SelectCommand.Parameters.Add("@salpencob", SqlDbType.Bit).Value = Enc.SalPenCob;
                    da.SelectCommand.Parameters.Add("@monfac", SqlDbType.Decimal).Value = Enc.MonFac;
                    da.SelectCommand.Parameters.Add("@faccon", SqlDbType.NVarChar, 200).Value = Enc.FacCon;
                    da.SelectCommand.Parameters.Add("@facdet", SqlDbType.NVarChar, 200).Value = Enc.FacDet;
                    da.SelectCommand.Parameters.Add("@direnvfac", SqlDbType.NVarChar, 200).Value = Enc.DirEnvFac;

                    da.SelectCommand.Connection.Open();
                    da.SelectCommand.ExecuteNonQuery();

                    Enc.NumMov = Convert.ToInt64(da.SelectCommand.Parameters["@nummov"].Value);
                    Enc.NumSol = Convert.ToString(da.SelectCommand.Parameters["@numsol"].Value);
                }

                using (SqlCommand cmd = new SqlCommand("DELETE VEN_SolFac_Det WHERE NumMov = @nummov", cn))
                {
                   
                    cmd.Parameters.Clear();
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                    cmd.ExecuteNonQuery();
                    cn.Close();
                }

                using (SqlCommand cmd = new SqlCommand("INSERT INTO VEN_SolFac_Det (NumMov,Item,DocNum,LineNum,CodArt,CanORV,CanSol,PreUni,TotLin,PorDes,CodAlm)" +
                                                           "values (@nummov,@item,@docnum,@lineum,@codart,@canorv,@cansol,@preuni,@totlin,@pordes,@codalm)", cn))
                {
                    cn.Open();

                    foreach (SolFac_Det Det in Enc.EncSolFac)
                    {
                        cmd.Parameters.Clear();
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@item", SqlDbType.SmallInt).Value = Det.Item;
                        cmd.Parameters.Add("@docnum", SqlDbType.Int).Value = Det.DocNum;
                        cmd.Parameters.Add("@lineum", SqlDbType.Int).Value = Det.LineNum; //
                        cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = Det.CodArt;
                        cmd.Parameters.Add("@canorv", SqlDbType.Decimal).Value = Det.CanORV;
                        cmd.Parameters.Add("@cansol", SqlDbType.Decimal).Value = Det.CanSol;
                        cmd.Parameters.Add("@preuni", SqlDbType.Decimal).Value = Det.PreUni;
                        cmd.Parameters.Add("@totlin", SqlDbType.Decimal).Value = Det.TotLin;
                        cmd.Parameters.Add("@pordes", SqlDbType.Decimal).Value = Det.PorDes;
                        cmd.Parameters.Add("@codalm", SqlDbType.NVarChar, 8).Value = Det.CodAlm;
                        cmd.ExecuteNonQuery();
                    }
                    cn.Close();
                }
            }
        }

        public DataTable SBO_TRAZ_PROD(string WhsCode)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("SELECT WhsCode FROM SBO_TRAZ_PRUEBA.dbo.owhs where WhsCode = @whscode", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    da.SelectCommand.Parameters.Add("@whscode", SqlDbType.NVarChar, 100).Value = WhsCode;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }         
        }

        public DataSet VEN_SolFac_Enc_Det_rec_(Int64 numMov)
        {

            DataSet ds = new DataSet();

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter SolFac_Enc_rec = new SqlDataAdapter("VEN_SolFac_Enc_rec", cn))
                {
                    SolFac_Enc_rec.SelectCommand.CommandType = CommandType.StoredProcedure;
                    SolFac_Enc_rec.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = numMov;
                    SolFac_Enc_rec.Fill(ds, "Enc");
                }

                try
                {
                    using (SqlDataAdapter SolFac_Det_rec = new SqlDataAdapter("VEN_SolFac_Det_rec", cn))
                    {
                        SolFac_Det_rec.SelectCommand.CommandType = CommandType.StoredProcedure;
                        SolFac_Det_rec.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = numMov;
                        SolFac_Det_rec.SelectCommand.Parameters.Add("@codest", SqlDbType.SmallInt).Value = ds.Tables["Enc"].Rows[0]["CodEst"].ToString();
                        SolFac_Det_rec.SelectCommand.Parameters.Add("@nummovoti", SqlDbType.NVarChar, 11).Value = ds.Tables["Enc"].Rows[0]["NumOTI"].ToString();

                        SolFac_Det_rec.Fill(ds, "Det");
                    }
                }
                catch { }

            }
            return ds;
        }     

        public DataTable VEN_SolFac_ListORV(int NumRQ)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("VEN_SolFac_ListORV", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.Add("@NumRQ", SqlDbType.Int).Value = NumRQ;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }


        public DataTable VEN_SolFac_DetORV(int Docnum)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("VEN_SolFac_DetORV", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.Add("@docnum", SqlDbType.Int).Value = Docnum;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }           
        }

        public int VEN_SolFac_ConAcc(int CodEmp, int Cam, byte Acc)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("VEN_SolFac_ConAcc", cn))
                {
                    SqlParameter ParaAcc = new SqlParameter("@Acc", SqlDbType.TinyInt);

                    cmd.CommandType = CommandType.StoredProcedure;
                    ParaAcc.Direction = ParameterDirection.InputOutput;

                    cmd.Parameters.Add("@Campo", SqlDbType.NVarChar, 20).Value = Cam;
                    cmd.Parameters.Add("@CodEmp", SqlDbType.SmallInt).Value = CodEmp;
                    cmd.Parameters.Add(ParaAcc).Value = Acc;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    Acc = Convert.ToByte(cmd.Parameters["@Acc"].Value);
                    return Acc;
                }
            }
        }

        public  void VEN_SolFac_Enc_Procesar(string DocNumBF,byte CodEst, DateTime FecMod, int CodUsuMod, Int64 NumMov)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand(@"UPDATE VEN_SolFac_Enc SET DocNumBF = @docnumbf,CodEst=@codest, 
                                                        FecMod=@fecmod,CodUsuMod=@codusumod where NumMov=@nummov", cn))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;
                    cmd.Parameters.Add("@docnumbf", SqlDbType.NVarChar,800).Value = DocNumBF;
                    cmd.Parameters.Add("@codest", SqlDbType.TinyInt).Value = CodEst;
                    cmd.Parameters.Add("@fecmod", SqlDbType.SmallDateTime).Value = FecMod;
                    cmd.Parameters.Add("@codusumod", SqlDbType.Int).Value = CodUsuMod;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public void VEN_SolFac_Enc_Anular(Int64 numMov, DateTime fecha, int codUsu)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand(@"UPDATE VEN_SolFac_Enc set CodEst=4,FecMod=@fec,CodUsuMod=@CodUsu where NumMov=@nummov", cn))
                {
                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = numMov;
                    cmd.Parameters.Add("@fec", SqlDbType.Date).Value = fecha;
                    cmd.Parameters.Add("CodUsu", SqlDbType.Int).Value = codUsu;
                    cn.Open();
                    cmd.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public DateTime FechaDespachoOddOti(string NumDoc)
        {
            using (SqlConnection cn= new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("SELECT FecDes FROM OPE_Odd_Enc WHERE NumOdd =@numdoc ",cn))
                {
                    da.SelectCommand.CommandType= CommandType.Text;
                    da.SelectCommand.Parameters.Add("@numdoc", SqlDbType.NVarChar, 11).Value = NumDoc;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    
                    if (dt.Rows.Count > 0)
                    {
                       return  Convert.ToDateTime( dt.Rows[0]["FecDes"].ToString());
                    }
                    else
                    {
                      return  Convert.ToDateTime( cf.FechaServidor());
                    }                                  
                }
            }
        }      
    }
}
