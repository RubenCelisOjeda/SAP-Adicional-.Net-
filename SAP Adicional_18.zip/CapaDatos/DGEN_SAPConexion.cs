﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades;
using SAPbobsCOM;
using Entidades.VEN_SolNotCre;


namespace CapaDatos
{

    public class DGEN_SAPConexion
    {
        private static SAPbobsCOM.Company oCompany = new SAPbobsCOM.Company();

        DVarGlo dvarglo = DVarGlo.Instance();

        public AuthenticateUserResultsEnum SAP_ValidarUsuario(string Usuario, string Password)
        {
            oCompany.Server = "zeus";
            oCompany.CompanyDB = dvarglo.BaseSAP; //"SBO_TRAZ_PROD";
            oCompany.LicenseServer = "zeus:30000";            
            oCompany.DbServerType = BoDataServerTypes.dst_MSSQL2012;
            oCompany.UseTrusted = false;

            return oCompany.AuthenticateUser(Usuario, Password);

        }     
        
        public Int32 SAP_ConectarCompañia(string Usuario, string Password)
        {
            //oCompany.DbUserName = "sa";
            //oCompany.DbPassword = "SQL400%";
            oCompany.Server = "zeus";
            oCompany.CompanyDB = dvarglo.BaseSAP; //"SBO_TRAZ_PROD";
            oCompany.LicenseServer = "zeus:30000";
            oCompany.DbServerType = BoDataServerTypes.dst_MSSQL2012;
            oCompany.UseTrusted = false;
            oCompany.UserName = Usuario;
            oCompany.Password = Password;

            //int ret = oCompany.Connect();
            //string errMsg = oCompany.GetLastErrorDescription();
            //int errNo = oCompany.GetLastErrorCode();

            if (oCompany.Connected == false)
            {
                return oCompany.Connect();
            }
            else
            {
                return 0;
            }
            
        }

        //public void VEN_SolNotCre_MigSAP(Int64 nummov, Int64 docnum, short tipnotcre)
        //{
        //    using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
        //    {              

        //        SAPbobsCOM.Documents vDoc;

        //        vDoc = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oDrafts);
        //        vDoc.DocObjectCode = BoObjectTypes.oCreditNotes;

        //        //Campos de encabezado
        //        SqlDataAdapter daEnc = new SqlDataAdapter("VEN_SolNotCre_MigSAP_Enc", cnx);
        //        daEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
        //        daEnc.SelectCommand.Parameters.Add("@docnum", SqlDbType.Int).Value = docnum;
        //        daEnc.SelectCommand.Parameters.Add("@tipnotcre", SqlDbType.TinyInt).Value = tipnotcre;

        //        DataTable dtEnc = new DataTable();

        //        daEnc.Fill(dtEnc);

        //        DateTime Hoy = DateTime.Today;
                
        //        vDoc.CardCode = dtEnc.Rows[0]["CardCode"].ToString();
        //        vDoc.CardName = dtEnc.Rows[0]["CardName"].ToString();
        //        vDoc.Address = dtEnc.Rows[0]["Address"].ToString();
        //        vDoc.Address2 = dtEnc.Rows[0]["Address2"].ToString();
        //        vDoc.DocDate = Convert.ToDateTime(Hoy.ToString("d"));
        //        vDoc.TaxDate = Convert.ToDateTime(Hoy.ToString("d"));
        //        vDoc.DocCurrency = dtEnc.Rows[0]["DocCur"].ToString();
        //        vDoc.JournalMemo = dtEnc.Rows[0]["JournalMemo"].ToString();
        //        vDoc.DocRate = Convert.ToDouble(dtEnc.Rows[0]["DocRate"].ToString());

        //        //Campos de usuario
        //        vDoc.UserFields.Fields.Item("U_SYP_MDTD").Value = "07"; //Tipo Documento
        //        vDoc.UserFields.Fields.Item("U_SYP_MDSD").Value = dtEnc.Rows[0]["u_syp_mdsd"].ToString(); //Serie Documento

        //        vDoc.UserFields.Fields.Item("U_SYP_MDTO").Value = dtEnc.Rows[0]["u_syp_mdtd"].ToString(); //Tipo Doc. vinculado (SUNAT)
        //        vDoc.UserFields.Fields.Item("U_SYP_MDSO").Value = dtEnc.Rows[0]["u_syp_mdsd"].ToString(); //Serie Doc. Vinculado (SUNAT)
        //        vDoc.UserFields.Fields.Item("U_SYP_MDCO").Value = dtEnc.Rows[0]["u_syp_mdcd"].ToString(); // Correlativo doc.vinculado (SUNAT)

        //        vDoc.UserFields.Fields.Item("U_SYP_RQ").Value = dtEnc.Rows[0]["u_syp_rq"].ToString(); //rq
        //        vDoc.UserFields.Fields.Item("U_SYP_MDMT").Value = "99"; //Motivo de traslado
        //        vDoc.UserFields.Fields.Item("U_SYP_FECHAREF").Value = dtEnc.Rows[0]["DocDate"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_MOTNCND").Value = "-"; //Motivo de emision N.C./N.D.

        //        if (tipnotcre == 1) //Si la nota de credito es de tipo mercaderia
        //        {
        //            vDoc.UserFields.Fields.Item("U_SYP_TPONC").Value = "07"; //Tipo de nota de credito
        //            vDoc.UserFields.Fields.Item("U_SYP_MOTNC").Value = "Devolucion de mercaderia"; //Tipo de nota de credito
        //        }

        //        vDoc.UserFields.Fields.Item("U_SYP_FETO").Value = "VENTA_INTERNA"; //FE - Tipo de operacion
                
        //        //Campos de Detalle
        //        SqlDataAdapter daDet = new SqlDataAdapter("VEN_SolNotCre_MigSAP_Det", cnx);
        //        daDet.SelectCommand.CommandType = CommandType.StoredProcedure;
        //        daDet.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
        //        daDet.SelectCommand.Parameters.Add("@docnumfac", SqlDbType.Int).Value = docnum;

        //        DataTable dtDet = new DataTable();

        //        daDet.Fill(dtDet);

        //        foreach (DataRow dr in dtDet.Rows)
        //        {
        //            vDoc.Lines.ItemCode = dr["CodArt"].ToString();
        //            vDoc.Lines.Quantity = Convert.ToDouble(dr["CanSol"].ToString());
        //            vDoc.Lines.DiscountPercent = Convert.ToDouble(dr["PorDes"].ToString());
        //            vDoc.Lines.UnitPrice = Convert.ToDouble(dr["PreUni"].ToString());
        //            vDoc.Lines.WarehouseCode = dr["CodAlm"].ToString();

        //            if (!string.IsNullOrEmpty(dr["AbsEntry"].ToString()))
        //            {
        //                vDoc.Lines.BinAllocations.BinAbsEntry = Convert.ToInt32(dr["AbsEntry"].ToString());
        //                vDoc.Lines.BinAllocations.Quantity = Convert.ToDouble(dr["CanSol"].ToString());
        //            }

        //            vDoc.Lines.CostingCode = dr["Area"].ToString();
        //            vDoc.Lines.CostingCode2 = dr["SubArea"].ToString();
        //            vDoc.Lines.CostingCode3 = dr["UnidadNegocio"].ToString();
        //            vDoc.Lines.AccountCode = dr["AcctCode"].ToString();
        //            vDoc.Lines.COGSAccountCode = dr["CogsAcct"].ToString();
        //            vDoc.Lines.SalesPersonCode = Convert.ToInt32(dr["slpCode"]);
                                      
        //            vDoc.Lines.UserFields.Fields.Item("U_SYP_FECAT07").Value = "10";

        //            vDoc.Lines.Add();
        //        }

        //        vDoc.SalesPersonCode = Convert.ToInt16(dtEnc.Rows[0]["slpCode"].ToString());
        //        vDoc.DocumentsOwner = Convert.ToInt16(dtEnc.Rows[0]["OwnerCode"].ToString());

        //        vDoc.Add();

        //        oCompany.Disconnect();              
        //    }
            
        //}

        //public void VEN_Cot_MigSAP(out string docentry, out string errorSAP, Int64 nummov, string empresa)
        //{

        //    docentry = ""; errorSAP = "";

        //    using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
        //    {

        //        SAPbobsCOM.Documents vDoc;

        //        vDoc = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oQuotations);
        //        vDoc.DocObjectCode = BoObjectTypes.oCreditNotes;

        //        //Campos de encabezado
        //        SqlDataAdapter daEnc = new SqlDataAdapter("VEN_CotEnc_rec", cnx);
        //        daEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
        //        daEnc.SelectCommand.Parameters.Add("@nummov",SqlDbType.Int).Value = nummov;

        //        DataTable dtEnc = new DataTable();

        //        daEnc.Fill(dtEnc);

        //        vDoc.CardCode = dtEnc.Rows[0]["CardCode"].ToString();
        //        vDoc.CardName = dtEnc.Rows[0]["NomCli"].ToString();
        //        vDoc.Address = dtEnc.Rows[0]["DirCli"].ToString();
        //        vDoc.Address2 = dtEnc.Rows[0]["DirObr"].ToString();

        //        if (dtEnc.Rows[0]["DocCur"].ToString() == "S/")
        //        {
        //            vDoc.DocRate = 1;
        //        }
        //        else
        //        {
        //            vDoc.DocRate = Convert.ToDouble(dtEnc.Rows[0]["DocRate"]);
        //        }

        //        if (empresa.Contains("TRAZZO"))
        //        {
        //            vDoc.DocCurrency = dtEnc.Rows[0]["DocCur"].ToString();
        //        }
        //        else
        //        {
        //            vDoc.DocCurrency = (dtEnc.Rows[0]["DocCur"].ToString() == "USD" ? "US$" : "S/");
        //        }

        //        vDoc.TaxDate = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
        //        vDoc.DocDate = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));
        //        vDoc.SalesPersonCode = Convert.ToInt16(dtEnc.Rows[0]["CodVen"]);
        //        vDoc.DocumentsOwner = Convert.ToInt16(dtEnc.Rows[0]["CodTitVen"]);

        //        //Campos de usuario

        //        vDoc.UserFields.Fields.Item("U_SYP_NOM_VENTA").Value = dtEnc.Rows[0]["Motivo"].ToString() + " - " + dtEnc.Rows[0]["NomCot"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_C_VENTA").Value = dtEnc.Rows[0]["CodCenVen"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_TIVENTA").Value = dtEnc.Rows[0]["CodTipVen"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_TVENTA_REL").Value = dtEnc.Rows[0]["TipVenRel"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_RUBRO").Value = dtEnc.Rows[0]["Rub"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_TIPO_OBRA").Value = dtEnc.Rows[0]["TipObr"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_DIMENSION").Value = dtEnc.Rows[0]["Dim"].ToString();
        //        vDoc.UserFields.Fields.Item("U_SYP_COD_RECOM").Value = "Ninguno";
        //        vDoc.UserFields.Fields.Item("U_SYP_NOM_REC").Value = dtEnc.Rows[0]["Rec"].ToString();
        //        vDoc.UserFields.Fields.Item("U_TRZ_NUMCOT").Value = dtEnc.Rows[0]["NumCot"].ToString();


        //        vDoc.UserFields.Fields.Item("U_TRZ_FACTIE").Value = dtEnc.Rows[0]["Tiempo"].ToString();
        //        vDoc.UserFields.Fields.Item("U_TRZ_FACOPCPAG").Value = dtEnc.Rows[0]["Opcion de Pago"].ToString();
        //        vDoc.UserFields.Fields.Item("U_TRZ_ADMRQ").Value = dtEnc.Rows[0]["AdmRQ"].ToString();

        //        Int64 rq = 0;

        //        Int64.TryParse(dtEnc.Rows[0]["u_syp_rq"].ToString(), out rq);

        //        if (rq != 0)
        //        {
        //            vDoc.UserFields.Fields.Item("U_SYP_RQ").Value = rq.ToString();
        //        }

        //        //Lineas de detalle
        //        SqlDataAdapter daDet = new SqlDataAdapter("VEN_Cot_ExpSAP", cnx);
        //        daDet.SelectCommand.CommandType = CommandType.StoredProcedure;
        //        daDet.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

        //        DataTable dtDet = new DataTable();

        //        daDet.Fill(dtDet);

        //        foreach (DataRow dr in dtDet.Rows)
        //        {
        //            vDoc.Lines.ItemCode = dr["Codigo"].ToString();
        //            vDoc.Lines.ItemDescription = dr["Des"].ToString();
        //            vDoc.Lines.Quantity = Convert.ToDouble(dr["Cantidad"]);                    
        //            vDoc.Lines.UserFields.Fields.Item("U_SYP_AMBIENTE").Value = dr["Ambiente"].ToString();
        //            vDoc.Lines.UnitPrice = Convert.ToDouble(dr["Precio Und."]);
        //            vDoc.Lines.DiscountPercent = Convert.ToDouble(dr["% de dscto"]);
        //            vDoc.Lines.CostingCode = dr["Area"].ToString();
        //            vDoc.Lines.CostingCode2 = dr["Sub área"].ToString();
        //            vDoc.Lines.CostingCode3 = dr["Unidad de negocio"].ToString();
        //            //
        //            if (empresa.Contains("TRAZZO"))
        //            {
        //                vDoc.Lines.Currency = dtEnc.Rows[0]["DocCur"].ToString();
        //            }
        //            else
        //            {
        //                vDoc.Lines.Currency = (dtEnc.Rows[0]["DocCur"].ToString() == "USD" ? "US$" : "S/");
        //            }

        //            //
        //            vDoc.Lines.Add();
        //        }

        //        int retval = 0;

        //        retval = vDoc.Add();

        //        if (retval != 0)
        //        {
        //            errorSAP = oCompany.GetLastErrorDescription();
        //        }
        //        else
        //        {
        //            docentry = oCompany.GetNewObjectKey();

        //        }

        //        oCompany.Disconnect();
        //    }
        //}

        //public void VEN_MaeArt_ActDat(out string errorSAP, string itemcode, double lon, double anc, 
        //                                double alt, double pes, string clagen,
        //                                string nomuni, string caradi)
        //{

        //    errorSAP = "";

        //    SAPbobsCOM.Items oItems;

        //    oItems = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems);

        //    if (oItems.GetByKey(itemcode) == true)
        //    {
        //        oItems.PurchaseUnitLength = lon;
        //        oItems.PurchaseUnitWidth = anc;
        //        oItems.PurchaseUnitHeight = alt;
        //        oItems.PurchaseUnitVolume = lon * anc * alt;
        //        oItems.PurchaseUnitWeight = pes;
        //        oItems.UserFields.Fields.Item("U_SYP_CLAS_GENERAL").Value = clagen;
        //        oItems.UserFields.Fields.Item("U_SYP_NOMBRE_UNICO").Value = nomuni;
        //        oItems.UserFields.Fields.Item("U_SYP_CARACT_ADIC").Value = caradi;

        //        int retval = 0;

        //        retval = oItems.Update();

        //        if (retval != 0)
        //        {
        //            errorSAP = oCompany.GetLastErrorDescription();
        //        }

        //    } 
        //    else
        //    {
        //        errorSAP = "No se encontró el código de artículo.";
        //    }                          
        //}
    }
}
