﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using CapaDatos;

namespace CapaDatos
{
    public class DCam_Contra
    {
        public SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena);
        public DataTable Rec_UsuarioEmpleado(Int16 CodUsu)
        {
            SqlDataAdapter RecUsu = new SqlDataAdapter("SELECT Usuario FROM UsuarioEmpleado WHERE CodigoUsuario=@codusu", cn);
            RecUsu.SelectCommand.CommandType = CommandType.Text;
            RecUsu.SelectCommand.Parameters.Add("@codusu",SqlDbType.SmallInt).Value = CodUsu;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            RecUsu.Fill(dt);
            return dt;
            
        }
        public void Act_UsuarioClave(Int16 CodUsu,string Clave)
        {
            using (SqlCommand ActCla = new SqlCommand("update Usuario set Clave=@clave where CodigoUsuario=@codusu",cn))
            {
                cn.Open();
                ActCla.CommandType = CommandType.Text;
                ActCla.Parameters.Add("@codusu",SqlDbType.SmallInt).Value = CodUsu;
                ActCla.Parameters.Add("@clave", SqlDbType.NVarChar).Value = Clave;
                ActCla.ExecuteNonQuery();
                cn.Close();
            }
        }

        public bool Val_UsuarioClave(int codUsu ,string clave,bool res)
        {
            SqlDataAdapter ValUsu = new SqlDataAdapter("UsuarioCambioPass", cn);
            ValUsu.SelectCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter Res = new SqlParameter("@Res", SqlDbType.Bit);
            Res.Direction = ParameterDirection.InputOutput;

            ValUsu.SelectCommand.Connection.Open();
            ValUsu.SelectCommand.Parameters.Add("@Codigo",SqlDbType.Int).Value = codUsu;
            ValUsu.SelectCommand.Parameters.Add("@Clave", SqlDbType.NVarChar,15).Value = clave;                
            ValUsu.SelectCommand.Parameters.Add(Res).Value = res;
            ValUsu.SelectCommand.ExecuteNonQuery();
            ValUsu.SelectCommand.Connection.Close();

            return res = Convert.ToBoolean(ValUsu.SelectCommand.Parameters["@Res"].Value);
        } 
    }
}
