﻿using Entidades.Men_Fav;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DMenFav
    {
       private SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena);
       public void MenFav_InsAct(byte Consulta, AgrMenu_Enc Enc)
        {
            switch (Consulta)
            {
                case 1:
                    using (SqlCommand cmdInsMen = new SqlCommand("INSERT INTO Men_Agr (codMen,nomMen,CodigoUsuario) VALUES (@codMen,@nomMen,@codUsu)", cn))
                    {
                        cn.Open();
                        cmdInsMen.CommandType = CommandType.Text;
                        cmdInsMen.Parameters.Add("@codMen", SqlDbType.NVarChar, 100).Value = Enc.CodMen;
                        cmdInsMen.Parameters.Add("@nomMen", SqlDbType.NVarChar, 100).Value = Enc.NomMen;
                        cmdInsMen.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                        cmdInsMen.ExecuteNonQuery();
                        cn.Close();
                    }
                    break;
                case 2:
                    using (SqlCommand cmdActMen = new SqlCommand("UPDATE Men_Agr Set nomMen = @nomMen WHERE codMen = @codMen AND CodigoUsuario = @codUsu", cn))
                    {
                        cn.Open();
                        cmdActMen.CommandType = CommandType.Text;
                        cmdActMen.Parameters.Add("@nomMen", SqlDbType.NVarChar,100).Value = Enc.NomMen;
                        cmdActMen.Parameters.Add("@codMen", SqlDbType.NVarChar, 100).Value = Enc.CodMen;
                        cmdActMen.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                        cmdActMen.ExecuteNonQuery();
                        cn.Close();
                    }
                    break;
            }
        }
        public DataTable MenFav_Rec(Int16 CodUsu)
        {
            SqlDataAdapter daRecMen = new SqlDataAdapter("SELECT nomMen[Nombre formulario de usuario],codMen [Nombre de formulario],CodigoUsuario FROM Men_Agr WHERE CodigoUsuario = @codUsu", cn);
            daRecMen.SelectCommand.CommandType = CommandType.Text;
            daRecMen.SelectCommand.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = CodUsu;

            DataTable dtRecMen = new DataTable();
            dtRecMen.Locale = System.Globalization.CultureInfo.InvariantCulture;
            daRecMen.Fill(dtRecMen);
            return dtRecMen;
        }
        public void MenFav_Eli(string CodMenu, Int16 CodUsu)
        {
            using (SqlCommand cmdEliMen = new SqlCommand("DELETE FROM Men_Agr WHERE codMen = @codMen AND CodigoUsuario = @codUsu", cn))
            {
                cn.Open();
                cmdEliMen.CommandType = CommandType.Text;
                cmdEliMen.Parameters.Add("@codMen", SqlDbType.NVarChar,100).Value = CodMenu;
                cmdEliMen.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = CodUsu;
                cmdEliMen.ExecuteNonQuery();
                cn.Close();
            }
        }

        public DataTable MenFav_RecMenFav( Int16 CodUsu)
        {
            SqlDataAdapter daRecMenFav = new SqlDataAdapter("SELECT * FROM Men_Agr WHERE  CodigoUsuario = @codUsu", cn);
            daRecMenFav.SelectCommand.CommandType = CommandType.Text;
            daRecMenFav.SelectCommand.Parameters.Add("@codUsu", SqlDbType.SmallInt).Value = CodUsu;

            DataTable dtRecMenFav = new DataTable();
            dtRecMenFav.Locale = System.Globalization.CultureInfo.InvariantCulture;
            daRecMenFav.Fill(dtRecMenFav);
            return dtRecMenFav;
        }

    }
}
