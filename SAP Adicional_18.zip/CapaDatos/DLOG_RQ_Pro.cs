﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class DLOG_RQ_Pro
    {
        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

        public DataTable LOG_RQ_PROVEEDOR(int rqDes, int rqHas)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_RQ_PROVEEDOR]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@rqdesde", SqlDbType.Int).Value = rqDes;
            da.SelectCommand.Parameters.Add("@rqhasta", SqlDbType.Int).Value = rqHas;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public void LOG_RQ_Proveedor_Obs(int posNrq, string posCodArt, string obs)
        {            

            using (SqlCommand cmd = new SqlCommand("DELETE LOG_RQ_ProveedorObs WHERE NumRQ = @posNrq AND CodArt = @posCodArt", cnx))
            {
                cnx.Open();
                cmd.Parameters.Add("@posNrq", SqlDbType.Int).Value = posNrq;
                cmd.Parameters.Add("@posCodArt", SqlDbType.NVarChar, 10).Value = posCodArt;
                cmd.ExecuteNonQuery();
                cnx.Close();
            }
            using (SqlCommand cmd = new SqlCommand("INSERT INTO LOG_RQ_ProveedorObs (NumRQ,CodArt,Obs) VALUES (@posNrq,@posCodArt,@obs)", cnx))
            {
                cnx.Open();
                cmd.Parameters.Clear();
                cmd.Parameters.Add("@posNrq", SqlDbType.Int).Value = posNrq;
                cmd.Parameters.Add("@posCodArt", SqlDbType.NVarChar, 10).Value = posCodArt;
                cmd.Parameters.Add("@obs", SqlDbType.NVarChar, 400).Value = obs;
                cmd.ExecuteNonQuery();
                cnx.Close();
            }
        }

    }
}
