﻿using Entidades.Ruta_Item;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DRuta_Item
    {
        private string consulta = "";

        public void Ruta_ItemDocRel_Eliminar(int NumMovRut,Int16 TipDoc, int NumDoc)
        {
            consulta = @"DELETE RutaDocRel WHERE NumMovRut = @numMov and 
                                                      TipDoc = @tipDoc and 
                                                      NumDoc = @numDoc";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdEliDocRel = new SqlCommand(consulta, cn))
                {
                    cmdEliDocRel.Connection.Open();
                    cmdEliDocRel.CommandType = CommandType.Text;
                    cmdEliDocRel.Parameters.Add("@numMov", SqlDbType.Int).Value = NumMovRut;
                    cmdEliDocRel.Parameters.Add("@tipDoc", SqlDbType.TinyInt).Value = TipDoc;
                    cmdEliDocRel.Parameters.Add("@numDoc", SqlDbType.Int).Value = NumDoc;
                    cmdEliDocRel.ExecuteNonQuery();
                    cmdEliDocRel.Connection.Close();
                }
            }
        }

        public void Ruta_ItemDocRel_Guardar(Ruta_Item_Enc DocRel)
        {
            consulta = "INSERT RutaDocRel(NumMovRut,TipDoc,NumDoc) VALUES (@numMovRut,@tipDoc,@numDoc)";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdGuDocRel = new SqlCommand(consulta, cn))
                {
                    cmdGuDocRel.Connection.Open();
                    cmdGuDocRel.CommandType = CommandType.Text;
                    cmdGuDocRel.Parameters.Add("@numMovRut", SqlDbType.Int).Value = DocRel.NumMovRut;
                    cmdGuDocRel.Parameters.Add("@tipDoc", SqlDbType.TinyInt).Value = DocRel.TipDoc;
                    cmdGuDocRel.Parameters.Add("@numDoc", SqlDbType.Int).Value = DocRel.NumDoc;
                    cmdGuDocRel.ExecuteNonQuery();
                    cmdGuDocRel.Connection.Close();
                }
            }
        }

        public DataTable Ruta_Item_Filtros(string vista, string procedimiento, string param,string param2="")
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daFiltros = new SqlDataAdapter(procedimiento, cn))
                {
                    daFiltros.SelectCommand.CommandType = CommandType.StoredProcedure;

                    switch (vista)
                    {
                        case "Tipo de Ruta":
                        case "Medio Transporte":
                            daFiltros.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 50).Value = param;
                            break;
                        case "Transportista":
                            daFiltros.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 100).Value = param;
                            break;
                        case "Distrito":
                            daFiltros.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param;
                            break;
                        case "Corte":
                            daFiltros.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 60).Value = param;
                            break;

                        //documentos relacinados
                        case "Entrega":
                            daFiltros.SelectCommand.CommandType = CommandType.StoredProcedure;
                            daFiltros.SelectCommand.Parameters.Add("@RQ", SqlDbType.Int).Value = Convert.ToInt32(param);
                            break;
                        case "Solicitud de traslado":
                        case "Traslado":
                            daFiltros.SelectCommand.Parameters.Add("@NumRQ ", SqlDbType.Int).Value = Convert.ToInt32(param);
                            daFiltros.SelectCommand.Parameters.Add("@Fec ", SqlDbType.SmallDateTime).Value = param2;
                            break;
                        case "Herramientas":
                            daFiltros.SelectCommand.Parameters.Add("@FecDes", SqlDbType.SmallDateTime).Value = param2;
                            break;
                        default:
                            break;
                    }

                    DataTable dtFiltros = new DataTable();
                    dtFiltros.Locale = CultureInfo.InvariantCulture;
                    daFiltros.Fill(dtFiltros);
                    return dtFiltros;
                }
            }
        }
       
        public void Ruta_Item_Eliminar(Int32 NumMov)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdEliRutPro = new SqlCommand("DELETE RutaProgramacion WHERE NumeroMovimiento =@numMov", cn))
                {
                    cmdEliRutPro.Connection.Open();
                    cmdEliRutPro.CommandType = CommandType.Text;
                    cmdEliRutPro.Parameters.Add("@numMov", SqlDbType.Int).Value = NumMov;
                    cmdEliRutPro.ExecuteNonQuery();

                    using (SqlCommand cmdEliDocRel = new SqlCommand("DELETE RutaDocRel WHERE NumMovRut =@numMov", cn))
                    {
                        cmdEliDocRel.CommandType = CommandType.Text;
                        cmdEliDocRel.Parameters.Add("@numMov", SqlDbType.Int).Value = NumMov;
                        cmdEliDocRel.ExecuteNonQuery();
                        cmdEliRutPro.Connection.Close();
                    }
                }
            }
        }

        public void Ruta_Item_GuardarActualizar(Ruta_Item_Enc Enc)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdGuaAct = new SqlCommand("[RutaItem_ActualizaGuarda]", cn))
                {
                    cmdGuaAct.Connection.Open();
                    cmdGuaAct.CommandType = CommandType.StoredProcedure;
                    cmdGuaAct.Parameters.Add("@Accion", SqlDbType.TinyInt).Value = Enc.Acc;

                    SqlParameter parNuMov = new SqlParameter("@NumeroMovimiento", SqlDbType.Int);
                    parNuMov.Direction = ParameterDirection.InputOutput;

                    cmdGuaAct.Parameters.Add(parNuMov).Value = Enc.NumMov;
                    cmdGuaAct.Parameters.Add("@CodTipRut", SqlDbType.TinyInt).Value = Enc.CodTipRut;
                    cmdGuaAct.Parameters.Add("@NumRQ", SqlDbType.Int).Value = Enc.NumRq;
                    cmdGuaAct.Parameters.Add("@Cliente", SqlDbType.NVarChar, 210).Value = Enc.Cli;
                    cmdGuaAct.Parameters.Add("@FechaRuta", SqlDbType.SmallDateTime).Value = Enc.FecRut;
                    cmdGuaAct.Parameters.Add("@CodTipPed", SqlDbType.TinyInt).Value = Enc.CodTipPed;
                    cmdGuaAct.Parameters.Add("@CodTra", SqlDbType.SmallInt).Value = Enc.CodTra;
                    cmdGuaAct.Parameters.Add("@Direccion", SqlDbType.NVarChar, 200).Value = Enc.Dir;
                    cmdGuaAct.Parameters.Add("@CodDis", SqlDbType.SmallInt).Value = Enc.CodDis;
                    cmdGuaAct.Parameters.Add("@CodCorPed", SqlDbType.TinyInt).Value = Enc.CodCorPed;
                    cmdGuaAct.Parameters.Add("@CodRut", SqlDbType.TinyInt).Value = Enc.CodRut;
                    cmdGuaAct.Parameters.Add("@Hora", SqlDbType.NVarChar, 50).Value = Enc.Hora;
                    cmdGuaAct.Parameters.Add("@HOpcion", SqlDbType.TinyInt).Value = Enc.HOpcion;
                    cmdGuaAct.Parameters.Add("@Contacto", SqlDbType.NVarChar, 100).Value = Enc.Contacto;
                    cmdGuaAct.Parameters.Add("@Tipo", SqlDbType.Char, 1).Value = Enc.Tipo;
                    cmdGuaAct.Parameters.Add("@Encargo", SqlDbType.NVarChar, 800).Value = Enc.Encargo;
                    cmdGuaAct.Parameters.Add("@CodigoUsuario", SqlDbType.SmallInt).Value = Enc.CodUsu;
                    cmdGuaAct.Parameters.Add("@Instalacion", SqlDbType.TinyInt).Value = Enc.Ins;
                    cmdGuaAct.Parameters.Add("@CodTipVen", SqlDbType.NVarChar, 5).Value = Enc.CodTipVen;
                    cmdGuaAct.Parameters.Add("@Coo", SqlDbType.NVarChar, 200).Value = Enc.Coo;
                    cmdGuaAct.Parameters.Add("@NumMovOTI", SqlDbType.Int).Value = Convert.ToInt32(Enc.NumMovOTI);
                    cmdGuaAct.Parameters.Add("@NumMovOdd", SqlDbType.Int).Value = Convert.ToInt32(Enc.NumMovOdd);
                    cmdGuaAct.Parameters.Add("@NumMovOTR", SqlDbType.Int).Value = Convert.ToInt32(Enc.NumMovOtr);
                    cmdGuaAct.ExecuteNonQuery();
                    Enc.NumMov = Convert.ToInt32(cmdGuaAct.Parameters["@NumeroMovimiento"].Value);
                    cmdGuaAct.Connection.Close();
                }
            }
        }

        public int Ruta_Item_CorPed(Int16 CodCorPed,DateTime Fec)
        {
            string consulta = "SELECT * FROM ALM_CorPed_Cor WHERE CodCorPed = @codCordPed and convert(nvarchar(10),FecCor,103)=@fec";

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdCordPed = new SqlCommand(consulta, cnx))
                {
                    cmdCordPed.Connection.Open();
                    cmdCordPed.CommandType = CommandType.Text;
                    cmdCordPed.Parameters.Add("@codCordPed", SqlDbType.TinyInt).Value = CodCorPed;
                    cmdCordPed.Parameters.Add("@fec", SqlDbType.SmallDateTime).Value = Fec.ToShortDateString();
                    return Convert.ToInt32(cmdCordPed.ExecuteScalar()); //retorna la primera fila
                }
            }
        }

        public bool Ruta_Item_AccTipVen(string CodTipVen,Int16 CodUsuAre)
        {
            bool Validar = false;

            consulta = "SELECT * FROM ALM_CorPed_AccTipVen WHERE CodTipVen =@codTipVen and CodUsuAre =@codUsuAre and Ind=0";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daAccTipVen = new SqlDataAdapter(consulta, cn))
                {
                    daAccTipVen.SelectCommand.CommandType = CommandType.Text;
                    daAccTipVen.SelectCommand.Parameters.Add("@codTipVen", SqlDbType.NVarChar, 10).Value = CodTipVen;
                    daAccTipVen.SelectCommand.Parameters.Add("@codUsuAre", SqlDbType.SmallInt).Value = CodUsuAre;

                    DataTable dtAccTipVen = new DataTable();
                    dtAccTipVen.Locale = CultureInfo.InvariantCulture;
                    daAccTipVen.Fill(dtAccTipVen);

                    if (dtAccTipVen.Rows.Count > 0)
                    {
                        Validar = true;
                    }
                    else
                    {
                        string consulta2 = "SELECT * FROM ALM_CordPed_AccTipVen WHERE CodTipVen =@codTipVen and CodUsuAre =@codUsuAre and Ind=1";

                        using (SqlDataAdapter daAccTipVen2 = new SqlDataAdapter(consulta2, cn))
                        {
                            daAccTipVen2.SelectCommand.CommandType = CommandType.Text;
                            daAccTipVen2.SelectCommand.Parameters.Add("@codTipVen", SqlDbType.NVarChar, 10).Value = CodTipVen;
                            daAccTipVen2.SelectCommand.Parameters.Add("@codUsuAre", SqlDbType.SmallInt).Value = CodUsuAre;

                            DataTable dtAccTipVen2 = new DataTable();
                            dtAccTipVen2.Locale = CultureInfo.InvariantCulture;
                            daAccTipVen.Fill(dtAccTipVen2);

                            if (dtAccTipVen2.Rows.Count > 0)
                            {
                                Validar = true;
                            }
                            else
                            {
                                Validar = false;
                            }
                        }

                    }
                    return Validar;
                }
            }
           
        }
       
        public DataTable Ruta_Item_RecDocRel(int NumMov)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecDocRel = new SqlDataAdapter("Ruta_DocRel_Rec", cn))
                {
                    daRecDocRel.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecDocRel.SelectCommand.Parameters.Add("@NumMov", SqlDbType.Int).Value = NumMov;

                    DataTable dtRecDocRel = new DataTable();
                    dtRecDocRel.Locale = CultureInfo.InvariantCulture;
                    daRecDocRel.Fill(dtRecDocRel);
                    return dtRecDocRel;
                }
            }
        }

        public DataTable Ruta_Item_RecEnc(int NumMov)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecEnc = new SqlDataAdapter("RutaItem_Encabezado", cn))
                {
                    daRecEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecEnc.SelectCommand.Parameters.Add("@NumeroMovimiento", SqlDbType.Int).Value = NumMov;

                    DataTable dtRecEnc = new DataTable();
                    dtRecEnc.Locale = CultureInfo.InvariantCulture;
                    daRecEnc.Fill(dtRecEnc);
                    return dtRecEnc;
                }
            }
        }
    }
}
