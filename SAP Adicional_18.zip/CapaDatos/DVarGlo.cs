﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DVarGlo
    {
        private static DVarGlo variables;

        private DVarGlo()
        {

        }

        //Se define un método o propiedad static, la cual será el punto 
        //central por donde se podrá recuperar una instancia de la clase
        //en este punto es donde se valida y crea la instancia de la 
        //variable static definida mas arriba, es por esto que siempre se retorna esta misma instancia.
        public static DVarGlo Instance()
        {
            if (variables == null)
            {
                variables = new DVarGlo();
            }
            return variables;
        }

        public string Cadena { get; set; }
        public string Base { get; set; }
        public string BaseSAP { get; set; }
        public bool ErrorBase { get; set; }
    }
}
