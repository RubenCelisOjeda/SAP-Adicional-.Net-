﻿using CapaDatos;
using Entidades.DMan_ArticuloCompuesto;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DMan_ArticuloCompuesto
    {
        public DataTable Man_ArtCom_Rec()
        {
            string cadena = "SELECT TOP 100 Codigo, Descripcion, Observacion, Tipo, Inactivo, Descuento, RutaImagen,"+
                            "NombreArchivo, RutaAplicacion, [Creado por:], [Creado el:],"+ 
                            "[Modificado por:],[Modificado el:] FROM ArtCom_Maestro order by Codigo";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdRecArtCom = new SqlCommand(cadena,cn))
                {
                    cn.Open();
                    cmdRecArtCom.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    SqlDataReader dr = cmdRecArtCom.ExecuteReader();
                    dt.Load(dr);
                    cn.Close();
                    return dt;
                }
            }
        }

        public DataSet ArtCom_MovGeneral_Rec(Int16 direccion, Int16 DArticulo)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string cod = "";

                using (SqlDataAdapter daArtMovGen = new SqlDataAdapter("[ArtCom_MovGeneral]",cn))
                {

                    daArtMovGen.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daArtMovGen.SelectCommand.Parameters.Clear();

                    daArtMovGen.SelectCommand.Parameters.Add("@Direccion", SqlDbType.SmallInt).Value = direccion;
                    daArtMovGen.SelectCommand.Parameters.Add("@CodArtCom", SqlDbType.SmallInt).Value = DArticulo;
                    daArtMovGen.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 200, null).Value = "";
                    
                    daArtMovGen.Fill(ds,"ArticuloGeneral");
                    dt = ds.Tables["ArticuloGeneral"];

                    // valida la primera vuelta el cod va hacer vacio
                    try
                    {
                        cod = dt.Rows[0]["Codigo"].ToString();
                    }
                    catch { cod = "0"; }
                   
                }

                using (SqlDataAdapter daArtCom_Det = new SqlDataAdapter("ArtCom_recDet", cn))
                {
                    daArtCom_Det.SelectCommand.Parameters.Clear();
                    daArtCom_Det.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daArtCom_Det.SelectCommand.Parameters.Add("@Codigo", SqlDbType.Int).Value = cod;
                    daArtCom_Det.Fill(ds, "ArticuloDetalle");
                }

            }
            return ds;
        }

        public void ArtCom_Act(string cadRut,string nomArc,int codArtCom)
        {
            string cadena = "update ArtCom set RutaImagen = @cadenaruta , NombreArchivo = @nombrearchivo where CodArtCom =@codartcom";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdArtComAct = new SqlCommand(cadena,cn))
                {
                    cn.Open();
                    cmdArtComAct.CommandType = CommandType.Text;
                    cmdArtComAct.Parameters.Clear();
                    cmdArtComAct.Parameters.Add("@cadenaruta",SqlDbType.NVarChar,400).Value = cadRut;
                    cmdArtComAct.Parameters.Add("@nombrearchivo", SqlDbType.NVarChar, 100).Value = nomArc;
                    cmdArtComAct.Parameters.Add("@codartcom", SqlDbType.Int).Value = codArtCom;
                    cmdArtComAct.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }
        public void ArtCom_ActApl(string cadRut,int codArtCom)
        {
            string cadena = "update ArtCom set RutaAplicacion = @cadenaruta where CodArtCom =@codartcom";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdArtComAct = new SqlCommand(cadena, cn))
                {
                    cn.Open();
                    cmdArtComAct.CommandType = CommandType.Text;
                    cmdArtComAct.Parameters.Clear();

                    cmdArtComAct.Parameters.Add("@cadenaruta", SqlDbType.NVarChar, 400).Value = cadRut;
                    cmdArtComAct.Parameters.Add("@codartcom", SqlDbType.Int).Value = codArtCom;
                    cmdArtComAct.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public void ArtCom_Eli(int Cod)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdArtComAct = new SqlCommand("[ArtCom_Eli]", cn))
                {
                    try
                    {
                        cn.Open();
                        cmdArtComAct.CommandType = CommandType.StoredProcedure;
                        cmdArtComAct.Parameters.Add("@Codigo", SqlDbType.Int).Value = Cod;
                        cmdArtComAct.ExecuteNonQuery();
                        cn.Close();
                    }
                    catch
                    {
                        System.Windows.Forms.MessageBox.Show("El articulo compuesto ya esta utilizado,no se puede borrar","Mensaje del sistema",
                                                             System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                        return;
                    }
                }
            }
        }

        public DataTable ArtCom_Tip_Rec()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdArtComAct = new SqlCommand("SELECT CodTipArtCom, Des FROM ArtCom_Tip ORDER BY Des", cn))
                {
                    cn.Open();
                    cmdArtComAct.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    SqlDataReader dr = cmdArtComAct.ExecuteReader();
                    dt.Load(dr);
                    cn.Close();
                    return dt;
                }
            }
        }

        public void ArtCom_ActGua(ArtCom_Enc Enc)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdArtComActGuar = new SqlCommand("ArtCom_actgua", cn))
                {
                    cn.Open();
                    cmdArtComActGuar.CommandType = CommandType.StoredProcedure;
                    cmdArtComActGuar.Parameters.Clear();

                    SqlParameter Cod = new SqlParameter("@Codigo", SqlDbType.Int);
                    Cod.Direction = ParameterDirection.InputOutput;

                    cmdArtComActGuar.Parameters.Add("@Accion", SqlDbType.Bit).Value = Enc.EstReg;
                    cmdArtComActGuar.Parameters.Add(Cod).Value = Enc.Cod;
                    cmdArtComActGuar.Parameters.Add("@Descripcion", SqlDbType.NVarChar,130).Value = Enc.Des;
                    cmdArtComActGuar.Parameters.Add("@Observacion ", SqlDbType.NVarChar, 300).Value = Enc.Obs;
                    cmdArtComActGuar.Parameters.Add("@Tipo ", SqlDbType.TinyInt).Value = Enc.CodTipArt;
                    cmdArtComActGuar.Parameters.Add("@CodUsu", SqlDbType.SmallInt).Value = Enc.CodUsuAct;
                    cmdArtComActGuar.Parameters.Add("@Inactivo", SqlDbType.SmallInt).Value = Enc.Inactivo;
                    cmdArtComActGuar.ExecuteNonQuery();

                    Enc.Cod = Convert.ToInt32(cmdArtComActGuar.Parameters["@Codigo"].Value);

                    cn.Close();
                }
                using (SqlCommand cmdArtComEli = new SqlCommand("DELETE ArtComDet WHERE CodArtCom = @codArtCom", cn))
                {
                    cn.Open();
                    cmdArtComEli.CommandType = CommandType.Text;
                    cmdArtComEli.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.Cod;
                    cmdArtComEli.ExecuteNonQuery();
                    cn.Close();
                }

                using (SqlCommand cmdArtComActGuaDet = new SqlCommand("ArtCom_actguadet", cn))
                {
                    foreach (ArtCom_Det Det in Enc.ArtComDet)
                    {
                        cn.Open();
                        cmdArtComActGuaDet.CommandType = CommandType.StoredProcedure;
                        cmdArtComActGuaDet.Parameters.Clear();
                        cmdArtComActGuaDet.Parameters.Add("@Codigo", SqlDbType.Int).Value = Enc.Cod;
                        cmdArtComActGuaDet.Parameters.Add("@CodigoArticulo", SqlDbType.NVarChar, 12).Value = Det.CodArt;
                        cmdArtComActGuaDet.Parameters.Add("@Cantidad", SqlDbType.SmallInt).Value = Det.Can;
                        cmdArtComActGuaDet.Parameters.Add("@Principal", SqlDbType.SmallInt).Value = Det.Pri;
                        cmdArtComActGuaDet.ExecuteNonQuery();
                        cn.Close();
                    }
                }
            }
        }

        public DataTable Man_ArticulosCompuesto_Filtros(string vista, string procedimiento, string param1, int param2 = 0)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(procedimiento, cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    switch (vista)
                    {
                        case "Tipo":
                            da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 100).Value = param1;
                            break;
                        case "Articulo":
                            da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param1;
                            da.SelectCommand.Parameters.Add("@Tipo", SqlDbType.SmallInt).Value = param2;
                            break;
                        default:
                            break;
                    }

                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public void ArtCom_UpdCol(Int16 Col, ArtComMae_Enc Enc, int CodUsu=0)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                switch (Col) //valida la columna
                {
                    case 1:
                        using (SqlCommand cmdArtComDes = new SqlCommand("update ArtCom set Des=@des where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComDes.CommandType = CommandType.Text;
                            cmdArtComDes.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComDes.Parameters.Add("@des", SqlDbType.NVarChar,130).Value = Enc.Des;
                            cmdArtComDes.ExecuteNonQuery();
                        }
                        break;
                    case 2:
                        using (SqlCommand cmdArtComObs = new SqlCommand("update ArtCom set Obs=@obs where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComObs.CommandType = CommandType.Text;
                            cmdArtComObs.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComObs.Parameters.Add("@obs", SqlDbType.NVarChar,300).Value = Enc.Obs;
                            cmdArtComObs.ExecuteNonQuery();
                        }
                        break;
                    case 3:
                        using (SqlCommand cmdArtComTip = new SqlCommand("update ArtCom set CodTipArtCom=@codTipArtCom where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComTip.CommandType = CommandType.Text;
                            cmdArtComTip.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComTip.Parameters.Add("@codTipArtCom", SqlDbType.TinyInt).Value = Enc.CodTipArtCom;
                            cmdArtComTip.ExecuteNonQuery();
                        }
                        break;
                    case 4:
                        using (SqlCommand cmdArtComIna = new SqlCommand("update ArtCom set Inactivo=@inactivo where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComIna.CommandType = CommandType.Text;
                            cmdArtComIna.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComIna.Parameters.Add("@inactivo", SqlDbType.SmallInt).Value = Enc.Inacivo;
                            cmdArtComIna.ExecuteNonQuery();
                        }
                        break;
                    case 5:
                        using (SqlCommand cmdArtComPorDes = new SqlCommand("update ArtCom set PorDes=@pordes where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComPorDes.CommandType = CommandType.Text;
                            cmdArtComPorDes.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComPorDes.Parameters.Add("@pordes", SqlDbType.Decimal,2).Value = Enc.PorDes;
                            cmdArtComPorDes.ExecuteNonQuery();
                        }
                        break;
                    case 6:
                        using (SqlCommand cmdArtComRutImg = new SqlCommand("update ArtCom set RutaImagen=@rutaImagen where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComRutImg.CommandType = CommandType.Text;
                            cmdArtComRutImg.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComRutImg.Parameters.Add("@rutaImagen", SqlDbType.NVarChar,400).Value = Enc.RutaImagen;
                            cmdArtComRutImg.ExecuteNonQuery();
                        }
                        break;
                    case 8:
                        using (SqlCommand cmdArtComRutApl = new SqlCommand("update ArtCom set RutaAplicacion=@rutaAplica where CodArtCom =@codArtCom", cn))
                        {
                            cn.Open();
                            cmdArtComRutApl.CommandType = CommandType.Text;
                            cmdArtComRutApl.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                            cmdArtComRutApl.Parameters.Add("@rutaAplica", SqlDbType.NVarChar, 400).Value = Enc.RutAplicacion;
                            cmdArtComRutApl.ExecuteNonQuery();
                        }
                        break;
                    default:
                        break;
                }

                //siempre ejecutamos la consulta
                using (SqlCommand cmdArtComFec = new SqlCommand("update ArtCom set FecMod=@fecMod ,CodUsuMod=@codUsuMod where CodArtCom =@codArtCom", cn))
                {
                    cmdArtComFec.CommandType = CommandType.Text;
                    cmdArtComFec.Parameters.Add("@codArtCom", SqlDbType.Int).Value = Enc.CodArtCom;
                    cmdArtComFec.Parameters.Add("@codUsuMod", SqlDbType.Int).Value = CodUsu;
                    cmdArtComFec.Parameters.Add("@fecMod", SqlDbType.SmallDateTime).Value = DateTime.Now;
                    cmdArtComFec.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public int Man_ArtCom_ValCodArt(string CodArt)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {

                string n = DVarGlo.Instance().BaseSAP;
                using (SqlDataAdapter daCodArt = new SqlDataAdapter("select ItemCode from " + DVarGlo.Instance().BaseSAP + ".dbo.OITM where ItemCode = @itemcode", cn))
                {
                    daCodArt.SelectCommand.CommandType = CommandType.Text;
                    daCodArt.SelectCommand.Parameters.Add("@itemcode", SqlDbType.NVarChar).Value = CodArt;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    daCodArt.Fill(dt);
                    return dt.Rows.Count;
                }
            }
        }
    }
}
