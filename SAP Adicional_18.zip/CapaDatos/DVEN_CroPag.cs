﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades.VEN_CroPag;

namespace CapaDatos
{
    public class DVEN_CroPag
    {
        public DataSet VEN_CroPag_Enc_rec(Int64 NumMov)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter("[VEN_CroPag_Enc_rec]", cn))
                    {
                        da.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;

                        da.Fill(ds, "Enc");
                    }

                    using (SqlDataAdapter da2 = new SqlDataAdapter("[VEN_CroPag_EncCot_rec]", cn))
                    {
                        da2.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da2.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;

                        da2.Fill(ds, "EncCotApr");
                        //dt = ds.Tables["EncCotApr"];

                        //n1 = 0;
                        //if (dt.Rows.Count > 0)
                        //{
                        //    n1 = Convert.ToDecimal(dt.Rows[0]["NumMovCot"]);
                        //}
                        //else
                        //{
                        //    n1 = NumMov;
                        //}
                    }

                    //using (SqlDataAdapter da3 = new SqlDataAdapter("[VEN_CroPag_TotDoc]", cn))
                    //{
                    //    da3.SelectCommand.CommandType = CommandType.StoredProcedure;
                    //    da3.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = n1;
                    //    da3.Fill(ds, "Enc2");
                    //}

                    using (SqlDataAdapter da4 = new SqlDataAdapter("[VEN_CroPag_Det_rec]", cn))
                    {
                        da4.SelectCommand.CommandType = CommandType.StoredProcedure;
                        da4.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = NumMov;

                        da4.Fill(ds, "Det");
                    }
                }

            }
            catch (SqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }
            return ds;

        }
        public DataTable VEN_CroPag_Tot_CA_OFV_ODV(string nummovcot)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("[VEN_CroPag_TotDoc]", cn);
                
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummovcot;

                DataTable dt = new DataTable();
                da.Fill(dt);

                return dt;
            }
            
            //DataSet ds = new DataSet();
            //using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            //{

            //    using (SqlDataAdapter da = new SqlDataAdapter("[VEN_CroPag_Tot_CotApr]", cn))
            //    {
            //        da.SelectCommand.CommandType = CommandType.StoredProcedure;
            //        da.SelectCommand.Parameters.Add("@nummov", SqlDbType.NVarChar, 100).Value = nummovcot;
            //        da.Fill(ds, "CA");
            //    }
            //    using (SqlDataAdapter da2 = new SqlDataAdapter("[VEN_CroPag_Tot_OfeVen]", cn))
            //    {
            //        da2.SelectCommand.CommandType = CommandType.StoredProcedure;
            //        da2.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = Convert.ToInt32(nummovcot);

            //        da2.Fill(ds, "OFV");
            //    }
            //    using (SqlDataAdapter da3 = new SqlDataAdapter("[VEN_CroPag_Tot_OrdVen]", cn))
            //    {
            //        da3.SelectCommand.CommandType = CommandType.StoredProcedure;
            //        da3.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummovcot;

            //        da3.Fill(ds, "ODV");
            //    }
            //}
            //return ds;
        }

        public DataTable VEN_CroPag_visgen(Int16 Columna, string filtro)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("VEN_CroPag_visgen", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.Add("@Col", SqlDbType.Int).Value = Columna;
                    da.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar,100).Value = filtro;

                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable VEN_CroPag_CotMigRQ(int NumRq, string cadnummovcot)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter CotMigRq = new SqlDataAdapter("VEN_CroPag_CotMigRQ", cn))
                {
                    CotMigRq.SelectCommand.Parameters.Clear();
                    CotMigRq.SelectCommand.CommandType = CommandType.StoredProcedure;
                    CotMigRq.SelectCommand.Parameters.Add("@NumRQ", SqlDbType.Int).Value = NumRq;
                    CotMigRq.SelectCommand.Parameters.Add("@cadnummovcot", SqlDbType.NVarChar, 200).Value = cadnummovcot;

                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    CotMigRq.Fill(dt);
                    return dt;
                }
            }
        }

        public void VEN_CroPag_Enc_actgua(VEN_CroPag Enc)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand EncActGua = new SqlCommand("VEN_CroPag_Enc_actgua", cn))
                {
                    EncActGua.CommandType = CommandType.StoredProcedure;

                    SqlParameter paraNumMov = new SqlParameter("@nummov", SqlDbType.Int);
                    paraNumMov.Direction = ParameterDirection.InputOutput;

                    SqlParameter paraNumCro = new SqlParameter("@numcro", SqlDbType.NVarChar, 11);
                    paraNumCro.Direction = ParameterDirection.InputOutput;

                    EncActGua.Parameters.Add(paraNumMov).Value = Enc.NumMov;
                    EncActGua.Parameters.Add(paraNumCro).Value = Enc.NumCro;
                    EncActGua.Parameters.Add("@rq", SqlDbType.Int).Value = Enc.Rq;
                    EncActGua.Parameters.Add("@obs", SqlDbType.NVarChar, 800).Value = Enc.Obs;
                    EncActGua.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;

                    cn.Open();
                    EncActGua.ExecuteNonQuery();

                    Enc.NumMov = Convert.ToInt64(EncActGua.Parameters["@nummov"].Value);
                    Enc.NumCro = Convert.ToString(EncActGua.Parameters["@numcro"].Value);
                }

                using (SqlCommand DetTEncCot = new SqlCommand("DELETE VEN_CroPag_EncCot WHERE NumMov = @NumMov", cn))
                {
                    DetTEncCot.CommandType = CommandType.Text;
                    DetTEncCot.Parameters.Add("@NumMov", SqlDbType.Int).Value = Enc.NumMov;
                    DetTEncCot.ExecuteNonQuery();
                }

                using (SqlCommand EncCotVin = new SqlCommand("INSERT INTO VEN_CroPag_EncCot (NumMov,NumMovCot,NumCot,RQ) VALUES (@nummov,@nummovcot,@numcot,@rq)", cn))
                {
                    foreach (VEN_CroPag_Cot EncCot in Enc.CroPagCot)
                    {
                        EncCotVin.Parameters.Clear();
                        EncCotVin.CommandType = CommandType.Text;
                        EncCotVin.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        EncCotVin.Parameters.Add("@nummovcot", SqlDbType.Int).Value = EncCot.NumMovCot; // hacer una entidad
                        EncCotVin.Parameters.Add("@numcot", SqlDbType.NVarChar).Value = EncCot.NumCot; // hacer una entidad
                        EncCotVin.Parameters.Add("@rq", SqlDbType.Int).Value = Enc.Rq;
                        EncCotVin.ExecuteNonQuery();
                    }

                }

                using (SqlCommand EncCroPagDet = new SqlCommand("DELETE VEN_CroPag_Det WHERE NumMov = @numMov", cn))
                {
                    VEN_CroPag_Det Det = new VEN_CroPag_Det();

                    EncCroPagDet.CommandType = CommandType.Text;
                    EncCroPagDet.Parameters.Add("@NumMov", SqlDbType.Int).Value = Enc.NumMov;
                    EncCroPagDet.ExecuteNonQuery();

                }
                using (SqlCommand CroDet = new SqlCommand("INSERT INTO VEN_CroPag_Det (NumMov,Item,FecCuo,MonCuo,Obs,Sit,FecPag,MonPag) VALUES (@nummov,@item,@feccuo,@moncuo,@obs,@sit,@fecpag,@monpag)", cn))
                {

                    foreach (VEN_CroPag_Det Det in Enc.CroPagDet)
                    {
                        CroDet.Parameters.Clear();
                        CroDet.CommandType = CommandType.Text;
                        CroDet.Parameters.Add("@nummov", SqlDbType.Int).Value = Enc.NumMov;
                        CroDet.Parameters.Add("@item", SqlDbType.Int).Value = Det.Item;
                        CroDet.Parameters.Add("@feccuo", SqlDbType.DateTime).Value = Det.FecCuo;
                        CroDet.Parameters.Add("@moncuo", SqlDbType.Decimal).Value = Det.MonCuo;
                        CroDet.Parameters.Add("@obs", SqlDbType.NVarChar, 100).Value = Det.Obs;
                        CroDet.Parameters.Add("@sit", SqlDbType.Bit).Value = Det.Sit;

                        object Fec;

                        var n = Det.FecPag;

                        if (string.IsNullOrEmpty(n.ToString()))
                        {
                            Fec = DBNull.Value;
                        }
                        else
                        {
                            Fec = Det.FecPag.ToString();
                        }

                        CroDet.Parameters.Add("@fecpag", SqlDbType.SmallDateTime).Value = Fec;
                        CroDet.Parameters.Add("@monpag", SqlDbType.Decimal).Value = Det.MonPag;
                        CroDet.ExecuteNonQuery();
                    }
                }
            }
        }

    }
}
