﻿using Entidades.ALM_Ubi_ConStock;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DALM_Ubi_ConStock
    {
        private string _consulta = "";

        public DataTable ALM_Ubi_ConStock_Filtros(string vista,string procedimiento,
                                                  string param,Int16 param2 = 0)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter daFiltro = new SqlDataAdapter(procedimiento, cn);
                daFiltro.SelectCommand.CommandType = CommandType.StoredProcedure;

                switch (vista)
                {
                    case "Almacen":
                        daFiltro.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 50).Value = param;

                        break;
                    case "Articulo2":
                    case "Articulo":
                        daFiltro.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param;
                        daFiltro.SelectCommand.Parameters.Add("@Tipo", SqlDbType.SmallInt).Value = param2;
                        break;

                    case "Instalador":
                        daFiltro.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param;
                        break;

                    default:
                        break;
                }

                DataTable dtFiltro = new DataTable();
                daFiltro.Fill(dtFiltro);
                return dtFiltro;
            }
        }

        public DataTable ALM_Ubi_ConStock_MosMovDia(DateTime FecDes,DateTime FecHas, string CodAlm,
                                                                           Int16 Tip,string CodArt)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daMosMov = new SqlDataAdapter("ALM_Ubi_MovCon", cn))
                {
                    daMosMov.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daMosMov.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = FecDes;
                    daMosMov.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = FecHas;
                    daMosMov.SelectCommand.Parameters.Add("@CodAlm", SqlDbType.NVarChar, 3).Value = CodAlm;
                    daMosMov.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt, 3).Value = Tip;
                    daMosMov.SelectCommand.Parameters.Add("@CodArt", SqlDbType.NVarChar, 13).Value = CodArt;
                    DataTable dtMosMov = new DataTable();
                    dtMosMov.Locale = CultureInfo.InvariantCulture;
                    daMosMov.Fill(dtMosMov);
                    return dtMosMov;
                }
            }
        }
       
        public DataTable ALM_Ubi_ConStock_ValUbi(Int16 Res,string CodAlm,string Zona, string Rack,
                                                                 string Col,string Fila,char Tipo)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daValUbi = new SqlDataAdapter("ALM_Ubi_ZonaFiltro", cn))
                {
                    daValUbi.SelectCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter paramRes = new SqlParameter("@Res", SqlDbType.Int);
                    paramRes.Direction = ParameterDirection.Output;

                    daValUbi.SelectCommand.Parameters.Add(paramRes).Value = Res;
                    daValUbi.SelectCommand.Parameters.Add("@CodAlm", SqlDbType.NVarChar, 3).Value = CodAlm;
                    daValUbi.SelectCommand.Parameters.Add("@Zona", SqlDbType.NVarChar, 3).Value = Zona;
                    daValUbi.SelectCommand.Parameters.Add("@Rack", SqlDbType.NVarChar, 3).Value = Rack;
                    daValUbi.SelectCommand.Parameters.Add("@Columna", SqlDbType.NVarChar, 3).Value = Col;
                    daValUbi.SelectCommand.Parameters.Add("@Fila", SqlDbType.NVarChar, 3).Value = Fila;
                    daValUbi.SelectCommand.Parameters.Add("@Tipo", SqlDbType.Char, 1).Value = Tipo;

                    DataTable dtValUbi = new DataTable();
                    dtValUbi.Locale = CultureInfo.InvariantCulture;
                    daValUbi.Fill(dtValUbi);
                    return dtValUbi;
                }
            }
        }
       
           
        public DataTable ALM_Ubi_ConStock_RecComStock(Int16 Index)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daComStock = new SqlDataAdapter("ALM_Ubi_ComStock", cn))
                {
                    daComStock.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daComStock.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = Index;
                    DataTable dtComStock = new DataTable();
                    daComStock.Fill(dtComStock);
                    return dtComStock;
                }
            }
        }

        public DataTable ALM_Ubi_ConStock_RecMovDia(DateTime FDes, DateTime FHas, string CodAlm,
                                                                         byte Tip,string CodArt)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecMovDia = new SqlDataAdapter("ALM_Ubi_MovCon", cn))
                {
                    daRecMovDia.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecMovDia.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = FDes;
                    daRecMovDia.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = FHas;
                    daRecMovDia.SelectCommand.Parameters.Add("@CodAlm", SqlDbType.NVarChar, 3).Value = CodAlm;
                    daRecMovDia.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = Tip;
                    daRecMovDia.SelectCommand.Parameters.Add("@CodArt", SqlDbType.NVarChar, 13).Value = CodArt;

                    DataTable dtRecMovDia = new DataTable();
                    dtRecMovDia.Locale = CultureInfo.InvariantCulture;
                    daRecMovDia.Fill(dtRecMovDia);
                    return dtRecMovDia;
                }
            }
        }

        public string  ALM_Ubi_ConStock_StoAlm(string CodAlm,string CodArt)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdUbiStoAlm = new SqlCommand("ALM_UbicacionesStock", cn))
                {
                    cmdUbiStoAlm.Connection.Open();
                    cmdUbiStoAlm.CommandType = CommandType.StoredProcedure;
                    cmdUbiStoAlm.Parameters.Add("@CodAlm",SqlDbType.NVarChar,3).Value = CodAlm;
                    cmdUbiStoAlm.Parameters.Add("@CodArt", SqlDbType.NVarChar, 10).Value = CodArt;

                    SqlDataReader dr = cmdUbiStoAlm.ExecuteReader();
                    string dat = "";

                    while (dr.Read())
                    {
                        dat = dr["Stock"].ToString();
                    }

                    return dat;
                }
            }
        }

        public string ALM_Ubi_ConStock_StoUniSapAdi(string CodArt,string Zon, string Rac, string Col,
                                                                              string Fil,string CodAlm)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdUbiSapAdiStoAlm = new SqlCommand("ALM_UbiStock_SAPAdi", cn))
                {
                    cmdUbiSapAdiStoAlm.Connection.Open();
                    cmdUbiSapAdiStoAlm.CommandType = CommandType.StoredProcedure;
                    cmdUbiSapAdiStoAlm.Parameters.Add("@CodArt", SqlDbType.NVarChar, 20).Value = CodArt;
                    cmdUbiSapAdiStoAlm.Parameters.Add("@zona", SqlDbType.NVarChar, 3).Value = Zon;
                    cmdUbiSapAdiStoAlm.Parameters.Add("@rack", SqlDbType.NVarChar, 3).Value = Rac;
                    cmdUbiSapAdiStoAlm.Parameters.Add("@columna", SqlDbType.NVarChar, 3).Value = Col;
                    cmdUbiSapAdiStoAlm.Parameters.Add("@fila", SqlDbType.NVarChar, 3).Value = Fil;
                    cmdUbiSapAdiStoAlm.Parameters.Add("@codalm", SqlDbType.NVarChar, 8).Value = CodAlm;

                    SqlDataReader dr = cmdUbiSapAdiStoAlm.ExecuteReader();
                    string dat = "";

                    while (dr.Read())
                    {
                        dat = dr["Stock"].ToString();
                    }

                    return dat;
                }
            }
        }

        public void ALM_Ubi_ConStock_ValMovStkFin(ALM_Ubi_ConStock_Enc Ubi)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdValMovStkFin =  new SqlCommand("[ALM_Ubi_MovValStockFin]", cn))
                {
                    cmdValMovStkFin.Connection.Open();
                    cmdValMovStkFin.CommandType = CommandType.StoredProcedure;
                    cmdValMovStkFin.Parameters.Add("@CodArt", SqlDbType.NVarChar,12).Value = Ubi.CodArtSap;
                    cmdValMovStkFin.Parameters.Add("@Cant", SqlDbType.Decimal).Value = Ubi.Can;
                    cmdValMovStkFin.Parameters.Add("@TipMov", SqlDbType.Char, 1).Value = Ubi.TipMov;
                    cmdValMovStkFin.Parameters.Add("@Zona", SqlDbType.NVarChar, 3).Value = Ubi.Zon;
                    cmdValMovStkFin.Parameters.Add("@Rack", SqlDbType.NVarChar, 3).Value = Ubi.Rac;
                    cmdValMovStkFin.Parameters.Add("@Columna", SqlDbType.NVarChar, 3).Value = Ubi.Col;
                    cmdValMovStkFin.Parameters.Add("@Fila", SqlDbType.NVarChar, 3).Value = Ubi.Row;
                    cmdValMovStkFin.Parameters.Add("@CodAlm", SqlDbType.NVarChar, 3).Value = Ubi.CodAlm;
                    cmdValMovStkFin.ExecuteNonQuery();
                }
            }
        }

        public void ALM_Ubi_ConStock_InsMov(ALM_Ubi_ConStock_Enc ubi)
        {
            int numDocCon = 0;
            int numCorr = 0;
            Int16 codRes = 0;

            numDocCon = Convert.ToInt32(ubi.NumDocCon);
            numCorr = Convert.ToInt32(ubi.NumCorr);
            codRes = Convert.ToInt16(ubi.CodRes);

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdValMovStkFin = new SqlCommand("[ALM_Ubi_MovIng]", cn))
                {
                    cmdValMovStkFin.Connection.Open();
                    cmdValMovStkFin.CommandType = CommandType.StoredProcedure;

                    List<SqlParameter> lisPrm = new List<SqlParameter>()
                    {
                        new SqlParameter("@NumMov", SqlDbType.Int) {Value = 0},
                        new SqlParameter("@CodAlm", SqlDbType.NVarChar,3) {Value = ubi.CodAlm },
                        new SqlParameter("@Zona", SqlDbType.NVarChar, 3) {Value = ubi.Zon },
                        new SqlParameter("@Rack", SqlDbType.NVarChar,3) {Value = ubi.Rac },
                        new SqlParameter("@Columna", SqlDbType.NVarChar,3) {Value = ubi.Col },
                        new SqlParameter("@Fila", SqlDbType.NVarChar,3) {Value = ubi.Row },
                        new SqlParameter("@CodArt", SqlDbType.NVarChar,12) {Value = ubi.CodArtSap },
                        new SqlParameter("@TipMov", SqlDbType.Char,1) {Value = ubi.TipMov},
                        new SqlParameter("@Cant", SqlDbType.Decimal){Value = ubi.Can},
                        new SqlParameter("@CodEst", SqlDbType.TinyInt){Value = 1},
                        new SqlParameter("@Obs", SqlDbType.NVarChar,200){Value = ubi.Obs},
                        new SqlParameter("@CodUsu", SqlDbType.SmallInt){Value = ubi.CodUsu},
                        new SqlParameter("@NumDocCon", SqlDbType.Int){Value = numDocCon},
                        new SqlParameter("@NumSer", SqlDbType.NVarChar,10){Value = ubi.NumSer},
                        new SqlParameter("@NumCorr", SqlDbType.Int){Value = numCorr},
                        new SqlParameter("@rq", SqlDbType.NVarChar,12){Value = ubi.Rq},
                        new SqlParameter("@feclle", SqlDbType.NVarChar,10){Value = ubi.FecLle},
                        new SqlParameter("@codres", SqlDbType.SmallInt){Value = codRes},
                    };

                    cmdValMovStkFin.Parameters.AddRange(lisPrm.ToArray());
                    cmdValMovStkFin.ExecuteNonQuery();
                }
            }
        }
        
        public void ALM_Ubi_ConStock_EliArt(int codUsu,DateTime fecMod,int numMov)
        {
            _consulta = @"UPDATE ALM_Ubi_Mov SET CodEst = 7,
                                                 CodUsuMod = @codUsu, 
                                                 FecMod = @fecMod 
                                                 WHERE NumMov = @numMov";
            
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdEliArt = new SqlCommand(_consulta, cn))
                {
                    cmdEliArt.Connection.Open();
                    cmdEliArt.CommandType = CommandType.Text;

                    List<SqlParameter> lisPrm = new List<SqlParameter>()
                    {
                        new SqlParameter("@codUsu",SqlDbType.Int) {Value = codUsu },
                        new SqlParameter("@fecMod",SqlDbType.SmallDateTime) {Value = fecMod },
                        new SqlParameter("@numMov",SqlDbType.Int) {Value = numMov },
                    };
                    cmdEliArt.Parameters.AddRange(lisPrm.ToArray());
                    cmdEliArt.ExecuteNonQuery();
                }
            }
        }

        public DataTable ALM_Ubi_ConStock_RecTipArt(Int16 tipInd)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecTipArt = new SqlDataAdapter("ALM_Ubi_ComStock", cn))
                {
                    daRecTipArt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecTipArt.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = tipInd;

                    DataTable dtRecArt = new DataTable();
                    dtRecArt.Locale = CultureInfo.InvariantCulture;
                    daRecTipArt.Fill(dtRecArt);
                    return dtRecArt;
                }
            }
        }

        public DataTable ALM_Ubi_ConStock_RecUbi()
        {
            _consulta = @"SELECT Zona,Rack,Columna,Fila
                                 FROM ALM_Ubi";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daUbi = new SqlDataAdapter(_consulta, cn))
                {
                    daUbi.SelectCommand.CommandType = CommandType.Text;
                    DataTable dtRecUbi = new DataTable();
                    dtRecUbi.Locale = CultureInfo.InvariantCulture;
                    daUbi.Fill(dtRecUbi);
                    return dtRecUbi;
                }
            }
        }

        public void ALM_Ubi_ConStock_ActCantCom(int? numMov,decimal? cantCom)
        {
            _consulta = @"UPDATE ALM_Ubi_Mov SET CanCom = @canCom
                                             WHERE NumMov = @numMov";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdCantCom = new SqlCommand(_consulta, cn))
                {
                    object valor;

                    if (cantCom == null)
                    {
                        valor = DBNull.Value;
                    }
                    else
                    {
                        valor = cantCom;
                    }

                    cmdCantCom.Connection.Open();
                    cmdCantCom.CommandType = CommandType.Text;
                    cmdCantCom.Parameters.Add("@canCom", SqlDbType.Decimal).Value = valor;
                    cmdCantCom.Parameters.Add("@numMov", SqlDbType.Int).Value = numMov;
                    cmdCantCom.ExecuteNonQuery();
                }
            }
        }
    }
}
