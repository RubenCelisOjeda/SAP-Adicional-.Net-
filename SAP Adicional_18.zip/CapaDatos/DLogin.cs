﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace CapaDatos
{    
    public class DLogin
    {//cn es nuestra variable cadena de conexion
        DVarGlo dvarglo = DVarGlo.Instance();
        public void GuarCheckUsu(bool chkUsu, string Usu)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdRecUsu = new SqlCommand("UPDATE Usuario SET  RecordarUsu = @chkUsu WHERE Usuario = @usuario", cn))
                {
                    cn.Open();
                    cmdRecUsu.CommandType = CommandType.Text;
                    cmdRecUsu.Parameters.Add("@chkUsu", SqlDbType.Bit).Value = Convert.ToInt16(chkUsu);
                    cmdRecUsu.Parameters.Add("@usuario", SqlDbType.NVarChar, 20).Value = Usu;
                    cmdRecUsu.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public DataTable RecUsu(string Usu)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daValUsu = new SqlDataAdapter("SELECT RecordarUsu FROM Usuario WHERE Usuario = @nomUsu", cn))
                {
                    daValUsu.SelectCommand.CommandType = CommandType.Text;
                    daValUsu.SelectCommand.Parameters.Add("@nomUsu", SqlDbType.NVarChar, 20).Value = Usu;
                    DataTable dtRec = new DataTable();
                    dtRec.Locale = CultureInfo.InvariantCulture;
                    daValUsu.Fill(dtRec);
                    return dtRec;
                }      
            }
        }
        
        public static int ValidarUsuario(string usu, string pass)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("GEN_UsuPass", cnx))
                {
                    cnx.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@usu", usu);
                    cmd.Parameters.AddWithValue("@pass", pass);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        public static void CreateConnectionString(string Base)
        {
            SqlConnectionStringBuilder sqlBuilder =
                                  new SqlConnectionStringBuilder();

            sqlBuilder.DataSource = "zeus";
            sqlBuilder.InitialCatalog = Base;
            sqlBuilder.IntegratedSecurity = true;

            DVarGlo.Instance().Cadena = sqlBuilder.ConnectionString;
            DVarGlo.Instance().Base = Base;                   

        }

        public DataTable RecuperoBases()
        {
            //"Data Source=zeus;User=u_trazzo;Password=U_trazzo100%"
            using (SqlConnection cn = new SqlConnection("Data Source=zeus;Integrated Security = true"))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select name,database_id from sys.databases where name like '%trazzo%'", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public string ConectarBases(string Base)
        {
            SqlConnectionStringBuilder sqlBuilder =
                                  new SqlConnectionStringBuilder();

            sqlBuilder.DataSource = "zeus";
            sqlBuilder.InitialCatalog = Base;
            sqlBuilder.IntegratedSecurity = true;
             
            using (SqlConnection cn = new SqlConnection(sqlBuilder.ConnectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select NomAbr from Empresa", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();

                    try
                    {
                        da.Fill(dt);
                    }
                    catch (Exception)
                    {
                         return "";
                    }
                    
                    return dt.Rows[0][0].ToString();
                }
            }
        }

        public string RecuperaBaseSAP()
        {
            //Documentos control de acceso            

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT BaseSAP FROM Empresa", cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cnx.Open();
                    
                    dvarglo.BaseSAP = (string)cmd.ExecuteScalar();

                    return dvarglo.BaseSAP;
                }

            }

        }
    }
}
