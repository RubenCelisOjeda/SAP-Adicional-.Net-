﻿using Entidades.LOG_InfRSV;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DLOG_InfRSV
    {
        SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena);
        public DataTable LOG_InfoRSV_RecOfv(bool MosTodOFV)
        {
            using (SqlDataAdapter daRecOfv = new SqlDataAdapter("LOG_InfRSV_OFV_rep", cn))
            {
                daRecOfv.SelectCommand.CommandType = CommandType.StoredProcedure;
                daRecOfv.SelectCommand.Parameters.Add("@fil", SqlDbType.TinyInt).Value = Convert.ToInt16(MosTodOFV);

                DataTable dtRecOfv = new DataTable();
                dtRecOfv.Locale = CultureInfo.InvariantCulture;
                daRecOfv.Fill(dtRecOfv);
                return dtRecOfv;
            }
        }

        public void LOG_InfoRSV_GuaOfv(LOG_InfRSV_Enc_Est Enc)
        {
            using (SqlCommand cmdGuaofv = new SqlCommand("LOG_InfRSV_OFV_act", cn))
            {
                cn.Open();
                cmdGuaofv.CommandType = CommandType.StoredProcedure;
                cmdGuaofv.Parameters.Add("@docnum",SqlDbType.Int).Value = Enc.DocNum;
                cmdGuaofv.Parameters.Add("@ingope", SqlDbType.NVarChar,100).Value = Enc.Ingope;
                cmdGuaofv.Parameters.Add("@dis", SqlDbType.NVarChar, 100).Value = Enc.Dis;
                cmdGuaofv.Parameters.Add("@est", SqlDbType.NVarChar,50).Value = Enc.Est;
                cmdGuaofv.Parameters.Add("@conofv", SqlDbType.NVarChar,50).Value = Enc.ConOfv;
                cmdGuaofv.Parameters.Add("@fecultreu", SqlDbType.NVarChar,10).Value = Enc.FecUltReu;
                cmdGuaofv.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                cmdGuaofv.Parameters.Add("@admped", SqlDbType.NVarChar,100).Value = Enc.AdmPed;
                cmdGuaofv.Parameters.Add("@aprins", SqlDbType.NVarChar,10).Value = Enc.AprIns;
                cmdGuaofv.Parameters.Add("@obs", SqlDbType.NVarChar,200).Value = Enc.Obs;
                cmdGuaofv.ExecuteNonQuery();
                cn.Close();
            }
        }
        public DataTable LOG_InfoRSV_RecOrd(bool MosTodOFV)
        {
            using (SqlDataAdapter daRecOrd = new SqlDataAdapter("LOG_InfRSV_ORV_rep", cn))
            {
                daRecOrd.SelectCommand.CommandType = CommandType.StoredProcedure;
                daRecOrd.SelectCommand.Parameters.Add("@fil", SqlDbType.TinyInt).Value = Convert.ToInt16(MosTodOFV);

                DataTable dtRecOrd = new DataTable();
                dtRecOrd.Locale = CultureInfo.InvariantCulture;
                daRecOrd.Fill(dtRecOrd);
                return dtRecOrd;
            }
        }
        public void LOG_InfoRSV_GuaOrd(LOG_InfRSV_Enc_Est Enc)
        {
            using (SqlCommand cmdGuaOrv = new SqlCommand("LOG_InfRSV_ORV_act", cn))
            {
                cn.Open();
                cmdGuaOrv.CommandType = CommandType.StoredProcedure;
                cmdGuaOrv.Parameters.Add("@docnum", SqlDbType.Int).Value = Enc.DocNum;
                cmdGuaOrv.Parameters.Add("@est", SqlDbType.NVarChar, 100).Value = Enc.Est;
                cmdGuaOrv.Parameters.Add("@eta", SqlDbType.NVarChar, 50).Value = Enc.Etp;
                cmdGuaOrv.Parameters.Add("@aprins", SqlDbType.NVarChar, 10).Value = Enc.AprIns;
                cmdGuaOrv.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                cmdGuaOrv.ExecuteNonQuery();
                cn.Close();
            }
        }
        public DataTable LOG_InfRSV_Filtro(string vista, string procedimiento, int param,string param2)
        {
            SqlDataAdapter daInfRSVRec = new SqlDataAdapter(procedimiento, cn);
            daInfRSVRec.SelectCommand.CommandType = CommandType.StoredProcedure;

            switch (vista)
            {
                case "RQ_DetPed":
                    daInfRSVRec.SelectCommand.Parameters.Add("@Tipo", SqlDbType.TinyInt).Value = param;
                    daInfRSVRec.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 120).Value = param2;
                    break;
                case "Articulo":
                case "ArticuloOc":
                    daInfRSVRec.SelectCommand.Parameters.Add("@Tipo", SqlDbType.SmallInt).Value = param;
                    daInfRSVRec.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param2;
                    break;
                default:
                    break;
            }

            DataTable dtFiltro = new DataTable();
            daInfRSVRec.Fill(dtFiltro);
            return dtFiltro;

        }
        public void LOG_InfoRSV_GuaDetPed(LOG_InfRSV_DetPed Det)
        {
            try
            {
                using (SqlCommand cmdGuaDetPed = new SqlCommand("LOG_InfRSV_DetPed_agr", cn))
                {
                    cn.Open();
                    cmdGuaDetPed.CommandType = CommandType.StoredProcedure;
                    cmdGuaDetPed.Parameters.Add("@RQ", SqlDbType.Int).Value = Det.Rq;
                    cmdGuaDetPed.Parameters.Add("@CodArt", SqlDbType.NVarChar, 12).Value = Det.CodArt;
                    cmdGuaDetPed.Parameters.Add("@Can", SqlDbType.Int).Value = Det.Can;
                    cmdGuaDetPed.Parameters.Add("@Ordcom", SqlDbType.NVarChar, 12).Value = Det.OrdCom;
                    cmdGuaDetPed.Parameters.Add("@CodUsu", SqlDbType.SmallInt).Value = Det.CodUsu;
                    cmdGuaDetPed.Parameters.Add("@Catalogo", SqlDbType.NVarChar, 150).Value = Det.Cat;
                    cmdGuaDetPed.ExecuteNonQuery();
                    cn.Close();
                    DVarGlo.Instance().ErrorBase = false;
                }
            }
            catch
            {
                DVarGlo.Instance().ErrorBase = true;
                cn.Close();
            }
        }
        public DataTable LOG_InfoRSV_RecDetPed(bool Tipo)
        {
            using (SqlDataAdapter daRecDetPed = new SqlDataAdapter("LOG_InfRSV_DetPed_rec", cn))
            {
                daRecDetPed.SelectCommand.CommandType = CommandType.StoredProcedure;
                daRecDetPed.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = Convert.ToByte(Tipo);

                DataTable dtRecDetPed = new DataTable();
                dtRecDetPed.Locale = CultureInfo.InvariantCulture;
                daRecDetPed.Fill(dtRecDetPed);
                return dtRecDetPed;
            }
        }
        public DataTable LOG_InfoRSV_RecOrdAba(bool Tipo)
        {
            using (SqlDataAdapter daRecOrdAba = new SqlDataAdapter("LOG_InfRSV_OrdCom_rec", cn))
            {
                daRecOrdAba.SelectCommand.CommandType = CommandType.StoredProcedure;
                daRecOrdAba.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = Convert.ToByte(Tipo);

                DataTable dtRecOrdAba = new DataTable();
                dtRecOrdAba.Locale = CultureInfo.InvariantCulture;
                daRecOrdAba.Fill(dtRecOrdAba);
                return dtRecOrdAba;
            }
        }
        public void LOG_InfoRSV_GuaOrdAba(LOG_InfRSV_Enc_OrdAba Enc)
        {
            try
            {
                using (SqlCommand cmdGuaOrdAba = new SqlCommand("LOG_InfRSV_OrdCom_agr", cn))
                {
                    cn.Open();
                    cmdGuaOrdAba.CommandType = CommandType.StoredProcedure;
                    cmdGuaOrdAba.Parameters.Add("@CodArt", SqlDbType.NVarChar,12).Value = Enc.CodArt;
                    cmdGuaOrdAba.Parameters.Add("@Can", SqlDbType.Decimal).Value = Enc.Can;
                    cmdGuaOrdAba.Parameters.Add("@OrdCom", SqlDbType.NVarChar,12).Value = Enc.OrdCom;
                    cmdGuaOrdAba.Parameters.Add("@Via", SqlDbType.NVarChar, 50).Value = Enc.Via;
                    cmdGuaOrdAba.Parameters.Add("@FecEntPro", SqlDbType.NVarChar,20).Value = Enc.FecEntPro;
                    cmdGuaOrdAba.Parameters.Add("@FecEmb", SqlDbType.NVarChar, 20).Value = Enc.FecEmb;
                    cmdGuaOrdAba.Parameters.Add("@FecLlePue", SqlDbType.NVarChar, 20).Value = Enc.FecLlePue;
                    cmdGuaOrdAba.Parameters.Add("@FecAprIng", SqlDbType.NVarChar, 150).Value = Enc.FecAprIng;
                    cmdGuaOrdAba.Parameters.Add("@CodUsu", SqlDbType.Int).Value = Enc.CodUsu;
                    cmdGuaOrdAba.ExecuteNonQuery();
                    cn.Close();
                    DVarGlo.Instance().ErrorBase = false;
                }
            }
            catch
            {
                DVarGlo.Instance().ErrorBase = true;
                cn.Close();
            }
        }
        public void LOG_InfoRSV_EliDetPed(LOG_InfRSV_DetPed Det)
        {
            using (SqlCommand cmdEliOrdAba = new SqlCommand("LOG_InfRSV_DetPed_ActEli", cn))
            {
                cn.Open();
                cmdEliOrdAba.CommandType = CommandType.StoredProcedure;
                cmdEliOrdAba.Parameters.Add("@numrq", SqlDbType.Int).Value = Det.Rq;
                cmdEliOrdAba.Parameters.Add("@codart", SqlDbType.NVarChar,12).Value = Det.CodArt;
                cmdEliOrdAba.Parameters.Add("@ordcom", SqlDbType.NVarChar,20).Value = Det.OrdCom;
                cmdEliOrdAba.Parameters.Add("@catalogo", SqlDbType.NVarChar,150).Value = Det.Cat;
                cmdEliOrdAba.ExecuteNonQuery();
                cn.Close();

            }
        }
        public void LOG_InfoRSV_EliOrdAba(LOG_InfRSV_Enc_OrdAba Enc)
        {
            using (SqlCommand cmdEliOrdAba = new SqlCommand("LOG_InfRSV_OrdCom_ActEli", cn))
            {
                cn.Open();
                cmdEliOrdAba.CommandType = CommandType.StoredProcedure;
                cmdEliOrdAba.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = Enc.CodArt;
                cmdEliOrdAba.Parameters.Add("@ordcom", SqlDbType.NVarChar, 12).Value = Enc.OrdCom;
                cmdEliOrdAba.Parameters.Add("@can", SqlDbType.Int).Value = Enc.Can;
                cmdEliOrdAba.Parameters.Add("@codusu", SqlDbType.Int).Value = Enc.CodUsu;
                cmdEliOrdAba.Parameters.Add("@catalogo", SqlDbType.NVarChar,150).Value = Enc.Cat;
                cmdEliOrdAba.ExecuteNonQuery();
                cn.Close();

            }
        }
    }
}
