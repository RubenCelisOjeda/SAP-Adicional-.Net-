﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DALM_Ruta_AsignarMontos
    {

        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

        public DataTable Ruta_AsignarMontos_Rec(DateTime FecDes, DateTime FecHas)
        {
            SqlDataAdapter daRecAsiMot = new SqlDataAdapter("[Ruta_AsignarMonto]", cnx);
            daRecAsiMot.SelectCommand.CommandType = CommandType.StoredProcedure;
            daRecAsiMot.SelectCommand.Parameters.Add("@FDesde", SqlDbType.SmallDateTime).Value = FecDes.ToShortDateString();
            daRecAsiMot.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = FecHas.ToShortDateString();
            DataTable dtRecAsiMot = new DataTable();
            dtRecAsiMot.Locale = CultureInfo.InvariantCulture;
            daRecAsiMot.SelectCommand.CommandTimeout = 0;
            daRecAsiMot.Fill(dtRecAsiMot);
            return dtRecAsiMot;
        }
        public void Ruta_AsignarMontos_GuaMon(decimal Monto,int NumMovRut)
        {
            using (SqlCommand cmdGuaMon = new SqlCommand("UPDATE RutaProg_Montos set Monto = @monto "+ 
                                                                                "Where NumMovRut = @numMovRuta",cnx))
            {
                cnx.Open();
                cmdGuaMon.CommandType = CommandType.Text;
                cmdGuaMon.Parameters.Add("@monto", SqlDbType.Decimal).Value = Monto;
                cmdGuaMon.Parameters.Add("@numMovRuta", SqlDbType.Int).Value = NumMovRut;
                cmdGuaMon.ExecuteNonQuery();
                cnx.Close();
            }
        }
        public DataTable Ruta_AsignarMontos_ExpSap(DateTime FDesde,DateTime FHasta)
        {
            SqlDataAdapter daExpSap = new SqlDataAdapter("[Ruta_AsignarMonto_ExpSAP]", cnx);
            daExpSap.SelectCommand.CommandType = CommandType.StoredProcedure;
            daExpSap.SelectCommand.Parameters.Add("@FDesde",SqlDbType.SmallDateTime).Value = FDesde.ToShortDateString();
            daExpSap.SelectCommand.Parameters.Add("@FHasta", SqlDbType.SmallDateTime).Value = FHasta.ToShortDateString();

            DataTable dtExpSap = new DataTable();
            dtExpSap.Locale = CultureInfo.InvariantCulture;
            daExpSap.Fill(dtExpSap);
            return dtExpSap;
        }
    }
}
