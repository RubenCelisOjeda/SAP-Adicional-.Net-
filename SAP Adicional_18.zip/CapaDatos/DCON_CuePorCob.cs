﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Entidades.CON_CuePorCob;
using CapaDatos;

namespace CapaDatos
{
    public class DCON_CuePorCob
    {

        public DataTable Con_Cueporcob_Clear()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select * from con_cueporcob_Clear_", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InstalledUICulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable CON_CuePorCob_CatSeg(Int16 codcat)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select Des,CodSeg from con_cueporcob_seg where codest =@codcat", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    da.SelectCommand.Parameters.Add("@codcat", SqlDbType.SmallInt).Value = codcat;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InstalledUICulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }


        public DataTable CON_CuePorCob_CatEst(Int16 codcat)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select Des,CodEst from con_cueporcob_est where codcat =@codcat", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    da.SelectCommand.Parameters.Add("@codcat", SqlDbType.SmallInt).Value = codcat;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InstalledUICulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }
        public DataTable CON_CuePorCob_cat()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("Select * from con_cueporcob_cat", cn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InstalledUICulture;       
                    da.Fill(dt);
                    return dt;
               }                             
            }         
        }

        public DataTable CON_CuePorCob(DateTime fDesde, DateTime fHasta, int tipo)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("[CON_CuePorCob]", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    da.SelectCommand.Parameters.Add("@fdesde", SqlDbType.SmallDateTime).Value = fDesde;
                    da.SelectCommand.Parameters.Add("@fhasta", SqlDbType.SmallDateTime).Value = fHasta;
                    da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = tipo;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }                                             
            }                 
        }

        public DataTable CON_CuePorCob_Enc()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("[CON_CuePorCob_Enc]", cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public void CON_CuePorCob_Col_actval(CON_CuePorCob_Col_actval Enc)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daActGua = new SqlDataAdapter("[CON_CuePorCob_Col_actval]", cn))
                {
                    daActGua.SelectCommand.Connection.Open();
                    daActGua.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daActGua.SelectCommand.Parameters.Add("@docnum", SqlDbType.Int).Value = Enc.DocNum;
                    daActGua.SelectCommand.Parameters.Add("@tipo", SqlDbType.NVarChar, 2).Value = Enc.Tipo;
                    daActGua.SelectCommand.Parameters.Add("@enc", SqlDbType.NVarChar, 200).Value = Enc.Enc;
                    daActGua.SelectCommand.Parameters.Add("@codcat", SqlDbType.SmallInt).Value = Enc.CodCat;
                    daActGua.SelectCommand.Parameters.Add("@codest", SqlDbType.SmallInt).Value = Enc.CodEst;
                    daActGua.SelectCommand.Parameters.Add("@codseg", SqlDbType.SmallInt).Value = Enc.CodSeg;
                    daActGua.SelectCommand.Parameters.Add("@cor1", SqlDbType.Bit).Value = Enc.Cor1;
                    daActGua.SelectCommand.Parameters.Add("@cor2", SqlDbType.Bit).Value = Enc.Cor2;
                    daActGua.SelectCommand.Parameters.Add("@cor3", SqlDbType.Bit).Value = Enc.Cor3;
                    daActGua.SelectCommand.Parameters.Add("@obs", SqlDbType.NVarChar, 800).Value = Enc.Obs;
                    daActGua.SelectCommand.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = Enc.CodUsu;
                    daActGua.SelectCommand.Parameters.Add("@ficxtrazzo", SqlDbType.NVarChar, 10).Value = Enc.FicXTrazzo;
                    daActGua.SelectCommand.Parameters.Add("@fecxtrazzo", SqlDbType.SmallDateTime).Value = Enc.FecXTrazzo;
                    daActGua.SelectCommand.Parameters.Add("@ven", SqlDbType.NVarChar, 150).Value = Enc.Ven;
                    daActGua.SelectCommand.Parameters.Add("@obs2", SqlDbType.NVarChar, 800).Value = Enc.Obs2;
                    daActGua.SelectCommand.ExecuteNonQuery();
                }               
            }        
        }
    }
}
