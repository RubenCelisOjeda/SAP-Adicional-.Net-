﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CapaDatos
{
    public class DPri
    {
        public static DataTable CargarMenu(Int32 IdMenu, ToolStripMenuItem mP, MenuStrip Menu, int CodUsuAct)
        {

            SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);
            DataTable menu = new DataTable();
            //Primero queremos recuperar los datos por empleado
            SqlDataAdapter da = new SqlDataAdapter("Menus_AccesoUsuario", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@CodigoUsuario", SqlDbType.SmallInt).Value = CodUsuAct;
            da.SelectCommand.Parameters.Add("@Valor", SqlDbType.Bit).Value = 0;

            //llenamos el datatable
            da.Fill(menu);

            //Si directamente por empleado no tiene ningun menu asignado buscamos por area.
            if (menu.Rows.Count == 0)
            {
                DataTable area = new DataTable();
                //Recuperamos el area del empleado
                da = new SqlDataAdapter("select codigoarea from empleado where codigoempleado = @codemp", cnx);
                da.SelectCommand.CommandType = CommandType.Text;
                da.SelectCommand.Parameters.Add("@codemp", SqlDbType.SmallInt).Value = CodUsuAct;

                da.Fill(area);

                //Con el area recuperamos los menus por area

                da = new SqlDataAdapter("Menus_AccesoUsuario", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@CodigoUsuario", SqlDbType.SmallInt).Value = area.Rows[0]["codigoarea"];

                //MessageBox.Show(area.Rows[0]["codigoarea"].ToString());

                da.SelectCommand.Parameters.Add("@Valor", SqlDbType.Bit).Value = 1;

                //limpiamos el datatable menu
                menu.Dispose();

                da.Fill(menu);

            }
            return menu;

        }
    }
}
