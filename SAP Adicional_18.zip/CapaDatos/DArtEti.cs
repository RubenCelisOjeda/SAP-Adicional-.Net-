﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DArtEti
    {
        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

        public DataTable ArtEti_Filtros(string vista,string procedimeinto,string param,Int16 param2)
        {
            SqlDataAdapter daFiltro = new SqlDataAdapter(procedimeinto, cnx);
            daFiltro.SelectCommand.CommandType = CommandType.StoredProcedure;

            switch (vista)
            {
                case "Codigo Articulo":
                case "Articulo Descripcion":
                    daFiltro.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 100).Value = param;
                    daFiltro.SelectCommand.Parameters.Add("@Param2", SqlDbType.TinyInt).Value = param2;
                    break;
               
                default:
                    break;
            }

            DataTable dtFiltro = new DataTable();
            dtFiltro.Locale = CultureInfo.InvariantCulture;
            daFiltro.Fill(dtFiltro);
            return dtFiltro;

        }
    }
}
