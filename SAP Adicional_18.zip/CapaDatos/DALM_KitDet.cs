﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DALM_KitDet
    {
        public DataTable Rec_AlmKitDet()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecKitDet = new SqlDataAdapter("ALM_KitDet", cn))
                {
                    daRecKitDet.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    daRecKitDet.Fill(dt);
                    return dt;
                }
            }
        }
    }
}
