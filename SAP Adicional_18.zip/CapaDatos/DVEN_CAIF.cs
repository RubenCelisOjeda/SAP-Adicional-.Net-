﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CapaDatos
{
    public class DVEN_CAIF
    {

        public DataTable VEN_CAIF_Años()
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter(@"SELECT distinct year(t0.docdate) Año
                                                    FROM SBO_TRAZ_PROD.dbo.OQUT t0
                                                    order by year(t0.docdate) desc "
                                                    , cnx);

                da.SelectCommand.CommandType = CommandType.Text;

                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }


        public DataTable VEN_CAIF_MetTip()
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter(@"SELECT CodTipMet, 
                                                                Des
                                                    FROM VEN_CAIF_MetTip t0
                                                    order by CodTipMet "
                                                    , cnx);

                da.SelectCommand.CommandType = CommandType.Text;

                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataTable VEN_CAIF_Metas(Int32 Año, Int16 CodTip)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_CAIF_Metas_rec", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@Año", SqlDbType.SmallInt).Value = Año;
                da.SelectCommand.Parameters.Add("@codtip", SqlDbType.TinyInt).Value = CodTip;

                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public void VEN_CAIF_Metas_acting(Int32 codemp, string codcenven, Int16 mes, Int32 año, Int16 codtipmet, decimal meta, Int32 codusu)
        {

            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlCommand cmd = new SqlCommand("VEN_CAIF_Metas_ingact", cnx);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@codemp", SqlDbType.SmallInt).Value = codemp;
                cmd.Parameters.Add("@codcenvencaif", SqlDbType.NVarChar,20).Value = codcenven;
                cmd.Parameters.Add("@mes", SqlDbType.TinyInt).Value = mes;
                cmd.Parameters.Add("@año", SqlDbType.SmallInt).Value = año;
                cmd.Parameters.Add("@codtipmet", SqlDbType.TinyInt).Value = codtipmet;
                cmd.Parameters.Add("@meta", SqlDbType.Decimal).Value = meta;
                cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                cnx.Open();

                cmd.ExecuteNonQuery();

            }
            
        }

        public DataTable VEN_CAIF_rep(DateTime fec, Int16 tiprep, Int32 codusu)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string proc;

                if (tiprep == 1) { proc = "VEN_CAIF_repcotapr"; }
                else if (tiprep == 2) { proc = "VEN_CAIF_reping"; }
                else { proc = "VEN_CAIF_repfac"; }

                SqlDataAdapter da = new SqlDataAdapter(proc, cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@fecfin", SqlDbType.SmallDateTime).Value = fec;
                da.SelectCommand.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                //da.SelectCommand.Parameters.Clear();
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public DataSet VEN_CAIF_gra(Int16 tiprep, DateTime fec, Int16 tipo, Int32 codemp, string codcenven)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string proc;

                if (tiprep == 1) { proc = "VEN_CAIF_gracotapr"; }
                else if (tiprep == 2) { proc = "VEN_CAIF_reping"; }
                else { proc = "VEN_CAIF_repfac"; }

                SqlDataAdapter da = new SqlDataAdapter(proc, cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@fecfin", SqlDbType.SmallDateTime).Value = fec;
                da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = tipo;
                da.SelectCommand.Parameters.Add("@codemp", SqlDbType.SmallInt).Value = codemp;
                da.SelectCommand.Parameters.Add("@codcenven", SqlDbType.NVarChar,15).Value = codcenven;

                DataSet ds = new DataSet();
                da.Fill(ds, "VEN_CAIF_gracotapr");
                return ds;
            }
        }
    }
}
