﻿using Entidades.Man_Contactos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DMan_Contactos
    {
        private string _consulta = "";

        public DataTable Man_Contactos_RecDis()
        {
            _consulta = @"SELECT CodigoDistrito,
                                 Nombre 
                                 FROM Distritos";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecDis = new SqlDataAdapter(this._consulta, cn))
                {
                    daRecDis.SelectCommand.CommandType = CommandType.Text;

                    DataTable dtRecDis = new DataTable();
                    dtRecDis.Locale = CultureInfo.InvariantCulture;
                    daRecDis.Fill(dtRecDis);
                    return dtRecDis;
                }
            }
            
        }

        public DataTable Man_Contactos_RecPro()
        {
            _consulta = @"SELECT CodigoProfesion,
                                 Profesion 
                                 FROM ContactoProfesion";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecDis = new SqlDataAdapter(this._consulta, cn))
                {
                    daRecDis.SelectCommand.CommandType = CommandType.Text;

                    DataTable dtRecDis = new DataTable();
                    dtRecDis.Locale = CultureInfo.InvariantCulture;
                    daRecDis.Fill(dtRecDis);
                    return dtRecDis;
                }
            }
        }

        public DataTable Man_Contactos_RecRes()
        {
            _consulta = @"SELECT  CodigoResponsabilidad,
                                  Responsabilidad 
                                  FROM ContactoResponsabilidad";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecRes = new SqlDataAdapter(this._consulta, cn))
                {
                    daRecRes.SelectCommand.CommandType = CommandType.Text;

                    DataTable dtRecRes = new DataTable();
                    dtRecRes.Locale = CultureInfo.InvariantCulture;
                    daRecRes.Fill(dtRecRes);
                    return dtRecRes;
                }
            }
        }

        public DataTable Man_Contactos_RecTipCon()
        {
            _consulta = @"SELECT  CodigoTipoContacto,
                                  TipoContacto 
                                  FROM Contactos_Tipo";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecTipCon = new SqlDataAdapter(this._consulta, cn))
                {
                    daRecTipCon.SelectCommand.CommandType = CommandType.Text;

                    DataTable dtTipCon = new DataTable();
                    dtTipCon.Locale = CultureInfo.InvariantCulture;
                    daRecTipCon.Fill(dtTipCon);
                    return dtTipCon;
                }
            }
        }

        public DataTable Man_Contactos_RecCat()
        {
            _consulta = @"SELECT  Codigo,
                                  Categoria 
                                  FROM Contacto_Categoria";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecCat = new SqlDataAdapter(this._consulta, cn))
                {
                    daRecCat.SelectCommand.CommandType = CommandType.Text;

                    DataTable dtCat = new DataTable();
                    dtCat.Locale = CultureInfo.InvariantCulture;
                    daRecCat.Fill(dtCat);
                    return dtCat;
                }
            }
        }

        public void Man_Contactos_UpdCampo(int codCon,string campo,string valor)
        {
            _consulta = string.Format(@"UPDATE Contactos SET {0} = @campo 
                                                         WHERE CodigoContacto = @codCon",
                                                         campo);

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdUpdCampo = new SqlCommand(this._consulta,cn))
                {
                    cmdUpdCampo.Connection.Open();
                    cmdUpdCampo.CommandType = CommandType.Text;
                    cmdUpdCampo.Parameters.Add("@codCon",SqlDbType.Int).Value = codCon;
                    cmdUpdCampo.Parameters.AddWithValue("@campo", valor);
                    cmdUpdCampo.ExecuteNonQuery();
                }
            }
        }

        public void Man_Contactos_UpdGuaCon(Man_Contactos_Enc con)
        {
            _consulta = "MantenimientoContacto_ActualizaGuarda";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdUpdGua = new SqlCommand(this._consulta,cn))
                {
                    cmdUpdGua.Connection.Open();
                    cmdUpdGua.CommandType = CommandType.StoredProcedure;

                    List<SqlParameter> lisPrm = new List<SqlParameter>()
                    {
                         new SqlParameter("@Accion", SqlDbType.Bit) { Value = Convert.ToInt16(con.acc) },
                         new SqlParameter("@CodigoContacto", SqlDbType.Int) { Value = con.codCon,
                                                     Direction = ParameterDirection.InputOutput},

                         new SqlParameter("@Nombres", SqlDbType.NVarChar,150) { Value = con.nom },
                         new SqlParameter("@Apellidos", SqlDbType.NVarChar,60) { Value = con.ape },
                         new SqlParameter("@Direccion", SqlDbType.NVarChar,150) { Value = con.dir },
                         new SqlParameter("@Distrito", SqlDbType.SmallInt) { Value = con.dis },
                         new SqlParameter("@DireccionCasa", SqlDbType.NVarChar,150) { Value = con.dirCas },
                         new SqlParameter("@CodigoDistritoCasa", SqlDbType.SmallInt) { Value = con.codDisCas },
                         new SqlParameter("@Telefono", SqlDbType.NVarChar,30) { Value = con.tel },
                         new SqlParameter("@Celular", SqlDbType.NVarChar,50) { Value = con.cel },
                         new SqlParameter("@Email", SqlDbType.NVarChar,50) { Value = con.ema },
                         new SqlParameter("@Email2", SqlDbType.NVarChar,50) { Value = con.ema2 },
                         new SqlParameter("@CodigoProfesion", SqlDbType.SmallInt) { Value = con.codPro },
                         new SqlParameter("@Compania", SqlDbType.NVarChar,100) { Value = con.com },
                         new SqlParameter("@CargoProfesion", SqlDbType.NVarChar,100) { Value = con.carPro },
                         new SqlParameter("@CodigoResponsabilidad", SqlDbType.SmallInt) { Value = con.codRes },
                         new SqlParameter("@TelfTrabajo", SqlDbType.NVarChar,30) { Value = con.telTra },
                         new SqlParameter("@CodigoTipoCia", SqlDbType.Int) { Value = con.codTipCia },
                         new SqlParameter("@FechaC", SqlDbType.SmallDateTime) { Value = con.fecC },
                         new SqlParameter("@CodigoUsuarioC", SqlDbType.SmallInt) { Value = con.codUsuC },
                         new SqlParameter("@FechaM", SqlDbType.SmallDateTime) { Value = con.fecM },
                         new SqlParameter("@CodigoUsuarioM", SqlDbType.SmallInt) { Value = con.codUsuM },
                         new SqlParameter("@CodigoTipoContacto", SqlDbType.SmallInt) { Value = con.codTipCon },
                         new SqlParameter("@FechaN", SqlDbType.NVarChar,10) { Value = con.fecN },
                         new SqlParameter("@RUC", SqlDbType.NVarChar,11) { Value = con.ruc },
                         new SqlParameter("@DNI", SqlDbType.NVarChar,8) { Value = con.dni },
                         new SqlParameter("@ContactoActivo", SqlDbType.SmallInt) { Value = con.conAct },
                         new SqlParameter("@CtaDet", SqlDbType.NVarChar,20) { Value = con.ctaDet },
                    };

                    cmdUpdGua.Parameters.AddRange(lisPrm.ToArray());
                    cmdUpdGua.ExecuteNonQuery();

                    con.codCon = Convert.ToInt16(cmdUpdGua.Parameters["@CodigoContacto"].Value);
                }
            }
        }

        public DataTable Man_Contactos_RecDatRecom(Int16 dir, int usu)
        {
            _consulta = "MantenimientoContacto_General";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecRecom = new SqlDataAdapter(this._consulta, cn))
                {
                    daRecRecom.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecRecom.SelectCommand.Parameters.Add("@Direccion", SqlDbType.SmallInt).Value = dir;
                    daRecRecom.SelectCommand.Parameters.Add("@Contacto", SqlDbType.Int).Value = usu;
                    daRecRecom.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 200).Value = "";

                    DataTable dtRecRecom = new DataTable();
                    dtRecRecom.Locale = CultureInfo.InvariantCulture;
                    daRecRecom.Fill(dtRecRecom);
                    return dtRecRecom;
                }
            }
        }

        public DataTable Man_Contactos_Filtro(string vista, string procedimiento, string prm)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daFil = new SqlDataAdapter(procedimiento, cn))
                {
                    daFil.SelectCommand.CommandType = CommandType.StoredProcedure;

                    switch (vista)
                    {
                        case "Distrito":
                        case "Distrito2":
                        case "Profesion":
                        case "Responsabilidad":
                            {
                                daFil.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = prm;
                            }
                            break;

                        case "TipoContacto":
                        case "Categoria":
                            {
                                daFil.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 50).Value = prm;
                            }
                            break;

                        default:
                            break;
                    }

                    DataTable dtFil = new DataTable();
                    daFil.Fill(dtFil);
                    return dtFil;
                }

            }
        }

        public void Man_Contactos_EliRecom(int codCon)
        {
            _consulta = @"DELETE Contactos
                                 WHERE CodigoContacto = @codCon";
            
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdEliRecom = new SqlCommand(this._consulta,cn))
                {
                    cmdEliRecom.Connection.Open();
                    cmdEliRecom.CommandType = CommandType.Text;
                    cmdEliRecom.Parameters.Add("@codCon",SqlDbType.Int).Value = codCon;
                    cmdEliRecom.ExecuteNonQuery();
                }
            }
        }

        public int Man_Contactos_ValCodCon(int codCon)
        {
            _consulta = "Man_Contactos_Impresion";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdRecCod = new SqlCommand(this._consulta, cn))
                {
                    cmdRecCod.Connection.Open();
                    cmdRecCod.CommandType = CommandType.StoredProcedure;
                    cmdRecCod.Parameters.Add("@Codigo",SqlDbType.Int).Value = codCon;
                    return (int)cmdRecCod.ExecuteScalar();
                }
            }
        }

        public DataTable Man_Contactos_FilRecom(Int16 col, string filtro)
        {
            _consulta = "MAN_Contactos_RecRecomendaores";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daManCon = new SqlDataAdapter(this._consulta,cn))
                {
                    daManCon.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daManCon.SelectCommand.Parameters.Add("@Col", SqlDbType.SmallInt).Value = col;
                    daManCon.SelectCommand.Parameters.Add("@filtro", SqlDbType.NVarChar, 100).Value = filtro;

                    DataTable dtManCon = new DataTable();
                    dtManCon.Locale = CultureInfo.InvariantCulture;
                    daManCon.Fill(dtManCon);
                    return dtManCon;
                }
            }          
        }
    }
}
