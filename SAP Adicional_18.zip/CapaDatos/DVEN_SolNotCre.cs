﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades.VEN_SolNotCre;

namespace CapaDatos
{
    public class DVEN_SolNotCre
    {
        public void VEN_SolNotCre_Est(Int64 nummov, Int32 codusu, Int16 codest, string docnumotcre)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string cadena = "";

                switch (codest)
                {
                    case 4: //anulado

                        cadena = @"UPDATE VEN_SolNotCre_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecAnu = getdate(),
                                                                CodUsuAnu = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                    case 5: //rechazado

                        cadena = @"UPDATE VEN_SolNotCre_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecRec = getdate(),
                                                                CodUsuRec = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                    case 8: //procesado

                        cadena = @"UPDATE VEN_SolNotCre_Enc SET DocNumNotCre = @docnumnotcre,
                                                                CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecPro = getdate(),
                                                                CodUsuPro = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                    case 11: //atendida

                        cadena = @"UPDATE VEN_SolNotCre_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecAte = getdate(),
                                                                CodUsuAte = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                    case 12: //aprobado

                        cadena = @"UPDATE VEN_SolNotCre_Enc SET CodEst = @codest,
                                                                FecMod = getdate(), 
                                                                CodUsuMod = @codusu,
                                                                FecApr = getdate(),
                                                                CodUsuApr = @codusu
                                                        WHERE NumMov = @nummov";

                        break;

                }

                using (SqlCommand cmd = new SqlCommand(cadena, cnx))
                {
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;
                    cmd.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;
                    cmd.Parameters.Add("@codest", SqlDbType.SmallInt).Value = codest;
                    if ( codest == 8) cmd.Parameters.Add("@docnumnotcre", SqlDbType.NVarChar,80).Value = docnumotcre;

                    cnx.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public DataSet VEN_SolNotCre_rec(Int64 nummov)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter daEnc = new SqlDataAdapter("VEN_SolNotCre_Enc_rec", cnx);
                daEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
                daEnc.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;

                SqlDataAdapter daDet = new SqlDataAdapter("VEN_SolNotCre_Det_rec", cnx);
                daDet.SelectCommand.CommandType = CommandType.StoredProcedure;
                daDet.SelectCommand.Parameters.Add("@nummov", SqlDbType.Int).Value = nummov;        

                DataSet ds = new DataSet();

                daEnc.Fill(ds, "VEN_SolNotCre_Enc");
                daDet.Fill(ds, "VEN_SolNotCre_Det");

                return (ds);
            }
        }

        public DataTable VEN_SolNotCre_VisGen(Int16 val, Int32 codusu)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_SolNotCre_visgen", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@val", SqlDbType.TinyInt).Value = val;
                da.SelectCommand.Parameters.Add("@codusu", SqlDbType.SmallInt).Value = codusu;

                //ejecutamos y llenamos el datatable
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }

        }

        public DataTable VEN_SolNotCre_ListDoc(Int64 RQ, short Tipo)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_SolNotCre_ListDocFB", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@rq", SqlDbType.Int).Value = RQ;
                da.SelectCommand.Parameters.Add("@tipo", SqlDbType.TinyInt).Value = Tipo;

                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;
            }
        }

        public DataTable VEN_SolNotCre_DocDet(Int64 docnum)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter("VEN_SolNotCre_DocDet", cnx);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.Add("@docnum", SqlDbType.Int).Value = docnum;

                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;
            }
        }

        public void VEN_SolNotCre_ingact(VEN_SolNotCre Enc)
        {
            //Ingresar o actualizar la informacion de la tabla VEN_SolNotCre_Enc
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using(SqlCommand cmd = new SqlCommand("VEN_SolNotCre_ingact", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter paramNumMov = new SqlParameter("@nummov", SqlDbType.Int);
                    paramNumMov.Direction = ParameterDirection.InputOutput;
                    paramNumMov.Value = Enc.NumMov;

                    SqlParameter paramNumOFC = new SqlParameter("@numsol", SqlDbType.NVarChar, 11);
                    paramNumOFC.Direction = ParameterDirection.InputOutput;
                    paramNumOFC.Value = Enc.NumSol;

                    cmd.Parameters.Add(paramNumMov);
                    cmd.Parameters.Add(paramNumOFC);
                    cmd.Parameters.Add("@tipnotcre", SqlDbType.TinyInt).Value = Enc.TipNotCre;
                    cmd.Parameters.Add("@tipdoc", SqlDbType.NVarChar,2).Value = Enc.TipDoc;
                    cmd.Parameters.Add("@docnum", SqlDbType.Int).Value = Enc.DocNum;
                    cmd.Parameters.AddWithValue("@rq", Enc.RQ) ;
                    cmd.Parameters.AddWithValue("@codcli", Enc.CodCli);
                    cmd.Parameters.AddWithValue("@codmon", Enc.CodMon);
                    cmd.Parameters.AddWithValue("@obs", Enc.Obs);
                    cmd.Parameters.AddWithValue("@direnvnotcre", Enc.DirEnvNotCre);
                    cmd.Parameters.AddWithValue("@codusu", Enc.CodUsu);

                    cmd.Parameters.Add("@tipdev", SqlDbType.SmallInt).Value = Enc.TipDev;
                    cmd.Parameters.Add("@tipdevdes", SqlDbType.VarChar, 100).Value = Enc.TipDevDes;
                    cmd.Parameters.Add("@monsoldev", SqlDbType.Decimal, 2).Value = Enc.MonDevDes;
                    cmd.Parameters.Add("@entban ", SqlDbType.SmallInt).Value = Enc.EntBan;
                    cmd.Parameters.Add("@tipcuen", SqlDbType.VarChar, 15).Value = Enc.TipCue;
                    cmd.Parameters.Add("@cuenban", SqlDbType.VarChar, 50).Value = Enc.CueBan;
                    cmd.Parameters.Add("@cueint", SqlDbType.VarChar, 50).Value = Enc.CueInt;
                    cmd.Parameters.Add("@otrban", SqlDbType.VarChar, 50).Value = Enc.OtrBan;

                    cnx.Open();

                    cmd.ExecuteNonQuery();
                    Enc.NumMov = Convert.ToInt64(cmd.Parameters["@nummov"].Value);
                    Enc.NumSol = (cmd.Parameters["@numsol"].Value).ToString();
                }

                //Eliminamos el detalle y lo volvemos a agregar
                using (SqlCommand cmd = new SqlCommand("DELETE VEN_SolNotCre_Det WHERE NumMov = @nummov", cnx))
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@nummov", SqlDbType.Int).Value = Enc.NumMov;

                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("VEN_SolNotCre_Det_ing", cnx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (VEN_SolNotCre_Det Det in Enc.Det)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@nummov",SqlDbType.Int).Value = Enc.NumMov;
                        cmd.Parameters.Add("@item", SqlDbType.SmallInt).Value = Det.Item;
                        cmd.Parameters.Add("@docnum", SqlDbType.Int).Value = Det.DocNum;
                        cmd.Parameters.Add("@linenum", SqlDbType.SmallInt).Value = Det.LineNum;
                        cmd.Parameters.Add("@codart", SqlDbType.NVarChar, 12).Value = Det.CodArt;
                        cmd.Parameters.AddWithValue("@canfac", Det.CanFac);
                        cmd.Parameters.AddWithValue("@cansol", Det.CanSol);
                        cmd.Parameters.AddWithValue("@preuni", Det.PreUni);
                        cmd.Parameters.AddWithValue("@totlin", Det.TotLin);
                        cmd.Parameters.AddWithValue("@pordes", Det.PorDes);
                        cmd.Parameters.Add("@codalm", SqlDbType.NVarChar, 8).Value = Det.CodAlm;                        
                        cmd.Parameters.Add("@tipdoc",SqlDbType.NVarChar,1).Value = Det.TipDoc;
                        cmd.Parameters.Add("@docnumfac", SqlDbType.Int).Value = Det.DocNumFac;
                        cmd.Parameters.AddWithValue("@igv", Det.IGV);

                        cmd.ExecuteNonQuery();
                    }

                }

            }
        }
    }
}
