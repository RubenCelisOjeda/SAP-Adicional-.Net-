﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DAccFrm
    {
        public SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena);
       
        public DataTable Acc_Frm_RecFrmUsu(int CodUsuAct)
        {
            SqlDataAdapter daRecAccUsu = new SqlDataAdapter("GEN_AccFrm_RecUsu", cn);
            daRecAccUsu.SelectCommand.CommandType = CommandType.StoredProcedure;
            daRecAccUsu.SelectCommand.Parameters.Add("@CodUsu", SqlDbType.Int).Value = CodUsuAct;
            DataTable dtRecAccUsu = new DataTable();
            dtRecAccUsu.Locale = CultureInfo.InvariantCulture;
            daRecAccUsu.Fill(dtRecAccUsu);
            return dtRecAccUsu;
        }

        public DataTable AccFrm_Filtros(string vista, string procedimiento, string param1,int CodUsu)
        {
            using (SqlDataAdapter daFil = new SqlDataAdapter(procedimiento, cn)) //variable
            {
                daFil.SelectCommand.CommandType = CommandType.StoredProcedure;

                switch (vista)
                {
                    case "Usuario":
                        daFil.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param1;
                        break;
                    case "Documento":
                        daFil.SelectCommand.Parameters.Add("@CodUsu", SqlDbType.Int).Value = CodUsu;
                        break;

                }

                DataTable dtFil = new DataTable();
                dtFil.Locale = CultureInfo.InvariantCulture;
                daFil.Fill(dtFil);
                return dtFil;
            }
        }

        public void AccFrm_InsUsu(int CodUsu,int CodDoc)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdInsUsu = new SqlCommand("GEN_AccFrm_InsUsu", cnx))
                {
                    cmdInsUsu.Connection.Open();
                    cmdInsUsu.CommandType = CommandType.StoredProcedure;
                    cmdInsUsu.Parameters.Add("@CodUsu", SqlDbType.Int).Value = CodUsu;
                    cmdInsUsu.Parameters.Add("@CodDoc", SqlDbType.Int).Value = CodDoc;
                    cmdInsUsu.ExecuteNonQuery();
                }
            }
        }


        public void AccFrm_UpdAccUsu(int CodUsu, int CodDoc,string Campo,bool Check)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdUpdUsu = new SqlCommand("GEN_AccFrm_UpdUsu", cnx))
                {
                    cmdUpdUsu.Connection.Open();
                    cmdUpdUsu.CommandType = CommandType.StoredProcedure;
                    cmdUpdUsu.Parameters.Add("@CodUsu", SqlDbType.Int).Value = CodUsu;
                    cmdUpdUsu.Parameters.Add("@CodDoc", SqlDbType.Int).Value = CodDoc;
                    cmdUpdUsu.Parameters.Add("@Campo", SqlDbType.NVarChar,10).Value = Campo;
                    cmdUpdUsu.Parameters.Add("@Acc", SqlDbType.TinyInt).Value = Convert.ToInt16(Check);
                    cmdUpdUsu.ExecuteNonQuery();
                }
            }
        }

        public DataTable AccFrm_RecUsuEmp(int CodUsuOcu)
        {
            SqlDataAdapter daRecUsuEmp = new SqlDataAdapter("GEN_RecUsuEmp", cn);
            daRecUsuEmp.SelectCommand.CommandType = CommandType.StoredProcedure;
            daRecUsuEmp.SelectCommand.Parameters.Add("@CodUsuOcu",SqlDbType.Int).Value = CodUsuOcu;
            DataTable dtRecUsuEmp = new DataTable();
            dtRecUsuEmp.Locale = CultureInfo.InvariantCulture;
            daRecUsuEmp.Fill(dtRecUsuEmp);
            return dtRecUsuEmp;
        }

        public void AccFrm_CopDocUsu(int CodUsuOri, int CodUsuDes)
        {
            using (SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdCopAccUsu = new SqlCommand("GEN_AccFrm_CopDoc", cnx))
                {
                    cmdCopAccUsu.Connection.Open();
                    cmdCopAccUsu.CommandType = CommandType.StoredProcedure;
                    cmdCopAccUsu.Parameters.Add("@CodUsuOri", SqlDbType.Int).Value = CodUsuOri;
                    cmdCopAccUsu.Parameters.Add("@CodUsuDes", SqlDbType.Int).Value = CodUsuDes;
                    cmdCopAccUsu.ExecuteNonQuery();
                }
            }
        }
    }
}
