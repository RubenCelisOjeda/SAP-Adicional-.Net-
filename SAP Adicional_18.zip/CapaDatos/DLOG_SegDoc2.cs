﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class DLOG_SegDoc2
    {
        SqlConnection cnx = new SqlConnection(DVarGlo.Instance().Cadena);

        public DataTable LOG_SegDoc2(DateTime fIni, DateTime fFin)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_SegDoc2]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@FInicial", SqlDbType.SmallDateTime).Value = fIni;
            da.SelectCommand.Parameters.Add("@FFinal", SqlDbType.SmallDateTime).Value = fFin;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_SegDoc_Est()
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select * from LOG_SegDoc_Est", cnx);
            da.SelectCommand.CommandType = CommandType.Text;
            da.Fill(dt);
            return dt;
        }

        public DataTable LOG_SegDoc_Est_(string tabla, int docnum, string est, string obs, Int16 CodUsu)
        {
            SqlDataAdapter da = new SqlDataAdapter("[LOG_SegDoc_act]", cnx);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@tabla", SqlDbType.NVarChar, 4).Value = tabla;
            da.SelectCommand.Parameters.Add("@docnum", SqlDbType.Int).Value = docnum;
            da.SelectCommand.Parameters.Add("@est", SqlDbType.NVarChar, 50).Value = est;
            da.SelectCommand.Parameters.Add("@obs", SqlDbType.NVarChar, 400).Value = obs;
            da.SelectCommand.Parameters.Add("@CodUsu", SqlDbType.SmallInt).Value = CodUsu;
            DataTable dt = new DataTable();
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
            da.Fill(dt);
            return dt;
        }
    }
}
