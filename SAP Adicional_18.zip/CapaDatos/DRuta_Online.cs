﻿using Entidades.Ruta_Online;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DRuta_Online
    {
        private string _consulta = "";

        public DataTable Ruta_Online_Filtros(string vista, string procedimiento, string param)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter da = new SqlDataAdapter(procedimiento, cn))
                {
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    switch (vista)
                    {
                        case "Rutas":
                        case "Corte":
                            da.SelectCommand.Parameters.Add("@Filtro", SqlDbType.NVarChar, 60).Value = param;
                            break;
                        case "Transportista":
                            da.SelectCommand.Parameters.Add("@Param1", SqlDbType.NVarChar, 60).Value = param;
                            break;
                        default:
                            break;
                    }

                    DataTable dt = new DataTable();
                    dt.Locale = CultureInfo.InvariantCulture;
                    da.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable Ruta_Online_RecCor(DateTime fec)
        {
            _consulta = @"SELECT * FROM ALM_CorPed_Cor 
                                  WHERE FecCor = @fecha";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRutOnlRecCor = new SqlDataAdapter(_consulta, cn))
                {
                    daRutOnlRecCor.SelectCommand.CommandType = CommandType.Text;
                    daRutOnlRecCor.SelectCommand.Parameters.Add("@fecha", SqlDbType.SmallDateTime).Value = fec;
                    DataTable dt = new DataTable();
                    dt.Locale = CultureInfo.InvariantCulture;
                    daRutOnlRecCor.Fill(dt);
                    return dt;
                }

            }
        }

        public DataTable Ruta_Online_RecDis()
        {
            _consulta = @"SELECT CodigoDistrito, Nombre 
                                FROM Distritos ORDER BY Nombre";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecDis = new SqlDataAdapter(_consulta, cn))
                {
                    daRecDis.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = CultureInfo.InvariantCulture;
                    daRecDis.Fill(dt);
                    return dt;
                }
            }
        }

        public DataTable Ruta_Online_RecArePro()
        {
            _consulta = "SELECT  CodArePro,Descripcion FROM LOG_Rut_ArePro";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecArePro = new SqlDataAdapter(_consulta, cn))
                {
                    daRecArePro.SelectCommand.CommandType = CommandType.Text;
                    DataTable dtArePro = new DataTable();
                    dtArePro.Locale = CultureInfo.InvariantCulture;
                    daRecArePro.Fill(dtArePro);
                    return dtArePro;
                }
            }
        }


        public DataTable Ruta_Online_RecTrans()
        {
            _consulta = @"SELECT CodigoEmpleado, Nombres + ' ' + Apellidos Transportista 
                                 FROM Empleado 
                                 WHERE Transportista = 1 AND EnUso = 1 ORDER BY Nombres ";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecTra = new SqlDataAdapter(_consulta,cn))
                {
                    daRecTra.SelectCommand.CommandType = CommandType.Text;
                    DataTable dt = new DataTable();
                    dt.Locale = CultureInfo.InvariantCulture;
                    daRecTra.Fill(dt);
                    return dt;
                }
            }
        }


        public DataTable Ruta_Online_RecPro(DateTime fec, bool tod)
        {
            _consulta = @"INSERT INTO ALM_tmpRuta 
                          SELECT NumeroMovimiento FROM RutaProgramacion 
                                                  WHERE FechaRuta = @fec";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdEliRut = new SqlCommand("DELETE ALM_tmpRuta", cn)) //se elimina la tabla
                {
                    cn.Open();
                    cmdEliRut.CommandType = CommandType.Text;
                    cmdEliRut.ExecuteNonQuery();

                    using (SqlCommand cmdInsRut = new SqlCommand(_consulta, cn))
                    {
                        cmdInsRut.CommandType = CommandType.Text;
                        cmdInsRut.Parameters.Add("@fec", SqlDbType.SmallDateTime).Value = fec;
                        cmdInsRut.ExecuteNonQuery();
                        cn.Close();
                    }
                }
               
                using (SqlDataAdapter daRutOnlRecPro = new SqlDataAdapter("RutaProgramacion_Online", cn)) //Recupera los datos despues de insertar
                {
                    daRutOnlRecPro.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRutOnlRecPro.SelectCommand.Parameters.Add("@Fecha", SqlDbType.SmallDateTime).Value = fec;
                    daRutOnlRecPro.SelectCommand.Parameters.Add("@Todo", SqlDbType.Bit).Value = tod;

                    DataTable dt = new DataTable();
                    dt.Locale = CultureInfo.InvariantCulture;
                    daRutOnlRecPro.Fill(dt);
                    return dt;
                }
            }
        }

        public void Ruta_Online_ActCol(Int16 numMov, Int16 col, string valor, Int16 estDat = 0, bool estado = false, Int16 rq = 0)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                string Parametro = "";

                if (col == 6 || col == 5) _consulta = "UPDATE RutaProgramacion SET Cliente = @valor Where NumeroMovimiento = @numMov";

                switch (estDat) //estado del grid cambia a la hora se actualizar los datos por la columna
                {
                    case 0:
                        if (col == 7) _consulta = "UPDATE RutaProgramacion SET Direccion = @valor Where NumeroMovimiento = @numMov";
                        if (col == 8) _consulta = "UPDATE RutaProgramacion SET CodDis = @valor Where NumeroMovimiento = @numMov";
                        if (col == 9) _consulta = "UPDATE RutaProgramacion SET Tipo = @valor Where NumeroMovimiento = @numMov";
                        if (col == 16) _consulta = "UPDATE RutaProgramacion SET CodTra = @valor Where NumeroMovimiento = @numMov";
                        if (col == 18) _consulta = "UPDATE RutaProgramacion SET Observaciones = @valor Where NumeroMovimiento = @numMov";
                        if (col == 24) _consulta = "UPDATE RutaProgramacion SET Estiba = @valor Where NumeroMovimiento = @numMov";
                        if (col == 25) _consulta = "UPDATE RutaProgramacion SET CodArePro = @valor Where NumeroMovimiento = @numMov";
                        break;
                    case 1:
                        if (col == 7) _consulta = "UPDATE RutaProgramacion SET CodDis = @valor Where NumeroMovimiento = @numMov";
                        if (col == 8) _consulta = "UPDATE RutaProgramacion SET Tipo = @valor Where NumeroMovimiento = @numMov";
                        if (col == 9) _consulta = "UPDATE RutaProgramacion SET Encargo = @valor Where NumeroMovimiento = @numMov";
                        if (col == 14) _consulta = "UPDATE RutaProgramacion SET CodTra = @valor Where NumeroMovimiento = @numMov";
                        if (col == 16) _consulta = "UPDATE RutaProgramacion SET Observaciones = @valor Where NumeroMovimiento = @numMov";
                        if (col == 15)
                        {
                            if (estado == true) _consulta = "UPDATE RutaProgramacion SET EstadoRegistro = 1 Where NumeroMovimiento = @numMov";
                            else _consulta = "UPDATE RutaProgramacion SET EstadoRegistro = 8 Where NumeroMovimiento = @numMov";

                            using (SqlCommand cmdActGuaVecRut = new SqlCommand("Ruta_ActVecRut", cn))
                            {
                                cmdActGuaVecRut.Connection.Open();
                                cmdActGuaVecRut.CommandType = CommandType.StoredProcedure;
                                cmdActGuaVecRut.Parameters.Add("@NumRQ", SqlDbType.Int).Value = rq;
                                cmdActGuaVecRut.ExecuteNonQuery();
                                cmdActGuaVecRut.Connection.Close();
                            }
                        }
                        break;

                    default:
                        break;
                }

                if (col == 10) _consulta = "UPDATE RutaProgramacion SET Encargo = @valor Where NumeroMovimiento = @numMov";

                if (col == 17)
                {
                    if (estado == true) _consulta = "UPDATE RutaProgramacion SET EstadoRegistro = 8 Where NumeroMovimiento = @numMov";
                    else _consulta = "UPDATE RutaProgramacion SET EstadoRegistro = 1 Where NumeroMovimiento = @numMov";

                    using (SqlCommand cmdActGuaVecRut = new SqlCommand("Ruta_ActVecRut", cn))
                    {
                        cmdActGuaVecRut.Connection.Open();
                        cmdActGuaVecRut.CommandType = CommandType.StoredProcedure;
                        cmdActGuaVecRut.Parameters.Add("@NumRQ", SqlDbType.Int).Value = rq;
                        cmdActGuaVecRut.ExecuteNonQuery();
                        cmdActGuaVecRut.Connection.Close();
                    }
                }

                Parametro = "@valor";

                using (SqlCommand cmdActCol = new SqlCommand(_consulta, cn))
                {
                    cmdActCol.Connection.Open();
                    cmdActCol.CommandType = CommandType.Text;
                    cmdActCol.Parameters.Add("@numMov", SqlDbType.Int).Value = numMov;
                    cmdActCol.Parameters.AddWithValue(Parametro, valor);
                    cmdActCol.ExecuteNonQuery();
                    cmdActCol.Connection.Close();
                }

            }
        }

        public void Ruta_Online_ActFecMod(Ruta_Online_ItemEnc Item)
        {
            _consulta = @"UPDATE RutaProgramacion SET FechaModificacion = GETDATE(), 
                                                      CodigoUsuarioM = @codUsuAct
                                                      WHERE NumeroMovimiento = @numMov";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdActFecMod = new SqlCommand(_consulta,cn))
                {
                    cmdActFecMod.Connection.Open();
                    cmdActFecMod.CommandType = CommandType.Text;
                    cmdActFecMod.Parameters.Add("@numMov", SqlDbType.Int).Value = Item.NumMov;
                    cmdActFecMod.Parameters.Add("@codUsuAct", SqlDbType.Int).Value = Item.CodUsu;
                    cmdActFecMod.ExecuteNonQuery();
                    cmdActFecMod.Connection.Close();
                }
            }
        }

        public Int16 Ruta_Online_RecVerMov(DateTime Fec)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecVerMov = new SqlDataAdapter("[RutaProgramacion_VerificarMovilidad]", cn))
                {
                    daRecVerMov.SelectCommand.CommandType = CommandType.StoredProcedure;

                    SqlParameter paramValor = new SqlParameter("@Valor", SqlDbType.SmallInt);
                    paramValor.Direction = ParameterDirection.InputOutput;

                    daRecVerMov.SelectCommand.Parameters.Add("@Fecha", SqlDbType.SmallDateTime).Value = Fec;
                    daRecVerMov.SelectCommand.Parameters.Add(paramValor).Value = 0;

                    return Convert.ToInt16(daRecVerMov.SelectCommand.Parameters["@Valor"].Value); //falta recuperar el valor
                }
            }
        }

        public void Ruta_Online_InsAteMon(Ruta_Online_ItemEnc Item)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdInsAteMon = new SqlCommand("RutaProg_AteMon", cn))
                {
                    cmdInsAteMon.Connection.Open();
                    cmdInsAteMon.CommandType = CommandType.StoredProcedure;
                    cmdInsAteMon.Parameters.Add("@Fec", SqlDbType.SmallDateTime).Value = Item.FecRuta;
                    cmdInsAteMon.Parameters.Add("@CodUsu", SqlDbType.SmallInt).Value = Item.CodUsu;
                    cmdInsAteMon.ExecuteNonQuery();
                    cmdInsAteMon.Connection.Close();
                }
            }
        }

        public void Ruta_Online_ActRutPro(Ruta_Online_ItemEnc item)
        {
            _consulta = @"UPDATE RutaProgramacion SET EstadoRegistro = 4,
                                                      FechaModificacion = GETDATE(),
                                                      CodigoUsuarioM = @codUsuAct   
                                                      WHERE NumeroMovimiento = @numMov";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdActFecMod = new SqlCommand(_consulta,cn))
                {
                    cmdActFecMod.Connection.Open();
                    cmdActFecMod.CommandType = CommandType.Text;
                    cmdActFecMod.Parameters.Add("@numMov", SqlDbType.Int).Value = item.NumMov;
                    cmdActFecMod.Parameters.Add("@codUsuAct", SqlDbType.Int).Value = item.CodUsu;
                    cmdActFecMod.ExecuteNonQuery();
                    cmdActFecMod.Connection.Close();
                }
            }
        }

        public DataTable Ruta_Online_RecProPen()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecProPen = new SqlDataAdapter("RutaProgramacion_Pendientes", cn))
                {
                    daRecProPen.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataTable dtRecProPen = new DataTable();
                    dtRecProPen.Locale = CultureInfo.InvariantCulture;
                    daRecProPen.Fill(dtRecProPen);
                    return dtRecProPen;
                }
            }
        }

        public DataTable Ruta_Online_RecItemEnc(int numMov)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecItemEnc = new SqlDataAdapter("RutaItem_Encabezado", cn))
                {
                    daRecItemEnc.SelectCommand.CommandType = CommandType.StoredProcedure;
                    daRecItemEnc.SelectCommand.Parameters.Add("@NumeroMovimiento", SqlDbType.Int).Value = numMov;

                    DataTable dtRecItemEnc = new DataTable();
                    dtRecItemEnc.Locale = CultureInfo.InvariantCulture;
                    daRecItemEnc.Fill(dtRecItemEnc);
                    return dtRecItemEnc;
                }
            }
        }
        public void Ruta_Online_ActItemEnc(Ruta_Online_ItemEnc item)
        {

            _consulta = @"UPDATE RutaProgramacion SET FechaRuta = @fecRuta,
                                                      FechaModificacion = GETDATE(),
                                                      CodigoUsuarioM = @codUsu 
                                                      WHERE NumeroMovimiento = @numMov";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand cmdActItemEnc = new SqlCommand(_consulta,cn))
                {
                    cn.Open();
                    cmdActItemEnc.CommandType = CommandType.Text;
                    cmdActItemEnc.Parameters.Add("@fecRuta", SqlDbType.SmallDateTime).Value = item.FecRuta.ToShortDateString();
                    cmdActItemEnc.Parameters.Add("@codUsu", SqlDbType.Int).Value = item.CodUsu;
                    cmdActItemEnc.Parameters.Add("@numMov", SqlDbType.Int).Value = item.NumMov;
                    cmdActItemEnc.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public DataTable Ruta_Online_RecDatTim(DateTime fecRut)
        {
            _consulta = @"SELECT r.Descripcion Ruta, rp.numrq [N° RQ],RP.Cliente ,RP.FechaRuta [Fecha/Ruta],Convert(NVarChar(10),RP.Hora,114) Hora 
                                                                        FROM  RutaProgramacion RP INNER JOIN Rutas R ON RP.CodigoRuta = R.Codigo 
                                                                        WHERE FechaRuta =@fecRut and [NumeroMovimiento] not in (select nummov FROM ALM_tmpRuta)";

            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlDataAdapter daRecDatTim = new SqlDataAdapter(_consulta, cn))
                {
                    daRecDatTim.SelectCommand.CommandType = CommandType.Text;
                    daRecDatTim.SelectCommand.Parameters.Add("@fecRut", SqlDbType.SmallDateTime).Value = fecRut.ToString("dd/MM/yyyy");

                    DataTable dtRecDatTim = new DataTable();
                    dtRecDatTim.Locale = CultureInfo.InvariantCulture;
                    daRecDatTim.Fill(dtRecDatTim);
                    return dtRecDatTim;
                }
            }
        }
    }
}
