﻿using Entidades.Man_Menus;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class DMan_Men
    {

        public DataTable Rec_KeyNod(string keyNod)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand manMen = new SqlCommand("SELECT Codigo, Menu, NivelSuperior, Notacion, Relacion, NotacionSuperior, Formulario,                                                        NivelJerarquico,OrdenEnsuNivel FROM Menus WHERE Notacion=@keynod",cn))
                {
                    cn.Open();
                    manMen.CommandType= CommandType.Text;
                    manMen.Parameters.Add("@keynod",SqlDbType.VarChar).Value= keyNod;
                    SqlDataReader dr = manMen.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dr);
                    return dt;
                }
             }           
        }

        public DataTable Rec_Menus()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand manMen = new SqlCommand("SELECT Codigo, Menu, NivelSuperior, Notacion, Relacion, NotacionSuperior, NivelJerarquico,                                                OrdenEnSuNivel FROM Menus ORDER BY NivelSuperior, NivelJerarquico, OrdenEnSuNivel", cn))
                {
                    cn.Open();
                    manMen.CommandType = CommandType.Text;
                    SqlDataReader dr = manMen.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Locale = System.Globalization.CultureInfo.InvariantCulture;
                    dt.Load(dr);
                    return dt;
                }
            }
        }

        public int RecCodMen()
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand carUltCod = new SqlCommand("SELECT CASE WHEN MAX(Codigo) IS NULL THEN 1 ELSE MAX(Codigo) + 1 END Codigo FROM Menus", cn))
                {
                    cn.Open();
                    carUltCod.CommandType = CommandType.Text;
                    return Convert.ToInt32(carUltCod.ExecuteScalar()); 

                }           
            }
        }

        public void InsMen(ManMen_Enc MenIns)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                SqlDataAdapter InsNueMen = new SqlDataAdapter("INSERT INTO Menus (Codigo,Menu,NivelSuperior,Notacion,Relacion,NotacionSuperior,Formulario)" +
                                             "values (@codigo,@menu,@nivSup,@notacion,@relacion,@notaSupe,@form)", cn);
                cn.Open();
                InsNueMen.SelectCommand.CommandType = CommandType.Text;
                InsNueMen.SelectCommand.Parameters.Add("@codigo", SqlDbType.Int).Value = MenIns.Codigo;
                InsNueMen.SelectCommand.Parameters.Add("@menu", SqlDbType.NVarChar, 50).Value = MenIns.Menu;
                InsNueMen.SelectCommand.Parameters.Add("@nivSup", SqlDbType.Int).Value = MenIns.NivSup;
                InsNueMen.SelectCommand.Parameters.Add("@notacion", SqlDbType.NVarChar, 50).Value = MenIns.Notacion;
                InsNueMen.SelectCommand.Parameters.Add("@relacion", SqlDbType.SmallInt).Value = 4;
                InsNueMen.SelectCommand.Parameters.Add("@notaSupe", SqlDbType.NVarChar, 50).Value = MenIns.NotSup;
                InsNueMen.SelectCommand.Parameters.Add("@form", SqlDbType.NVarChar, 100).Value = MenIns.Form;
                InsNueMen.SelectCommand.ExecuteNonQuery();
            }
        }

        public void EliMenu(Int16 codigo)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand EliMen = new SqlCommand("DELETE Menus WHERE Codigo=@codigo", cn))
                {
                    cn.Open();
                    EliMen.CommandType = CommandType.Text;
                    EliMen.Parameters.Add("@codigo",SqlDbType.Int).Value = codigo;
                    EliMen.ExecuteNonQuery();
                }
                using (SqlCommand EliMen = new SqlCommand("DELETE Menus_Accesos WHERE CodigoMenu=@codigomenu", cn))
                {
                    EliMen.CommandType = CommandType.Text;
                    EliMen.Parameters.Add("@codigomenu", SqlDbType.Int).Value = codigo;
                    EliMen.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }

        public void ActMen(ManMen_Enc MenAct)
        {
            using (SqlConnection cn = new SqlConnection(DVarGlo.Instance().Cadena))
            {
                using (SqlCommand ActMen = new SqlCommand("update menus set menu=@menu,Formulario=@for,NivelJerarquico=@nivJer,OrdenEnSuNivel=@ordEnSuNiv where codigo=@codigo", cn))
                {
                    cn.Open();
                    ActMen.CommandType = CommandType.Text;
                    ActMen.Parameters.Add("@menu",SqlDbType.NVarChar,50).Value = MenAct.Menu;
                    ActMen.Parameters.Add("@for", SqlDbType.NVarChar, 100).Value = MenAct.Form;
                    ActMen.Parameters.Add("@nivJer", SqlDbType.SmallInt).Value = MenAct.NivJer;
                    ActMen.Parameters.Add("@ordEnSuNiv", SqlDbType.SmallInt).Value = MenAct.OrdEnSuNiv;
                    ActMen.Parameters.Add("@codigo", SqlDbType.Int).Value = MenAct.Codigo;
                    ActMen.ExecuteNonQuery();
                    cn.Close();
                }
            }
        }
      
    }
}
