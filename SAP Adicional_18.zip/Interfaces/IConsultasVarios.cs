﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    interface IConsultasVarios
    {

    }

    public interface IMan_Contactos
    {
        void RecDat_Dis(string codDis,string dis);
        void RecDat_Dis2(string codDis, string dis);
        void RecDat_Pro(string codPro,string pro);
        void RecDat_TipCon(string codTipCon ,string tipCon);
        void RecDat_Res(string codRes,string res);
        void RecDat_Cat(string codCat,string cat);
    }

    public interface AccFrm
    {
        void recdat_Usu(string CodUsu, string DesUsu);
        void recdat_Doc(string CodCod, string DesDoc);
    }

    public interface LOG_Imp
    {
        void recdat_Pro(string CodPro, string DesPro);
        void recdat_Env(string CodEnv, string DesEnv,string Ali);
        void recdat_EstPag(string CodEstPag,string DesEstPag);
        void recdat_Mon(string CodMon, string DesMon);
        void recdat_Art(string CodArt, string DesArt,string Cat,string Can,string NomExt);
    }
    public interface LOG_InfRS
    {
        void recdat_RqPed(string NumRq, string Cli);
        void recdat_Art(string CodArt, string DesArt,string Pro,string Cat);
        void recdat_ArtOC(string CodArtOC, string DesArtOC, string ProOC);
    }
    public interface frmMan_Articulo_Compuesto
    {
        void recdat_TipSer(string CodTipArt, string DesTipArt);
        void recdat_ArtCom(string CodArt, string DesArt, string Cat, string Pre, string Mon, string Descon);
    }
    public interface frm_Man_Usuarios
    {
        void recdat_frm_Man_Usuario(string CodEmp,string NomEmp);
    }
    public interface Men_Acc_Filtros
    {
        void recdat_Men_Acc_Filtros_Empleado(string CodEmp, string DesEmp); //datos que se van a recuperar
        void recdat_Men_Acc_Filtros_Empleado2(string CodEmp2, string DesEm2); //datos que se van a recuperar
        void recdat_Men_Acc_Filtros_Area(string CodAre, string DesAre);

    }
    public interface Ruta_ItemDocRel
    {
        void recdat_Ruta_Item_DocRel(string NumDoc);
    }
    public interface ALM_Inventario
    {
        void recdat_ALM_Inventario_Dis(string CodDes, string DesDes);
        void recdat_ALM_Inventario_Alm(string CodSap, string CodXtr, string DesArt, string Stock);
    }
    public interface IALM_Ubi_ConStock
    {
        void recdat_ALM_Ubi_ConStock_Alm(string CodAlm, string DesAlm);
        void recdat_ALM_Ubi_ConStock_Art(string CodSap, string CodXtr, string DesArt);
        void recdat_ALM_Ubi_ConStock_Art2(string CodArt, string DesArt);
        void recdat_ALM_Ubi_ConStock_Res(string CodRes, string DesRes);
    }
    public interface ArtEti
    {
        void recdat_ArtEtic_Dat(string CodSAp, string CodXtra, string Des, string Cod, string DesArt, string ClaGen, string NomUni, string CarAdi);
    }
    public interface ALM_PreDoc_Con
    {
        void recdat_ALM_PreDoc_Con_Rut(string CodRut, string DesRut);
        void recdat_ALM_PreDoc_Con_Alm(string CodAlm, string DesAlm);
    }
    public interface Ruta_Corte
    {
        void recdat_Ruta_Corte_Cor(string CodCor, string DesCor);
    }
    public interface Ruta_Item
    {
        void recdat_Ruta_Item_TipRut(string CodTipRut, string DesTipRut);
        void recdat_Ruta_Item_MedTra(string CodMedTra, string DesMedTra);
        void recdat_Ruta_Item_Tra(string CodTra, string DesTra);
        void recdat_Ruta_Item_Dis(string CodDis, string DesDis);
        void recdat_Ruta_Item_Cor(string CodCor, string DesCor, string CodRut);
    }
 public interface Ruta_Online
    {
        void recdat_Ruta_Online_RutCor(string CodRutCor, string DesRutCor);
        void recdat_Ruta_Online_Tra(string CodTra, string DesTra);
    }
   
    public interface ALM_Ubi_Mae
    {
        void recdat_ALM_Ubi_Mae(string CodAlm, string DesAlm);
    }

    public interface ALM_UbiImp_BarCode
    {
        void recdat_ALM_UbiImp_BarCode(string CodAlm, string DesAlm);
    }

    public interface Alm_RelAlmEnc
    {
        void recdat_Alm_RelAlm(string CodAlm, string DesAlm);
        void recdat_Alm_RelAlmEnc(string CodEnc, string DesEnc);
    }

    public interface frmVEN_RQ_Info
    {
        void recdat_frmVEN_RQ_info(string rq, string cli);
    }

    public interface VEN_Cot_Filtros
    {
        void recdat_frmVEN_Cot_Cliente(string codcli, string cli, string rucdni, string codtipdoc, string tel, string email);
        void recdat_frmVEN_Cot_EmpleadoVentas(string codemp, string emp);
        void recdat_frmVEN_Cot_CentroVenta(string codcenven, string cenven);
        void recdat_frmVEN_Cot_TipoVenta(string codtipven, string tipven);
        void recdat_frmVEN_Cot_TipoVentaRelativo(string tipvenrel);
        void recdat_frmVEN_Cot_Rubro(string rubro);
        void recdat_frmVEN_Cot_TipoObra(string tipoobra);
        void recdat_frmVEN_Cot_Dimension(string dimension);
        void recdat_frmVEN_Cot_Recomendador(string codrec, string rec);
        void recdat_frmVEN_Cot_ArticuloCompuesto(string Codigo, string Art, string Precio, string Obs);
        void recdat_frmVEN_Cot_Ambiente(string CodAmb, string Amb);
        void recdat_frmVEN_Cot_Motivo(string CodMot, string Mot);
        void recdat_frmVEN_Cot_AdmRQ(string CodAdmRQ, string AdmRQ);
        void recdat_frmVEN_Cot_Tiempo(string Tiempo);
        void recdat_frmVEN_Cot_ArtCom(string Codigo, string Des, string Can, string ValVen);
        void recdat_frmVEN_Cot_AmbienteAA(string CodAmb, string Amb);
        void recdat_frmVEN_Cot_Articulo(string Codigo, string Art, string Precio);
        void recdat_frmVEN_Cot_ArtAmb(string CodAmb, string Amb);
        void recdat_frmVEN_Cot_FalEn(string CodFalEn, string FalEn);
        void recdat_frmVEN_Cot_LinPro(string CodLinPro, string LinPro);
        void recdat_frmVEN_Cot_Tip(string CodTip, string Tip);
        void recdat_frmVEN_Cot_SubLin(string CodSubLin, string SubLin);
        void recdat_frmVEN_Cot_Fam(string CodFam, string Fam);
        void recdat_frmVEN_Cot_CliCon(string CodCon, string Con);
        void recdat_frmVEN_Cot_Neg(string Cod, string Des);
        void recdat_frmVEN_Cot_Env(string Cod, string Des);
        void recdat_frmVEN_Cot_Lin(string Codigo, string Linea);
        void recdat_frmVEN_Cot_SubLinAA(string Codigo, string SubLinea);
        void recdat_frmVEN_Cot_FamAA(string Codigo, string Familia);
        void recdat_frmVEN_Cot_SubFam(string Codigo, string SubFamilia);
        void recdat_frmVEN_Cot_Marca(string Codigo, string Marca);
        void recdat_frmVEN_Cot_Pro(string Codigo, string Proveedor);
        //void recdat_frmVEN_Cot_ColMue(string Codigo, string Proveedor);
        void recdat_frmVEN_Cot_MatBasMue(string Codigo, string Material);
        void recdat_frmVEN_Cot_ProHom(string Codigo, string Proveedor, string CodMon, string Mon, string PorDesFOB, string FacImp);

    }

    public interface VEN_rep_AdmRQ
    {

    }

    public interface OPE_Pro_Filtros
    {
        void recdat_OPE_Pro_Tipo(string CodTip, string Tipo);
        void recdat_OPE_Pro_Complejidad(string CodCom, string Com);
        void recdat_OPE_Pro_TipoPredio(string CodTipPre, string TipPre);
        void recdat_OPE_Pro_Diseño(string CodDis, string Dis);
        void recdat_OPE_Pro_IngOpe(string CodIngOpe, string IngOpe);
        void recdat_OPE_Pro_Supervisor(string CodSup, string Sup);
        void recdat_OPE_Pro_AdmPed(string CodAdmPed, string AdmPed);
        void recdat_OPE_Pro_RQ(string rq, string cli, string vend);

    }

    public interface OPE_Pro_Filtros_Act
    {
        void recdat_OPE_Pro_Cargo(string CodCar, string Cargo);
        void recdat_OPE_Pro_EstadoObra(string CodEstObr, string EstObr);
    }

    public interface LOG_OFC_Filtros
    {
        void recdat_LOG_OFC_TipOFC(string CodTipOFC, string TipOFC);
        void recdat_LOG_OFC_TipSer(string CodTipSer, string TipSer);
        void recdat_LOG_OFC_CatGas(string CodCatGas, string CatGas);
        void recdat_LOG_OFC_Ser(string CodSer, string Ser, string Cta, string CodAre, string Are, string CodSubAre, string SubAre, string CodUniNeg, string UniNeg);
        void recdat_LOG_OFC_Are(string CodAre, string Are);
        void recdat_LOG_OFC_SubAre(string CodSubAre, string SubAre);
        void recdat_LOG_OFC_UniNeg(string CodUniNeg, string UniNeg);
        void recdat_LOG_OFC_Pro(string CodPro, string Pro);
        void recdat_LOG_OFC_Mon(string CodMon, string Mon);
    }

    public interface ALM_MovIngxEnc
    {
        void recdat_ALM_MovIngxEnc_Rango(string CodEnc, string NomEnc);
    }
}


