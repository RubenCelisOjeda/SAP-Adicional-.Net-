﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    interface IVariablesVarios
    {
    }

    public interface SAP_Variables
    {
        void rec_SAP_UserBad(bool res);
        void rec_SAP_Connection(Int32 ErrorCode);
    }
}
