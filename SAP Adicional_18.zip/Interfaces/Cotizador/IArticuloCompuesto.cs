﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.VEN_Cot;

namespace Interfaces.Cotizador
{
    public interface IArticuloCompuesto
    {
        //te obliga 
        //int agregar(ArticuloCompuesto AC);
        //int editar(ArticuloCompuesto AC);
        //int eliminar(int CodArtCom);

        //ArticuloCompuesto buscar(int CodArtCom);

        //List<ArticuloCompuesto> Listar();

        //bool Existe(int CodArtCom);
    }


}
