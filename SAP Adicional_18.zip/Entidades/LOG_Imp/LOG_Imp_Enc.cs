﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_Imp
{
    public class LOG_Imp_Enc
    {
        public int NumMov { get; set; }
        public string NumImp { get; set; }
        public string CodPro { get; set; }
        public string Nompro { get; set; }
        public string Etd { get; set; }
        public string Eta { get; set; }
        public Int16 CodForEnv { get; set; }
        public Int16 CodEstPag { get; set; }
        public DateTime FecEmi { get; set; }
        public string InVoiTo { get; set; }
        public string Shipo { get; set; }
        public string CouImp { get; set; }
        public string UltDest { get; set; }
        public string Pho { get; set; }
        public string Fax { get; set; }
        public string Fwd { get; set; }
        public string Adrs { get; set; }
        public string FwdPho { get; set; }
        public string FwdFax { get; set; }
        public string Ema { get; set; }
        public string ConPer { get; set; }
        public string PayTer { get; set; }
        public string Lbs { get; set; }
        public Int16 CodMon { get; set; }
        public string FecLleSqo { get; set; }
        public Int16 IncTer { get; set; }
        public Int16 CodUsu { get; set; }
        public Int16 EnvInt { get; set; }
        public byte CodLey { get; set; }

        public string FecDisDes { get; set; }
        public string NomBar { get; set; }
        public string AwbTra { get; set; }
        public string CodImp { get; set; }
        public string OtrNumImp { get; set; }
        public string Fepe { get; set; }

        public List<LOG_Imp_Det> Log_Imp_Det { get; set; }
        public List<LOG_Imp_Enc> Log_Imp_Enc { get; set; }
        public List<LOG_Imp_DetSinSto> Log_Imp_DetSinStock { get; set; }

        public LOG_Imp_Enc()
        {
            this.Log_Imp_Det = new List<LOG_Imp_Det>();
            this.Log_Imp_Enc = new List<LOG_Imp_Enc>();
            this.Log_Imp_DetSinStock = new List<LOG_Imp_DetSinSto>();
        }
    }
}
