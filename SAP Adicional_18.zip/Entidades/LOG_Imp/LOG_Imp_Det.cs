﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_Imp
{
    public class LOG_Imp_Det
    {
        public string CodArt { get; set; }
        public Int16 NumId { get; set; }
        public int Can { get; set; }
        public decimal Cos { get; set; }
        public string Obs { get; set; }
        public bool Ocu { get; set; }
        public Int16 Ord { get; set; }
        public string FecEnPro { get; set; }
    }
}
