﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_Imp
{
    public class LOG_Imp_DetSinSto
    {
        public Int16 Ite { get; set; }
        public string Cat { get; set; }
        public string DesPro { get; set; }
        public string Tra { get; set; }
        public decimal Can { get; set; }
        public decimal Cos { get; set; }
        public string Par { get; set; }
        public byte Ord { get; set; }
        public string FecEntPro { get; set; }
    }
}
