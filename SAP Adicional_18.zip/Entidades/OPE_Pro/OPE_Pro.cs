﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.OPE_Pro
{
    public class OPE_Pro
    {
        public Int64 NumMov { get; set; }
        public string  NomPro { get; set; }
        public string DirPro { get; set; }
        public string DisPro { get; set; }
        public Int32 CodUsu { get; set; }
        public Int16? CodEstObr { get; set; } //acepta null
        public DateTime? FecIni { get; set; } //acepta null
        public DateTime? FecCab { get; set; } //acepta null
        public DateTime? FecAprIns { get; set; } //acepta null
        public DateTime? FecFin { get; set; } //acepta null
        public string AlcPro { get; set; }

        public List<OPE_Pro_Det0> Det0 { get; set; }
        public List<OPE_Pro_Det1> Det1 { get; set; }
        public List<OPE_Pro_Det4> Det4 { get; set; }

        public OPE_Pro ()
        {        
            this.Det0 = new List<OPE_Pro_Det0>();
            this.Det1 = new List<OPE_Pro_Det1>();
            this.Det4 = new List<OPE_Pro_Det4>();
        }
        
    }
}
