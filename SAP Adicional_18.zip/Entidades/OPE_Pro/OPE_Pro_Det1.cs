﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.OPE_Pro
{
    public class OPE_Pro_Det1
    {

        public Int64 NumMov { get; set; }
        public int RQ { get; set; }
        public int Dis_DurEst_Mes { get; set; }
        public int Dis_CanVis_Und { get; set; }
        public int Dis_TraOfi_Hor { get; set; }
        public int Dis_TraPla_Hor { get; set; }
        public int Dis_TraDia_Hor { get; set; }
        public decimal Dis_CosDir { get; set; }
        public decimal Dis_CosInd { get; set; }
        public decimal Dis_GasGen { get; set; }
        public decimal Dis_Uti { get; set; }

        public int Sup_DurEst_Mes { get; set; }
        public int Sup_CanVisIngOpe_Und { get; set; }
        public int Sup_TraOfiOpe_Hor { get; set; }
        public int Sup_CanVisSup_Und { get; set; }
        public int Sup_CanPruMue_Und { get; set; }
        public int Sup_CanPruMueDobAlt_Und { get; set; }
        public int Sup_CanPrueMeg_Und { get; set; }
        public decimal Sup_CosDir { get; set; }
        public decimal Sup_CosInd { get; set; }
        public decimal Sup_GasGen { get; set; }
        public decimal Sup_Uti { get; set; }

        public int Ins_DurEst_Dia { get; set; }
        public int Ins_CanTecDia_Und { get; set; }
        public int Ins_CanVisCoo_Und { get; set; }
        public int Ins_CanViaMov_Und { get; set; }
        public int Ins_CanPruLuc_Und { get; set; }
        public decimal Ins_CosTraNoc_Sol { get; set; }
        public decimal Ins_CosMat_Sol { get; set; }
        public decimal Ins_CosDir { get; set; }
        public decimal Ins_CosInd { get; set; }
        public decimal Ins_GasGen { get; set; }
        public decimal Ins_Uti { get; set; }

        public int Pro_DurEst_Dia { get; set; }
        public int Pro_CanBotSenDri_Und { get; set; }
        public int Pro_CanModRepAmp_Und { get; set; }
        public int Pro_CanPanConLic_Und { get; set; }
        public decimal Pro_CosPro_Sol { get; set; }
        public decimal Pro_CosDir { get; set; }
        public decimal Pro_CosInd { get; set; }
        public decimal Pro_GasGen { get; set; }
        public decimal Pro_Uti { get; set; }

    }
}
