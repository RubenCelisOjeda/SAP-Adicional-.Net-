﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.OPE_Pro
{
    public class OPE_Pro_Det4
    {
        public Int64 NumMov { get; set; }
        public int Item { get; set; }
        public int CodIntPro { get; set; }
        public string Nom { get; set; }
        public string Cel1 { get; set; }
        public string Cel2 { get; set; }
        public string Email { get; set; }
        public bool ResFirGui { get; set; }
        public bool ResActVis { get; set; }
    }
}
