﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.OPE_Pro
{
    public class OPE_Pro_Det0
    {

        public Int64 NumMov { get; set; }
        public int RQ { get; set; }
        public Int16 CodTip { get; set; }
        public bool Tipico { get; set; }
        public bool Pendiente { get; set; }
        public string SocNeg { get; set; }
        public string Ven { get; set; }
        public Int16 CodCom { get; set; }
        public Int16 CodTipPre { get; set; }
        public Int32 CodDis { get; set; }
        public Int32 CodIngOpe { get; set; }
        public Int32 CodSup { get; set; }
        public Int32 CodAdmPed { get; set; }
        public bool Sup { get; set; }
        public Int16 CorTipPen { get; set; }
    }
}
