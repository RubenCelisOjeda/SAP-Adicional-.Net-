﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Ruta_Online
{
    public class Ruta_Online_ItemEnc
    {
        public DateTime FecRuta { get; set; }
        public Int16 CodUsu { get; set; }
        public Int16 NumMov { get; set;}
    }
}
