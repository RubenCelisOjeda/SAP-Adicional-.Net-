﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_Cot
{
    public class VEN_Cot
    {

        public Int64 NumMov { get; set; }
        public string NumCot { get; set; }
        public DateTime FecEmi { get; set; }
        public Int16 CodMot { get; set; }
        public Int16 EstDoc { get; set; }
        public string CardCode { get; set; }
        public string NomCli { get; set; }
        public string Tel { get; set; }
        public string Email { get; set; }
        public string DirCli { get; set; }
        public string DirObr { get; set; }
        public Int16 CntctCode { get; set; }
        public Int16 SlpCode { get; set; }
        public string U_SYP_C_VENTA { get; set; }
        public string U_SYP_TIVENTA { get; set; }
        public string U_SYP_RQ { get; set; }
        public string U_SYP_TVENTA_REL { get; set; }
        public string U_SYP_RUBRO { get; set; }
        public string U_SYP_TIPO_OBRA { get; set; }
        public string U_SYP_DIMENSION { get; set; }
        public string U_SYP_NOM_VENTA { get; set; }
        public string U_TRZ_TIE { get; set; }
        public string U_TRZ_OPCPAG { get; set; }
        public Int32 CodCon { get; set; }
        public string DocCur { get; set; }
        public decimal DocRate { get; set; }
        public decimal PorIGV { get; set; }
        public Int64 DocEntrySAP { get; set; }
        public Int64 DocNumSAP { get; set; }
        public string NomAdi { get; set; }
        public Int16 CodAdmRQ { get; set; }
        public int CodRecFalEn { get; set; }
        public int CodRecLinPro { get; set; }
        public int CodRecTip { get; set; }
        public int CodRecSubLin { get; set; }
        public int CodRecFam { get; set; }
        public Int32 CodUsu { get; set; }
        public int EstMigSAP { get; set; }
        public int EstApr { get; set; }

        public List<VEN_Cot_Det> Det { get; set; }
        public List<VEN_Cot_DetAmb> DetAmb { get; set; }
        public List<VEN_Cot_DetCom> DetCom { get; set; }
        public List<VEN_Cot_DetAA> DetAA { get; set; }
        public List<VEN_Cot_DetAS> DetAS { get; set; }
        public List<VEN_Cot_DetAmbAS> DetAmbAS { get; set; }

        public VEN_Cot()
        {

            Det = new List<VEN_Cot_Det>();
            DetAmb = new List<VEN_Cot_DetAmb>();
            DetCom = new List<VEN_Cot_DetCom>();
            DetAA = new List<VEN_Cot_DetAA>();
            DetAS = new List<VEN_Cot_DetAS>();
            DetAmbAS = new List<VEN_Cot_DetAmbAS>();

        }

    }
}
