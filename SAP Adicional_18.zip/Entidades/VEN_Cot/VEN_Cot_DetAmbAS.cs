﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_Cot
{
    public class VEN_Cot_DetAmbAS
    {
        public Int64 NumMov { get; set; }
        public string CodArt { get; set; }
        public Int32 CodAmb { get; set; }
        public decimal Can { get; set; }
    }
}
