﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_Cot
{
    public class VEN_Cot_DetCom
    {
        public Int64 NumMov { get; set; }
        public Int32 CodArtCom { get; set; }
        public string CodArt { get; set; }
        public decimal Can { get; set; }
        public decimal PreUni { get; set; }

    }
}
