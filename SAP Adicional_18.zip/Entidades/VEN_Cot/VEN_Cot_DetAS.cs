﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_Cot
{
    public class VEN_Cot_DetAS
    {

        public Int64 NumMov { get; set; }
        public string CodArt { get; set; }
        public decimal Can { get; set; }
        public decimal PreUni { get; set; }
        public decimal VenBru { get; set; }
        public decimal PorDes { get; set; }
        public decimal Desct { get; set; }
        public decimal ValNet { get; set; }
        public decimal IGV { get; set; }
        public decimal SubTot { get; set; }
        public string Obs { get; set; }
        public string Sim { get; set; }

    }
}
