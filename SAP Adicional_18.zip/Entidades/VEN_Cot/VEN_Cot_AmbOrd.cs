﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_Cot
{
    public class VEN_Cot_AmbOrd
    {
        public Int64 NumMov { get; set; }
        public Int32 CodAmb { get; set; }
        public short Orden { get; set; }

        public List<VEN_Cot_AmbOrd> AmbOrd { get; set; }

        public VEN_Cot_AmbOrd()
        {
            AmbOrd = new List<VEN_Cot_AmbOrd>();
        }
    }
}
