﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Man_Contactos
{
    public class Man_Contactos_Enc
    {
        public bool acc { get; set; }
        public int codCon { get; set; }
        public string nom { get; set; }
        public string ape { get; set; }
        public string dir { get; set; }
        public Int16 dis { get; set; }
        public string dirCas { get; set; }
        public Int16 codDisCas { get; set; }
        public string tel { get; set; }
        public string cel { get; set; }
        public string ema { get; set; }
        public string ema2 { get; set; }
        public Int16 codPro { get; set; }
        public string com { get; set; }
        public string carPro { get; set; }
        public Int16 codRes { get; set; }
        public string telTra { get; set; }
        public int? codTipCia { get; set; }
        public DateTime fecC { get; set; }
        public Int16 codUsuC { get; set; }
        public DateTime fecM { get; set; }
        public Int16 codUsuM { get; set; }
        public Int16? codTipCon { get; set; }
        public string fecN { get; set; }
        public string ruc { get; set; }
        public string dni { get; set; }
        public Int16 conAct { get; set; }
        public string ctaDet { get; set; }

    }
}
