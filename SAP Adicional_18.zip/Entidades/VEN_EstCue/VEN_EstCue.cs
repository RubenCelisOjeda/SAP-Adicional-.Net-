﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_EstCue
{
    public class VEN_EstCue
    {
        public int RQ { get; set; }
        public string NumDoc { get; set; }
        public int CodUsuActi { get; set; }

        public List<VEN_EstCue> EstCueList { get; set; }

        public VEN_EstCue()
        {
            this.EstCueList = new List<VEN_EstCue>();
        }
    }
}
