﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Ruta_Item
{
    public class Ruta_Item_Enc
    {
        public byte Acc { get; set; }
        public Int32 NumMov { get; set; }
        public byte? CodTipRut { get; set; }
        public Int32 NumRq { get; set; }
        public string Cli { get; set; }
        public DateTime FecRut { get; set; }
        public byte CodTipPed { get; set; }
        public Int16 CodTra { get; set; }
        public string Dir { get; set; }
        public Int16 CodDis { get; set; }
        public byte CodCorPed { get; set; }
        public byte CodRut { get; set; }
        public string Hora { get; set; }
        public byte HOpcion { get; set; }
        public string Contacto { get; set; }
        public char Tipo { get; set; }
        public string Encargo { get; set; }
        public Int16 CodUsu { get; set; }
        public byte Ins { get; set; }
        public string CodTipVen { get; set; }
        public string Coo { get; set; }
        public bool NumMovOTI { get; set; }
        public bool NumMovOdd { get; set; }
        public bool NumMovOtr { get; set; }


        //Documento relacionado
        public int NumDoc { get; set; }
        public Int16 TipDoc { get; set; }
        public int NumMovRut { get; set; }
     
        
    }
}
