﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_SolNotCre
{
    public class VEN_SolNotCre
    {
        public Int64 NumMov { get; set; }
        public string NumSol { get; set; }
        public short TipNotCre { get; set; }
        public string TipDoc { get; set; }
        public Int64 DocNum { get; set; }
        public DateTime FecEmi { get; set; }
        public Int64 RQ { get; set; }
        public string CodCli { get; set; }
        public Int16 CodEst { get; set; }
        public string CodMon { get; set; }
        public string Obs { get; set; }
        public string DocNumNotCre { get; set; }
        public string DirEnvNotCre { get; set; }
        public Int32 CodUsu { get; set; }

        //encabezado de solicitud de devolucion
        public Int16 TipDev { get; set; }
        public string TipDevDes { get; set; }
        public decimal MonDevDes { get; set; }
        public Int16 EntBan { get; set; }
        public string OtrBan { get; set; }
        public string TipCue { get; set; }
        public string CueBan { get; set; }
        public string CueInt { get; set; }

        public List<VEN_SolNotCre_Det> Det { get; set; }

        public VEN_SolNotCre()
        {
            this.Det = new List<VEN_SolNotCre_Det>();
        }
    }
}
