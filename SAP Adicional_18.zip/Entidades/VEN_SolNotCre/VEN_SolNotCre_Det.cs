﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_SolNotCre
{
    public class VEN_SolNotCre_Det
    {
        public Int64 NumMov { get; set; }
        public Int16 Item { get; set; }
        public Int64 DocNum { get; set; }
        public Int16 LineNum { get; set; }
        public string CodArt { get; set; }
        public decimal CanFac { get; set; }
        public decimal CanSol { get; set; }
        public decimal PreUni { get; set; }
        public decimal TotLin { get; set; }
        public decimal PorDes { get; set; }
        public string CodAlm { get; set; }
        public string TipDoc { get; set; }
        public Int64 DocNumFac { get; set;}
        public decimal IGV { get; set; }
    }
}
