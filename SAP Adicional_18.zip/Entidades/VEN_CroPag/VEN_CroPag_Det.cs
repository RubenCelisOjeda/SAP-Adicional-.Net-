﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_CroPag
{
    public class VEN_CroPag_Det
    {
        public Int64 NumMov { get; set; }
        public int Item { get; set; }
        public DateTime FecCuo { get; set; }
        public decimal MonCuo { get; set; }
        public string Obs { get; set; }
        public bool Sit { get; set; }
        public string FecPag { get; set; } //
        public decimal MonPag { get; set; }
    }
}
