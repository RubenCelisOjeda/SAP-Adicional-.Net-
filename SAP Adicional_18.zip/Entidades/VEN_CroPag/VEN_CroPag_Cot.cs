﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_CroPag
{
    public class VEN_CroPag_Cot
    {
        public int NumMovCot { get; set; }
        public string NumCot { get; set; }

    }
}
