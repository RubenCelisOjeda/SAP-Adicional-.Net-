﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.VEN_CroPag
{
    public class VEN_CroPag
    {

        public Int64 NumMov { get; set; }
        public string NumCro { get; set; }
        public int Rq { get; set; }
        public string Obs { get; set; }
        public Int16 CodUsu { get; set; }
        public string Moneda { get; set; }

        public List<VEN_CroPag_Cot> CroPagCot { get; set; }
        public List<VEN_CroPag_Det> CroPagDet { get; set; }

        public VEN_CroPag()
        {
            this.CroPagCot = new List<VEN_CroPag_Cot>();
            this.CroPagDet = new List<VEN_CroPag_Det>();
        }
    }
}
