﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Man_Menus
{
    public class Man_UsuMae
    {
        public Int16 Acc { get; set; }
        public int CodUsu { get; set; }
        public string Usu { get; set; }
        public string Cla { get; set; }
        public Int16 UsuAct { get; set; }
    }
}
