﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Man_Menus
{
    public class ManMen_Enc
    {
        //insertar
        public int Codigo { get; set; }
        public string Menu { get; set; }
        public int NivSup { get; set; }
        public string Notacion { get; set; }
        public Int16? Relacion { get; set; }
        public string NotSup { get; set; }
        public string Form { get; set; }

        //actualizar
        public Int16 NivJer { get; set; }
        public Int16 OrdEnSuNiv { get; set; }


    }
}
