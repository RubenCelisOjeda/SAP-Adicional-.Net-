﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_OFC
{
    public class LOG_OFC_Det
    {
        public Int64 NumMov { get; set; }
        public Int16 Item { get; set; }
        public Int16 CodCatGas { get; set; }
        public string CodPro { get; set; }
        public string CodGas { get; set; }
        public Int32 Cta { get; set; }
        public string DesSer { get; set; }
        public Int16 CanSer { get; set; }
        public string CodArt { get; set; }
        public decimal Can { get; set; }
        public decimal PreUni { get; set; }
        public decimal Tot { get; set; }
        public string CodAre { get; set; }
        public string CodSubAre { get; set; }
        public string CodUniNeg { get; set; }
        public int RQ { get; set; }
        public string RutArc { get; set; } 
        public string NomArc { get; set; }
    }
}
