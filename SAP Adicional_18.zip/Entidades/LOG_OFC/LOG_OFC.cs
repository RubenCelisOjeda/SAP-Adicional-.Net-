﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_OFC
{
    public class LOG_OFC
    {
        public Int64 NumMov { get; set; }
        public string NumOFC { get; set; }
        public Int16 CodTipOFC { get; set; }
        public Int16 CodTipSer { get; set; }
        public Int16 EstDoc { get; set; }
        public string DocCur { get; set; }
        public Int32 CodUsu { get; set; }

        public List<LOG_OFC_Det> Det { get; set; }

        public LOG_OFC()
        {
            this.Det = new List<LOG_OFC_Det>();
        }
    }
}
