﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Men_Fav
{
    public class AgrMenu_Enc
    {
        public string CodMen { get; set; }
        public string NomMen { get; set; }
        public Int16 CodUsu { get; set; }

    }
}
