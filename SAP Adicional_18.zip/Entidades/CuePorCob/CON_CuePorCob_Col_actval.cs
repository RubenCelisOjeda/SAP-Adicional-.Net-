﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.CON_CuePorCob
{
    public class CON_CuePorCob_Col_actval
    {
        public int DocNum { get; set; }
        public string Tipo { get; set; }
        public string Enc { get; set; }
        public Int16 CodCat { get; set; }
        public Int16 CodEst { get; set; }
        public Int16 CodSeg { get; set; }
        public bool Cor1 { get; set; }
        public bool Cor2 { get; set; }
        public bool Cor3 { get; set; }
        public string Obs { get; set; }
        public Int16 CodUsu { get; set; }
        public string FicXTrazzo { get; set; }
        public DateTime FecXTrazzo { get; set; }
        public string Ven { get; set; }
        public string Obs2  { get; set; } 
    }
}
