﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.ALM_Ubi_ConStock
{
    public class ALM_Ubi_ConStock_Enc 
    {
        public string CodArtSap { get; set; }
        public string Can { get; set; }
        public char TipMov { get; set; }
        public string Zon { get; set; }
        public string  Rac { get; set; }
        public string Col { get; set; }
        public string Row { get; set; }
        public string CodAlm { get; set; }

        //OtrDat
        public Int16 CodUsu { get; set; }
        public string Obs { get; set; }
        public int? NumDocCon { get; set; } //se cambio de tipo de dato
        public string NumSer { get; set; }
        public string  NumCorr { get; set; }//se cambio de tipo de dato
        public string Rq { get; set; }
        public string FecLle { get; set; }
        public string CodRes { get; set; }//se cambio de tipo de dato
    }
}
