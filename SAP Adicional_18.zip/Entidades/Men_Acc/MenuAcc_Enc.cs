﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Men_Acc
{
    public class MenuAcc_Enc
    {
        //varibles para 
        public Int16 CodUsu { get; set; }
        public Int16 CodUsuRes { get; set; }
        public Int16 CodMen{ get; set; }
        public DateTime FecIng { get; set; }
        public bool SelPer { get; set; }

        public int CodUsuOri { get; set; }
        public int CodUsuDes { get; set; }

    }
}
