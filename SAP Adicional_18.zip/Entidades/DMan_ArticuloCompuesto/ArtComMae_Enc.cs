﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.DMan_ArticuloCompuesto
{
    public class ArtComMae_Enc
    {
        public string Des { get; set; }
        public string Obs { get; set; }
        public int CodArtCom { get; set; }
        public Int16 CodTipArtCom { get; set; }
        public bool Inacivo { get; set; }
        public decimal PorDes { get; set; }
        public string RutaImagen { get; set; }
        public string RutAplicacion { get; set; }
        //public DateTime FecMod { get; set; }
    }
}
