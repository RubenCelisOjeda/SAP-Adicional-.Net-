﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.DMan_ArticuloCompuesto
{
    public class ArtCom_Det
    {
        public string CodArt { get; set; }
        public Int16 Can { get; set; }
        public byte Pri { get; set; }
    }
}
