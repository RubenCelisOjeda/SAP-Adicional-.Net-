﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.DMan_ArticuloCompuesto
{
    public class ArtCom_Enc
    {
        public byte EstReg { get; set; }
        public int Cod { get; set; }
        public string Des { get; set; }
        public string Obs { get; set; }
        public int CodTipArt { get; set; }
        public int Inactivo { get; set; }
        public int CodUsuAct { get; set; }

        public List<ArtCom_Det> ArtComDet { get; set; }

        public ArtCom_Enc()
        {
            this.ArtComDet = new List<ArtCom_Det>();
        }
    }
}
