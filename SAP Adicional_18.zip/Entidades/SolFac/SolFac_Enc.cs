﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SolFac
{
    public class SolFac_Enc
    {
        public Int64 NumMov { get; set; }
        public string  NumSol { get; set; }
        public int Rq { get; set; }
        public string Cli { get; set; }
        public string CodMon { get; set; }
        public Int16 CodUsu { get; set; }
        public string Obs { get; set; }
        public string DocNumBf { get; set; }
        public string NumOti { get; set; }
        public decimal IGV { get; set; }
        public byte SalPenCob { get; set; }
        public decimal MonFac { get; set; }
        public string FacCon { get; set; }
        public string FacDet { get; set; }
        public string DirEnvFac { get; set; }


        public List<SolFac_Det> EncSolFac { get; set; }

        public SolFac_Enc()
        {
            this.EncSolFac = new List<SolFac_Det>();
        }
    }
}
