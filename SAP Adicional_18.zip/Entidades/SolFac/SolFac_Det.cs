﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.SolFac
{
   public  class SolFac_Det
    {
        public Int64 NumMov { get; set; }
        public Int16 Item { get; set; }
        public int DocNum { get; set; }
        public int LineNum { get; set; }
        public string CodArt { get; set; }
        public decimal CanORV { get; set; }
        public decimal CanSol { get; set; }
        public decimal PreUni { get; set; }
        public decimal TotLin { get; set; }
        public decimal PorDes { get; set; }
        public string CodAlm { get; set; }
    }
}
