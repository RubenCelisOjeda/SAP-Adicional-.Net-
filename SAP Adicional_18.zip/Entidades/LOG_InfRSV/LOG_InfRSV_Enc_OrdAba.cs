﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_InfRSV
{
    public class LOG_InfRSV_Enc_OrdAba
    {
        public string CodArt { get; set; }
        public decimal Can { get; set; }
        public string OrdCom { get; set; }
        public string Via { get; set; }
        public string FecEntPro { get; set; }
        public string FecEmb { get; set; }
        public string FecLlePue { get; set; }
        public string FecAprIng { get; set; }
        public int CodUsu { get; set; }

        //act eli
        public int Rq { get; set; }
        public string Cat { get; set; }
    }
}
