﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_InfRSV
{
    public class LOG_InfRSV_Enc_Est
    {
        public int DocNum { get; set; }
        public string Ingope { get; set; }
        public string Dis { get; set; }
        public string Est { get; set; }
        public string ConOfv { get; set; }
        public string FecUltReu { get; set; }
        public Int16 CodUsu { get; set; }
        public string AdmPed { get; set; }
        public string AprIns { get; set; }
        public string Obs { get; set; }
        public string Etp { get; set; }





    }
}
