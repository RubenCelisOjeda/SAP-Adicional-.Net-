﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.LOG_InfRSV
{
    public class LOG_InfRSV_DetPed
    {
        public int Rq { get; set; }
        public string CodArt { get; set; }
        public int Can { get; set; }
        public string OrdCom { get; set; }
        public Int16 CodUsu { get; set; }
        public string Cat { get; set; }

    }
}
